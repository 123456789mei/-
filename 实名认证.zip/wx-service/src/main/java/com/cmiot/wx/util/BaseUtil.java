package com.cmiot.wx.util;

/**
 * 存放微信接口地址及常量
 */
public class BaseUtil {

    private BaseUtil() {

    }

    //数据库取值常量
    public static final String WX_APPID = "WX.APPID";
    public static final String WX_APPSECRET = "WX.APPSECRET";

    public static final String WX_PERSON_TRIGGER = "WX_PERSON_TRIGGER";

    public static final String WX_UNITE_PAY_URL = "WX_UNITE_PAY_URL";

    /**实名登记图片存放目录*/
    public static final String REAL_NAME_REGISTER_LOCAL = "REAL_NAME_REGISTER_LOCAL";

    /**CT卡实名登记并发数*/
    public static final String CT_REALNAME_CALL_THREAD_MAX_LIMIT = "CT_REALNAME_CALL_THREAD_MAX_LIMIT";
}
