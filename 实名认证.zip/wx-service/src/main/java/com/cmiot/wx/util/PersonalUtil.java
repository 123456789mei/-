package com.cmiot.wx.util;

import com.alibaba.fastjson.JSON;
import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.cache.impl.CacheManager;
import com.cmiot.commons.common.utils.HttpRequestClient;
import com.cmiot.commons.log.ILog;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.wx.api.client.WxApiClient;
import com.cmiot.wx.config.ExternalPlatConfig;
import com.cmiot.wx.constant.CommomConstant;
import com.cmiot.wx.constant.PersonalConstant;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * @author xiapeicheng
 * @date 2019/1/9 11:00
 * @email xiapeicheng@cmiot.chinamobile.com
 */
@Component
public class PersonalUtil {

    private static Logger logger = LoggerFactory.getLogger(PersonalUtil.class);

    @Autowired
    ICache cache;

    @Autowired
    ILog iLog;

    @Autowired
    WxApiClient wxApiClient;

    @Autowired
    HttpRequestClient httpRequestClient;

    @Autowired
    ExternalPlatConfig platConfig;

    private static final String WX_CACHE_KEY_PRE = "WECHAT_NET_";

    /**
     * 设置或更新 微信用户登陆时间
     * */
    public void setLoginCache(String openId){
        SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        iLog.info(logger, null, null, "设置个人用户登录时间 key {}, value {}", PersonalConstant.PERSONAL_LOGIN_TIME_PREFIX +openId, simpleFormat.format(System.currentTimeMillis()));
        cache.put(CacheManager.PublicNameSpace.USERAUTH,PersonalConstant.PERSONAL_LOGIN_TIME_PREFIX +openId,simpleFormat.format(System.currentTimeMillis()),-1);
    }

    public void setLogoutCache(String openId){
        iLog.info(logger, null, null, "个人用户退出登录");
        cache.put(CacheManager.PublicNameSpace.USERAUTH, PersonalConstant.PERSONAL_LOGIN_TIME_PREFIX +openId, CommomConstant.PUBLIC_LOGOUT_STRING);
    }

    public void removeLoginInfo(String phone, String openId){
        cache.remove(CacheManager.PublicNameSpace.USERAUTH, WX_CACHE_KEY_PRE + openId);
        cache.remove(CacheManager.PublicNameSpace.USERAUTH, WX_CACHE_KEY_PRE + phone);
    }

    /**
     * 判断是否是从新的公众号登录
     * @param openId
     * @return
     */
    public boolean fromNewWeChat(String openId){
        Map<String, String> paramsMap = new HashMap<>(1);
        paramsMap.put("openId", openId);
        ResponseVo responseVo = wxApiClient.checkOpenId(paramsMap);
        if (responseVo.isSuccess()){
            if ((int)responseVo.getData() == 0){
                String cachePhone = cache.get(CacheManager.PublicNameSpace.USERAUTH, "LOGINRECORD_" + openId);
                if(StringUtils.isNotBlank(cachePhone)&&!"null".equals(cachePhone)){
                    logger.info("openId:{}在缓存有登录记录,cachePhone:{}",openId,cachePhone);
                    return false;
                }
                return true;
            }
            iLog.info(logger, null, null, "该微信号已绑定过账号");
            return false;
        }
        iLog.error(logger, null, null, "检查openId出错,请检查参数,openId:{}", openId);
        return false;
    }

    /**
     * 微信公众号登录是否存在账号
     * @param phone
     * @return
     */
    public String existAccount(String phone){
        Map<String, String> paramsMap = new HashMap<>(1);
        paramsMap.put("phone", phone);
        ResponseVo responseVo = wxApiClient.checkWeChatAccountExist(paramsMap);
        if (responseVo.isSuccess()){
            int count = (int) responseVo.getData();
            if (count == 1){
                iLog.info(logger, null, null, "微信公众号账号已存在");
                return "1";
            }else if (count == 0){
                iLog.info(logger, null, null, "微信公众号账号未注册");
                return "0";
            }else {
                iLog.error(logger, null, null, "数据库存在重复微信公众号账号，count:{},请检查数据库", count, phone);
                return "2";
            }
        }
        iLog.error(logger, null, null, "检查账号是否存在出错,请检查参数,phone:{}", phone);
        return "3";
    }

    /**
     * 通过手机号获取该手机号对应的openId(数据库)
     * @param phone
     * @return
     */
    public String getOpenIdByPhone(String phone){
        Map<String, String> paramsMap = new HashMap<>(1);
        paramsMap.put("phone", phone);
        ResponseVo responseVo = wxApiClient.getOpenIdByPhone(paramsMap);
        if (responseVo.isSuccess()){
            String openId = (String) responseVo.getData();
            if (StringUtils.isEmpty(openId)){
                return "";
            }
            iLog.info(logger, null, null, "获取手机{}对应的openId{}", phone, openId);
            return openId;
        }
        iLog.error(logger, null, null, "获取openId出错,请检查参数,phone:{}", phone);
        return "";
    }

    /**
     * 保存或更新phone与openId映射关系 该openId为phone最后登录的openId(单点登录验证)
     * @param phone
     * @param openId
     */
    public void setOpenIdByPhone(String phone, String openId){
        cache.put(CacheManager.PublicNameSpace.USERAUTH, WX_CACHE_KEY_PRE + phone, openId, -1);
        iLog.info(logger, null, null, "phone与openId映射关系已保存,phone:{},openId{}", phone, openId);
    }

    /**
     * 从缓存中获取phone最后登录的openId（单点登录验证）
     * @param phone
     * @return
     */
    public String getLastOpenIdInCache(String phone){
        String openId = cache.get(CacheManager.PublicNameSpace.USERAUTH, WX_CACHE_KEY_PRE + phone);
        iLog.info(logger, null, null, "从缓存中获取到openId：{}", openId);
        return openId;
    }

    /**
     * 从缓存或微信服务器获取openId(从菜单按钮进入)
     * @param code
     * @return
     */
    public String getOpenId(String code){
        String openId = getOpenIdByCode(code);
        if (openId == null || StringUtils.isEmpty(openId)){
            openId = getOpenIdByWeChat(code);
        }
        if(openId != null && !StringUtils.isEmpty(openId)){
            //openId 不为空的时候才缓存
            setOpenIdByCode(code, openId);
        }
        logger.info("utils getOpenId,code is:[{}],openId is:[{}]",code,openId);
        return openId;
    }

    /**
     * openId放入缓存，有效时间5分钟
     * @param code key
     * @param openId value
     */
    public void setOpenIdByCode(String code, String openId){
        cache.put(CacheManager.PublicNameSpace.TEMP, WX_CACHE_KEY_PRE + code, openId, 300);
        iLog.info(logger, null, null, "code与openId映射关系已保存，有效时间5分钟,code:{},openId{}", code, openId);
    }

    /**
     * 从缓存中获取openId
     * @param code key
     * @return
     */
    public String getOpenIdByCode(String code){
        String openId = cache.get(CacheManager.PublicNameSpace.TEMP, WX_CACHE_KEY_PRE + code);
        iLog.info(logger, null, null, "从缓存中获取到openId：{}", openId);
        return openId;
    }

    /**
     * 从微信服务器获取openId
     * @param code
     * @return
     */
    public String getOpenIdByWeChat(String code){
        String openidUrl = platConfig.getWxAccessTokenByCodeUrl();
        String appId = cache.getSysParams("WX.APPID", null);
        String secret = cache.getSysParams("WX.APPSECRET", null);

        String jsonStr = httpRequestClient.get(null, openidUrl.replace("APPID", appId).replace("SECRET", secret).replace("CODE", code));
        Map jsonMap = (Map) JSON.parse(jsonStr);
        String openid = (String) jsonMap.get("openid");
        if (StringUtils.isEmpty(openid)) {
            return null;
        }
        iLog.info(logger, null, null, "从微信服务器获取到openId：{}", openid);
        return openid;
    }

    /**
     * 检查是否需要重新登录 1：登录时间过期 2：用户注销登录 3：该账号在别处登录
     * @param openId
     * @return true:需要重新登录 false:不需要重新登录
     */
    public boolean checkUserLogin(String openId){
        String lastLoginTime = cache.get(CacheManager.PublicNameSpace.USERAUTH,PersonalConstant.PERSONAL_LOGIN_TIME_PREFIX+openId);
        Integer loginExpiredTime = Integer.valueOf(cache.getSysParams("WX_LOGIN_EXPIRED_TIME", "30"));
        //注销登录的情况
        if (CommomConstant.PUBLIC_LOGOUT_STRING.equals(lastLoginTime)){
            iLog.info(logger, null, null, "用户已注销登录，重新登录");
            return true;
        }

        //登录时间过期
        if(getTimeDiff(lastLoginTime) > loginExpiredTime){
            iLog.info(logger, null, null, "用户登录时间过期，重新登录");
            return true;
        }

        //该账号是否在别处登录
        return alreadyLoginOtherWeChat(openId);
    }

    /**
     * 判断该微信号上次登录的账号是否已在的微信号登录过
     * 根据openId获取数据库中最新的手机号（获取的手机号不一定是实际最后登录的的，账号在别处登录后会更新账号对应openId openId和电话的存储关系是1:n）
     * 再利用openId在缓存中去查该openId最后登录的手机号，对比手机号是否相等 openId和电话的存储关系是1:1
     * @param openId
     * @return true:已经登录过其他微信号 false:没有登录过其他微信号
     */
    public boolean alreadyLoginOtherWeChat(String openId){
        String phoneDb = getPhoneFomeDb(openId);
        String phoneCache = getPhoneFromCache(openId);
        if (StringUtils.isEmpty(phoneCache) || "null".equals(phoneCache)){
            //如果缓存没有，第一次登录 即创建账号后未跳转到首页直接退出
            return false;
        }
        if (phoneDb.equals(phoneCache)){
            return false;
        }
        iLog.info(logger, null, null, "用户在其他微信号登录过，重新登录");
        return true;
    }

    /**
     * 从缓存中获取电话 电话号码有可能在其他微信号登录过
     * @param openId
     * @return phone
     */
    public String getPhoneFromCache(String openId){
        //账号为null代表第一次登录 特殊情况
        String phone = cache.get(CacheManager.PublicNameSpace.USERAUTH, WX_CACHE_KEY_PRE + openId);
        logger.info("openId{}最后登录的手机号在缓存中为{}",openId, phone);
        return phone;
    }

    public String getPhoneFomeDb(String openId){
        String phoneDb = "";
        Map<String, String> paramsMap = new HashMap<>(1);
        paramsMap.put("openId", openId);
        ResponseVo responseVo = wxApiClient.getPersonUserPhoneByOpenId(paramsMap);
        if (responseVo.isSuccess()){
            phoneDb = (String) responseVo.getData();
        }
        logger.info("openId{}最后登录的手机号在数据库中为{}",openId, phoneDb);
        return phoneDb;
    }

    /**
     * 将openId和phone的对应关系放入缓存 即该微信号最后登录的手机号 1:1
     * @param openId
     * @param phone
     */
    public void setPhoneInCache(String openId, String phone){
        cache.put(CacheManager.PublicNameSpace.USERAUTH, WX_CACHE_KEY_PRE + openId, phone, -1);
        iLog.info(logger, null, null, "设置该openId{}最后登录的账号为：{}", openId, phone);
    }

    /**
     * 获取时间天数差值 传入起始时间字符串
     * */
    private int getTimeDiff(String beginTime){
        if (StringUtils.isEmpty(beginTime)){
            //为空代表 创建账号后未跳转到首页直接退出
            return 0;
        }
        SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String toDate = simpleFormat.format(System.currentTimeMillis());
        long from = 0;
        int days =0;
        long to =0;
        try {
            from = simpleFormat.parse(beginTime).getTime();
            to = simpleFormat.parse(toDate).getTime();
            days = (int) ((to - from)/(1000 * 60 * 60 * 24));
        } catch (ParseException e) {
            iLog.error(logger,null,null,"获取登录时间差值错误 :"+e);
        }
        return days;
    }
}
