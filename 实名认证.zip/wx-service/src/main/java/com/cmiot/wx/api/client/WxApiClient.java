package com.cmiot.wx.api.client;

import com.cmiot.commons.common.constants.RequestConstants;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.commons.response.vo.PageResultVo;
import com.cmiot.wx.api.degraded.WxApiImpl;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@FeignClient(value = "wx-api-service", fallback = WxApiImpl.class)
public interface WxApiClient {

    /**
     * 微信账户注册
     */
    @RequestMapping(value = "/user/register")
    ResponseVo register(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                        @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 微信账户注册
     */
    @RequestMapping(value = "/person/login/register")
    ResponseVo personRegister(Map paramMap);

    /**
     * 微信用户类型修改
     */
    @RequestMapping(value = "/user/updateType")
    ResponseVo updateType(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                          @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    @RequestMapping(value = "/personUser/invalidAllAccount")
    ResponseVo invalidAllAccount(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                 @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    @RequestMapping(value = "/personUser/logout")
    ResponseVo logout(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                      @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 获取微信注册账户信息
     */
    @RequestMapping(value = "/user/getWxUserInfo")
    ResponseVo getWxUserInfo(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                             @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 获取微信注册账户信息
     */
    @RequestMapping(value = "/personUser/getWxUserInfo")
    ResponseVo getWxPersonUserInfo(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                   @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 检查是否存在openId
     *
     * @param paramMap openId
     * @return
     */
    @RequestMapping(value = "/person/login/checkOpenId")
    ResponseVo checkOpenId(Map paramMap);

    /**
     * 检查是否存在账号phone
     *
     * @param paramMap phone
     * @return
     */
    @RequestMapping(value = "/person/login/checkWeChatAccountExist")
    ResponseVo checkWeChatAccountExist(Map paramMap);


    /**
     * 获得phone对应的openId
     *
     * @param paramMap phone
     * @return
     */
    @RequestMapping(value = "/person/login/getOpenIdByPhone")
    ResponseVo getOpenIdByPhone(Map paramMap);

    /**
     * 更新phone对应的openId
     *
     * @param paramMap phone
     * @return
     */
    @RequestMapping(value = "/person/login/updateOpenId")
    ResponseVo updateOpenId(Map paramMap);

    /**
     * 微信账户绑定EC账户
     */
    @RequestMapping(value = "/user/bind")
    ResponseVo bind(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                    @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 获取微信账户绑定的EC账户列表
     */
    @RequestMapping(value = "/user/accountlist")
    ResponseVo accountlist(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                           @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 移除微信账户的全部 EC账户绑定关系
     */
    @RequestMapping(value = "/user/deleteAllAccount")
    ResponseVo deleteAllAccount(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 移除微信账户的EC账户绑定关系
     */
    @RequestMapping(value = "/user/deleteAccount")
    ResponseVo deleteAccount(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                             @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 获取微信账户的卡信息查询记录列表
     */
    @RequestMapping(value = "/history/getSearchList")
    ResponseVo getSearchList(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                             @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 保存微信账户的查询记录
     */
    @RequestMapping(value = "/history/saveHistory")
    ResponseVo saveHistory(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                           @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 获取卡余额信息
     */
    @RequestMapping(value = "/account/getBalance")
    ResponseVo getBalance(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                          @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    @RequestMapping(value = "/account/getBalanceFromCT")
    ResponseVo getBalanceFromCT(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 获取卡余量信息，获取卡套餐信息
     */
    @RequestMapping(value = "/account/getSimFlow")
    ResponseVo getSimFlow(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                          @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    @RequestMapping(value = "/account/getSimFlowFromCT")
    ResponseVo getSimFlowFromCT(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 激活CT的物联卡
     *
     * @param paramMap
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping(value = "/personUser/activateCardFromCT")
    ResponseVo activateCardFromCT(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                  @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 向CT发起用户身份信息实名认证
     *
     * @param paramMap
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping(value = "/register/realNameRegist")
    ResponseVo realNameRegist(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                              @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 校验用户输入信息是否和账号实名信息一致
     *
     * @param paramMap
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping(value = "/register/isUserIdentityInfo")
    ResponseVo isUserIdentityInfo(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                  @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 查询物联卡是否已完成实名登记
     *
     * @param paramMap
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping(value = "/register/getSuccessRegisterInfo")
    ResponseVo getSuccessRegisterInfo(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                      @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 实名认证登记信息保存
     *
     * @param paramMap
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping(value = "/register/saveRealNameRegInfo")
    ResponseVo saveRealNameRegInfo(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                   @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 获取卡套餐信息
     */
    @RequestMapping(value = "/account/productList")
    ResponseVo productList(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                           @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    @RequestMapping(value = "/account/productListFromCT")
    ResponseVo productListFromCT(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                 @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    @RequestMapping(value = "/account/getAccountInfo")
    ResponseVo getAccountInfo(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                              @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 发送验证码
     */
    @RequestMapping(value = "/user/getAuthCode")
    ResponseVo getAuthCode(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                           @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 校验验证码
     */
    @RequestMapping(value = "/user/validateCode")
    ResponseVo validateCode(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                            @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    @RequestMapping(value = "/personUser/getMsisdnList")
    ResponseVo getMsisdnList(@RequestBody Map map , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                             @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    @RequestMapping(value = "/user/rechargeOrder")
    ResponseVo rechargeOrder(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                             @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 暂未使用
     *
     * @param paramMap
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping(value = "/user/chargePayment")
    ResponseVo chargePayment(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                             @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    @RequestMapping("/user/getUserPhone")
    ResponseVo getUserPhoneByOpenId(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                    @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    @RequestMapping("/person/login/getUserPhone")
    ResponseVo getPersonUserPhoneByOpenId(Map paramMap);

    /**
     * msisdn与iccid绑定
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping("/personUser/msisdnBind")
    ResponseVo msisdnBind(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                          @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * msisdn与iccid自动绑定
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping("/personUser/msisdnAutoBind")
    ResponseVo msisdnAutoBind(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                              @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * msisdn 与 iccid 校验
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping("/personUser/checkMsisdnIccid")
    ResponseVo checkMsisdnIccid(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    @RequestMapping("/person/login/sendSmsCode")
    ResponseVo sendSmsCode(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                           @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    @RequestMapping("/person/login/validateCode")
    ResponseVo validateCodePersonal(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                    @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    @RequestMapping("/person/login/updateOperateTime")
    ResponseVo updateOperateTime(Map params);

    /**
     * 获取物联网卡基本信息
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping("/personUser/getMsisdnInfo")
    ResponseVo getMsisdnInfo(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                             @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 修改备注
     *
     * @param map
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping("/personUser/modifyRemark")
    ResponseVo modifyRemark(Map map , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo , @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 置顶
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping("/personUser/setTop")
    ResponseVo setTop(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo , @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 解绑物联卡
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping("/personUser/unbindMsisdn")
    ResponseVo unbindMsisdn(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo , @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 获取物联网卡用量信息
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping("/personUser/getSimFlowInfo")
    ResponseVo getSimFlowInfo(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                              @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 获取物联网卡套餐信息
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping("/personUser/getProductInfo")
    ResponseVo getProductInfo(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                              @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * CT卡充值
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping("/personUser/chargeOfCT")
    ResponseVo chargeOfCT(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo , @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);


    @RequestMapping("/person/login/getUserIdByPhone")
    ResponseVo getUserIdByPhone(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    @RequestMapping("/personUser/getVerifiedStatus")
    ResponseVo getVerifiedStatus(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                 @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 通过手机号获取实名认证的URL
     */
    @RequestMapping(value = "/personUser/getRealNameAuthURL")
    ResponseVo getRealNameAuthURL(Map<String, String> paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                  @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);


    /**
     * 接收认证结果
     */
    @RequestMapping(value = "/personUser/receiveAuditResult")
    String receiveAuditResult(Map<String, String> paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                              @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 接收加密秘钥
     */
    @RequestMapping(value = "/personUser/receiveDesKey")
    String receiveDesKey(Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                         @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 更新登录日志
     *
     * @param params
     * @return
     */
    @RequestMapping("/person/login/setLoginLog")
    ResponseVo setLoginLog(Map params);


    /**
     * 微信公众号 - 查询物联卡余额（新）
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/personUser/queryBalance")
    Map queryBalance(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                     @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken) throws Exception;

    /**
     * 微信公众号 - 查询物联卡开关机状态（新）
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/personUser/queryNetStatus")
    Map queryNetStatus(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                       @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken) throws Exception;

    /**
     * 微信公众号 - 查询物联卡列表（新）
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/personUser/queryMsisdnList")
    PageResultVo queryMsisdnList(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                 @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken) throws Exception;

    /**
     * 微信公众号 - 查询物联卡列表（新）
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/personUser/queryUseTotal")
    Map queryUseTotal(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                      @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken) throws Exception;

    /**
     * 微信公众号 - 查询物联卡状态（新）
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/personUser/queryStatus")
    Map queryStatus(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                    @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken) throws Exception;

    /**
     * 微信公众号 - 充值操作记录（PB）
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/personUser/saveChargeLogOfPB")
    ResponseVo saveChargeLogOfPB(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                 @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken) throws Exception;

    /**
     * /**
     * 微信公众号 - 个人账户验证（CT）
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/personUser/checkIndividualAccount")
    ResponseVo checkIndividualAccount(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                      @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken) throws Exception;


    /**
     * 微信公众号 - 实名登记结果短信下发
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/personUser/sendRegisterResult")
    ResponseVo sendRegisterResult(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                  @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 同步该账号实名认证的身份证下有效的非销户物联卡列表
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping(value = "/personUser/syncMsisdnList")
    Map syncMsisdnList(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                       @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 同步该账号实名认证的身份证下有效的非销户物联卡列表
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping(value = "/personUser/saveBusinessHitLog")
    ResponseVo saveBusinessHitLog(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                                  @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 用业务流水号获取实名认证结果
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping(value = "/personUser/getRealNameAuthResult")
    Map getRealNameAuthResult(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                              @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 查询行业信息
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping(value = "/personUser/getDicts")
    ResponseVo getDicts(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                            @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 保存用户反馈信息
     *
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping(value = "/personUser/saveFeedback")
    ResponseVo saveFeedback(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                            @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 查询CT集团物联卡生命周期分布
     * */
    @RequestMapping(value = "/CT/group/CountByStatus")
    ResponseVo countByStatus(@RequestBody Map params, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                             @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 查询CT集团物联卡生命周期分布
     * */
    @RequestMapping(value = "/CT/group/getStatusByMsisdn")
    ResponseVo getStatusByMsisdn(@RequestParam("msisdn") String msisdn, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 查询CT集团物联卡余量列表
     * msisdn
     * beId
     * custId
     * */
    @RequestMapping(value = "/CT/group/getSimFlowCT")
    ResponseVo getSimFlowCT(@RequestBody Map param, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 查询CT集团物联卡余额信息
     * msisdn
     * beId
     * custId
     * */
    @RequestMapping(value = "/CT/group/getBalanceCT")
    ResponseVo getBalanceCT(@RequestBody Map param, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 查询PB物联卡订购信息
     * msisdn
     * prodInstId
     * */
    @RequestMapping(value = "/PB/group/getProductInfo")
    ResponseVo getProductInfoByInstId(@RequestBody Map param, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 重庆个人业务物联卡列表查询
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping(value = "/personUser/getCQMsisdns")
    Map getCQMsisdns(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                       @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 查询微信自动回复信息
     * */
    @RequestMapping(value = "/wxmanage/getAutoMsg",method = RequestMethod.POST)
    ResponseVo getAutoMsg(@RequestBody Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 查询微信自动回复图文列表
     * */
    @RequestMapping(value = "/wxmanage/getNewsList")
    ResponseVo getNewsList(@RequestParam("id") String id , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);


    /**
     * 获取物联网卡基本信息
     * 不鉴权
     * @param params
     * @param transNo
     * @param accessToken
     * @return
     */
    @RequestMapping("/external/getMsisdnInfo")
    ResponseVo cardInfo(Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo ,
                             @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);
    /**
     * 安徽PB卡实名认证流程查询
     * */
    @RequestMapping(value = "/pbRegister/checkMsisdnFlow")
    ResponseVo checkMsisdnFlow(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 记录日志
     * */
    @RequestMapping(value = "/wxlog/insertWxLog",method = RequestMethod.POST)
    ResponseVo insertWxLog(@RequestBody Map params , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 安徽PB卡实名认证-一证五号校验
     * */
    @RequestMapping(value = "/pbRegister/idCardCheck")
    ResponseVo idCardCheck(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 安徽PB卡实名认证-回调流水校验
     * */
    @RequestMapping(value = "/pbRegister/orderNumCheck")
    ResponseVo orderNumCheck(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 隐私协议查询
     * */
    @RequestMapping(value = "/personUser/queryProtocolApi")
    ResponseVo queryProtocolApi(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 隐私协议新增
     * */
    @RequestMapping(value = "/personUser/insertProtocolApi")
    ResponseVo insertProtocolApi(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 公众号ct实名认证-卡激活弹窗判断
     * */
    @RequestMapping(value = "/register/queryBbcStatus")
    ResponseVo queryBbcStatusApi(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 公众号ct实名认证-获取实名登记url
     * */
    @RequestMapping(value = "/register/registerUrl")
    ResponseVo startCtRegisterApi(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);


    /**
     * 河南PB卡实名认证流程查询
     * */
    @RequestMapping(value = "/pbRegister/checkMsisdnFlowHN")
    ResponseVo checkMsisdnFlowHN(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 河南PB卡实名认证-一证五号校验
     * */
    @RequestMapping(value = "/pbRegister/idCardCheckHN")
    ResponseVo idCardCheckHN(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 北京PB卡实名认证流程查询
     * */
    @RequestMapping(value = "/pbRegister/checkMsisdnFlowBJ")
    ResponseVo checkMsisdnFlowBJ(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 北京PB卡实名认证-一证五号校验
     * */
    @RequestMapping(value = "/pbRegister/idCardCheckBJ")
    ResponseVo idCardCheckBJ(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 天津PB卡实名认证流程查询
     * */
    @RequestMapping(value = "/pbRegister/checkMsisdnFlowTJ")
    ResponseVo checkMsisdnFlowTJ(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 天津PB卡实名认证-一证五号校验
     * */
    @RequestMapping(value = "/pbRegister/idCardCheckTJ")
    ResponseVo idCardCheckTJ(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 江苏PB卡实名认证流程查询
     * */
    @RequestMapping(value = "/pbRegister/checkMsisdnFlowJS")
    ResponseVo checkMsisdnFlowJS(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 江苏PB卡实名认证-一证五号校验
     * */
    @RequestMapping(value = "/pbRegister/idCardCheckJS")
    ResponseVo idCardCheckJS(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * PB卡实名认证-限制重复入库
     * */
    @RequestMapping(value = "/pbRegister/querySameOrderPb")
    ResponseVo querySameOrderPb(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 埋点统计
     * */
    @RequestMapping(value = "/register/innerStatis")
    ResponseVo innerStatis(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    @RequestMapping(value = "/personUser/deleteOpenIdByPhone")
    ResponseVo deleteOpenIdByPhone(@RequestBody Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    @RequestMapping(value = "/register/queryCardRegisterList")
    ResponseVo queryCardRegisterList(@RequestBody Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    @RequestMapping(value = "/register/queryCustNameByAppId")
    ResponseVo queryCustNameByAppId(@RequestBody Map paramMap , @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 上海PB卡实名认证-一证五号校验
     * */
    @RequestMapping(value = "/pbRegister/checkMsisdnFlowSH")
    ResponseVo checkMsisdnFlowSH(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 海南PB卡实名认证流程查询
     * */
    @RequestMapping(value = "/pbRegister/checkMsisdnFlowHainan")
    ResponseVo checkMsisdnFlowHainan(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 海南PB卡实名认证-一证五号校验
     * */
    @RequestMapping(value = "/pbRegister/idCardCheckHainan")
    ResponseVo idCardCheckHainan(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);
}
