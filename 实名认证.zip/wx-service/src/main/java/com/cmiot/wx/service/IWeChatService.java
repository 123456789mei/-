package com.cmiot.wx.service;

import com.cmiot.commons.response.ResponseVo;

/**
 * company ustcinfo.com
 * description IWeChatService
 * date 2018/2/28
 *
 * @author yang.dehao@ustcinfo.com
 * @version
 */
public interface IWeChatService {

    ResponseVo getAppIdAndSecret(String transNo);

    ResponseVo personTrigger(String transNo);

    ResponseVo getUnitePayUrl(String transNo);

    ResponseVo   getSysParamById(String transNo, String paramId);

}
