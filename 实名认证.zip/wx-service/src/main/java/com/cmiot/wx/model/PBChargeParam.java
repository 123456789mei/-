package com.cmiot.wx.model;

import com.cmiot.wx.constant.CommomConstant;

public class PBChargeParam {

    public PBChargeParam(){
        this.PaymentType = CommomConstant.PAY_TYPE_WX;
        this.WeiXinAppId = "";
    }

    /**
     * 物联卡号
     * */
    private String IDValue;

    /**
     * 支付金额
     * */
    private String Payment;

    /**
     * 支付方式
     * */
    private String PaymentType;

    /**
     * 支付公众号ID
     * */
    private String WeiXinAppId;

    /**
     * 卡号归属省份
     * */
    private String beID;

    /**
     * 支付结果跳转地址
     * */
    private String ReturnURL;

    public String getIDValue() {
        return IDValue;
    }

    public void setIDValue(String IDValue) {
        this.IDValue = IDValue;
    }

    public String getPayment() {
        return Payment;
    }

    public void setPayment(String payment) {
        Payment = payment;
    }

    public String getPaymentType() {
        return PaymentType;
    }

    public void setPaymentType(String paymentType) {
        PaymentType = paymentType;
    }

    public String getWeiXinAppId() {
        return WeiXinAppId;
    }

    public void setWeiXinAppId(String weiXinAppId) {
        WeiXinAppId = weiXinAppId;
    }

    public String getBeId() {
        return beID;
    }

    public void setBeId(String beId) {
        this.beID = beId;
    }

    public String getReturnURL() {
        return ReturnURL;
    }

    public void setReturnURL(String returnURL) {
        ReturnURL = returnURL;
    }

    @Override
    public String toString() {
        return "{" +
                "IDValue='" + IDValue + '\'' +
                ", Payment='" + Payment + '\'' +
                ", beID='" + beID + '\'' +
                ", ReturnURL='" + ReturnURL + '\'' +
                ", PaymentType='" + PaymentType + '\'' +
                ", WeiXinAppId='" + WeiXinAppId + '\'' +
                '}';
    }
}
