package com.cmiot.wx.controller;

import com.alibaba.fastjson.JSONArray;
import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.cache.impl.CacheManager;
import com.cmiot.commons.common.constants.ParamConstants;
import com.cmiot.commons.common.utils.MapParamChecker;
import com.cmiot.commons.response.ResponseCode;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.commons.rest.RestBase;
import com.cmiot.wx.api.client.WxApiClient;
import com.cmiot.wx.constant.CommomConstant;
import com.cmiot.wx.constant.ResponseCodeConstant;
import com.cmiot.wx.service.IWeChatService;
import com.cmiot.wx.util.BaseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
@RequestMapping("realnameH5")
public class RealNameH5Controller extends RestBase {

    private static Logger logger = LoggerFactory.getLogger(RealNameH5Controller.class);

    @Autowired
    ICache cache;

    @Autowired
    HttpServletRequest request;

    @Autowired
    WxApiClient apiClient;

    @Autowired
    PersonApiController personApiController;

    @Autowired
    WxApiClient wxApiClient;

    @Autowired
    IWeChatService weChatService;

    private static final String[] ACCESS_FILE_TYPE = new String[]{"jpg", "jpeg"};

    private static final int PAGE_EXPIRED_TIME = 60 * 20; //页面过期时间 20min
    private static final String AUTH_ID_VALUE = "realnameH5";
    private static final int MAX_FILE_SIZE = 10;

    private void setAuthId(Model model) {
        String authId = String.valueOf(UUID.randomUUID());
        //缓存5分钟失效
        cache.put(CacheManager.PublicNameSpace.TEMP, authId, AUTH_ID_VALUE, PAGE_EXPIRED_TIME);
        model.addAttribute("AUTHID", authId);
    }

    /**
     * 因为临时需求，添加访问渠道信息，非法的访问渠道拒绝服务
     * */
    @RequestMapping("stepOne")
    public String stepOne(Model model, HttpServletRequest request) {
        setAuthId(model);
        String channelId = request.getParameter("channelId");
        String beId = request.getParameter(ParamConstants.CCMP_BEID);
        String msisdn = request.getParameter(ParamConstants.MSISDN);
        String iccid = request.getParameter("iccid");
        String msgId = request.getParameter("msgId");//流控的消息标识
        String channel = cache.getSysParams("REAL_NAME_CHANNELS","");
        String phone=request.getParameter("phone");
        String orderNo=request.getParameter("orderNo");
        String idCard=request.getParameter("idCard");
        //TODO 请求未携带接入渠道直接无权访问
        if(StringUtils.isEmpty(channelId) || StringUtils.isEmpty(channel)){
            logger.info("非法的访问，未携带接入渠道编码");
            return "/authError";
        }
        List<String> channelArray = Arrays.asList(channel.split(","));
        if(channelArray.size() == 0 || !channelArray.contains(channelId)){
            logger.info("不合法的渠道访问，channel is:[{}]",channelId);
            return "/authError";
        }
        Map paramMap=new HashMap();
        paramMap.put("appId",channelId);
        ResponseVo vo = wxApiClient.queryCustNameByAppId(paramMap, getTransNo(request));
        if(vo.isSuccess()&&vo.getData()!=null&&!"".equals(vo.getData())){
            model.addAttribute("h5CustName",vo.getData());
        }else {
            model.addAttribute("h5CustName","企业");
        }
        logger.info("{}h5接入参数校验,msisdn:{},iccid:{},phone:{},custList:{},orderNo:{},idCard:{}",channelId,msisdn,iccid,phone,vo.getData(),orderNo,idCard);
        if(!StringUtils.isEmpty(msisdn)){
            model.addAttribute(ParamConstants.MSISDN,msisdn);
        }
        if(!StringUtils.isEmpty(phone)){
            model.addAttribute("phone",phone);
        }
        if(!StringUtils.isEmpty(iccid)){
            model.addAttribute("iccid",iccid);
        }
        if(!StringUtils.isEmpty(msgId)){
            model.addAttribute("msgId",msgId);
        }
        if(!StringUtils.isEmpty(orderNo)){
            model.addAttribute("orderNo",orderNo);
        }
        if(!StringUtils.isEmpty(idCard)){
            model.addAttribute("idCard",idCard);
        }
        if(!StringUtils.isEmpty(beId)){
            //TODO 保存省公司接入的省份ID
            cache.put(CacheManager.PublicNameSpace.TEMP,AUTH_ID_VALUE.concat("_").concat(msgId),beId,60*60*5);//5小时过期
        }
        model.addAttribute("channelId",channelId);
        return "/realname/stepOne";
    }

    @RequestMapping("stepTwo")
    public String stepTwo(Model model, HttpServletRequest request) {
        String isRealNameRegisted = request.getParameter("isRealNameRegisted");
        String cardBelong = request.getParameter("cardBelong");
        String imsi = request.getParameter("imsi");
        String beId = request.getParameter("beId");
        String phone = request.getParameter("phone");
        String iccid = request.getParameter("iccid");
        String msisdn = request.getParameter("cardNum");
        String custId = request.getParameter("custId");
        String status = request.getParameter("status");
        String channelId = request.getParameter("channelId");//4.300.8.5.1添加
        String msgId = request.getParameter("msgId");//5.2.14.3添加
        setAuthId(model);
        model.addAttribute("isRealNameRegisted", isRealNameRegisted);
        model.addAttribute("cardBelong", cardBelong);
        model.addAttribute("imsi", imsi);
        model.addAttribute("beId", beId);
        model.addAttribute("phone", phone);
        model.addAttribute("iccid", iccid);
        model.addAttribute("msisdn", msisdn);
        model.addAttribute("custId", custId);
        model.addAttribute("status", status);
        model.addAttribute("channelId",channelId);
        model.addAttribute("msgId",msgId);
        return "/realname/stepTwo";
    }

    @RequestMapping("stepTwoPB")
    public String stepTwoPB(Model model, HttpServletRequest request){
        setAuthId(model);
        String beId = request.getParameter("beId");
        String phone = request.getParameter("phone");
        String iccid = request.getParameter("iccid");
        String msisdn = request.getParameter("cardNum");
        String channelId = request.getParameter("channelId");//4.300.8.5.1添加
        String msgId = request.getParameter("msgId");//5.2.14.3添加
        //4.300.8.16.1安徽奇瑞定制需求
        String orderNo = request.getParameter("orderNo");
        String idCard = request.getParameter("idCard");
        logger.info("安徽奇瑞参数检查：orderNo:{},idCard:{}",orderNo,idCard);
        model.addAttribute("beId", beId);
        model.addAttribute("phone", phone);
        model.addAttribute("iccid", iccid);
        model.addAttribute("msisdn", msisdn);
        model.addAttribute("channelId",channelId);
        model.addAttribute("msgId",msgId);
        if(!StringUtils.isEmpty(orderNo)){
            model.addAttribute("orderNo",orderNo);
        }
        if(!StringUtils.isEmpty(idCard)){
            model.addAttribute("idCard",idCard);
        }
        return "/realname/stepTwoPB";
    }

    /**
     * @deprecated 已废弃
     * 4.300.8.8版本
     * */
    @RequestMapping("stepThreePB")
    public String stepThreePB(Model model, HttpServletRequest request) {
        String msisdn = request.getParameter("msisdn");
        boolean flag = Boolean.parseBoolean(request.getParameter("flag"));
        setAuthId(model);
        model.addAttribute("msisdn", msisdn);
        model.addAttribute("FLAG", flag);
        return "/realname/stepThreePB";
    }

    /**
     * @deprecated 已废弃
     * 4.300.8.8版本
     * */
    @RequestMapping("stepThreeCT")
    public String stepThreeCT(Model model, HttpServletRequest request) {
        String msisdn = request.getParameter("msisdn");
        String phone = request.getParameter("phone");
        boolean flag = Boolean.parseBoolean(request.getParameter("flag"));
        setAuthId(model);
        model.addAttribute("phone", phone);
        model.addAttribute("msisdn", msisdn);
        model.addAttribute("FLAG", flag);
        return "/realname/stepThreeCT";
    }

    /**
     * 卡号校验
     */
    @ResponseBody
    @RequestMapping("checkMsisdnIccid")
    public ResponseVo checkMsisdn(@RequestBody Map params) {
        String authId = request.getHeader(CommomConstant.REAL_NAME_H5_AUTHID);
        if (authId == null || StringUtils.isEmpty(authId)) {
            return ResponseVo.fail(ResponseCode.ERROR_AUTH_EXPIRED, new String[]{"非法的接口访问"});
        }
        if (!cache.containsKey(CacheManager.PublicNameSpace.TEMP, authId)) {
            return ResponseVo.fail(ResponseCode.ERROR_AUTH_EXPIRED, new String[]{"页面已过期，请刷新后重试"});
        }
        MapParamChecker mapParamChecker = MapParamChecker.instance(params)
                .isNotBlank(ParamConstants.MSISDN)
                .isNotBlank("iccid");
        if (!mapParamChecker.isValid()) {
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM, new String[]{"缺少必要的请求参数"});
        }
        params.put(ParamConstants.USERID, "realNameH5");
        params.put(ParamConstants.TRANSNO, request.getHeader(ParamConstants.TRANSNO));
        ResponseVo responseVo = apiClient.checkMsisdnIccid(params, getTransNo(request), getAccessToken(request));
        return responseVo;
    }

    /**
     * type:Front Back
     * @deprecated 已废弃
     * 4.300.8.8版本
     */
    @ResponseBody
    @RequestMapping("ocr")
    public ResponseVo ocr(@RequestBody Map params) {
        String authId = request.getHeader(CommomConstant.REAL_NAME_H5_AUTHID);
        if (authId == null || StringUtils.isEmpty(authId)) {
            return ResponseVo.fail(ResponseCode.ERROR_AUTH_EXPIRED, new String[]{"非法的接口访问"});
        }
        if (!cache.containsKey(CacheManager.PublicNameSpace.TEMP, authId)) {
            return ResponseVo.fail(ResponseCode.ERROR_AUTH_EXPIRED, new String[]{"页面已过期，请关闭重新进入"});
        }
        MapParamChecker mapParamChecker = MapParamChecker.instance(params)
                .isNotBlank(ParamConstants.MSISDN)
                .isNotBlank(CommomConstant.MEDIA_ID)
                .isNotBlank(ParamConstants.TYPE);
        if (!mapParamChecker.isValid()) {
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM, new String[]{"缺少必要的请求参数"});
        }
        return personApiController.ocr(String.valueOf(params.get(ParamConstants.MSISDN)), String.valueOf(params.get(CommomConstant.MEDIA_ID)), String.valueOf(params.get(ParamConstants.TYPE)));
    }

    /**
     * @deprecated 已废弃
     * 4.300.8.8版本
     * */
    @ResponseBody
    @RequestMapping("realNameReg")
    public ResponseVo realNameReg(@RequestBody Map map) {
        String authId = request.getHeader(CommomConstant.REAL_NAME_H5_AUTHID);
        if (authId == null || StringUtils.isEmpty(authId)) {
            return ResponseVo.fail(ResponseCode.ERROR_AUTH_EXPIRED, new String[]{"非法的接口访问"});
        }
        if (!cache.containsKey(CacheManager.PublicNameSpace.TEMP, authId)) {
            return ResponseVo.fail(ResponseCode.ERROR_AUTH_EXPIRED, new String[]{"页面已过期，请关闭重新进入"});
        }
        return personApiController.realNameAuth(map);
    }

    /**
     * @deprecated 已废弃
     * 4.300.8.8版本
     * */
    @ResponseBody
    @RequestMapping("fileUpload")
    public ResponseVo fileUpload(@RequestParam("file") MultipartFile file) {
        String authId = request.getHeader(CommomConstant.REAL_NAME_H5_AUTHID);
        if (authId == null || StringUtils.isEmpty(authId)) {
            return ResponseVo.fail(ResponseCode.ERROR_AUTH_EXPIRED, new String[]{"非法的接口访问"});
        }
        if (!cache.containsKey(CacheManager.PublicNameSpace.TEMP, authId)) {
            return ResponseVo.fail(ResponseCode.ERROR_AUTH_EXPIRED, new String[]{"页面已过期，请关闭重新进入"});
        }
        if (file.isEmpty()) {
            return ResponseVo.fail(ResponseCode.ERROR_OBJECT_NOT_EXIST, new String[]{"上传文件为空"});
        }
        String fileName = file.getOriginalFilename();
        int size = (int) file.getSize();
        /**
         * TODO 文件不大于5M
         * 因业务运行，实际调整为不超过5MB
         * */
        if (size > 1024 * 1024 * MAX_FILE_SIZE) {
            return ResponseVo.fail(ResponseCode.ERROR_FILE_OVER_MAXSIZE, new String[]{"上传文件不得大于"+ MAX_FILE_SIZE +"MB"});
        }
        String type = fileName.split("\\.")[1];
        //文件格式校验
        if (!Arrays.asList(ACCESS_FILE_TYPE).contains(type)) {
            return ResponseVo.fail(ResponseCode.ERROR_FILE_OVER_MAXSIZE, new String[]{"上传图像必须是JPEG格式"});
        }
        ResponseVo dir = weChatService.getSysParamById(getTransNo(request), BaseUtil.REAL_NAME_REGISTER_LOCAL);
        if (!dir.isSuccess()) {
            logger.error("transNo is:[{}],ocr证件扫描时获取素材文件临时存放地址失败", getTransNo(request));
            return ResponseVo.fail(ResponseCodeConstant.SEARCH_FAILED, new String[]{"临时文件存放地址获取失败"});
        }
        String newFileName = new StringBuilder(CommomConstant.PLATFORM_WX_OA)
                .append("_")
                .append(new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()))
                .append("_")
                .append("realNameH5").toString();
        //文件存放地址
        String path = new StringBuilder(String.valueOf(dir.getData()))
                .append(File.separatorChar)
                .append(CommomConstant.PLATFORM_WX_OA)
                .append(File.separator)
                .append(new SimpleDateFormat("yyyy-MM-dd").format(new Date()))
                .append(File.separatorChar)
                .append("temp")
                .append(File.separatorChar)
                .append(newFileName)
                .append(".jpg").toString();
        File dest = new File(path);
        if (!dest.getParentFile().exists()) { //判断文件父目录是否存在
            dest.getParentFile().mkdirs();
        }
        try {
            file.transferTo(dest); //保存文件
            String fileId = String.valueOf(UUID.randomUUID());
            cache.put(CacheManager.PublicNameSpace.TEMP, "realName".concat(fileId), dest.getPath(), 60 * 30);  // 设置过期时间 30min
            Map data = new HashMap();
            data.put("id", "realName".concat(fileId));
            data.put("path", dest.getPath()); //仅仅用作后续登记保存数据库记录，无实际意义
            return ResponseVo.success(data);
        } catch (IllegalStateException | IOException e) {
            logger.error("transNo is:[{}],保存用户上传文件异常", getTransNo(request), e);
            return ResponseVo.fail(ResponseCode.ERROR_CREATE_LOCAL_FILE, new String[]{"文件另存异常，请稍后重试！"});
        }
    }

    /**
     * 公众号ct实名认证-卡激活弹窗判断
     *
     * @return
     */
    @RequestMapping(value = "/queryBbcStatus")
    @ResponseBody
    public ResponseVo queryBbcStatus(@RequestBody Map map) {
        try {
            MapParamChecker checker = MapParamChecker.instance(map)
                    .isNotBlank("msisdn")
                    .isNotBlank("userId");
            if (!checker.isValid()) {
                logger.info("H5 queryBbcStatus...卡号为空...{}", JSONArray.toJSONString(map));
                return ResponseVo.fail(ResponseCode.ERROR_INVALID_PARAMS);
            }
            return wxApiClient.queryBbcStatusApi(map, getTransNo(request));
        } catch (Exception e) {
            logger.info("H5 queryPccStatus fail...{}...{}", JSONArray.toJSONString(map), e);
            return ResponseVo.fail("99");
        }
    }

    /**
     * 公众号ct实名认证-获取在线公司url
     *
     * @return
     */
    @RequestMapping(value = "/startCtRegister")
    @ResponseBody
    public ResponseVo startCtRegister(@RequestBody Map map) {
        try {
            MapParamChecker checker = MapParamChecker.instance(map)
                    .isNotBlank("custId")
                    .isNotBlank("beId")
                    .isNotBlank("status")
                    .isNotBlank("userId")
                    .isNotBlank("phone")
                    .isNotBlank("iccid");
            if (!checker.isValid()) {
                logger.info("H5 startCtRegister 缺少请求参数...{}", JSONArray.toJSONString(map));
                return ResponseVo.fail(ResponseCode.ERROR_INVALID_PARAMS);
            }
            if(!"realNameH5".equals(map.get("userId"))&&map.get("flag")==null){
                logger.info("H5 startCtRegister 公众号缺少授权状态...{}", JSONArray.toJSONString(map));
                return ResponseVo.fail(ResponseCode.ERROR_INVALID_PARAMS);
            }
            return wxApiClient.startCtRegisterApi(map, getTransNo(request));
        } catch (Exception e) {
            logger.info("H5 startCtRegister fail...{}...{}", JSONArray.toJSONString(map), e);
            return ResponseVo.fail("99");
        }
    }
}
