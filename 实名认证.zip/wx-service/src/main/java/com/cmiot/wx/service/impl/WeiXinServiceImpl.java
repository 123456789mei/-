package com.cmiot.wx.service.impl;

import com.alibaba.fastjson.JSON;
import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.cache.impl.CacheManager;
import com.cmiot.commons.common.utils.HttpRequestClient;
import com.cmiot.commons.log.ILog;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.wx.config.ExternalPlatConfig;
import com.cmiot.wx.constant.ResponseCodeConstant;
import com.cmiot.wx.model.AppInfoEntity;
import com.cmiot.wx.service.IWeChatService;
import com.cmiot.wx.service.IWeiXinService;
import com.cmiot.wx.constant.CommomConstant;
import com.cmiot.wx.util.ParamsUtil;
import com.cmiot.wx.util.WXHttpRequest;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

/*
微信接口调用
 */
@Service(value = "WeiXinService")
public class WeiXinServiceImpl implements IWeiXinService {

    private static final Logger logger = LoggerFactory.getLogger(WeiXinServiceImpl.class);

    @Autowired
    private ILog ilog;

    @Autowired
    ICache cache;

    @Autowired
    IWeChatService weChatService;

    @Autowired
    HttpRequestClient httpRequestClient;

    @Autowired
    ExternalPlatConfig platConfig;

    private static final int WX_SOCKET_TIMEOUT = Integer.parseInt(ParamsUtil.getProperties("WX_SOCKET_TIMEOUT"));//socket_timeout

    /**
     * 获取微信接口调用凭证access_token，并保存在缓存当中
     *
     * @param transNo
     * @return
     */
    @Override
    public ResponseVo getAccessToken(String transNo) {
        String wxAccessToken = cache.get(CacheManager.PublicNameSpace.TEMP, CommomConstant.WX_ACCESSTOKEN, "");//从缓存中获取微信access_token
        if (StringUtils.isBlank(wxAccessToken)) {//缓存中微信access_token丢失之调用微信接口拿取
            AppInfoEntity appInfoEntity = (AppInfoEntity) weChatService.getAppIdAndSecret(transNo).getData();
            String appId = appInfoEntity.getAppid();//小程序唯一凭证 AppID
            String secret = appInfoEntity.getSecret();//小程序唯一凭证密钥 secret
            //微信接口调用凭据URL
            String url = platConfig.getWxAccessTokenByAppIdUrl().replace("APPID", appId).replace("APPSECRET", secret);
            ilog.debug(logger, transNo, null, "请求微信access_token url ：{}", url);
            String resp = httpRequestClient.get(transNo, url, WX_SOCKET_TIMEOUT);
            Map rsMap = (Map) JSON.parse(resp);
            String accessToken = rsMap.getOrDefault("access_token", "").toString();
            if (StringUtils.isNotBlank(accessToken)) {//获取access_token成功放入缓存并返回
                int expiresIn = Integer.parseInt(rsMap.get("expires_in").toString());//凭证有效时间，单位：秒。目前是7200秒之内的值。
                Double inSaveTime = expiresIn * CommomConstant.WX_EXPIRESIN_REDUCE_PERCENT;//缓存中存放时间
                cache.put(CacheManager.PublicNameSpace.TEMP, CommomConstant.WX_ACCESSTOKEN, accessToken, inSaveTime.intValue());
                return ResponseVo.success(accessToken);
            } else {//获取access_token失败
                String errcode = rsMap.get("errcode").toString();
                String errMsg = rsMap.get("errmsg").toString();
                return ResponseVo.fail(errcode, errMsg);
            }
        } else {//直接返回缓存中access_token
            return ResponseVo.success(wxAccessToken);
        }
    }

    /**
     * 通过微信临时素材接口获取用户上传实名登记认证图片
     *
     * @return
     */
    @Override
    public File getMedia(String transNo, String accessToken, String mediaId, String downLoadDir,String fileName) {
        String url = platConfig.getWxGetMediaUrl().replace("ACCESS_TOKEN", accessToken).replace("MEDIA_ID", mediaId);
        return WXHttpRequest.downloadFile(url, downLoadDir, fileName, null);
    }

    /**
     * 微信OCR识别
     *
     * @param transNo
     * @param type
     * @param file
     * @param accesstoken
     * @return
     */
    @Override
    public ResponseVo wxOCRRecognition(String transNo, String type, File file, String accesstoken) {
        String url = platConfig.getWxOcrUrl().replace("MODE", type).replace("ACCESS_TOCKEN", accesstoken);
        Map<String, String> params = new HashMap<>(2);
        params.put("type", type);
        params.put("access_token", accesstoken);
        String result = WXHttpRequest.postForm(url, params, file, WX_SOCKET_TIMEOUT, WX_SOCKET_TIMEOUT, transNo);
        if (StringUtils.isEmpty(result)) {
            return ResponseVo.fail(ResponseCodeConstant.CERNO_OCR_RECOGNITION_FAILED);
        }
        Map jsonMap = (Map) JSON.parse(result);
        ilog.debug(logger, transNo, null, "OCR识别结果：{}", jsonMap);
        String errCode = jsonMap.getOrDefault("errcode", "").toString();
        return "0".equals(errCode) ? ResponseVo.success(jsonMap) : ResponseVo.fail(errCode);
    }

    @Override
    public String getJSSDKSignatrue(String transNo, String nonceStr, String timestamp, String signatureUrl) {
        String jsTicket = getJSTicket(transNo);
        //字典序
        HashMap<String,String> map=new HashMap<String,String>();
        map.put("jsapi_ticket", jsTicket);
        map.put("timestamp", timestamp);
        map.put("noncestr", nonceStr);
        map.put("url", signatureUrl);

        String linkParams = spliceParams(map);
        logger.info("string1 is {}", linkParams);
        MessageDigest crypt = null;
        String signature = "";
        try {
            crypt = MessageDigest.getInstance("SHA-1");
            crypt.reset();
            crypt.update(linkParams.getBytes("UTF-8"));
            signature = byteToHex(crypt.digest());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        logger.info("签名已生成,随机字符串:{},时间戳:{},url:{},ticket:{},签名:{}",nonceStr, timestamp, signatureUrl, jsTicket, signature);
        return signature;
    }


    private String getJSTicket(String transNo) {
        String jsTicket = cache.get(CacheManager.PublicNameSpace.TEMP, CommomConstant.WX_JS_TICKET, "");
        if (StringUtils.isEmpty(jsTicket)){
            String accessToken = (String) getAccessToken(transNo).getData();
            String url = platConfig.getWxJsSdkUrl().replace("ACCESS_TOKEN", accessToken);
            String jsonStr = httpRequestClient.get(transNo, url, Integer.valueOf(WX_SOCKET_TIMEOUT));
            Map jsonMap = (Map) JSON.parse(jsonStr);
            jsTicket = (String) jsonMap.get("ticket");
            int expiresIn = Integer.parseInt(jsonMap.get("expires_in").toString());
            Double inSaveTime = expiresIn * CommomConstant.WX_EXPIRESIN_REDUCE_PERCENT;
            cache.put(CacheManager.PublicNameSpace.TEMP, CommomConstant.WX_JS_TICKET, jsTicket, inSaveTime.intValue());
        }
        return jsTicket;
    }

    private String spliceParams(Map<String, String> map){

        Collection<String> keyset= map.keySet();
        List list= new ArrayList<String>(keyset);
        Collections.sort(list);
        StringBuilder builder = new StringBuilder();
        for(int i=0;i<list.size();i++){
            builder.append(list.get(i)).append("=").append(map.get(list.get(i))).append("&");
        }
        builder.deleteCharAt(builder.length()-1);
        return builder.toString();
    }

    private static String byteToHex(final byte[] hash) {
        Formatter formatter = new Formatter();
        for (byte b : hash) {
            formatter.format("%02x", b);
        }
        String result = formatter.toString();
        formatter.close();
        return result;
    }


}
