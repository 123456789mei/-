package com.cmiot.wx.constant;

/**
 * @author jiangchengyi
 */
public class ResponseCodeConstant {

    private ResponseCodeConstant() {

    }

    /**
     * 成功
     */
    public static final String AUTHENTICATE_SUCCESS = "0";

    /**
     * 参数错误（参数缺失，或不合法）
     */
    public static final String PARAM_ILLEGALLY = "401";

    /**
     * 查询异常（请重试）
     */
    public static final String SEARCH_FAILED = "403";


    //===========校验用户输入身份信息是否和账户实名信息一致=========

    /**
     * 输入身份信息是否和账户实名信息一致
     */
    public static final String NOT_EQUAL = "010";

    /**
     * 输入身份信息是否和账户实名信息不一致
     */
    public static final String EQUAL = "011";


    //=================查询物联卡是否已实名登记=============

    /**
     * 该卡你已实名登记，无需重复实名登记
     */
    public static final String AUTHED_BY_SELF = "420";

    /**
     * 该卡已被其他人实名登记
     */
    public static final String AUTHED_BY_OTHER = "421";
    /**
     * 人证比对不一致
     */
    public static final String AUTHED_INFO_INVALID = "422";

    //======================实名登记==========================
    /**
     * 获取微信access_token失败
     */
    public static final String GET_WX_ACCESS_TOKEN_FAILED = "430";

    /**
     * 人证对比不一致(输入的{姓名/身份证号}与身份证上的{姓名/公民身份号码}不一致)
     */
    public static final String DIFFER_IN_OCR_RECOGNITION = "431";

    /**
     * 微信OCR识别身份证件失败，请重试
     */
    public static final String CERNO_OCR_RECOGNITION_FAILED = "432";

    /**
     * 拉取微信临时素材文件失败
     */
    public static final String PULL_WX_MEDIA_FAILED = "433";

    /**
     * 登记信息保存失败
     */
    public static final String SAVE_REGISTER_INFO_FAILED = "434";

    /**
     * ICCID和MSISDN对应关系错误
     */
    public static final String AUTHENTICATE_FAILED = "435";

    /**
     * 该卡已销户，无法实名登记
     */
    public static final String MSISDN_DELETE = "436";

    /**
     * 该卡在CMIOT系统中不存在
     */
    public static final String MSISDN_NOT_EXISTS_IN_CMIOT = "437";

    /**
     * 该卡实名登记请求次数已超过系统每日最大限制（10次）
     */
    public static final String MSISDN_AUTHED_DAILY_LIMIT = "438";

    /**
     * 该卡正在进行实名登记，请勿重复提交请求
     */
	 
	public static final String MSISDN_IN_AUTH = "439";

    /**
     * 手机号码格式错误
     */
    public static final String PHONE_NO_FORMAT_ERR = "440";

    /**
     * 手机号码位数错误
     */
    public static final String PHONE_NO_DIGIT_ERR = "441";

    /**
     * 身份证号码位数错误
     */
    public static final String CERT_NO_DIGIT_ERR = "442";

    /**
     * 实名认证用户信息变更失败
     */
    public static final String REAL_NAME_REG_USERINFO_MODIFY_FAILED = "443";

    /**
     * CT卡激活成功
     */
    public static final String RESPONSE_CODE_ACTIVATE_CARD_SUCCESS = "040";
    /**
     * 账号在其他地方登录
     */
    public static final String RESPONSE_CODE_USER_OTHERPLACE_LOGIN = "087";

    
    /**
     * CT卡激活失败，当前卡状态不支持激活
     */
    public static final String RESPONSE_CODE_ACTIVATE_CARD_NOTALLOWED = "041";

    /**
     * CT卡激活失败，系统错误
     */
    public static final String RESPONSE_CODE_ACTIVATE_CARD_FAIL = "042";

    /**
     * CT实名登记人像图片不符合规范
     * */
    public static final String RESPONSE_CODE_CT_REGISTER_FILER_FAIL = "055";

}
