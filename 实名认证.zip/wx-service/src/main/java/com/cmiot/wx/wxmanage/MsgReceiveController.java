package com.cmiot.wx.wxmanage;

import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.rest.RestBase;
import com.cmiot.wx.service.HandleWxMsg;
import com.cmiot.wx.util.MessageUtil;
import com.cmiot.wx.util.SHA1;
import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

@Controller
@RequestMapping("wxMsg")
public class MsgReceiveController extends RestBase {

    Logger logger = LoggerFactory.getLogger(MsgReceiveController.class);

    private static final String wxToken = "OneLinkMobile";

    @Autowired
    HttpServletRequest request;

    @Autowired
    HandleWxMsg handleWxMsg;

    @RequestMapping(value = "receiveMsg", method = RequestMethod.GET)
    public void receiveMsg(@RequestParam("signature") String signature,
                           @RequestParam("nonce") String nonce,
                           @RequestParam("echostr") String echostr,
                           @RequestParam("timestamp") String timestamp, HttpServletResponse response) {
        logger.info("received wx signature info");
        try {
            String jiami = SHA1.getSHA1(wxToken, timestamp, nonce, "");//这里是对三个参数进行加密
            if (jiami.equals(signature)) {
                sendResponse(response, echostr);
            } else {
                sendResponse(response, "false");
            }
        } catch (Exception e) {
            logger.error("wxMsg receiveMsg signature fail", e);
            sendResponse(response, "false");
        }
    }

    @RequestMapping(value = "receiveMsg", method = RequestMethod.POST)
    public void receiveMsg(HttpServletRequest request, HttpServletResponse response) {
        String respMessage = null;
        try {
            request.setCharacterEncoding("UTF-8");
            Map<String, String> requestMap = MessageUtil.parseXml(request);
            logger.info("公众号接收信息{}", JsonUtils.parseString(requestMap));
            respMessage = handleWxMsg.handle(requestMap,getTransNo(request));
            response.setContentType("text/xml,charset=utf-8");
            sendResponse(response,respMessage);
            logger.info("receive wx push msg:[{}]", request.getParameterMap());
        } catch (Exception e) {
            logger.error("receive wx msg fail", e);
        }
    }

    private void sendResponse(HttpServletResponse response, String data) {
        PrintWriter out = null;
        response.setCharacterEncoding("UTF-8");
        try {
            out = response.getWriter();
            out.print(data);
        } catch (IOException e) {
            logger.error("set response to wx fail", e);
        } finally {
            out.close();
            out = null;
        }
    }
}
