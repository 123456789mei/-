package com.cmiot.wx.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.Properties;

/**
 * 读取properties文件、参数工具类
 */
public class ParamsUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(ParamsUtil.class);

    public static final String ERROR = "error";

    //读取properties属性
    public static String getProperties(String param) {
        try (InputStream inputStream = ParamsUtil.class.getClassLoader().getResourceAsStream("application.properties")) {
            Properties properties = new Properties();
            properties.load(inputStream);
            String result = properties.getProperty(param);
            result = new String(result.getBytes("UTF-8"), "UTF-8");
            return result;
        } catch (Exception e) {
            LOGGER.error("getProperties failed:{}", e);
        }
        return "";
    }

    private ParamsUtil(){

    }
}
