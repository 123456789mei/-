package com.cmiot.wx.service;

import com.cmiot.commons.response.ResponseVo;

import java.io.File;

/**
 * 微信接口调用
 */
public interface IWeiXinService {

    ResponseVo getAccessToken(String transNo);

    File getMedia(String transNo , String accessToken , String mediaId , String downLoadDir , String fileName);

    ResponseVo wxOCRRecognition(String transNo, String type, File file, String accessToken);

    String getJSSDKSignatrue(String transNo, String nonceStr, String timestamp, String signatureUrl);
}
