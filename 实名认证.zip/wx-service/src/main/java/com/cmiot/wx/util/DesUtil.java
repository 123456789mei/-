package com.cmiot.wx.util;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;
import java.security.Key;

/**
 * 加密工具类
 */
public class DesUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(DesUtil.class);

    private static final String ENCODING = "utf-8";
    private static final String KEY = "cnmobile";
    private static final String SECRET_KEY = "cmcc_cnmobile_asiainfo_ocs";

    /**
     * 加密
     * @param plainText
     * @return
     */
    public static String encode(String plainText) {
        Key deskey = null;
        byte[] encryptData = null;
        try {
            DESedeKeySpec spec = new DESedeKeySpec(SECRET_KEY.getBytes());
            SecretKeyFactory keyfactory = SecretKeyFactory.getInstance("desede");
            deskey = keyfactory.generateSecret(spec);
            Cipher cipher = Cipher.getInstance("desede/CBC/PKCS5Padding");
            IvParameterSpec ips = new IvParameterSpec(KEY.getBytes());
            cipher.init(Cipher.ENCRYPT_MODE, deskey, ips);
            encryptData = cipher.doFinal(plainText.getBytes(ENCODING));
            Base64 base64 = new Base64();
            return str2Hex(new String(base64.encode(encryptData)));
        } catch (Exception e) {
            LOGGER.error("encode failed:", e);
        }
        return "";
    }

    public static String str2Hex(String theStr) {
        int tmp;
        String tmpStr;
        byte[] bytes = theStr.getBytes();
        StringBuilder result = new StringBuilder(bytes.length * 2);
        for (int i = 0; i < bytes.length; i++) {
            tmp = bytes[i];
            if (tmp < 0) {
                tmp += 256;
            }
            tmpStr = Integer.toHexString(tmp);
            if (tmpStr.length() == 1) {
                result.append('0');
            }
            result.append(tmpStr);
        }
        return result.toString();
    }

    private DesUtil(){

    }
}
