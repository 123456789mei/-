package com.cmiot.wx.wxmanage;

import com.alibaba.fastjson.JSON;
import com.cmiot.commons.common.constants.ParamConstants;
import com.cmiot.commons.common.utils.HttpRequestClient;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.common.utils.MapParamChecker;
import com.cmiot.commons.response.ResponseCode;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.commons.rest.RestBase;
import com.cmiot.wx.api.client.WxApiClient;
import com.cmiot.wx.config.ExternalPlatConfig;
import com.cmiot.wx.model.wxmsg.TemplateMsgVo;
import com.cmiot.wx.service.IWeiXinService;
import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("wxManage")
public class ManageController extends RestBase {

    Logger logger = LoggerFactory.getLogger(ManageController.class);

    @Autowired
    IWeiXinService iWeiXinService;

    @Autowired
    ExternalPlatConfig platConfig;

    @Autowired
    HttpRequestClient httpRequestClient;

    @Autowired
    WxApiClient wxApiClient;

    @Autowired
    HttpServletRequest request;

    private final String CREATE_MENUS = "/cgi-bin/menu/create?access_token=ACCESS_TOKEN"; //创建菜单
    private final String GET_MENUS = "/cgi-bin/get_current_selfmenu_info?access_token=ACCESS_TOKEN";  //查询菜单
    private final String DELETE_MENUS = "/cgi-bin/menu/delete?access_token=ACCESS_TOKEN";  //清除自定义菜单

    private final String TEMPLATE_MSG = "/cgi-bin/message/template/send?access_token=ACCESS_TOKEN"; //发送模板消息
    private final String SET_INDUSTRY = "/cgi-bin/template/api_set_industry?access_token=ACCESS_TOKEN"; //设置所属行业，一月可调用一次
    private final String GET_INDUSTRY = "/cgi-bin/template/get_industry?access_token=ACCESS_TOKEN"; //获取当前账户的所属行业

    private final String ALL_PRIVATE_TEMPLATE = "/cgi-bin/template/get_all_private_template?access_token=ACCESS_TOKEN"; //获取当前账户的模板列表

    private final String GET_ALL_MATERIAL = "/cgi-bin/material/batchget_material?access_token=ACCESS_TOKEN"; //获取素材列表


    /**
     * 设置公众号自定义菜单
     */
    @RequestMapping(value = "createMenu", method = RequestMethod.POST)
    public ResponseVo createMenu(@RequestBody Map params) {
        ResponseVo tokenVo = iWeiXinService.getAccessToken(getTransNo(request));
        if (tokenVo.isSuccess()) {
            String token = String.valueOf(tokenVo.getData());
            String url = platConfig.getWxApiPath().concat(CREATE_MENUS.replace("ACCESS_TOKEN", token));
            String resp = httpRequestClient.post(getTransNo(request), url, JsonUtils.parseString(params), HttpRequestClient.CONTENT_TYPE_JSON);
            Map respMap = (Map) JSON.parse(resp);
            if (respMap != null && String.valueOf(respMap.get("errcode")).equals("0")) {
                return ResponseVo.success("");
            } else {
                return ResponseVo.fail(ResponseCode.ERROR_COMMUNICATION_EXTENAL_SYS, new String[]{String.valueOf(respMap != null ? respMap.get("errmsg") : "调用微信服务超时")});
            }
        }
        return ResponseVo.fail(ResponseCode.ERROR_SYS, new String[]{"获取accessToken失败"});
    }

    /**
     * 查询公众号自定义菜单
     */
    @RequestMapping(value = "getMenus", method = RequestMethod.GET)
    public ResponseVo getMenus() {
        ResponseVo tokenVo = iWeiXinService.getAccessToken(getTransNo(request));
        if (tokenVo.isSuccess()) {
            String token = String.valueOf(tokenVo.getData());
            String url = platConfig.getWxApiPath().concat(GET_MENUS.replace("ACCESS_TOKEN", token));
            String resp = httpRequestClient.get(getTransNo(request), url);
            Map respMap = (Map) JSON.parse(resp);
            if (respMap != null && respMap.containsKey("selfmenu_info")) {
                return ResponseVo.success(respMap.get("selfmenu_info"));
            } else {
                return ResponseVo.fail(ResponseCode.ERROR_COMMUNICATION_EXTENAL_SYS, new String[]{String.valueOf(respMap != null ? respMap.get("errmsg") : "调用微信服务超时")});
            }
        }
        return ResponseVo.fail(ResponseCode.ERROR_SYS, new String[]{"获取accessToken失败"});
    }

    /**
     * 删除公众号菜单
     */
    @RequestMapping(value = "deleteMenus", method = RequestMethod.GET)
    public ResponseVo deleteMenus() {
        ResponseVo tokenVo = iWeiXinService.getAccessToken(getTransNo(request));
        if (tokenVo.isSuccess()) {
            String token = String.valueOf(tokenVo.getData());
            String url = platConfig.getWxApiPath().concat(DELETE_MENUS.replace("ACCESS_TOKEN", token));
            String resp = httpRequestClient.get(getTransNo(request), url);
            Map respMap = (Map) JSON.parse(resp);
            if (respMap != null && String.valueOf(respMap.get("errcode")).equals("0")) {
                return ResponseVo.success("");
            } else {
                return ResponseVo.fail(ResponseCode.ERROR_COMMUNICATION_EXTENAL_SYS, new String[]{String.valueOf(respMap != null ? respMap.get("errmsg") : "调用微信服务超时")});
            }
        }
        return ResponseVo.fail(ResponseCode.ERROR_SYS, new String[]{"获取accessToken失败"});
    }

    /**
     * 获取公众号素材列表
     */
    @RequestMapping(value = "getAllMaterial", method = RequestMethod.POST)
    public ResponseVo getAllMaterial(@RequestBody Map pageParam) {

        MapParamChecker mapParamChecker = MapParamChecker.instance(pageParam)
                .isNotBlank(ParamConstants.PAGENO)
                .isNotBlank(ParamConstants.TYPE);
        if (!mapParamChecker.isValid()) {
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM, new String[]{"缺少必要的接口参数"});
        }
        ResponseVo tokenVo = iWeiXinService.getAccessToken(getTransNo(request));
        if (tokenVo.isSuccess()) {
            String token = String.valueOf(tokenVo.getData());
            int offset = (int) pageParam.get(ParamConstants.PAGENO);
            offset = 10 * (offset - 1);
            Map params = new HashMap(3);
            params.put("offset", offset); //分页起点
            params.put("count", 10); //分页大小
            params.put("type", pageParam.get(ParamConstants.TYPE)); //类型筛选
            String url = platConfig.getWxApiPath().concat(GET_ALL_MATERIAL.replace("ACCESS_TOKEN", token));
            String resp = httpRequestClient.post(getTransNo(request), url, JsonUtils.parseString(params), HttpRequestClient.CONTENT_TYPE_JSON);
            Map respMap = (Map) JSON.parse(resp);
            if (respMap != null && respMap.get("item") != null) {
                Map dataMap = new HashMap();
                dataMap.put("totalCount", respMap.get("total_count"));
                dataMap.put("itemCount", respMap.get("item_count"));
                dataMap.put("list", respMap.get("item"));
                return ResponseVo.success(dataMap);
            } else {
                return ResponseVo.fail(ResponseCode.ERROR_COMMUNICATION_EXTENAL_SYS, new String[]{String.valueOf(respMap != null ? respMap.get("errmsg") : "调用微信服务超时")});
            }
        }
        return ResponseVo.fail(ResponseCode.ERROR_SYS, new String[]{"获取accessToken失败"});
    }

    /**
     * 设置公众号所属行业
     */
    @RequestMapping(value = "setIndustry", method = RequestMethod.POST)
    public ResponseVo setIndustry(@RequestBody Map params) {
        MapParamChecker mapParamChecker = MapParamChecker.instance(params)
                .isNotBlank("industry_id1")
                .isNotBlank("industry_id2");

        if (!mapParamChecker.isValid()) {
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM, new String[]{"缺少必要的接口参数"});
        }
        ResponseVo tokenVo = iWeiXinService.getAccessToken(getTransNo(request));
        if (tokenVo.isSuccess()) {
            String token = String.valueOf(tokenVo.getData());
            String url = platConfig.getWxApiPath().concat(SET_INDUSTRY.replace("ACCESS_TOKEN", token));
            String resp = httpRequestClient.post(getTransNo(request), url, JsonUtils.parseString(params), HttpRequestClient.CONTENT_TYPE_JSON);
            Map respMap = (Map) JSON.parse(resp);
            if (respMap != null && String.valueOf(respMap.get("errcode")).equals("0")) {
                return ResponseVo.success("");
            } else {
                return ResponseVo.fail(ResponseCode.ERROR_COMMUNICATION_EXTENAL_SYS, new String[]{String.valueOf(respMap != null ? respMap.get("errmsg") : "调用微信服务超时")});
            }
        }
        return ResponseVo.fail(ResponseCode.ERROR_SYS, new String[]{"获取accessToken失败"});
    }

    /**
     * 拉取账户下模板列表
     * */
    @RequestMapping(value = "privateTemplate",method = RequestMethod.GET)
    public ResponseVo privateTemplate(){
        ResponseVo tokenVo = iWeiXinService.getAccessToken(getTransNo(request));
        if (tokenVo.isSuccess()) {
            String token = String.valueOf(tokenVo.getData());
            String url = platConfig.getWxApiPath().concat(ALL_PRIVATE_TEMPLATE.replace("ACCESS_TOKEN", token));
            String resp = httpRequestClient.get(getTransNo(request),url);
            Map respMap = (Map) JSON.parse(resp);
            if(respMap != null && respMap.get("template_list") != null){
                return ResponseVo.success(respMap.get("template_list"));
            }else {
                return ResponseVo.fail(ResponseCode.ERROR_COMMUNICATION_EXTENAL_SYS, new String[]{String.valueOf(respMap != null ? respMap.get("errmsg") : "调用微信服务超时")});
            }
        }
        return ResponseVo.fail(ResponseCode.ERROR_SYS, new String[]{"获取accessToken失败"});
    }


    /**
     * 内购平台》订单处理进度通知
     * 【1】物联网人员订单待处理消息
     * 【2】省公司人员订单待处理消息
     */
    @RequestMapping(value = "templateMsg", method = RequestMethod.POST)
    public ResponseVo templateMsg(@RequestBody TemplateMsgVo templateMsgVo) {
        //记录日志参数
        Map logMap = new HashMap();
        logMap.put("businessCode", "2");
        if(StringUtils.isEmpty(templateMsgVo.getTemplateId()) || StringUtils.isEmpty(templateMsgVo.getToUser()) || templateMsgVo.getParams() == null || templateMsgVo.getParams().size() == 0){
            logger.info("transNo is:[{}],模板推送缺少必要的参数，params is:[{}]",getTransNo(request),JsonUtils.parseString(templateMsgVo));
            logMap.put("results", "0");
            wxApiClient.insertWxLog(logMap, getTransNo(request));
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM,new String[]{"缺少必要的请求参数"});
        }
        ResponseVo tokenVo = iWeiXinService.getAccessToken(getTransNo(request));
        if (tokenVo.isSuccess()) {
            String token = String.valueOf(tokenVo.getData());
            String url = platConfig.getWxApiPath().concat(TEMPLATE_MSG.replace("ACCESS_TOKEN", token));
            Map params = new HashMap();
            params.put("touser",templateMsgVo.getToUser());
            params.put("template_id",templateMsgVo.getTemplateId());
            if(templateMsgVo.getMiniprogram() != null){
                params.put("miniprogram",templateMsgVo.getMiniprogram());
            }
            if(templateMsgVo.getUrl() != null){
                params.put("url",templateMsgVo.getUrl());
            }
            params.put("data",templateMsgVo.getParams());
            //TODO 记录模板推送记录
            String resp = httpRequestClient.post(getTransNo(request),url,JsonUtils.parseString(params), HttpRequestClient.CONTENT_TYPE_JSON);
            Map respMap = (Map) JSON.parse(resp);
            if (respMap != null && String.valueOf(respMap.get("errcode")).equals("0")) {
                logMap.put("results", "1");
                wxApiClient.insertWxLog(logMap, getTransNo(request));
                return ResponseVo.success("");
            }else {
                logMap.put("results", "0");
                wxApiClient.insertWxLog(logMap, getTransNo(request));
                return ResponseVo.fail(ResponseCode.ERROR_COMMUNICATION_EXTENAL_SYS, new String[]{String.valueOf(respMap != null ? respMap.get("errmsg") : "调用微信服务超时")});
            }
        }
        logMap.put("results", "0");
        wxApiClient.insertWxLog(logMap, getTransNo(request));
        return ResponseVo.fail(ResponseCode.ERROR_SYS, new String[]{"获取accessToken失败"});
    }

}
