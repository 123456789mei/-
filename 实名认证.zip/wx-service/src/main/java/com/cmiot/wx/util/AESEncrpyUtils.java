package com.cmiot.wx.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

/**
 * 用于AES对称加密和解密工具类
 *
 * @author lKF16720
 */
public class AESEncrpyUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(AESEncrpyUtils.class);

    /**
     * 密钥算法
     */
    private static final String KEY_ALGORITHM = "AES";

    /**
     * 加密解密算法 工作模式 填充方式
     */
    private static final String CIPHER_ALGORITHM = "AES/ECB/PKCS5Padding";

    //加密的密钥
    private static final String SECURE_KEY = "!%4&M2M&#1234560";


    private static final String  NOSUCHALGORITHMEXCEPTION = "encrpy NoSuchAlgorithmException error ";
    private static final String  NOSUCHPADDINGEXCEPTION = "encrpy NoSuchPaddingException error ";
    private static final String  INVALIDKEYEXCEPTION = "encrpy InvalidKeyException error ";
    private static final String  ILLEGALBLOCKSIZEEXCEPTION = "encrpy IllegalBlockSizeException error ";
    private static final String  BADPADDINGEXCEPTION = "encrpy BadPaddingException error ";


    private AESEncrpyUtils(){

    }
    /**
     * 生成密钥
     *
     * @return 二进制密钥
     * @throws Exception
     */
    private static byte[] initKey() {
        return SECURE_KEY.getBytes();
    }


    /**
     * 转换密钥，二进制密钥转换为密钥对象
     *
     * @param key 二级制密钥
     * @return Key 密钥
     * @throws Exception
     */
    private static Key toKey(byte[] key) {
        return new SecretKeySpec(key, KEY_ALGORITHM);
    }

    /**
     * 加密
     *
     * @param data 需要加密的内容
     * @return
     */
    public static String encrypt(byte[] data) {
        try {
            byte[] key = initKey();
            // 实例化，创建密码器
            Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
            // 初始化  设置为加密模式
            cipher.init(Cipher.ENCRYPT_MODE, toKey(key));
            // 加密
            return parseByte2HexStr(cipher.doFinal(data));

        } catch (NoSuchAlgorithmException e) {
            LOGGER.error(NOSUCHALGORITHMEXCEPTION + e);
        } catch (NoSuchPaddingException e) {
            LOGGER.error(NOSUCHPADDINGEXCEPTION + e);
        } catch (InvalidKeyException e) {
            LOGGER.error(INVALIDKEYEXCEPTION + e);
        } catch (IllegalBlockSizeException e) {
            LOGGER.error(ILLEGALBLOCKSIZEEXCEPTION + e);
        } catch (BadPaddingException e) {
            LOGGER.error(BADPADDINGEXCEPTION + e);
        }
        return "";
    }

    /**
     * 解密
     *
     * @param encrpyData 待解密内容
     * @return
     */
    public static String decrypt(String encrpyData) {
        try {
            byte[] key = initKey();
            byte[] data = parseHexStr2Byte(encrpyData);
            // 实例化，创建密码器
            Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
            // 初始化  设置为解密模式
            cipher.init(Cipher.DECRYPT_MODE, toKey(key));
            byte[] decryptBytes = cipher.doFinal(data);
            return new String(decryptBytes);
        } catch (NoSuchAlgorithmException exp) {
            LOGGER.error(NOSUCHALGORITHMEXCEPTION + exp);
        } catch (NoSuchPaddingException exp) {
            LOGGER.error(NOSUCHPADDINGEXCEPTION + exp);
        } catch (InvalidKeyException exp) {
            LOGGER.error(INVALIDKEYEXCEPTION + exp);
        } catch (IllegalBlockSizeException exp) {
            LOGGER.error(ILLEGALBLOCKSIZEEXCEPTION + exp);
        } catch (BadPaddingException exp) {
            LOGGER.error(BADPADDINGEXCEPTION + exp);
        }
        return null;
    }




    /**
     * 将16进制转换为二进制
     *
     * @param hexStr
     * @return
     */
    public static byte[] parseHexStr2Byte(String hexStr) {
        if (hexStr.length() < 1) {
            return new byte[]{};
        }
        final int hex = 16;
        byte[] result = new byte[hexStr.length() / 2];
        for (int i = 0; i < hexStr.length() / 2; i++) {
            int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), hex);
            int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), hex);
            result[i] = (byte) (high * hex + low);
        }
        return result;
    }

    /**
     * 将二进制转换为十六进制
     * @param buf
     * @return
     */
    public static String parseByte2HexStr(byte[] buf) {
        StringBuilder sb = new StringBuilder(buf.length * 2);
        for (int i = 0; i < buf.length; i++) {
            String hex = Integer.toHexString(buf[i] & 0xFF);
            if (hex.length() == 1) {
                hex = '0' + hex;
            }
            sb.append(hex.toUpperCase());
        }
        return sb.toString();
    }

    private static byte charToByte(char c) {
        return (byte) "0123456789ABCDEF".indexOf(c);
    }
}
