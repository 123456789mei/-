package com.cmiot.wx.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.cache.impl.CacheManager;
import com.cmiot.commons.common.constants.InteConstants;
import com.cmiot.commons.common.utils.FileUtils;
import com.cmiot.commons.common.utils.HttpRequestClient;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.common.utils.MapParamChecker;
import com.cmiot.commons.log.ILog;
import com.cmiot.commons.response.ResponseCode;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.commons.response.vo.PageResultVo;
import com.cmiot.commons.rest.RestBase;
import com.cmiot.wx.api.client.AuthenticationServiceClient;
import com.cmiot.wx.api.client.IProdInfoClient;
import com.cmiot.wx.api.client.ReChargeClient;
import com.cmiot.wx.api.client.WxApiClient;
import com.cmiot.wx.constant.CommomConstant;
import com.cmiot.wx.constant.PersonalConstant;
import com.cmiot.wx.constant.ResponseCodeConstant;
import com.cmiot.wx.model.AppInfoEntity;
import com.cmiot.wx.model.PBChargeParam;
import com.cmiot.wx.service.FileUploadService;
import com.cmiot.wx.service.IWeChatService;
import com.cmiot.wx.service.IWeiXinService;
import com.cmiot.wx.service.RsaService;
import com.cmiot.wx.util.*;
import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author xiapeicheng
 * @date 2019/1/8 14:14
 * @email xiapeicheng@cmiot.chinamobile.com
 */
@RestController
@RequestMapping(value = "/person/api")
public class PersonApiController extends RestBase {

    Logger logger = LoggerFactory.getLogger(PersonApiController.class);

    @Autowired
    private ILog iLog;

    @Autowired
    HttpServletRequest request;

    @Autowired
    WxApiClient wxApiClient;

    @Autowired
    IWeChatService weChatService;

    @Autowired
    HttpRequestClient httpRequestClient;

    @Autowired
    RsaService rsaService;

    @Autowired
    private ICache cache;

    @Autowired
    PublicUtils publicUtils;

    @Autowired
    PersonalUtil personalUtil;

    @Autowired
    IProdInfoClient iProdInfoClient;

    @Autowired
    IWeiXinService iWeiXinService;

    @Autowired
    FileUploadService fileUploadService;

    @Autowired
    ReChargeClient chargeClient;

    @Autowired
    AuthenticationServiceClient authenticationServiceClient;


    private static final ExecutorService FIXED_THREAD_POOL = Executors.newFixedThreadPool(Integer.parseInt(ParamsUtil.getProperties(BaseUtil.CT_REALNAME_CALL_THREAD_MAX_LIMIT)));

    /**
     * 发送短信验证码
     */
    @RequestMapping("/sendAuthCode")
    public ResponseVo sendAuthCode(@RequestParam String phone, @RequestParam String openId) {
        if (StringUtils.isEmpty(phone) || StringUtils.isEmpty(openId)) {
            iLog.error(logger, getTransNo(request), null, "sendAuthCode fail case param missing:");
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
        }
        iLog.info(logger, getTransNo(request), null, "wxUser get smsCode");
        Map params = new HashMap(2);
//        logger.info();
        String cachePhone = personalUtil.getPhoneFromCache(openId);
        if(!"null".equals(cachePhone) && !StringUtils.isEmpty(cachePhone)){
            //登陆过手机号
            if(!cachePhone.equals(phone)){
                logger.info("手机号与缓存不匹配cachePhone:{}，发送验证码校验入参phone:{},openId:{}",
                        CommonUtils.mobileEncrypt(cachePhone),CommonUtils.mobileEncrypt(phone),openId);
                //手机号不匹配
                return ResponseVo.fail(ResponseCode.ERROR_NO_AUTH,new String[]{"已存在绑定的手机号，暂不支持切换其他手机号登录"});
            }
        }
        params.put("openId", openId);
        params.put("phone", phone);
        ResponseVo responseVo = wxApiClient.sendSmsCode(params, getTransNo(request), getAccessToken(request));
        //保证安全（短信验证码等不需要传到前端），清空不需要的数据
        responseVo.setData("");
        return responseVo;
    }

    /**
     * 个人用户
     * 校验短信验证码
     */
    @RequestMapping("/validateCode")
    public ResponseVo validateCodePerson(@RequestParam String authCode, @RequestParam String openId, @RequestParam String phone) {
        if (StringUtils.isEmpty(authCode) || StringUtils.isEmpty(openId) || StringUtils.isEmpty(phone)) {
            iLog.error(logger, getTransNo(request), null, "validateCode fail case param missing:");
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
        }
        Map params = new HashMap(2);
        params.put("authCode", authCode);
        params.put("openId", openId);
        params.put("phone", phone);
        ResponseVo responseVo = wxApiClient.validateCodePersonal(params, getTransNo(request), getAccessToken(request));
        return responseVo;
    }


    /**
     * 获取卡号余量信息
     */
    @RequestMapping(value = "/getSimFlow")
    public ResponseVo getSimFlow(@RequestParam String userId, @RequestParam String msisdn) {
        if (StringUtils.isEmpty(userId) || StringUtils.isEmpty(msisdn)) {
            iLog.error(logger, getTransNo(request), null, "wx ec getSimFlow params is missing");
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
        }
        Map param = new HashMap(2);
        param.put("userId", userId);
        param.put("msisdn", msisdn);
        ResponseVo responseVo = wxApiClient.getSimFlow(param, getTransNo(request), getAccessToken(request));

        //保存查询日志
        ResponseVo historyVo = wxApiClient.saveHistory(param, getTransNo(request), getAccessToken(request));
        if (!historyVo.isSuccess()) {
            iLog.error(logger, getTransNo(request), param, "wx user{} saveHistory fail params is:{}");
        }

        return responseVo;
    }

    /**
     * 获取CT卡套餐余量信息
     *
     * @param userId
     * @param msisdn
     * @param accountId
     * @param custId
     * @param beId
     * @return
     */
    @RequestMapping(value = "/getSimFlowFromCT")
    public ResponseVo getSimFlowFromCT(@RequestParam String userId, @RequestParam String msisdn, @RequestParam String accountId,
                                       @RequestParam String custId, @RequestParam String beId) {
        if (StringUtils.isEmpty(userId) || StringUtils.isEmpty(msisdn)) {
            iLog.error(logger, getTransNo(request), null, "wx ec getSimFlow params is missing");
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
        }
        Map param = new HashMap(2);
        param.put("userId", userId);
        param.put("msisdn", msisdn);
        param.put("accountId", accountId);
        param.put("custId", custId);
        param.put("beId", beId);
        ResponseVo responseVo = wxApiClient.getSimFlowFromCT(param, getTransNo(request), getAccessToken(request));
        return responseVo;
    }

    /**
     * 根据产品订购唯一实列号获取套餐订购信息
     */
    @RequestMapping(value = "/getProdInfoByProdInstID")
    public ResponseVo getProdInfoByProdInstID(@RequestParam String prodInstIds, @RequestParam String msisdn) {
        if (StringUtils.isEmpty(prodInstIds) || StringUtils.isEmpty(msisdn)) {
            iLog.error(logger, getTransNo(request), null, "wx ec getProductInfo params is missing");
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
        }
        Map param = new HashMap(2);
        param.put("prodInstIds", prodInstIds);
        param.put("provinceId", cache.getMsisdnProvince(msisdn));
        ResponseVo responseVo = iProdInfoClient.getProdInfoByProdInstID(param, getTransNo(request), getAccessToken(request));
        return responseVo;
    }

    /**
     * 获取产品列表
     *
     * @param userId
     * @param msisdn
     * @param accountId
     * @param custId
     * @param beId
     * @return
     */
    @RequestMapping(value = "/getProductListFromCT")
    public ResponseVo getProductListFromCT(@RequestParam String userId, @RequestParam String msisdn, @RequestParam String accountId,
                                           @RequestParam String custId, @RequestParam String beId) {
        if (StringUtils.isEmpty(userId) || StringUtils.isEmpty(msisdn)) {
            iLog.error(logger, getTransNo(request), null, "wx ec getProductList params is missing");
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
        }
        Map param = new HashMap(2);
        param.put("userId", userId);
        param.put("msisdn", msisdn);
        param.put("accountId", accountId);
        param.put("custId", custId);
        param.put("beId", beId);
        ResponseVo responseVo = wxApiClient.productListFromCT(param, getTransNo(request), getAccessToken(request));
        return responseVo;
    }

    @RequestMapping("/logout")
    public ResponseVo logout() {
        String userId = request.getHeader(CommomConstant.USER_ID) == null ? "" : request.getHeader(CommomConstant.USER_ID);
        String openId = request.getHeader(CommomConstant.OPEN_ID) == null ? "" : request.getHeader(CommomConstant.OPEN_ID);
        String phone = request.getHeader(CommomConstant.PHONE) == null ? "" : request.getHeader(CommomConstant.PHONE);
        if (StringUtils.isEmpty(openId) || StringUtils.isEmpty(phone)) {
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
        }
        Map<String, String> map = new HashMap<>(2);
        map.put(CommomConstant.USER_ID, userId);
        map.put("plat", "00");// 全网业务模块点击量统计-渠道来源：00 公众号
        personalUtil.setLogoutCache(openId);
        personalUtil.removeLoginInfo(phone, openId);
        // 跳转api-service,用于业务模块统计
        wxApiClient.logout(map, getTransNo(request), getAccessToken(request));
        cache.put(CacheManager.PublicNameSpace.USERAUTH,"LOGINRECORD_"+openId, phone);
        //退出登录时，清除该手机号数据库中的openId
        Map reqMap=new HashMap();
        reqMap.put("openId",openId);
        reqMap.put("phone",phone);
        wxApiClient.deleteOpenIdByPhone(reqMap,getTransNo(request));
        logger.info("账户退出登录,openId:{}", openId);
        Map<String, String> responseMap = new HashMap<>(1);
        responseMap.put("status", "00");
        return ResponseVo.success(responseMap);
    }

    @RequestMapping("/deleteAccount")
    public ResponseVo deleteAccount() {
        String userId = request.getHeader(CommomConstant.USER_ID) == null ? "" : request.getHeader(CommomConstant.USER_ID);
        String openId = request.getHeader(CommomConstant.OPEN_ID) == null ? "" : request.getHeader(CommomConstant.OPEN_ID);
        String phone = request.getHeader(CommomConstant.PHONE) == null ? "" : request.getHeader(CommomConstant.PHONE);
        if (StringUtils.isEmpty(userId) || StringUtils.isEmpty(openId) || StringUtils.isEmpty(phone)) {
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
        }
        Map<String, String> map = new HashMap<>(3);
        map.put(CommomConstant.USER_ID, userId);
        map.put(CommomConstant.OPEN_ID, openId);
        map.put(CommomConstant.PHONE, phone);
        map.put("plat", "00");// 全网业务模块点击量统计-渠道来源：00 公众号
        wxApiClient.invalidAllAccount(map, getTransNo(request), getAccessToken(request));
        personalUtil.removeLoginInfo(phone, openId);
        logger.info("账户已注销,userId:{}", userId);
        Map<String, String> responseMap = new HashMap<>(1);
        responseMap.put("status", "00");
        return ResponseVo.success(responseMap);
    }

    /**
     * msisdn绑定iccid
     */
    @RequestMapping(value = "/bindingMsisdn", method = RequestMethod.POST)
    public ResponseVo bindMsisdn(@RequestBody Map params) {
        String msisdn = params.get(CommomConstant.MSISDN) == null ? "" : params.get(CommomConstant.MSISDN).toString();
        String iccid = params.get(CommomConstant.ICCID) == null ? "" : params.get(CommomConstant.ICCID).toString();
        String userid = request.getHeader(CommomConstant.USER_ID) == null ? "" : request.getHeader(CommomConstant.USER_ID);
        String remark = params.get(CommomConstant.REMARK) == null ? "" : params.get(CommomConstant.REMARK).toString();
        iLog.info(logger, null, null, userid + "绑定:" + msisdn + "--ICCID:" + iccid);
        if (StringUtils.isEmpty(userid) || StringUtils.isEmpty(msisdn) || StringUtils.isEmpty(iccid)) {
            iLog.error(logger, getTransNo(request), null, "缺少必要的参数,{}", params);
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
        }
        Map<String, Object> map = new HashMap<>(4);
        map.put(CommomConstant.MSISDN, msisdn);
        map.put(CommomConstant.ICCID, iccid);
        map.put(CommomConstant.USER_ID, userid);
        map.put(CommomConstant.REMARK, remark);
        map.put("plat", "00");// 全网业务模块点击量统计-渠道来源：00 公众号
        return wxApiClient.msisdnBind(map, getTransNo(request), getAccessToken(request));
    }

    /**
     * 校验 msisdn 和 iccid
     */
    @RequestMapping(value = "/checkMsisdnIccid", method = RequestMethod.POST)
    public ResponseVo checkMsisdnIccid(@RequestBody Map params) {
        String msisdn = params.get(CommomConstant.MSISDN) == null ? "" : params.get(CommomConstant.MSISDN).toString();
        String iccid = params.get(CommomConstant.ICCID) == null ? "" : params.get(CommomConstant.ICCID).toString();
        String userid = request.getHeader(CommomConstant.USER_ID) == null ? "" : request.getHeader(CommomConstant.USER_ID);
        if (StringUtils.isEmpty(userid) || StringUtils.isEmpty(msisdn) || StringUtils.isEmpty(iccid)) {
            iLog.error(logger, getTransNo(request), null, "缺少必要的参数,{}", params);
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
        }
        Map<String, Object> map = new HashMap<>(4);
        map.put(CommomConstant.MSISDN, msisdn);
        map.put(CommomConstant.ICCID, iccid);
        map.put(CommomConstant.USER_ID, userid);
        return wxApiClient.checkMsisdnIccid(map, getTransNo(request), getAccessToken(request));
    }

    /**
     * 解绑物联卡
     *
     * @param params
     * @return
     */
    @RequestMapping(value = "/unbindMsisdn", method = RequestMethod.POST)
    public ResponseVo unbindMsisdn(@RequestBody Map params) {
        try {
            String msisdn = params.get(CommomConstant.MSISDN) == null ? "" : params.get(CommomConstant.MSISDN).toString();
            String userid = request.getHeader(CommomConstant.USER_ID) == null ? "" : request.getHeader(CommomConstant.USER_ID);
            if (StringUtils.isEmpty(msisdn) || StringUtils.isEmpty(userid)) {
                return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
            }
            params.put(CommomConstant.USER_ID, userid);
            params.put("plat", "00");// 全网业务模块点击量统计-渠道来源：00 公众号
            return wxApiClient.unbindMsisdn(params, getTransNo(request), getAccessToken(request));
        } catch (Exception e) {
            return ResponseVo.fail(ResponseCode.ERROR_SYS);
        }
    }

    @RequestMapping(value = "/activateCardFromCT", method = RequestMethod.POST)
    public ResponseVo activateCardFromCT(@RequestBody Map<String, String> params) {

        String msisdn = params.get(CommomConstant.MSISDN) == null ? "" : params.get(CommomConstant.MSISDN);
        String transNo = getTransNo(request);

        if (StringUtils.isEmpty(msisdn)) {
            iLog.error(logger, transNo, null, "activateCardFromCT Fail Because params Is Missing {}", params);
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM, "激活缺少卡号!");
        }
        iLog.info(logger, transNo, null, "wx service Start to activateCardFromCT {}", params);
        return wxApiClient.activateCardFromCT(params, transNo, getAccessToken(request));
    }

    @RequestMapping(value = "/getRealNameAuthURL", method = RequestMethod.POST)
    public ResponseVo getRealNameAuthURL(@RequestHeader Map<String, String> params) {
        String transNo = getTransNo(request);
        String phone = params.getOrDefault("phone", "");
        iLog.info(logger, transNo, null, "wx service Start to getRealNameAuthURL, phone is[{}]", CommonUtils.mobileEncrypt(phone));
        logger.info("pb活体认证前参数检查：{}",JsonUtils.parseString(params));
        if (StringUtils.isEmpty(phone)) {
            iLog.error(logger, transNo, null, "getRealNameAuthURL Fail Because Phone Is Missing");
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM, "Phone Is Missing");
        }
        String userid = request.getHeader(CommomConstant.USER_ID) == null ? "" : request.getHeader(CommomConstant.USER_ID);
        String channelFrom = request.getHeader("channelFrom") == null ? "" : request.getHeader("channelFrom");
        String msgFrom = request.getHeader("msgFrom") == null ? "" : request.getHeader("msgFrom");
        params.put(CommomConstant.USER_ID, userid);
        params.put("plat", "00");// 全网业务模块点击量统计-渠道来源：00 公众号
        params.put("channelFrom",channelFrom);
        params.put("msgFrom",msgFrom);
        return wxApiClient.getRealNameAuthURL(params, transNo, getAccessToken(request));
    }


    @RequestMapping(value = "/routeRealNameAuthInfo", method = RequestMethod.POST)
    public String routeRealNameAuthInfo(@RequestParam("reqParam") String reqParamStr) {
        JSONObject reqParam = JSON.parseObject(reqParamStr);
        String transNo = getTransNo(request);
//        iLog.info(logger, transNo, reqParam, "Start to routeRealNameAuthInfo");
        String version = reqParam.getString("version");
        String sourceCode = reqParam.getString("sourceCode");
        String targetCode = reqParam.getString("targetCode");
        String busiCode = reqParam.getString("busiCode");

        if (!(!StringUtils.isEmpty(sourceCode) && !StringUtils.isEmpty(targetCode)
                && !StringUtils.isEmpty(version) && !StringUtils.isEmpty(busiCode)
                && sourceCode.equals(PersonalConstant.ONLINE_CODE) && targetCode.equals(PersonalConstant.CMIOT_CODE)
                && version.equals(PersonalConstant.MSG_VERSION))) {
            iLog.error(logger, transNo, reqParam, "reqParam busiCode /sourceCode / targetCode / version Is Not Correct");
            JSONObject result = new JSONObject(2);
            result.put("returnCode", PersonalConstant.EXCEPTION_RETURN_CODE);
            result.put("returnMessage", "reqParam busiCode /sourceCode / targetCode / version Is Not Correct");
            return result.toJSONString();
        }

        String returnJson;
        switch (busiCode) {
            case PersonalConstant.RESULT_BUSI_CODE:
                JSONObject reqInfo = reqParam.getJSONObject("reqInfo");
                String busiType = reqInfo.getString("busiType");
                if (StringUtils.isEmpty(sourceCode) || !busiType.equals(PersonalConstant.AUTH_BUSI_TYPE)) {
                    iLog.error(logger, transNo, reqParam, "reqParam busiType Is Not Correct");
                    JSONObject errorResult = new JSONObject(2);
                    errorResult.put("returnCode", PersonalConstant.EXCEPTION_RETURN_CODE);
                    errorResult.put("returnMessage", "reqParam busiType Is Not Correct");
                    returnJson = errorResult.toJSONString();
                    break;
                }

                Map<String, String> params = new HashMap<>(7);
                params.put("channelId", reqInfo.getString("channelId"));// 存库 标识平台
                params.put("transactionID", reqParam.getString("transactionID"));
                params.put("phone", reqInfo.getString("billId"));
                params.put("auditStatus", reqInfo.getString("auditStatus"));
                params.put("auditMessage", reqInfo.getString("auditMessage"));
                params.put("busiSeq", reqInfo.getString("busiSeq"));
                params.put("information", reqInfo.getString("information"));


                //transactionID  和 reqInfo 中auditStatus 和 infomation密文
                returnJson = wxApiClient.receiveAuditResult(params, transNo, getAccessToken(request));
                break;
            case PersonalConstant.DESKEY_BUSI_CODE:
                returnJson = wxApiClient.receiveDesKey(reqParam.getJSONObject("reqInfo"), transNo, getAccessToken(request));
                break;
            default:
                JSONObject errorResult = new JSONObject(2);
                errorResult.put("returnCode", PersonalConstant.EXCEPTION_RETURN_CODE);
                errorResult.put("returnMessage", "reqParam contains unknown busiCode");
                returnJson = errorResult.toJSONString();
                break;
        }
        return returnJson;
    }


    /**
     * 获取物联卡基本信息（新）
     *
     * @param params
     * @return
     */
    @RequestMapping(value = "/getMsisdnInfo", method = RequestMethod.POST)
    public ResponseVo getMsisdnInfo(@RequestBody Map params) {
        try {
            String msisdn = params.get(CommomConstant.MSISDN) == null ? "" : params.get(CommomConstant.MSISDN).toString();
            String userid = request.getHeader(CommomConstant.USER_ID) == null ? "" : request.getHeader(CommomConstant.USER_ID);
            if (StringUtils.isEmpty(msisdn) || StringUtils.isEmpty(userid)) {
                return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
            }
            params.put(CommomConstant.USER_ID, userid);
            params.put("plat", "00");// 全网业务模块点击量统计-渠道来源：00 公众号
            return wxApiClient.getMsisdnInfo(params, getTransNo(request), getAccessToken(request));
        } catch (Exception e) {
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
        }
    }


    /**
     * 获取物联卡用量信息(PB or CT)
     *
     * @param params
     */
    @RequestMapping(value = "/getSimFlowInfo", method = RequestMethod.POST)
    public ResponseVo getSimFlowInfo(@RequestBody Map params) {
        try {
            String userId = request.getHeader(CommomConstant.USER_ID) == null ? "" : request.getHeader(CommomConstant.USER_ID);
            String msisdn = params.get("msisdn") == null ? "" : params.get("msisdn").toString();
            String custId = params.get("custId") == null ? "" : params.get("custId").toString();
            String beId = params.get("beId") == null ? "" : params.get("beId").toString();
            String cardBelong = params.get("cardBelong") == null ? "" : params.get("cardBelong").toString();
            if (StringUtils.isEmpty(userId) || StringUtils.isEmpty(msisdn)) {
                iLog.error(logger, getTransNo(request), null, "缺少必要参数，请求参数:{}", params);
                return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
            }
            Map param = new HashMap(8);

            param.put("userId", userId);
            param.put("msisdn", msisdn);
            param.put("custId", custId);
            param.put("beId", beId);
            param.put("cardBelong", cardBelong);
            param.put("plat", "00");// 全网业务模块点击量统计-渠道来源：00 公众号
            ResponseVo responseVo = wxApiClient.getSimFlowInfo(param, getTransNo(request), getAccessToken(request));
            return responseVo;
        } catch (Exception e) {
            iLog.error(logger, getTransNo(request), null, "获取用量信息异常，参数:{}", e, params);
            return ResponseVo.fail(ResponseCode.ERROR_SYS);
        }
    }


    /**
     * 修改备注
     *
     * @param params
     * @return
     */
    @RequestMapping(value = "/modifyRemark", method = RequestMethod.POST)
    public ResponseVo modifyRemark(@RequestBody Map params) {
        try {
            String msisdn = params.get(CommomConstant.MSISDN) == null ? "" : params.get(CommomConstant.MSISDN).toString();
            String userid = request.getHeader(CommomConstant.USER_ID) == null ? "" : request.getHeader(CommomConstant.USER_ID).toString();
            if (StringUtils.isEmpty(msisdn) || StringUtils.isEmpty(userid)) {
                iLog.error(logger, getTransNo(request), null, "缺少必要参数，{}", params);
                return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
            }
            params.put(CommomConstant.USER_ID, userid);
            Map qryParams = new HashMap();
            qryParams.putAll(params);
            qryParams.put(CommomConstant.USER_ID, userid);
            qryParams.put("plat", "00");// 全网业务模块点击量统计-渠道来源：00 公众号
            return wxApiClient.modifyRemark(qryParams, getTransNo(request), getAccessToken(request));
        } catch (Exception e) {
            iLog.error(logger, getTransNo(request), null, "修改备注异常，参数:{}", e, params);
            return ResponseVo.fail(ResponseCode.ERROR_SYS);
        }
    }

    /**
     * CT充值缴费接口
     *
     * @param map
     * @return
     */
    @RequestMapping(value = "/chargeOfCT", method = RequestMethod.POST)
    public ResponseVo chargeOfCT(@RequestBody Map map) {
        try {
            logger.info("CT充值chargeOfCT...{}",JsonUtils.parseString(map));
            String userId = request.getHeader(CommomConstant.USER_ID) == null ? "" : request.getHeader(CommomConstant.USER_ID);
//            String beid = map.get(CommomConstant.BEID) == null ? "" : map.get(CommomConstant.BEID).toString();
//            String custid = map.get(CommomConstant.CUSTID) == null ? "" : map.get(CommomConstant.CUSTID).toString();
            String msisdn = map.get(CommomConstant.MSISDN) == null ? "" : map.get(CommomConstant.MSISDN).toString();
            String money = map.get(CommomConstant.CHARGE_MONEY) == null ? "" : map.get(CommomConstant.CHARGE_MONEY).toString();
            if (StringUtils.isEmpty(userId) || StringUtils.isEmpty(msisdn) || StringUtils.isEmpty(money)) {
                iLog.error(logger, getTransNo(request), null, "缺少必要参数，请求参数:{}", map);
                return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
            }
            // 封装微信端参数
            map.put(CommomConstant.USER_ID, userId);
            map.put("clientIp", getIP(request));
            map.put("payedType", "01");
            map.put("defaultBank", "");//默认银行编码
            map.put("entityType", "2");//2:账户Id充值
            ResponseVo responseVo = weChatService.getSysParamById(getTransNo(request), CommomConstant.WX_CT_CHARGE_RETURN_URL);
            String returnURL;
            if (responseVo.isSuccess()) {
                returnURL = responseVo.getData().toString();
                map.put("returnURL", returnURL);
                iLog.info(logger, getTransNo(request), null, "微信平台CT充值 获取系统参数retrunURL成功：{}", returnURL);
            } else {
                iLog.error(logger, getTransNo(request), null, "微信平台CT充值 获取系统参数retrunURL失败！");
                return ResponseVo.fail(ResponseCodeConstant.SEARCH_FAILED);
            }
            map.put("paymentType", CommomConstant.PAY_TYPE_WX);
            map.put("channelId", CommomConstant.PLATFORM_WX_OA);
            map.put("cardBelong", CommomConstant.CARD_BELONG_CT);
            map.put("plat", "00");// 全网业务模块点击量统计-渠道来源：00 公众号
            return chargeClient.CTrecharge(map, getTransNo(request));
        } catch (Exception e) {
            iLog.error(logger, getTransNo(request), null, "充值操作发生异常，请求参数:{}", e, map);
            return ResponseVo.fail(ResponseCode.ERROR_SYS);
        }
    }

    /**
     * 获取物联卡套餐信息(PB or CT)
     *
     * @param params
     * @return
     */
    @RequestMapping(value = "/getProductInfo", method = RequestMethod.POST)
    public ResponseVo getProductInfo(@RequestBody Map params) {
        try {
            String userId = request.getHeader(CommomConstant.USER_ID) == null ? "" : request.getHeader(CommomConstant.USER_ID);
            String msisdn = params.get("msisdn") == null ? "" : params.get("msisdn").toString();
            String prodInstIds = params.get("prodInstIds") == null ? "" : params.get("prodInstIds").toString();
            String cardBelong = params.get("cardBelong") == null ? "" : params.get("cardBelong").toString();
            List<String> apnNames = params.get("apnNames") == null ? new ArrayList<>() : (List<String>) params.get("apnNames");
            if ("00".equals(cardBelong)) {
                if (StringUtils.isEmpty(prodInstIds) || StringUtils.isEmpty(userId) || StringUtils.isEmpty(msisdn)) {
                    iLog.error(logger, getTransNo(request), null, "缺少必要参数，请求参数:{}", params);
                    return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
                }
            } else {
                if (StringUtils.isEmpty(prodInstIds) || StringUtils.isEmpty(userId) || StringUtils.isEmpty(msisdn) || apnNames.size() == 0) {
                    iLog.error(logger, getTransNo(request), null, "缺少必要参数，请求参数:{}", params);
                    return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
                }
            }
            Map param = new HashMap(8);

            param.put("prodInstIds", prodInstIds);
            param.put("apnNames", apnNames);
            param.put("userId", userId);
            param.put("msisdn", msisdn);
            param.put("cardBelong", cardBelong);
            param.put("plat", "00");// 全网业务模块点击量统计-渠道来源：00 公众号
            return wxApiClient.getProductInfo(param, getTransNo(request), getAccessToken(request));

        } catch (Exception e) {
            iLog.error(logger, getTransNo(request), null, "查询套餐发生异常，请求参数:{}", e, params);
            return ResponseVo.fail(ResponseCode.ERROR_SYS);
        }
    }

    /**
     * 获取实名状态
     *
     * @return
     */
    @RequestMapping(value = "/getVerifiedStatus", method = RequestMethod.POST)
    public ResponseVo getVerifiedStatus() {
        String userId = request.getHeader(CommomConstant.USER_ID) == null ? "" : request.getHeader(CommomConstant.USER_ID);
        if (StringUtils.isEmpty(userId)) {
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
        }
        Map<String, String> map = new HashMap<>(1);
        map.put("userId", userId);
        return wxApiClient.getVerifiedStatus(map, getTransNo(request), getAccessToken(request));
    }

    @RequestMapping("/getBaseInfo")
    public ResponseVo getBaseInfo(@RequestBody Map map) {
        String ticket = (String) map.get("ticket");
        if (StringUtils.isEmpty(ticket)) {
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
        }
        String value = cache.get(CacheManager.PublicNameSpace.TEMP, CommomConstant.CAHCE_LOGIN_TICKET_PRE + ticket);
        if (value == null || "".equals(value)) return ResponseVo.fail("99");
        String[] baseInfo = value.split(",");
        Map<String, String> baseInfoMap = new HashMap<>(3);
        baseInfoMap.put("openId", baseInfo[0]);
        baseInfoMap.put("phone", baseInfo[1]);
        baseInfoMap.put("userId", baseInfo[2]);
        return ResponseVo.success(baseInfoMap);
    }

    @RequestMapping("/authorityLess")
    public ResponseVo authorityLess() {
        return ResponseVo.fail(ResponseCodeConstant.RESPONSE_CODE_USER_OTHERPLACE_LOGIN);
    }


    @RequestMapping("/wxJSSignature")
    public ResponseVo wxJSSignature(@RequestBody Map<String, String> map) {
        AppInfoEntity appInfoEntity = (AppInfoEntity) weChatService.getAppIdAndSecret(getTransNo(request)).getData();
        String appId = appInfoEntity.getAppid();
        String signatureUrl = map.get("signatureUrl");
        String timeStamp = Long.toString(System.currentTimeMillis() / 1000);
        String nonceStr = UUID.randomUUID().toString();
        String signature = iWeiXinService.getJSSDKSignatrue(getTransNo(request), nonceStr, timeStamp, signatureUrl);
        Map<String, String> responseMap = new HashMap<>(4);
        responseMap.put("appId", appId);
        responseMap.put("timestamp", timeStamp);
        responseMap.put("nonceStr", nonceStr);
        responseMap.put("signature", signature);
        return ResponseVo.success(responseMap);
    }

    /**
     * 校验物联卡是否已被实名登记
     * 2019-03-07 该方法废弃，已被其他人实现
     *
     * @param msisdn    物联卡号
     * @param custCerNo 身份证号
     * @return
     */
    @Deprecated
    @GetMapping(value = "/isRegistSuccess")
    public ResponseVo isRegistSuccess(@RequestParam(value = "msisdn", required = true) String msisdn, @RequestParam(value = "custCerNo", required = true) String custCerNo) {
        if (StringUtils.isEmpty(msisdn) || StringUtils.isEmpty(custCerNo)) {
            return ResponseVo.fail(ResponseCodeConstant.PARAM_ILLEGALLY);
        }
        Map map = new HashMap<>();
        map.put("msisdn", msisdn);
        ResponseVo resp = wxApiClient.getSuccessRegisterInfo(map, getTransNo(request), getAccessToken(request));
        switch (resp.getCode()) {
            case "0":
                return ResponseVo.success(ResponseCodeConstant.AUTHENTICATE_SUCCESS);
            case "22":
                Map data = (Map) resp.getData();
                String certNo = (String) data.get("custCerNo");
                return custCerNo.equals(certNo) ? ResponseVo.fail(ResponseCodeConstant.AUTHED_BY_SELF) : ResponseVo.fail(ResponseCodeConstant.AUTHED_BY_OTHER);
            case "002":
                return ResponseVo.fail(ResponseCodeConstant.SEARCH_FAILED);
            default:
                return ResponseVo.fail(ResponseCodeConstant.SEARCH_FAILED);
        }
    }

    /**
     * 校验实名认证时用户输入身份信息与账号实名信息是否一致
     *
     * @param map
     * @return
     */
    @PostMapping(value = "/userIdentityValidate")
    public ResponseVo userIdentityValidate(@RequestBody Map map) {
        ParamChecker pc = ParamChecker.newInstance()
                .notBlankCheck("name", map.getOrDefault("name", "").toString())
                .notBlankCheck("custCertId", map.getOrDefault("custCertId", "").toString())
                .notBlankCheck("userId", request.getHeader("userId"));
        map.put("userId", request.getHeader("userId"));
        if (pc.isNotValid()) {
            iLog.error(logger, getTransNo(request), null, "缺少必要的参数,{}", map);
            return ResponseVo.fail(ResponseCodeConstant.PARAM_ILLEGALLY);
        }
        return wxApiClient.isUserIdentityInfo(map, getTransNo(request), getAccessToken(request));
    }


    /**
     * 身份证ocr识别
     *
     * @param mediaId
     * @return
     */
    @GetMapping(value = "/ocr")
    public ResponseVo ocr(@RequestParam(value = CommomConstant.MSISDN) String msisdn, @RequestParam(value = CommomConstant.MEDIA_ID) String mediaId,
                          @RequestParam(value = "type") String type) {
        Map ocrResultMap;
        String transNo = getTransNo(request);
        String userId = request.getHeader(CommomConstant.USER_ID);
        ResponseVo tokenResp = iWeiXinService.getAccessToken(transNo);
        if (!tokenResp.isSuccess()) {
            iLog.error(logger, transNo, null, "OCR证件扫描时获取微信ACCESS_TOKEN失败！");
            return ResponseVo.fail(ResponseCodeConstant.GET_WX_ACCESS_TOKEN_FAILED);
        }
        String wxAccessToken = tokenResp.getData().toString();
        ResponseVo dir = weChatService.getSysParamById(transNo, BaseUtil.REAL_NAME_REGISTER_LOCAL);
        if (!dir.isSuccess()) {
            iLog.error(logger, transNo, null, "ocr证件扫描时获取素材文件临时存放地址失败！");
            return ResponseVo.fail(ResponseCodeConstant.SEARCH_FAILED);
        }
        String newFileName = new StringBuilder(CommomConstant.PLATFORM_WX_OA).append("_").append(new SimpleDateFormat("yyyyMMddHHmmss").format(new Date())).append("_").append(userId).append("_").append(msisdn).toString();
        File file = null;
        if (mediaId.startsWith("realName")) {
            /**
             * 为了兼容实名登记H5的功能添加，文件获取新的渠道
             * lixiangcheng
             * 2020-07-27
             * */
            logger.info("transNo is:[{}],实名登记H5流量，msisdn is:[{}],mediaId is:[{}]", transNo, msisdn, mediaId);
            String sourcePath = cache.get(CacheManager.PublicNameSpace.TEMP, mediaId);
            if (!StringUtils.isEmpty(sourcePath)) {
                String destPath = new StringBuilder(String.valueOf(dir.getData()))
                        .append(File.separatorChar)
                        .append(CommomConstant.PLATFORM_WX_OA)
                        .append(File.separator)
                        .append(new SimpleDateFormat("yyyy-MM-dd").format(new Date()))
                        .append(File.separatorChar)
                        .append(newFileName)
                        .append(".jpg").toString();
                file = publicUtils.getTempFile(sourcePath, destPath);
            }
        } else {
            //微信服务器拉取文件
            file = iWeiXinService.getMedia(transNo, wxAccessToken, mediaId, dir.getData().toString(), newFileName);
        }
        if (null == file) {
            iLog.error(logger, transNo, null, "OCR证件扫描下载临时素材失败！, media_id：{}", mediaId);
            return ResponseVo.fail(ResponseCodeConstant.PULL_WX_MEDIA_FAILED, new String[]{"OCR证件扫描下载临时素材失败"});
        }
        //打印证件图片大小
        iLog.info(logger, transNo, null, type + "图片大小为=====>：" + String.format("%.1f", file.length() / 1024.0) + "KB");
        //身份证有效期是否做校验
        //单张照片大小大于50KB，小于300KB验证
        File destFile;
        if (FileUtil.getBytes(file).length > CommomConstant.REAL_NAME_FILE_MAX) {
            String imgdist = publicUtils.reScaleImg(false,file);
            destFile = new File(imgdist);
            iLog.error(logger, transNo, null, "图片缩放处理图片大小为：" + String.format("%.1f", destFile.length() / 1024.0) + "KB");
            if (FileUtil.getBytes(destFile).length > CommomConstant.REAL_NAME_FILE_MAX) {
                iLog.error(logger, transNo, null, "图片缩放处理后图片大小仍不符合上传要求，当前图片大小为：" + String.format("%.1f", destFile.length() / 1024.0) + "KB");
                return ResponseVo.fail(ResponseCode.ERROR_FILE_OVER_MAXSIZE, new String[]{"源文件处理后仍大于300KB，不符合系统规范，请适当减小源文件大小"});
            }
        } else if (FileUtil.getBytes(file).length < CommomConstant.REAL_NAME_FILE_MIN) {
            logger.info("实名登记上传图像小于50KB,不进行文件处理，返回错误信息");
            return ResponseVo.fail(ResponseCode.ERROR_FILE_OVER_MAXSIZE, new String[]{"源文件小于50KB，不符合系统规范，请重新选择文件上传"});
//            destFile = file;
        } else {
            destFile = file;
        }
        //TODO 缓存文件参数至redis，以便下一步提交登记信息使用，添加缓存过期时间
        String base64File = new String(Base64.encodeBase64(FileUtil.getBytes(destFile)));
        cache.put(CacheManager.PublicNameSpace.TEMP, mediaId, base64File,60*60*24);
        //是否启动OCR扫描模拟测试(添加这个的原因是因为测试环境不能做微信OCR扫描)
        String isOpenOCRMockTest = cache.getSysParams("WX.OCR.IS_OPEN_OCR_MOCK", "1");
        //开启ocr扫描模拟测试
        if (ResponseCode.SUCCESS.equals(isOpenOCRMockTest)) {
//            ocrResultMap = publicUtils.getTestOcrData(transNo, type);
//            if (!ResponseCode.SUCCESS.equals(String.valueOf(ocrResultMap.get("errcode")))) {
//                logger.error("transNo is:[{}],OCR扫描证件失败:,code is:[{}]", transNo, ocrResultMap.get("errcode"));
            logger.info("已关闭OCR识别功能");
            ResponseVo responseVo = ResponseVo.fail(ResponseCodeConstant.CERNO_OCR_RECOGNITION_FAILED, new String[]{"证件识别失败"});
            responseVo.setData(file.getPath());
            return responseVo;
//            }
        } else {
            /**
             * TODO 生产实际运行逻辑，调用OCR服务接口
             * 2020-11-16 因OCR服务到期，且12月会改版为活体认证，关闭OCR识别功能
             * ResponseVo ocrResp = iWeiXinService.wxOCRRecognition(transNo, "photo", destFile, wxAccessToken);
             */
            ResponseVo ocrResp = ResponseVo.fail(ResponseCode.ERROR_OBJECT_NOT_EXIST);
            if (!ocrResp.isSuccess()) {
                iLog.error(logger, transNo, null, "OCR扫描证件失败: {}", ocrResp.getCode());
                /**
                 * 这里是否要删除文件
                 * 2020-07-17
                 * 因开放用户手动填写数据，即使OCR识别失败任然需要保留图像文件
                 * FileUtils.deleteFile(destFile);
                 * FileUtils.deleteFile(file);
                 * */
                ResponseVo responseVo = ResponseVo.fail(ResponseCodeConstant.CERNO_OCR_RECOGNITION_FAILED, new String[]{"证件识别失败"});
                responseVo.setData(file.getPath());
                return responseVo;
            }
            ocrResultMap = (Map) ocrResp.getData();
        }
        iLog.info(logger, transNo, null, "本次OCR扫描结果为:{}", ocrResultMap);
        ocrResultMap.put("mediaFilePath", file.getPath());
        return ResponseVo.success(ocrResultMap);
    }

    /**
     * 2.1.3.5.3	身份信息录入
     * func：手持身份证物联卡实名登记
     *
     * @deprecated 已废弃
     * 4.300.8.8版本
     */
    @PostMapping(value = "/realNameReg")
    public ResponseVo realNameAuth(@RequestBody Map map) {
        String iccId = (String) map.get(CommomConstant.ICCID);
        String msisdn = (String) map.get(CommomConstant.MSISDN);
        //别名
//        String alias = map.getOrDefault(CommomConstant.ALIAS, "").toString();
        //省份ID
        String beId = map.getOrDefault(CommomConstant.BEID, "").toString();
        String custId = map.getOrDefault(CommomConstant.CUSTID, "").toString();
        String userId = request.getHeader(CommomConstant.USER_ID);
        // 输入的姓名
        String formCustName = (String) map.get(CommomConstant.FORM_CUST_NAME);
        // 输入的身份证号
        String formCustCerNo = (String) map.get(CommomConstant.FORM_CUST_CERNO);
        // 手机号
        String phone = map.getOrDefault(CommomConstant.CUST_PHONE_NO, "").toString();
        // 物联卡套餐信息(PB or CT)
        String pbOrct = (String) map.get(CommomConstant.PB_OR_CT);
        //头像微信临时素材文件ID
        String mediaIdR = (String) map.get(CommomConstant.MEDIA_ID_R);
        String transNo = getTransNo(request);
        String accessToken = getAccessToken(request);
        // 实名登记认证成功后是否激活物联卡
//        String isActive = map.getOrDefault(CommomConstant.IS_ACTIVE, "1").toString();
        // 3.7改造升级
        String custCertAddr = (String) map.get(CommomConstant.CUST_CERT_ADDR);//身份证地址
        String certValiddate = (String) map.get(CommomConstant.CERT_VALIDDATE);//身份证生效时间
        String certExpdate = (String) map.get(CommomConstant.CERT_EXPDATE);//身份证失效时间
        String gender = (String) map.get(CommomConstant.GENDER);//性别
        String nation = (String) map.get(CommomConstant.NATION);//民族
        String birthday = (String) map.get(CommomConstant.BIRTHDAY);//生日
        String issuingAuthority = (String) map.get(CommomConstant.ISSUING_AUTHORITY);//签证机关
        String fileZPath = (String) map.get(CommomConstant.MEDIA_FILE_Z_PATH);//已下载的证件正面地址
        String fileFPath = (String) map.get(CommomConstant.MEDIA_FILE_F_PATH);//已下载的证件反面地址
        String mediaIdZ = (String) map.get(CommomConstant.MEDIA_ID_Z);//正面微信临时素材文件ID
        String mediaIdF = (String) map.get(CommomConstant.MEDIA_ID_F);//背面微信临时素材文件ID
        String plat = map.getOrDefault(CommomConstant.BUSINESS_PLAT, "").toString();
        /* 参数校验 */
        ParamChecker pc = ParamChecker.newInstance()
                .notBlankCheck(InteConstants.ICCID, iccId)
                .notBlankCheck(InteConstants.MSISDN, msisdn)
                .notBlankCheck(CommomConstant.FORM_CUST_NAME, formCustName)
                .notBlankCheck(CommomConstant.FORM_CUST_CERNO, formCustCerNo)
                .notBlankCheck(CommomConstant.CUST_PHONE_NO, phone)
                .notBlankCheck(CommomConstant.PB_OR_CT, pbOrct)
                .notBlankCheck(CommomConstant.MEDIA_ID_R, mediaIdR)
                .notBlankCheck(CommomConstant.BEID, beId)
                .notBlankCheck(CommomConstant.USER_ID, userId)
                // 3.7改造升级
                .notBlankCheck(CommomConstant.CUST_CERT_ADDR, custCertAddr)
                .notBlankCheck(CommomConstant.CERT_VALIDDATE, certValiddate)
                .notBlankCheck(CommomConstant.CERT_EXPDATE, certExpdate)
                .notBlankCheck(CommomConstant.GENDER, gender)
                .notBlankCheck(CommomConstant.NATION, nation)
                .notBlankCheck(CommomConstant.BIRTHDAY, birthday)
                .notBlankCheck(CommomConstant.ISSUING_AUTHORITY, issuingAuthority)
                .notBlankCheck(CommomConstant.MEDIA_FILE_Z_PATH, fileZPath)
                .notBlankCheck(CommomConstant.MEDIA_FILE_F_PATH, fileFPath)
                .notBlankCheck(CommomConstant.MEDIA_ID_Z, mediaIdZ)
                .notBlankCheck(CommomConstant.MEDIA_ID_F, mediaIdF)
                .notBlankCheck(CommomConstant.BUSINESS_PLAT, plat);

        if ("01".equals(pbOrct)) {//PB没有custId
            pc.notBlankCheck(CommomConstant.CUSTID, custId);
        }
        switch (gender) {
            case "男":
                gender = "1";
                break;
            case "女":
                gender = "0";
                break;
            default:
                break;
        }
        map.put(CommomConstant.GENDER, gender);

        // 缺少必要参数
        if (pc.isNotValid()) {
            iLog.error(logger, getTransNo(request), null, "必要参数缺失", map);
            return ResponseVo.fail(ResponseCodeConstant.PARAM_ILLEGALLY);
        }
        // 获取微信access_token
        ResponseVo tokenResp = iWeiXinService.getAccessToken(transNo);
        if (!tokenResp.isSuccess()) {
            // 获取access_token失败
            return ResponseVo.fail(ResponseCodeConstant.GET_WX_ACCESS_TOKEN_FAILED);
        }
        // 按规则定义文件名
        String fileName = new StringBuilder(CommomConstant.PLATFORM_WX_OA)
                .append("_")
                .append(new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()))
                .append("_")
                .append(userId)
                .append("_")
                .append(msisdn).toString();

        String wxAccessToken = tokenResp.getData().toString();
        // 调用微信临时素材接口拉取用户上传证件 从缓存获取实名登记图片存放目录
        String wx_media_download_dir;
        ResponseVo mediaDir = weChatService.getSysParamById(transNo, BaseUtil.REAL_NAME_REGISTER_LOCAL);
        if (mediaDir.isSuccess()) {
            wx_media_download_dir = mediaDir.getData().toString();
        } else {
            return ResponseVo.fail(ResponseCodeConstant.SEARCH_FAILED);
        }

        //获取头像文件
        /**
         * TODO 为提高实名登记成功率，强制缩放正面头像照长宽比（16:9）
         * 图像大小也需要满足 50~300KB要求
         * */
        File fileR = null;
        if (mediaIdR.startsWith("realName")) {
            /**
             * 为了兼容实名登记H5的功能添加，文件获取新的渠道
             * lixiangcheng
             * 2020-07-27
             * */
            logger.info("transNo is:[{}],实名登记H5流量，msisdn is:[{}],mediaId is:[{}]", transNo, msisdn, mediaIdR);
            String sourcePath = cache.get(CacheManager.PublicNameSpace.TEMP, mediaIdR);
            if (!StringUtils.isEmpty(sourcePath)) {
                String destPath = new StringBuilder(wx_media_download_dir)
                        .append(File.separatorChar)
                        .append(CommomConstant.PLATFORM_WX_OA)
                        .append(File.separator)
                        .append(new SimpleDateFormat("yyyy-MM-dd").format(new Date()))
                        .append(File.separatorChar)
                        .append(fileName + "_R")
                        .append(".jpg").toString();
                fileR = publicUtils.getTempFile(sourcePath, destPath);
            }
        } else {
            fileR = iWeiXinService.getMedia(transNo, wxAccessToken, mediaIdR, wx_media_download_dir, fileName + "_R");
        }
        File newFileR = null;
        if (fileR == null) {
            iLog.error(logger, getTransNo(request), null, "拉取微信临时素材R失败！media_id_R is [{}]", mediaIdR);
            return ResponseVo.fail(ResponseCodeConstant.PULL_WX_MEDIA_FAILED, new String[]{"未获取到现场人像照，请重新上传"});
        } else {
            //人像文件比例处理
            try {
                newFileR = publicUtils.translateFile(fileR);
            }catch (Exception e){
                logger.error("实名登记现场人像照片预处理失败：".concat(e.getMessage()));
                return ResponseVo.fail(ResponseCodeConstant.PARAM_ILLEGALLY,new String[]{e.getMessage()});
            }
        }
        // 判断是否登记成功
        map.put("userId", userId);
        map.put("transNo", transNo);
        map.put("accessToken", accessToken);
        if (newFileR == null) {
            logger.info("transNo is:[{}],get new fileR fail,返回错误提示给前端", getTransNo(request));
            return ResponseVo.fail(ResponseCodeConstant.PARAM_ILLEGALLY, new String[]{"现场人像照处理后仍大于300KB，不符合系统规范，请适当减小源文件大小"});
        } else {
            map.put("fileR", newFileR);
        }
        //拉取微信临时素材证件正面照片
        String base64FileZ = cache.get(CacheManager.PublicNameSpace.TEMP, mediaIdZ);
        if (StringUtils.isEmpty(base64FileZ)) {
            iLog.error(logger, getTransNo(request), null, "从缓存中拉取微信素材临时文件失败！media_id_Z is [{}]", mediaIdZ);
            return ResponseVo.fail(ResponseCodeConstant.PULL_WX_MEDIA_FAILED, new String[]{"未获取到身份证正面照片，请重新上传"});
        }
        map.put("base64FileZ", base64FileZ);
        cache.remove(CacheManager.PublicNameSpace.TEMP, mediaIdZ);

        //拉取微信临时素材证件背面照片
        String base64FileF = cache.get(CacheManager.PublicNameSpace.TEMP, mediaIdF);
        if (StringUtils.isEmpty(base64FileF)) {
            iLog.error(logger, getTransNo(request), null, "从缓存中拉取微信素材临时文件失败！media_id_F is [{}]", mediaIdF);
            return ResponseVo.fail(ResponseCodeConstant.PULL_WX_MEDIA_FAILED, new String[]{"未获取到身份证反面照片，请重新上传"});
        }
        map.put("base64FileF", base64FileF);
        cache.remove(CacheManager.PublicNameSpace.TEMP, mediaIdF);

        switch (pbOrct) {
            case "00":// TODO 前端已屏蔽 PB卡直接登记成功
                ResponseVo respPb = doRealNameRegSaveBindActive(wx_media_download_dir, map);
                return respPb.isSuccess() ? ResponseVo.success(ResponseCodeConstant.AUTHENTICATE_SUCCESS) : ResponseVo.fail(ResponseCodeConstant.SAVE_REGISTER_INFO_FAILED);
            case "01"://CT卡加入多线程调CT接口
                FIXED_THREAD_POOL.execute(() -> {
                    iLog.info(logger, map.get("transNo").toString(), null, "调用CT实名认证接口线程池使用量：", ((ThreadPoolExecutor) FIXED_THREAD_POOL).getActiveCount());
                    ResponseVo respCt = doRealNameRegSaveBindActive(wx_media_download_dir, map);
                    Map<String, String> smsDataMap = (Map) respCt.getData();
                    //CT卡发送实名登记短信结果通知
                    sendRegisterResult(smsDataMap, map.get("transNo").toString(), map.get("accessToken").toString());
                });
                return ResponseVo.success(ResponseCodeConstant.AUTHENTICATE_SUCCESS);//资料提交成功
            default:
                iLog.error(logger, getTransNo(request), null, "参数pbOrct错误：{}", pbOrct);
                //默认异常
                return ResponseVo.fail(ResponseCodeConstant.PARAM_ILLEGALLY);
        }
    }

    /**
     * 下发登记结果短信
     *
     * @param
     * @return
     */
    private ResponseVo sendRegisterResult(Map map, String transNo, String accessToken) {
        MapParamChecker mapParamChecker = MapParamChecker.instance(map)
                .isNotBlank("phone")
                .isNotBlank(CommomConstant.MSISDN)
                .isNotBlank(CommomConstant.CODE)
                .isNotBlank(CommomConstant.REASON);
        if (mapParamChecker.isValid()) {
            return wxApiClient.sendRegisterResult(map, transNo, accessToken);
        }
        iLog.error(logger, transNo, map, "实名登记结果短信下发参数缺失", map);
        return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM, "miss param");
    }


    /**
     * @param wx_media_download_dir
     * @param map
     * @return
     */
    private ResponseVo doRealNameRegSaveBindActive(String wx_media_download_dir, Map map) {
        File fileR = (File) map.get("fileR");
        String msisdn = (String) map.get(CommomConstant.MSISDN);
        String iccId = (String) map.get(CommomConstant.ICCID);
        String beId = map.getOrDefault(CommomConstant.BEID, "").toString(); //省份ID
        String alias = map.getOrDefault(CommomConstant.ALIAS, "").toString();//别名
        String userId = map.getOrDefault(CommomConstant.USER_ID, "").toString();
        String custId = map.getOrDefault(CommomConstant.CUSTID, "").toString();
        String formCustCerNo = (String) map.get(CommomConstant.FORM_CUST_CERNO);// 输入的身份证号
        String formCustName = (String) map.get(CommomConstant.FORM_CUST_NAME); // 输入的姓名
        String pbOrct = (String) map.get(CommomConstant.PB_OR_CT);// 物联卡套餐信息(PB or CT)
        String phone = map.getOrDefault(CommomConstant.CUST_PHONE_NO, "").toString();// 手机号
//        String accessToken = map.getOrDefault("transNo", "").toString();
        String transNo = map.getOrDefault("transNo", "").toString();
//        String transNo = map.getOrDefault("accessToken", "").toString();
        String accessToken = map.getOrDefault("accessToken", "").toString();
        String isHandleCard = "0";
        String isActive = map.getOrDefault(CommomConstant.IS_ACTIVE, "1").toString(); // 实名登记认证成功后是否激活物联卡
        String registerCode = "";
        Map regMap = new HashMap(13);
        //调用CT接口失败返回信息
        Map<String, String> registerDataMap = new HashMap<>(4);
        registerDataMap.put("phone", phone);
        registerDataMap.put(CommomConstant.MSISDN, msisdn);
        switch (pbOrct) {
            case "00":
                // PB 直接登记成功
                registerCode = CommomConstant.RESPONSE_CODE_SUCCESS;
                regMap.put(CommomConstant.REGISTER_CODE, CommomConstant.RESPONSE_CODE_SUCCESS);
                break;
            case "01":
                // 调用CT实名登记接口
                Map ctReqMap = new HashMap(10);
                ctReqMap.put(CommomConstant.MSISDN, msisdn);
                ctReqMap.put(CommomConstant.ICCID, iccId);
                ctReqMap.put(CommomConstant.CUST_NAME, formCustName);
                ctReqMap.put(CommomConstant.CUST_CERT_NO, formCustCerNo);
                ctReqMap.put(CommomConstant.CUST_PHONE_NO, phone);
                // 是否为手持身份证照片
                ctReqMap.put(CommomConstant.IS_HANDLE_CARD, isHandleCard);
                // 人像图片Base64字符串
                String base64R = new String(Base64.encodeBase64(FileUtil.getBytes(fileR)));
                ctReqMap.put(CommomConstant.PIC_NAME_R, base64R);
                // 3.7升级改造
                ctReqMap.put(CommomConstant.CUST_CERT_ADDR, map.get(CommomConstant.CUST_CERT_ADDR));
                ctReqMap.put(CommomConstant.CERT_VALIDDATE, map.get(CommomConstant.CERT_VALIDDATE));
                ctReqMap.put(CommomConstant.CERT_EXPDATE, map.get(CommomConstant.CERT_EXPDATE));
                ctReqMap.put(CommomConstant.GENDER, map.get(CommomConstant.GENDER));
                ctReqMap.put(CommomConstant.NATION, map.get(CommomConstant.NATION));
                ctReqMap.put(CommomConstant.BIRTHDAY, map.get(CommomConstant.BIRTHDAY));
                ctReqMap.put(CommomConstant.ISSUING_AUTHORITY, map.get(CommomConstant.ISSUING_AUTHORITY));
                ctReqMap.put(CommomConstant.PIC_NAME_Z, map.get("base64FileZ"));
                ctReqMap.put(CommomConstant.PIC_NAME_T, map.get("base64FileZ"));//当isHandleCard=0时，该字段必传； （用户身份证芯片头像图片）
                ctReqMap.put(CommomConstant.PIC_NAME_F, map.get("base64FileF"));
                ctReqMap.put(CommomConstant.BEID, beId);
                ctReqMap.put(CommomConstant.CUSTID, custId);
                ResponseVo ctResp = wxApiClient.realNameRegist(ctReqMap, transNo, accessToken);
                switch (ctResp.getCode()) {
                    case "0":
                        // 登记成功
                        registerCode = CommomConstant.RESPONSE_CODE_SUCCESS;
                        break;
                    case "40130":
                        // ICCID和MSISDN对应关系错误
                        registerDataMap.put(CommomConstant.CODE, ResponseCodeConstant.AUTHENTICATE_FAILED);
                        registerDataMap.put(CommomConstant.REASON, "ICCID和MSISDN对应关系错误");
                        registerCode = ResponseCodeConstant.AUTHENTICATE_FAILED;
                        break;
                    case "40131":
                        // 该卡实名登记请求次数已超过系统每日最大限制（10次）
                        registerDataMap.put(CommomConstant.CODE, ResponseCodeConstant.MSISDN_AUTHED_DAILY_LIMIT);
                        registerDataMap.put(CommomConstant.REASON, "该卡实名登记请求次数已超过系统每日最大限制（10次）");
                        registerCode = ResponseCodeConstant.MSISDN_AUTHED_DAILY_LIMIT;
                        break;
                    case "40132":
                        // 该卡已被其他人实名登记
                        registerDataMap.put(CommomConstant.CODE, ResponseCodeConstant.AUTHED_BY_OTHER);
                        registerDataMap.put(CommomConstant.REASON, "该卡已被其他人实名登记");
                        registerCode = ResponseCodeConstant.AUTHED_BY_OTHER;
                        break;
                    case "40133":
                        // 该卡你已实名登记，无需重复实名登记（设置为登记成功，再次保存）
                        registerCode = "00000";
                        break;
                    case "40134":
                        // 人证比对不一致
                        registerDataMap.put(CommomConstant.CODE, ResponseCodeConstant.AUTHED_INFO_INVALID);
                        registerDataMap.put(CommomConstant.REASON, "人证比对不一致");
                        registerCode = ResponseCodeConstant.AUTHED_INFO_INVALID;
                        break;
                    case "40135":
                        // 手机号码格式错误
                        registerDataMap.put(CommomConstant.CODE, ResponseCodeConstant.PHONE_NO_FORMAT_ERR);
                        registerDataMap.put(CommomConstant.REASON, "手机号码格式错误");
                        registerCode = ResponseCodeConstant.PHONE_NO_FORMAT_ERR;
                        break;
                    case "40136":
                        // 手机号码位数错误
                        registerDataMap.put(CommomConstant.CODE, ResponseCodeConstant.PHONE_NO_DIGIT_ERR);
                        registerDataMap.put(CommomConstant.REASON, "手机号码位数错误");
                        registerCode = ResponseCodeConstant.PHONE_NO_DIGIT_ERR;
                        break;
                    case "40137":
                        // 身份证号码位数错误
                        registerDataMap.put(CommomConstant.CODE, ResponseCodeConstant.CERT_NO_DIGIT_ERR);
                        registerDataMap.put(CommomConstant.REASON, "身份证号码位数错误");
                        registerCode = ResponseCodeConstant.CERT_NO_DIGIT_ERR;
                        break;
                    case "40138":
                        // 该卡正在认证，请稍候再试
                        registerDataMap.put(CommomConstant.CODE, ResponseCodeConstant.MSISDN_IN_AUTH);
                        registerDataMap.put(CommomConstant.REASON, "该卡正在认证，请稍候再试");
                        registerCode = ResponseCodeConstant.MSISDN_IN_AUTH;
                        break;
                    case "40139":
                        // 实名认证用户信息变更失败
                        registerDataMap.put(CommomConstant.CODE, ResponseCodeConstant.REAL_NAME_REG_USERINFO_MODIFY_FAILED);
                        registerDataMap.put(CommomConstant.REASON, "实名认证用户信息变更失败");
                        registerCode = ResponseCodeConstant.REAL_NAME_REG_USERINFO_MODIFY_FAILED;
                        break;
                    case "40199":
                        registerDataMap.put(CommomConstant.CODE, "001");
                        registerDataMap.put(CommomConstant.REASON, "身份证图像不符合系统要求，请重新提交认证材料");
                        registerCode = "001";
                        break;
                    case "40187":
                        registerDataMap.put(CommomConstant.CODE, "001");
                        registerDataMap.put(CommomConstant.REASON, "该卡处于管理停机状态，无法自助办理业务，详询客户经理");
                        registerCode = "001";
                        break;
                    case "49999":
                        registerDataMap.put(CommomConstant.CODE, "001");
                        registerDataMap.put(CommomConstant.REASON, "实名登记系统错误，请稍后再试");
                        registerCode = "001";
                        break;
                    case "40050":
                        registerDataMap.put(CommomConstant.CODE, "001");
                        registerDataMap.put(CommomConstant.REASON, "实名登记系统未查询到用户信息，请稍后再试");
                        registerCode = "001";
                        break;
                    case "49998":
                        registerDataMap.put(CommomConstant.CODE, "001");
                        registerDataMap.put(CommomConstant.REASON, "后端系统异常，请稍后再试");
                        registerCode = "001";
                        break;
                    default:
                        registerDataMap.put(CommomConstant.CODE, "001");
                        registerDataMap.put(CommomConstant.REASON, "认证系统繁忙，请稍后再试");
                        registerCode = "001";
                        break;
                }
                regMap.put(CommomConstant.REGISTER_CODE, "0".equals(ctResp.getCode()) ? CommomConstant.RESPONSE_CODE_SUCCESS : ctResp.getCode());
                break;
        }
        regMap.put(CommomConstant.CUST_CERT_NO, formCustCerNo);
        regMap.put(CommomConstant.NAME, formCustName);
        regMap.put(CommomConstant.MSISDN, msisdn);
        regMap.put(CommomConstant.ACTIVE_OPTS, isActive);
        regMap.put(CommomConstant.ICCID, iccId);
        regMap.put(CommomConstant.CARD_BELONG, pbOrct);
        regMap.put(CommomConstant.PHONE, phone);
        regMap.put(CommomConstant.BEID, beId);
        regMap.put(CommomConstant.CUSTID, custId);
        regMap.put(CommomConstant.REGISTER_PIC_ID_R, fileR.getAbsolutePath().replace(wx_media_download_dir, ""));
        regMap.put(CommomConstant.REGISTER_PIC_ID_Z, map.get(CommomConstant.MEDIA_FILE_Z_PATH).toString().replace(wx_media_download_dir, ""));
        regMap.put(CommomConstant.REGISTER_PIC_ID_F, map.get(CommomConstant.MEDIA_FILE_F_PATH).toString().replace(wx_media_download_dir, ""));
        regMap.put(CommomConstant.REGISTER_PIC_ID_T, map.get(CommomConstant.MEDIA_FILE_Z_PATH).toString().replace(wx_media_download_dir, ""));
        regMap.put(CommomConstant.BUSINESS_PLAT, map.get(CommomConstant.BUSINESS_PLAT));
        regMap.put(CommomConstant.USER_ID, userId);
        if ("realNameH5".equals(userId)) {
            //通过登记H5进来的流量
            regMap.put("channelId", map.get("channelId"));

            //TODO 添加限流回收通知逻辑,认证通过置为有效调用，认证未通过置为无效调用
            String msgId = String.valueOf(map.get("msgId"));
            if (map.get("msgId") != null) {
                //2:有效调用 3:无效调用
                int status = CommomConstant.RESPONSE_CODE_SUCCESS.equals(registerCode) ? 2 : 3;
                Map<String, Integer> param = new HashMap<>(2);
                param.put("msgId", Integer.valueOf(msgId));
                param.put("status", status);
                ResponseVo verifyStatusVo = authenticationServiceClient.changeVerifyStatus(param);
                if (verifyStatusVo.isSuccess()) {
                    logger.info("实名登记H5，限流状态更新成功,msgId is:[{}],status is:[{}]", msgId, (status == 2) ? "有效调用" : "无效调用");
                } else {
                    logger.info("实名登记H5，限流状态更新失败,msgId is:[{}],status is:[{}]", msgId, (status == 2) ? "有效调用" : "无效调用");
                }
            }
        }

        ResponseVo saveResp = wxApiClient.saveRealNameRegInfo(regMap, transNo, accessToken); // 登记信息入库
        if (saveResp.isSuccess()) {// 入库成功
            if (CommomConstant.RESPONSE_CODE_SUCCESS.equals(registerCode)) {// 实名登记成功
                registerDataMap.put(CommomConstant.CODE, ResponseCodeConstant.AUTHENTICATE_SUCCESS);
                // 卡实名登记成功。
                registerDataMap.put(CommomConstant.REASON, "success");
                // CT卡是否激活
                if (pbOrct.equals("01") && isActive.equals("0")) {
                    Map activateMap = new HashMap(3);
                    activateMap.put(CommomConstant.BEID, beId);
                    activateMap.put(CommomConstant.CUSTID, custId);
                    activateMap.put(CommomConstant.MSISDN, msisdn);
                    ResponseVo activateResp = wxApiClient.activateCardFromCT(activateMap, transNo, accessToken);
                    //前端提示信息
                    if (activateResp.isSuccess()) {
                        registerDataMap.put(CommomConstant.CODE, ResponseCodeConstant.RESPONSE_CODE_ACTIVATE_CARD_SUCCESS);
                        registerDataMap.put(CommomConstant.REASON, activateResp.getData().toString());
                    } else if (activateResp.getCode().equals(ResponseCode.ERROR_NOTALLOW_REQUEST)) {
                        registerDataMap.put(CommomConstant.CODE, ResponseCodeConstant.RESPONSE_CODE_ACTIVATE_CARD_NOTALLOWED);
                        registerDataMap.put(CommomConstant.REASON, activateResp.getData().toString());
                    } else {
                        registerDataMap.put(CommomConstant.CODE, ResponseCodeConstant.RESPONSE_CODE_ACTIVATE_CARD_FAIL);
                        registerDataMap.put(CommomConstant.REASON, activateResp.getData().toString());
                    }
                }
                //自动绑定结果无需前端提示
                Map<String, Object> autoBindMap = new HashMap<>(6);
                autoBindMap.put(CommomConstant.MSISDN, msisdn);
                autoBindMap.put(CommomConstant.ICCID, iccId);
                autoBindMap.put(CommomConstant.REMARK, alias);
                autoBindMap.put(CommomConstant.CUST_CERT_NO, formCustCerNo);
                autoBindMap.put(CommomConstant.CARD_BELONG, pbOrct);

                ResponseVo autoBindResp = wxApiClient.msisdnAutoBind(autoBindMap, transNo, accessToken);
                iLog.info(logger, transNo, autoBindMap, "自动绑定，绑定参数为{},绑定结果为{}", autoBindMap, autoBindResp);
                return ResponseVo.success(registerDataMap);
            } else {// 实名登记失败
                return ResponseVo.fail(registerCode, registerDataMap);
            }
        } else { //入库失败，删除文件
            FileUtils.deleteFile(fileR);
            registerDataMap.put(CommomConstant.CODE, ResponseCodeConstant.SAVE_REGISTER_INFO_FAILED);
            registerDataMap.put(CommomConstant.REASON, "登记信息入库失败");
            return ResponseVo.fail(ResponseCodeConstant.SAVE_REGISTER_INFO_FAILED, registerDataMap);
        }
    }

    /**
     * 微信OCR功能调用
     *
     * @param params
     * @return
     */
    @RequestMapping("/getOCRInfo")
    public ResponseVo getOCRInfo(@RequestBody Map params) {
        iLog.info(logger, getTransNo(request), params, "wx-service start to OCR WX_MP OR APP picture");
        String transNo = getTransNo(request);
        MapParamChecker mapParamChecker = MapParamChecker.instance(params)
                .isNotBlank("channelId")
                .isNotBlank("dateDir")
                .isNotBlank("fileName");
        if (mapParamChecker.isValid()) {
            String channelId = params.get("channelId").toString();
            String dateDir = params.get("dateDir").toString();
            String filename = params.get("fileName").toString();

            //从redis 或 数据库中查询
            String baseDir;
            ResponseVo dirInfo = weChatService.getSysParamById(transNo, BaseUtil.REAL_NAME_REGISTER_LOCAL);
            if (dirInfo.isSuccess()) {
                baseDir = dirInfo.getData().toString();
            } else {
                return ResponseVo.fail(ResponseCodeConstant.SEARCH_FAILED);
            }

            Path p = Paths.get(baseDir, channelId, dateDir, filename);
            File file = p.toFile();
            if (!file.exists()) {
                //文件不存在
                iLog.error(logger, getTransNo(request), params, "OCR文件不存在{}", filename);
                return ResponseVo.fail(ResponseCodeConstant.CERNO_OCR_RECOGNITION_FAILED);
            }
            //获取微信access_token
            ResponseVo tokenResp = iWeiXinService.getAccessToken(transNo);
            if (!tokenResp.isSuccess()) {
                return ResponseVo.fail(ResponseCodeConstant.GET_WX_ACCESS_TOKEN_FAILED);//获取不到access_token
            }
            String wxAccessToken = tokenResp.getData().toString();
            ResponseVo ocrResp = iWeiXinService.wxOCRRecognition(transNo, "photo", file, wxAccessToken);//调用微信OCR识别接口进行身份识别
            if (ocrResp.isSuccess()) {
                Map ocrDataMap = (Map) ocrResp.getData();
                return ResponseVo.success(ocrDataMap);
            } else {//OCR扫描失败
                iLog.error(logger, getTransNo(request), null, "OCR识别返回码: {}", ocrResp.getCode());
                return ResponseVo.fail(ResponseCodeConstant.CERNO_OCR_RECOGNITION_FAILED);
            }
        }
        iLog.error(logger, getTransNo(request), params, "上传的图片OCR缺少参数");
        return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM, "miss param");
    }

    /**
     * 使用 接收文件存储到/data_realname/register/data/channel()/yyyy-MM-dd里面
     */
    @RequestMapping(method = RequestMethod.POST, value = "/uploadpicture")
    public ResponseVo uploadPicture(@RequestBody Map params) {
        MapParamChecker mapParamChecker = MapParamChecker.instance(params)
                .isNotBlank("fileStr")
                .isNotBlank("channelId")
                .isNotBlank("dateDir")
                .isNotBlank("fileName");
        if (mapParamChecker.isValid()) {
            iLog.info(logger, getTransNo(request), params, "wx-service start to receive WX_MP OR APP picture");
            return fileUploadService.uploadPicFileInfo(params, getTransNo(request));
        }
        return ResponseVo.fail(ResponseCodeConstant.SAVE_REGISTER_INFO_FAILED);
    }

    /**
     * 查询绑定的卡列表（新）
     *
     * @param params
     * @return
     */
    @RequestMapping("/queryMsisdnList")
    public ResponseVo queryMsisdnList(@RequestBody Map params) {
        try {
            String userId = StringUtils.isEmpty(request.getHeader(CommomConstant.USER_ID)) ? "" : request.getHeader(CommomConstant.USER_ID);
            if (!StringUtils.isEmpty(userId)) {
                params.put(CommomConstant.USER_ID, userId);
                PageResultVo pages = wxApiClient.queryMsisdnList(params, getTransNo(request), getAccessToken(request));
                if (pages == null) {
                    throw new Exception("调用api-service查询绑定的物联卡列表异常");
                } else {
                    return ResponseVo.success(pages);
                }
            } else {
                iLog.error(logger, getTransNo(request), null, "缺少必要的参数,{}", params);
                return ResponseVo.fail(ResponseCodeConstant.PARAM_ILLEGALLY, new String[]{"缺少必要的参数"});
            }
        } catch (Exception e) {
            iLog.error(logger, getTransNo(request), null, "查询绑定的卡列表发生异常", e, params);
            return ResponseVo.fail(ResponseCodeConstant.SEARCH_FAILED, new String[]{e.getMessage()});
        }
    }

    /**
     * 查询余额（新）
     *
     * @param params
     * @return
     */
    @RequestMapping(value = "/queryBalance", method = RequestMethod.POST)
    public ResponseVo queryBalance(@RequestBody Map params) {
        try {
            MapParamChecker mapParamChecker = MapParamChecker.instance(params)
                    .isNotBlank(CommomConstant.MSISDN);
            String userId = StringUtils.isEmpty(request.getHeader(CommomConstant.USER_ID)) ? "" : request.getHeader(CommomConstant.USER_ID);
            if (mapParamChecker.isValid() && !StringUtils.isEmpty(userId)) {
                params.put(CommomConstant.USER_ID, userId);
                Map balance = wxApiClient.queryBalance(params, getTransNo(request), getAccessToken(request));
                if (balance == null) {
                    throw new Exception("调用接口查询物联卡余额发生异常");
                } else {
                    return ResponseVo.success(balance);
                }
            } else {
                iLog.error(logger, getTransNo(request), null, "缺少必要的参数,{}", params);
                return ResponseVo.fail(ResponseCodeConstant.PARAM_ILLEGALLY, new String[]{"缺少必要的参数"});
            }
        } catch (Exception e) {
            iLog.error(logger, getTransNo(request), null, "查询余额发生异常", e, params);
            return ResponseVo.fail(ResponseCodeConstant.SEARCH_FAILED, new String[]{e.getMessage()});
        }
    }

    /**
     * 查询开关机状态（新）
     *
     * @param params
     * @return
     */
    @RequestMapping(value = "/queryNetStatus", method = RequestMethod.POST)
    public ResponseVo queryNetStatus(@RequestBody Map params) {
        try {
            MapParamChecker mapParamChecker = MapParamChecker.instance(params)
                    .isNotBlank(CommomConstant.MSISDN);
            String userId = StringUtils.isEmpty(request.getHeader(CommomConstant.USER_ID)) ? "" : request.getHeader(CommomConstant.USER_ID);
            if (mapParamChecker.isValid() && !StringUtils.isEmpty(userId)) {
                params.put(CommomConstant.USER_ID, userId);
                Map netStatus = wxApiClient.queryNetStatus(params, getTransNo(request), getAccessToken(request));
                if (netStatus == null) {
                    throw new Exception("调用接口查询开关机状态发生异常");
                } else {
                    return ResponseVo.success(netStatus);
                }
            } else {
                iLog.error(logger, getTransNo(request), null, "缺少必要的参数,{}", params);
                return ResponseVo.fail(ResponseCodeConstant.PARAM_ILLEGALLY, new String[]{"缺少必要的参数"});
            }
        } catch (Exception e) {
            iLog.error(logger, getTransNo(request), null, "查询开关机状态发生异常", e, params);
            return ResponseVo.fail(ResponseCodeConstant.SEARCH_FAILED, new String[]{e.getMessage()});
        }
    }

    /**
     * 查询用量信息（新）
     *
     * @param params
     * @return
     */
    @RequestMapping(value = "/queryUseTotal", method = RequestMethod.POST)
    public ResponseVo queryUseTotal(@RequestBody Map params) {
        try {
            MapParamChecker mapParamChecker = MapParamChecker.instance(params)
                    .isNotBlank(CommomConstant.MSISDN);
            String userId = StringUtils.isEmpty(request.getHeader(CommomConstant.USER_ID)) ? "" : request.getHeader(CommomConstant.USER_ID);
            if (mapParamChecker.isValid() && !StringUtils.isEmpty(userId)) {
                params.put(CommomConstant.USER_ID, userId);
                Map useTotal = wxApiClient.queryUseTotal(params, getTransNo(request), getAccessToken(request));
                if (useTotal == null) {
                    throw new Exception("调用接口查询用量信息发生异常");
                } else {
                    return ResponseVo.success(useTotal);
                }
            } else {
                iLog.error(logger, getTransNo(request), null, "缺少必要的参数,{}", params);
                return ResponseVo.fail(ResponseCodeConstant.PARAM_ILLEGALLY, new String[]{"缺少必要的参数"});
            }
        } catch (Exception e) {
            iLog.error(logger, getTransNo(request), null, "查询查询用量信息发生异常", e, params);
            return ResponseVo.fail(ResponseCodeConstant.SEARCH_FAILED, new String[]{e.getMessage()});
        }
    }

    /**
     * 查询物联卡状态（新）
     *
     * @param params
     * @return
     */
    @RequestMapping(value = "/queryStatus", method = RequestMethod.POST)
    public ResponseVo queryStatus(@RequestBody Map params) {
        try {
            MapParamChecker mapParamChecker = MapParamChecker.instance(params)
                    .isNotBlank(CommomConstant.MSISDN);
            String userId = StringUtils.isEmpty(request.getHeader(CommomConstant.USER_ID)) ? "" : request.getHeader(CommomConstant.USER_ID);
            if (mapParamChecker.isValid() && !StringUtils.isEmpty(userId)) {
                params.put(CommomConstant.USER_ID, userId);
                Map statusInfo = wxApiClient.queryStatus(params, getTransNo(request), getAccessToken(request));
                if (statusInfo == null) {
                    throw new Exception("调用接口查询卡状态发生异常");
                } else {
                    return ResponseVo.success(statusInfo);
                }
            } else {
                iLog.error(logger, getTransNo(request), null, "缺少必要的参数,{}", params);
                return ResponseVo.fail(ResponseCodeConstant.PARAM_ILLEGALLY, new String[]{"缺少必要的参数"});
            }
        } catch (Exception e) {
            iLog.error(logger, getTransNo(request), null, "查询查询卡状态发生异常", e, params);
            return ResponseVo.fail(ResponseCodeConstant.SEARCH_FAILED, new String[]{e.getMessage()});
        }
    }

    /**
     * PB充值操作记录
     *
     * @param map
     * @return
     */
    @RequestMapping(value = "/saveChargeLogOfPB", method = RequestMethod.POST)
    public ResponseVo saveChargeLogOfPB(@RequestBody Map map) {
        try {
            String userId = request.getHeader(CommomConstant.USER_ID) == null ? "" : request.getHeader(CommomConstant.USER_ID);
            String msisdn = map.get(CommomConstant.MSISDN) == null ? "" : map.get(CommomConstant.MSISDN).toString();
            if (StringUtils.isEmpty(userId) || StringUtils.isEmpty(msisdn)) {
                iLog.error(logger, getTransNo(request), null, "缺少必要参数，请求参数:{}", map);
                return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
            }
            // 封装微信端参数
            map.put(CommomConstant.USER_ID, userId);
            map.put("entityType", "1");// 充值标识 1：msisdn
            map.put("payedType", "01");// 缴费类型 01：预存
            map.put("channelId", "WX_OA");//微信公众号
            map.put("cardBelong", "00");//卡归属PB
            map.put("plat", "00");// 全网业务模块点击量统计-渠道来源：00 公众号
            return wxApiClient.saveChargeLogOfPB(map, getTransNo(request), getAccessToken(request));
        } catch (Exception e) {
            iLog.error(logger, getTransNo(request), null, "充值操作记录发生异常，请求参数:{}", e, map);
            return ResponseVo.fail(ResponseCode.ERROR_SYS);
        }
    }

    /**
     * CT卡个人账户验证
     *
     * @param map
     * @return
     */
    @RequestMapping(value = "/checkIndividualAccount", method = RequestMethod.POST)
    public ResponseVo checkIndividualAccount(@RequestBody Map map) {
        try {
            String userId = request.getHeader(CommomConstant.USER_ID) == null ? "" : request.getHeader(CommomConstant.USER_ID);
            String msisdn = map.get(CommomConstant.MSISDN) == null ? "" : map.get(CommomConstant.MSISDN).toString();
            if (StringUtils.isEmpty(userId) || StringUtils.isEmpty(msisdn)) {
                iLog.error(logger, getTransNo(request), null, "缺少必要参数，请求参数:{}", map);
                return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
            }
            map.put(CommomConstant.USER_ID, userId);
            return wxApiClient.checkIndividualAccount(map, getTransNo(request), getAccessToken(request));
        } catch (Exception e) {
            iLog.error(logger, getTransNo(request), null, "充值操作记录发生异常，请求参数:{}", e, map);
            return ResponseVo.fail(ResponseCode.ERROR_SYS);
        }
    }

    /**
     * 同步该账号实名认证的身份证下有效的非销户物联卡列表
     *
     * @param params
     * @return
     */
    @RequestMapping(value = "/syncMsisdnList", method = RequestMethod.POST)
    public ResponseVo syncMsisdnList(@RequestBody Map params) {
        try {
            String userId = StringUtils.isEmpty(request.getHeader(CommomConstant.USER_ID)) ? "" : request.getHeader(CommomConstant.USER_ID);
            params.put(CommomConstant.USER_ID, userId);
            Map statusInfo = wxApiClient.syncMsisdnList(params, getTransNo(request), getAccessToken(request));
            if (statusInfo == null) {
                throw new Exception("查询CT侧该账号实名认证的身份证下有效的非销户物联卡列表发生异常");
            } else {
                return ResponseVo.success(statusInfo);
            }
        } catch (Exception e) {
            iLog.error(logger, getTransNo(request), null, "查询CT侧该账号实名认证的身份证下有效的非销户物联卡列表发生异常", e, params);
            return ResponseVo.fail(ResponseCodeConstant.SEARCH_FAILED, new String[]{e.getMessage()});
        }
    }


    /**
     * 个人业务点击量统计
     *
     * @param params
     * @return
     */
    @RequestMapping(value = "/saveBusinessHitLog", method = RequestMethod.POST)
    public ResponseVo saveBusinessHitLog(@RequestBody Map params) {
        try {
            String userId = StringUtils.isEmpty(request.getHeader(CommomConstant.USER_ID)) ? "" : request.getHeader(CommomConstant.USER_ID);
            if ("".equals(userId)) {
                userId = (String) params.get(CommomConstant.USER_ID);
            }
            // 微信公众号渠道plat:00
            String plat = (String) params.get(CommomConstant.BUSINESS_PLAT);
            if (plat == null) {
                params.put(CommomConstant.BUSINESS_PLAT, CommomConstant.BUSINESS_PLATFORM_WX_OA);
            }
            // 点击量list
            List<Map> list = (List<Map>) params.get("list");
            if (list == null || list.size() == 0 && StringUtils.isEmpty(userId)) {
                iLog.error(logger, getTransNo(request), null, "缺少必要参数，请求参数:{},userId:{}", params, userId);
                return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
            }
            // 点击信息入库
            return wxApiClient.saveBusinessHitLog(params, getTransNo(request), getAccessToken(request));
        } catch (Exception e) {
            iLog.error(logger, getTransNo(request), null, "个人业务点击量信息保存发生异常", e, params);
            return ResponseVo.fail(ResponseCode.ERROR_SYS);
        }
    }

    /**
     * 查询行业信息/问题类型
     *
     * @param params
     * @return
     */
    @RequestMapping(value = "/getDicts", method = RequestMethod.POST)
    public ResponseVo getDicts(@RequestBody Map params) {
        try {
            String userid = request.getHeader(CommomConstant.USER_ID);
            if (StringUtils.isEmpty(userid)) {
                iLog.error(logger, getTransNo(request), null, "用户id不能为空！", params);
                return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
            }
            params.put(CommomConstant.USER_ID, userid);
            params.put("type", params.getOrDefault("type", "industry"));
            return wxApiClient.getDicts(params, getTransNo(request), getAccessToken(request));
        } catch (Exception e) {
            iLog.error(logger, getTransNo(request), null, "查询行业信息/问题类型发生异常", e, params);
            return ResponseVo.fail(ResponseCode.ERROR_SYS);
        }
    }

    /**
     * 保存用户反馈信息
     *
     * @param params
     * @return
     */
    @RequestMapping(value = "/saveFeedback", method = RequestMethod.POST)
    public ResponseVo saveFeedback(@RequestBody Map params) {
        try {
            logger.info("留言校验入参：{}",JsonUtils.parseString(params));
            String userid = request.getHeader(CommomConstant.USER_ID);
            if (StringUtils.isEmpty(userid)) {
                iLog.error(logger, getTransNo(request), null, "用户id不能为空！", params);
                return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
            }
            params.put(CommomConstant.USER_ID, userid);
            params.put(CommomConstant.BUSINESS_PLAT, CommomConstant.BUSINESS_PLATFORM_WX_OA);
            return wxApiClient.saveFeedback(params, getTransNo(request), getAccessToken(request));

        } catch (Exception e) {
            iLog.error(logger, getTransNo(request), null, "保存用户反馈信息发生异常", e, params);
            return ResponseVo.fail(ResponseCode.ERROR_SYS);
        }
    }

    /**
     * 重庆个人业务物联卡列表查询
     *
     * @param params
     * @return
     */
    @RequestMapping(value = "/getCQMsisdns", method = RequestMethod.POST)
    public ResponseVo getCQMsisdns(@RequestBody Map params) {
        try {
            String userId = StringUtils.isEmpty(request.getHeader(CommomConstant.USER_ID)) ? "" : request.getHeader(CommomConstant.USER_ID);
            params.put(CommomConstant.USER_ID, userId);
            Map statusInfo = wxApiClient.getCQMsisdns(params, getTransNo(request), getAccessToken(request));
            if (statusInfo == null) {
                throw new Exception("查询重庆BOSS该账号下有效的物联卡列表发生异常");
            } else {
                return ResponseVo.success(statusInfo);
            }
        } catch (Exception e) {
            iLog.error(logger, getTransNo(request), null, "查询重庆BOSS该账号下有效的物联卡列表发生异常", e, params);
            return ResponseVo.fail(ResponseCodeConstant.SEARCH_FAILED, new String[]{e.getMessage()});
        }
    }

    /**
     * PB物联卡充值接口
     * beId 省份ID
     * msisdn 物联卡号
     * chargeMoney 充值金额
     */
    @RequestMapping("/chargeOfPB")
    public ResponseVo chargeOfPB(@RequestBody Map params) {
        String userid = request.getHeader(CommomConstant.USER_ID);
        if (StringUtils.isEmpty(userid)) {
            return ResponseVo.fail(ResponseCode.ERROR_NO_AUTH, new String[]{"缺少登陆用户信息，无权限调用系统接口"});
        }
        MapParamChecker checker = MapParamChecker.instance(params)
                .isNotBlank(CommomConstant.MSISDN)
                .isNotBlank(CommomConstant.BEID)
                .isNotBlank(CommomConstant.CHARGE_MONEY);
        if (checker.isValid()) {
            String beIds = cache.getSysParams("recharge_province_close", "");
            logger.info("屏蔽省份检查：{}",beIds);
            if(beIds!=null&&!"".equals(beIds)){
                List<String> list= Arrays.asList(beIds.split(","));
                if(list.contains(params.get("beId"))){
                    logger.info("省份{}暂时关闭充值",params.get("beId"));
                    return ResponseVo.fail("999", new String[]{"该省系统正在升级，暂不支持充值服务"});
                }
            }
            PBChargeParam chargeParam = new PBChargeParam();
            chargeParam.setBeId(String.valueOf(params.get(CommomConstant.BEID)));
            chargeParam.setIDValue(String.valueOf(params.get(CommomConstant.MSISDN)));
            chargeParam.setPayment(String.valueOf(params.get(CommomConstant.CHARGE_MONEY)));
            //设置充值完成跳转地址
            String returnUrl = cache.getSysParams(CommomConstant.WX_CT_CHARGE_RETURN_URL, "");
            chargeParam.setReturnURL(returnUrl);
            Map paramMap = new HashMap();
            paramMap.put("IDValue", chargeParam.getIDValue());
            //PB充值金额放大 100倍 元
            BigDecimal chargeMoney = new BigDecimal(chargeParam.getPayment()).setScale(0, BigDecimal.ROUND_DOWN);
            BigDecimal times = new BigDecimal(100);
            chargeMoney = chargeMoney.multiply(times);
            paramMap.put("Payment", String.valueOf(chargeMoney));
            paramMap.put("PaymentType", chargeParam.getPaymentType());
            paramMap.put("beID", chargeParam.getBeId());
            paramMap.put("ReturnURL", chargeParam.getReturnURL());
            ResponseVo responseVo = chargeClient.iotCmpPaymentH5(paramMap, getTransNo(request));
            if (responseVo != null && responseVo.isSuccess() && responseVo.getData() != null) {
                Map data = JsonUtils.parseObjectToMap(responseVo.getData());
                logger.info("transNo is:[{}]，充值中心返回充值地址：[{}]", getTransNo(request), JsonUtils.parseString(data));
                if ("0000".equals(data.get("RespCode"))) {
                    Map<String, Object> responseMap = new HashMap<>(1);
                    responseMap.put("url", data.get("PayUrl"));
                    return ResponseVo.success(responseMap);
                } else {
                    String errorMsg = (data.get("RespDesc") != null && !StringUtils.isEmpty(String.valueOf(data.get("RespDesc")))) ? String.valueOf(data.get("RespDesc")) : "充值系统异常，请稍后再试！";
                    return ResponseVo.fail(ResponseCode.ERROR_COMMUNICATION_EXTENAL_SYS, new String[]{errorMsg});
                }
            } else {
                return ResponseVo.fail(ResponseCode.ERROR_SERVICE_UNAVAILABLE, new String[]{"业务系统繁忙，请稍后再试！"});
            }
        } else {
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM, new String[]{"缺少必要的请求参数"});
        }
    }

    /**
     * 获取物联卡基本信息（不校验个人用户归属）
     *
     * @param params
     * @return
     */
    @RequestMapping(value = "/cardInfo", method = RequestMethod.POST)
    public ResponseVo getMsisdnInfoNoAuth(@RequestBody Map params) {
        try {
            String msisdn = params.get(CommomConstant.MSISDN) == null ? "" : params.get(CommomConstant.MSISDN).toString();
            String userid = request.getHeader(CommomConstant.USER_ID) == null ? "" : request.getHeader(CommomConstant.USER_ID);
            if (StringUtils.isEmpty(msisdn) || StringUtils.isEmpty(userid)) {
                return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
            }
            params.put(CommomConstant.USER_ID, userid);
            params.put("plat", "00");// 全网业务模块点击量统计-渠道来源：00 公众号
            return wxApiClient.cardInfo(params, getTransNo(request), getAccessToken(request));
        } catch (Exception e) {
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
        }
    }

    /**
     * PB卡实名认证流程查询
     *
     * @return
     */
    @RequestMapping(value = "/checkMsisdnFlow", method = RequestMethod.POST)
    public ResponseVo checkMsisdnFlow(@RequestBody Map map) {
        try {
            ResponseVo vo = wxApiClient.querySameOrderPb(map, getTransNo(request));
            if("4014".equals(vo.getCode()))return vo;
            switch (map.get("beId").toString()){
                case "551":
                    return wxApiClient.checkMsisdnFlow(map, getTransNo(request));
                case "371":
                    return wxApiClient.checkMsisdnFlowHN(map,getTransNo(request));
                case "100":
                    return wxApiClient.checkMsisdnFlowBJ(map,getTransNo(request));
                case "220":
                    return wxApiClient.checkMsisdnFlowTJ(map,getTransNo(request));
                case "250":
                    return wxApiClient.checkMsisdnFlowJS(map,getTransNo(request));
                case "210":
                    return wxApiClient.checkMsisdnFlowSH(map,getTransNo(request));
                case "898":
                    return wxApiClient.checkMsisdnFlowHainan(map,getTransNo(request));
                default:
                    return ResponseVo.fail("099");
            }
        } catch (Exception e) {
            logger.info("PB卡实名认证流程查询失败checkMsisdnFlow...{}...{}", JsonUtils.parseString(map), e.getMessage());
            return ResponseVo.fail("99");
        }
    }

    /**
     * PB卡实名认证流程-一证五号校验
     *
     * @return
     */
    @RequestMapping(value = "/idCardCheck", method = RequestMethod.POST)
    public ResponseVo idCardCheck(@RequestBody Map map) {
        try {
            MapParamChecker checker = MapParamChecker.instance(map)
                    .isNotBlank("idType")
                    .isNotBlank("idCard");
            if (!checker.isValid()) {
                logger.info("一证五号校验请求参数不合法idCardCheck...{}", JSONArray.toJSONString(map));
                return ResponseVo.fail(ResponseCode.ERROR_INVALID_PARAMS);
            }
            //pb卡一证五号埋点
            Map statMap=new HashMap();
            statMap.put("step","threepb");
            wxApiClient.innerStatis(statMap, getTransNo(request));
            switch (map.get("beId").toString()){
                case "551":
                    return wxApiClient.idCardCheck(map, getTransNo(request));
                case "371":
                    return wxApiClient.idCardCheckHN(map,getTransNo(request));
                case "100":
                    return wxApiClient.idCardCheckBJ(map,getTransNo(request));
                case "220":
                    return wxApiClient.idCardCheckTJ(map,getTransNo(request));
                case "250":
                    return wxApiClient.idCardCheckJS(map,getTransNo(request));
                case "898":
                    return wxApiClient.idCardCheckHainan(map,getTransNo(request));
                default:
                    return ResponseVo.fail("099");
            }
        } catch (Exception e) {
            logger.info("一证五号校验失败idCardCheck...{}...{}", JSONArray.toJSONString(map), e);
            return ResponseVo.fail("99");
        }
    }

    /**
     * 个人业务-隐私协议查询
     *
     * @return
     */
    @RequestMapping(value = "/queryProtocolInfo", method = RequestMethod.POST)
    public ResponseVo queryProtocolInfo(@RequestBody Map map) {
        try {
            MapParamChecker checker = MapParamChecker.instance(map)
                    .isNotBlank("phone");
            if (!checker.isValid()) {
                logger.info("隐私协议查询请求参数不合法queryProtocolInfo...{}", JSONArray.toJSONString(map));
                return ResponseVo.fail(ResponseCode.ERROR_INVALID_PARAMS);
            }
            String cachePhone = cache.get(CacheManager.PublicNameSpace.TEMP, "protocol_" + map.get("phone"));
            if(cachePhone==null||"null".equals(cachePhone)||"".equals(cachePhone)){
                return wxApiClient.queryProtocolApi(map, getTransNo(request));
            }else{
                Map result=new HashMap();
                result.put("flag","1");
                return ResponseVo.success(result);
            }
        } catch (Exception e) {
            logger.info("隐私协议查询失败queryProtocolInfo...{}...{}", JSONArray.toJSONString(map), e.getMessage());
            return ResponseVo.fail("99");
        }
    }

    /**
     * 个人业务-隐私协议-增加记录
     *
     * @return
     */
    @RequestMapping(value = "/insertProtocolInfo", method = RequestMethod.POST)
    public ResponseVo insertProtocolInfo(@RequestBody Map map) {
        try {
            MapParamChecker checker = MapParamChecker.instance(map)
                    .isNotBlank("phone");
            if (!checker.isValid()) {
                logger.info("隐私协议增加记录请求参数不合法insertProtocolInfo...{}", JSONArray.toJSONString(map));
                return ResponseVo.fail(ResponseCode.ERROR_INVALID_PARAMS);
            }
            return wxApiClient.insertProtocolApi(map, getTransNo(request));
        } catch (Exception e) {
            logger.info("隐私协议增加记录请求参数不合法insertProtocolInfo...{}...{}", JSONArray.toJSONString(map), e.getMessage());
            return ResponseVo.fail("99");
        }
    }

    /**
     * 公众号ct实名认证-卡激活弹窗判断
     *
     * @return
     */
    @RequestMapping(value = "/queryBbcStatus", method = RequestMethod.POST)
    public ResponseVo queryBbcStatus(@RequestBody Map map) {
        try {
            MapParamChecker checker = MapParamChecker.instance(map)
                    .isNotBlank("msisdn")
                    .isNotBlank("userId");
            if (!checker.isValid()) {
                logger.info("queryBbcStatus...卡号为空...{}", JSONArray.toJSONString(map));
                return ResponseVo.fail(ResponseCode.ERROR_INVALID_PARAMS);
            }
            return wxApiClient.queryBbcStatusApi(map, getTransNo(request));
        } catch (Exception e) {
            logger.info("queryPccStatus fail...{}...{}", JSONArray.toJSONString(map), e);
            return ResponseVo.fail("99");
        }
    }

    /**
     * 公众号ct实名认证-获取在线公司url
     *
     * @return
     */
    @RequestMapping(value = "/startCtRegister", method = RequestMethod.POST)
    public ResponseVo startCtRegister(@RequestBody Map map) {
        try {
            MapParamChecker checker = MapParamChecker.instance(map)
                    .isNotBlank("custId")
                    .isNotBlank("beId")
                    .isNotBlank("status")
                    .isNotBlank("userId")
                    .isNotBlank("phone")
                    .isNotBlank("iccid");
            if (!checker.isValid()) {
                logger.info("startCtRegister 缺少请求参数...{}", JSONArray.toJSONString(map));
                return ResponseVo.fail(ResponseCode.ERROR_INVALID_PARAMS);
            }
            if(!"realNameH5".equals(map.get("userId"))&&map.get("flag")==null){
                logger.info("startCtRegister 公众号缺少授权状态...{}", JSONArray.toJSONString(map));
                return ResponseVo.fail(ResponseCode.ERROR_INVALID_PARAMS);
            }
            return wxApiClient.startCtRegisterApi(map, getTransNo(request));
        } catch (Exception e) {
            logger.info("startCtRegister fail...{}...{}", JSONArray.toJSONString(map), e);
            return ResponseVo.fail("99");
        }
    }

    /**
     * 埋点统计
     *
     * @return
     */
    @RequestMapping(value = "/innerStatis", method = RequestMethod.POST)
    public ResponseVo innerStatis(@RequestBody Map map) {
        try {
            logger.info("埋点统计one...");
            return wxApiClient.innerStatis(map, getTransNo(request));
        } catch (Exception e) {
            logger.info("innerStatis fail...{}...{}", JSONArray.toJSONString(map), e);
            return ResponseVo.fail("99");
        }
    }

    /**
     * 卡实名查询
     *
     * @return
     */
    @RequestMapping(value = "/queryCardRegisterList", method = RequestMethod.POST)
    public ResponseVo queryCardRegisterList(@RequestBody Map map) {
        try {
            logger.info("queryCardRegisterList...{}",JsonUtils.parseString(map));
            return wxApiClient.queryCardRegisterList(map, getTransNo(request));
        } catch (Exception e) {
            logger.info("queryCardRegisterList fail...{}...{}", JSONArray.toJSONString(map), e);
            return ResponseVo.fail("99");
        }
    }
}
