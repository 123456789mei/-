package com.cmiot.wx.service.impl;

import com.cmiot.wx.api.client.ISystemParamManageDalServiceClient;
import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.common.constants.ParamConstants;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.wx.constant.ResponseCodeConstant;
import com.cmiot.wx.model.AppInfoEntity;
import com.cmiot.wx.service.IWeChatService;
import com.cmiot.wx.util.BaseUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * company ustcinfo.com
 * description IWeChatService实现类
 * date 2018/2/28
 *
 * @author yang.dehao@ustcinfo.com
 * @version
 */
@Service(value = "IWeChatService")
public class WeChatServiceImpl implements IWeChatService {

    @Autowired
    ISystemParamManageDalServiceClient sysParamClient;

    @Autowired
    ICache cache;

    @Override
    public ResponseVo getAppIdAndSecret(String transNo) {
        Map<String, Object> map = new HashMap<>();
        //获取appid
        map.put(ParamConstants.PARAMID, BaseUtil.WX_APPID);
        ResponseVo responseAppid = sysParamClient.getValueById(transNo, map);
        //获取appsecret
        map.put(ParamConstants.PARAMID, BaseUtil.WX_APPSECRET);
        ResponseVo responseSecret = sysParamClient.getValueById(transNo, map);
        //封装至AppInfoEntity
        AppInfoEntity appInfoEntity = new AppInfoEntity();
        appInfoEntity.setAppid(String.valueOf(responseAppid.getData()));
        appInfoEntity.setSecret(String.valueOf(responseSecret.getData()));
        return ResponseVo.success(appInfoEntity);
    }

    @Override
    public ResponseVo personTrigger(String  transNo){
        Map<String, Object> params = new HashMap<>(1);
        params.put(ParamConstants.PARAMID, BaseUtil.WX_PERSON_TRIGGER);
        ResponseVo responseVo = sysParamClient.getValueById(transNo, params);
        return responseVo;
    }

    @Override
    public ResponseVo getUnitePayUrl(String transNo) {
        Map<String, Object> params = new HashMap<>(1);
        params.put(ParamConstants.PARAMID, BaseUtil.WX_UNITE_PAY_URL);
        ResponseVo responseVo = sysParamClient.getValueById(transNo, params);
        return responseVo;
    }

    @Override
    public ResponseVo getSysParamById(String transNo,String paramId) {
        String paramValue = cache.getSysParams(paramId,"");
        if ("".equals(paramValue)) {
            // 如果缓存中不存在，则查询数据库
            Map qry = new HashMap(1);
            qry.put(ParamConstants.PARAMID , paramId);
            ResponseVo responseVo = sysParamClient.getValueById(transNo , qry);
            if (responseVo != null && responseVo.isSuccess() && !StringUtils.isEmpty(responseVo.getData())) {
                paramValue = String.valueOf(responseVo.getData());
                // 将查询结果放入缓存
                cache.setSysParams(paramId, paramValue);
            } else {
                return ResponseVo.fail(ResponseCodeConstant.SEARCH_FAILED);
            }
        }
        return  ResponseVo.success(paramValue);
    }

}
