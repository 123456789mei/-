package com.cmiot.wx.api.degraded;

import com.cmiot.commons.response.ResponseCode;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.commons.response.vo.PageResultVo;
import com.cmiot.wx.api.client.WxApiClient;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class WxApiImpl implements WxApiClient {

    private ResponseVo defaultResponse() {
        return ResponseVo.fail(ResponseCode.ERROR_SERVICE_UNAVAILABLE);
    }

    @Override
    public ResponseVo register(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo personRegister(Map paramMap) {
        return defaultResponse();
    }

    @Override
    public ResponseVo updateType(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo invalidAllAccount(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo logout(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getWxUserInfo(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getWxPersonUserInfo(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo checkOpenId(Map paramMap) {
        return defaultResponse();
    }

    @Override
    public ResponseVo checkWeChatAccountExist(Map paramMap) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getOpenIdByPhone(Map paramMap) {
        return defaultResponse();
    }

    @Override
    public ResponseVo updateOpenId(Map paramMap) {
        return defaultResponse();
    }

    @Override
    public ResponseVo bind(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo accountlist(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo deleteAllAccount(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo deleteAccount(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getSearchList(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo saveHistory(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getBalance(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getBalanceFromCT(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getSimFlow(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }


    @Override
    public ResponseVo activateCardFromCT(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getSimFlowFromCT(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo realNameRegist(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo isUserIdentityInfo(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getSuccessRegisterInfo(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo saveRealNameRegInfo(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo productList(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo productListFromCT(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getAccountInfo(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getAuthCode(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo validateCode(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getMsisdnList(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo rechargeOrder(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo chargePayment(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getUserPhoneByOpenId(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getPersonUserPhoneByOpenId(Map paramMap) {
        return defaultResponse();
    }

    @Override
    public ResponseVo unbindMsisdn(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getRealNameAuthURL(Map<String, String> paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo updateOperateTime(Map params) {
        return defaultResponse();
    }

    @Override
    public String receiveAuditResult(Map paramMap, String transNo, String accessToken) {
        return "";
    }

    @Override
    public String receiveDesKey(Map paramMap, String transNo, String accessToken) {
        return "";
    }

    @Override
    public ResponseVo setLoginLog(Map params) {
        return defaultResponse();
    }

    @Override
    public Map queryBalance(Map params, String transNo, String accessToken) throws Exception {
        return null;
    }

    @Override
    public Map queryNetStatus(Map params, String transNo, String accessToken) throws Exception {
        return null;
    }

    @Override
    public PageResultVo queryMsisdnList(Map params, String transNo, String accessToken) throws Exception {
        return PageResultVo.newInstance(0, null);
    }

    @Override
    public Map queryUseTotal(Map params, String transNo, String accessToken) throws Exception {
        return null;
    }

    @Override
    public Map queryStatus(Map params, String transNo, String accessToken) throws Exception {
        return null;
    }

    @Override
    public ResponseVo msisdnBind(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }


    @Override
    public ResponseVo msisdnAutoBind(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }


    @Override
    public ResponseVo checkMsisdnIccid(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo sendSmsCode(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo validateCodePersonal(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getMsisdnInfo(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getSimFlowInfo(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo modifyRemark(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo setTop(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo chargeOfCT(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getProductInfo(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getUserIdByPhone(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getVerifiedStatus(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }


    @Override
    public ResponseVo saveChargeLogOfPB(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo checkIndividualAccount(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo sendRegisterResult(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public Map syncMsisdnList(Map params, String transNo, String accessToken) {
        return null;
    }

    @Override
    public ResponseVo saveBusinessHitLog(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public Map getRealNameAuthResult(Map params, String transNo, String accessToken) {
        return null;
    }

    @Override
    public ResponseVo getDicts(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo saveFeedback(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo countByStatus(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getStatusByMsisdn(String msisdn, String transNo) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getSimFlowCT(Map param, String transNo) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getBalanceCT(Map param, String transNo) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getProductInfoByInstId(Map param, String transNo) {
        return defaultResponse();
    }

    @Override
    public Map getCQMsisdns(Map params, String transNo, String accessToken) {
        return null;
    }

    @Override
    public ResponseVo getAutoMsg(Map params, String transNo) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getNewsList(String id, String transNo) {
        return defaultResponse();
    }

    @Override
    public ResponseVo cardInfo(Map params, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo insertWxLog(Map params, String transNo) {
        return defaultResponse();
    }

    @Override
    public ResponseVo checkMsisdnFlow(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo idCardCheck(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo orderNumCheck(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo queryProtocolApi(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo insertProtocolApi(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo queryBbcStatusApi(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo startCtRegisterApi(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo checkMsisdnFlowHN(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo idCardCheckHN(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo checkMsisdnFlowBJ(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo idCardCheckBJ(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo checkMsisdnFlowTJ(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo idCardCheckTJ(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo checkMsisdnFlowJS(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo idCardCheckJS(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo querySameOrderPb(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo innerStatis(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo deleteOpenIdByPhone(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo queryCardRegisterList(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo queryCustNameByAppId(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo checkMsisdnFlowSH(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo checkMsisdnFlowHainan(Map map, String transNo) {
        return defaultResponse();
    }
    @Override
    public ResponseVo idCardCheckHainan(Map map, String transNo) {
        return defaultResponse();
    }

}
