package com.cmiot.wx;

import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.cache.impl.CacheImpl;
import com.cmiot.commons.config.BaseRedisConfig;
import com.cmiot.commons.config.CardRedisConfig;
import com.cmiot.commons.config.CommonRedisConfig;
import com.cmiot.commons.config.KafkaConfig;
import com.cmiot.commons.config.OtherRedisConfig;
import com.cmiot.commons.config.SystemRedisConfig;
import com.cmiot.commons.config.TempRedisConfig;
import com.cmiot.commons.log.ILog;
import com.cmiot.commons.log.LogImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@SpringBootApplication
@EnableEurekaClient
@EnableHystrixDashboard
@EnableCircuitBreaker
@ComponentScan(basePackages = "com.cmiot")
@EnableFeignClients(basePackages = "com.cmiot.wx.api")
public class WxServiceApplication {
    @Autowired
    private CardRedisConfig cardRedisConfig;

    @Autowired
    private CommonRedisConfig commonRedisConfig;

    @Autowired
    private SystemRedisConfig systemRedisConfig;

    @Autowired
    private TempRedisConfig tempRedisConfig;

    @Autowired
    private OtherRedisConfig otherRedisConfig;

    @Autowired
    private KafkaConfig kafkaConfig;

    public static void main(String[] args) {
        SpringApplication.run(WxServiceApplication.class, args);
    }

    @Bean
    public ICache getCache() {
        List<BaseRedisConfig> configs = Stream.of(cardRedisConfig, commonRedisConfig, systemRedisConfig,
                tempRedisConfig, otherRedisConfig).collect(Collectors.toList());
        return new CacheImpl(configs, kafkaConfig);
    }

    @Bean
    public ILog getLogger() {
        return new LogImpl();
    }
}