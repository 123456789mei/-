package com.cmiot.wx.vo;


import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

/**
 * 物联卡实时在线状态查询 传参实体
 *
 * @Author HuangXing
 * @Date 2020/12/8
 */
@Data
@ToString
public class ReTmOnLineWxVo implements Serializable {

    /**
     * 物联卡号
     */
    private String msisdn;

    /**
     * 用户IMSI标识
     */
    private String imsi;

    /**
     * 卡归属省份
     */
    private String provinceId;
}
