package com.cmiot.wx.model;

public class MsisdnVoForCT {

    /**
     * 物联卡号
     * */
    private String msisdn;

    /**
     * imsi
     * */
    private String imsi;

    /**
     * iccid
     * */
    private String iccid;

    /**
     * 物联卡状态
     * 1：待激活
     * 2：已激活
     * 4：停机
     * 6：可测试
     * 7：库存
     * 8：预销户
     * */
    private String status;

    /**
     * 上次状态更新时间
     * */
    private String lastChangeDate;

    /**
     * 激活日期
     * */
    private String activeDate;

    /**
     * 开卡时间
     * */
    private String openDate;

    /**
     * 集团客户Id
     * */
    private String custId;

    /**
     * 集团客户编码
     * */
    private String custCode;

    /**
     * 集团客户名称
     * */
    private String custName;

    /**
     * 归属省份
     * */
    private String beId;

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getIccid() {
        return iccid;
    }

    public void setIccid(String iccid) {
        this.iccid = iccid;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLastChangeDate() {
        return lastChangeDate;
    }

    public void setLastChangeDate(String lastChangeDate) {
        this.lastChangeDate = lastChangeDate;
    }

    public String getActiveDate() {
        return activeDate;
    }

    public void setActiveDate(String activeDate) {
        this.activeDate = activeDate;
    }

    public String getOpenDate() {
        return openDate;
    }

    public void setOpenDate(String openDate) {
        this.openDate = openDate;
    }

    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }

    public String getCustCode() {
        return custCode;
    }

    public void setCustCode(String custCode) {
        this.custCode = custCode;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getBeId() {
        return beId;
    }

    public void setBeId(String beId) {
        this.beId = beId;
    }
}
