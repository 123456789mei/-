package com.cmiot.wx.util;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ParamChecker {
    public static final String PARAM_NOT_NULL_TIPS = "param [%s] is null";
    public static final String PARAM_NOT_NUMBER = "param [%s] must be number";
    public static final String PARAM_OVER_MAXLENGTH = "param [%s] maxlength is ";

    public static final String PARAM_NOT_DATE_MONTH = "param [%s] must be yyyyMM";
    public static final String PARAM_NOT_DATE_DAY = "param [%s] must be yyyyMMdd ";

    public static final String PARAM_NOT_DATE = "param [%s] must be [%s]";
    public static final String PARAM_ONE_OF_THEM =
            "param [%s] must be one of them %s ,param value is [%s]";

    public static final String DATE_FMT_YYYYMMDDHHMMSS = "yyyyMMddhhmmss";

    private boolean isValid = true;
    private String checkResult;

    /**
     *
     * @return
     */
    public static ParamChecker newInstance() {
        return new ParamChecker();
    }

    public boolean isValid() {
        return this.isValid;
    }

    public boolean isNotValid() {
        return !isValid();
    }

    public void setValid(boolean valid) {
        this.isValid = valid;
    }

    /**
     * 非空检查
     * @param paramName
     * @param paramVal
     * @return
     */
    public ParamChecker notBlankCheck(String paramName, String paramVal) {
        if (!isValid()) {
            return this;
        }
        if (StringUtils.isBlank(paramVal)) {
            this.checkResult = String.format(PARAM_NOT_NULL_TIPS, paramName);
            this.setValid(false);
        }
        return this;
    }

    /**
     * 数字类型检查
     * @param paramName
     * @param paramVal
     * @return
     */
    public ParamChecker notNumberCheck(String paramName, String paramVal) {
        if (!isValid()) {
            return this;
        }
        if (!NumberUtils.isCreatable(paramVal)) {
            this.checkResult = String.format(PARAM_NOT_NUMBER, paramName, paramVal);
            this.setValid(false);
        }
        return this;
    }

    /**
     * 非空时数字类型检查
     * @param paramName
     * @param paramVal
     * @return
     */
    public ParamChecker notNullNumberCheck(String paramName, String paramVal) {
        if (!isValid()) {
            return this;
        }
        if (StringUtils.isNotEmpty(paramVal) && !NumberUtils.isCreatable(paramVal)) {
            this.checkResult = String.format(PARAM_NOT_NUMBER, paramName, paramVal);
            this.setValid(false);
        }
        return this;
    }

    /**
     * 检验IP是否合法
     * @param paramName
     * @param paramVal
     * @return
     */
    public ParamChecker notIpCheck(String paramName, String paramVal) {
        if (!isValid()) {
            return this;
        }
        String rexp = "([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])(\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])){3}";
        if (StringUtils.isNotEmpty(paramVal) && !paramVal.matches(rexp)) {
            this.checkResult = String.format(PARAM_NOT_NUMBER, paramName, paramVal);
            this.setValid(false);
        }
        return this;
    }

    /**
     *
     * @param paramName
     * @param paramVal
     * @param queryType
     * @return
     */
    public ParamChecker notDateCheck(String paramName, String paramVal, String queryType) {
        if (!isValid()) {
            return this;
        }
        String eL = "";
        String msg = "";
        if (StringUtils.isEmpty(paramVal)) {
            msg = PARAM_NOT_NULL_TIPS;
            this.checkResult = String.format(msg, paramName, paramVal);
            this.setValid(false);
            return this;
        }
        if ("day".equals(queryType)) {
            eL = "[0-9]{4}[0-9]{2}[0-9]{2}";
            msg = PARAM_NOT_DATE_DAY;
        } else if ("month".equals(queryType)) {
            eL = "[0-9]{4}[0-9]{2}";
            msg = PARAM_NOT_DATE_MONTH;
        }

        Pattern p = Pattern.compile(eL);
        Matcher m = p.matcher(paramVal);
        boolean dateFlag = m.matches();
        if (StringUtils.isNotEmpty(paramVal) && !dateFlag) {
            this.checkResult = String.format(msg, paramName, paramVal);
            this.setValid(false);
        }
        return this;
    }

    /**
     *
     * @param paramName
     * @param paramVal
     * @return
     */
    public ParamChecker notQueryTypeCheck(String paramName, String paramVal) {
        if (!isValid()) {
            return this;
        }
        String msg = "invalid querytype";
        boolean dataFlag = "day".equals(paramVal) || "month".equals(paramVal);
        if (StringUtils.isNotEmpty(paramVal) && !dataFlag) {
            this.checkResult = String.format(msg, paramName, paramVal);
            this.setValid(false);
        }
        return this;
    }

    /**
     * 长度检查
     * @param paramName
     * @param paramVal
     * @param length
     * @return
     */
    public ParamChecker paramLengthCheck(String paramName, String paramVal, int length) {
        if (!isValid()) {
            return this;
        }
        if (StringUtils.isNotEmpty(paramVal) && length < paramVal.length()) {
            this.checkResult = String.format(PARAM_OVER_MAXLENGTH, paramName) + length;
            this.setValid(false);
        }
        return this;
    }

    /**
     * 日期字符串
     * @param paramName
     * @param paramVal
     * @param formatStr
     * @return
     */
    public ParamChecker paramDateCheck(String paramName, String paramVal, String formatStr) {
        if (!isValid() || StringUtils.isEmpty(paramVal)) {
            return this;
        }

        SimpleDateFormat format = new SimpleDateFormat(formatStr);
        try {
            format.parse(paramVal);
        } catch (ParseException e) {
            this.checkResult = String.format(PARAM_NOT_DATE, paramName, formatStr);
            this.setValid(false);
        }
        return this;
    }

    private boolean isValidCheck() {
        return !this.isValid;
    }


    /**
     * 参数限定值检查。是否在数组中
     *
     * @param arr
     * @param paramName
     * @param paramVal
     * @param ignoreCase
     * @return
     */
    public ParamChecker arrContainsCheck(String[] arr, String paramName, String paramVal,
            boolean ignoreCase) {
        if (isValidCheck())
            return this;
        boolean result = false;
        if (StringUtils.isNotBlank(paramVal)) {
            for (String value : arr) {
                if (ignoreCase && value.equalsIgnoreCase(paramVal)) {
                    result = true;
                    break;
                }
                if (!ignoreCase && value.equals(paramVal)) {
                    result = true;
                }
            }
            if (!result) {
                this.checkResult =
                        String.format(PARAM_ONE_OF_THEM, paramName, Arrays.toString(arr), paramVal);
                this.setValid(false);
            }
        }

        return this;
    }

    public String getCheckResult() {
        return this.checkResult;
    }



    /**
      * @Author zhao.zhilue@ustcinfo.com
      * @Description //TODO 校验电话号码
      * @Date 10:41 2018/09/09
      * @Param
      * @return
      **/
    public boolean phoneNumberCheck(String paramVal){

        if (!isValid() || StringUtils.isEmpty(paramVal)) {
            return false;
        }
        String regex = "^((13[0-9])|(14[5,7,9])|(15([0-3]|[5-9]))|(166)|(17[0,1,3,5,6,7,8])|(18[0-9])|(19[8|9]))\\d{8}$";
        if (paramVal.length() != 11) {
            return false;
        } else {
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(paramVal);
            boolean isMatch = m.matches();
            return isMatch;
        }
    }
}

