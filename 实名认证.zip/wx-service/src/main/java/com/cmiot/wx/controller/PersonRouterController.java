package com.cmiot.wx.controller;

import com.cmiot.wx.api.client.WxApiClient;
import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.cache.impl.CacheManager;
import com.cmiot.commons.log.ILog;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.commons.rest.RestBase;
import com.cmiot.wx.service.RsaService;
import com.cmiot.wx.constant.CommomConstant;
import com.cmiot.wx.util.CommonUtils;
import com.cmiot.wx.util.PersonalUtil;
import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;


/**
 * @author xiapeicheng
 * @date 2019/1/4 16:14
 * @email xiapeicheng@cmiot.chinamobile.com
 */
@Controller
@RequestMapping("/person")
public class PersonRouterController extends RestBase {


    Logger logger = LoggerFactory.getLogger(PersonRouterController.class);


    @Autowired
    private ILog ilog;

    @Autowired
    ICache cache;

    @Autowired
    HttpServletRequest request;

    @Autowired
    WxApiClient wxApiClient;

    @Autowired
    RsaService rsaService;

    @Autowired
    PersonalUtil personalUtil;


    /**
     * 登录页面
     */
    @RequestMapping(value = "/login")
    public String personLogin(Model model, HttpServletRequest request) {
        String openId = request.getParameter(CommomConstant.OPEN_ID);
        String msgId = request.getParameter("msgId");
        model.addAttribute("openId", openId);
        model.addAttribute("errMsg", chooseMsg(msgId));
        return "/login/personLogin";
    }

    /**
     * 个人首页
     * @param model
     * @param request
     * @return
     * 个人业务入口地址
     */
    @RequestMapping(value = "/index")
    public String index(Model model, HttpServletRequest request) {

        String phone = request.getParameter(CommomConstant.PHONE);
        String openId = request.getParameter(CommomConstant.OPEN_ID);
        String code = request.getParameter(CommomConstant.CODE);
        if (StringUtils.isEmpty(phone) || StringUtils.isEmpty(openId)){
            openId = personalUtil.getOpenId(code);
        }

        if(openId == null || StringUtils.isEmpty(openId)){
            //未获取到openId，跳转至错误页面
            logger.error("个人业务入口，未获取到openId");
            model.addAttribute("msg", "获取OpenId失败，请重新进入");
            return "/person/error";
        }
        logger.info("个人业务入口，openId is:[{}]",openId);
        phone = personalUtil.getPhoneFomeDb(openId);
        ilog.info(logger, null, null, "openId:{}, phone:{}", openId, CommonUtils.mobileEncrypt(phone));
        Map<String, String> params = new HashMap<>(1);
        params.put("phone", phone);
        ResponseVo responseVo = wxApiClient.getUserIdByPhone(params, getTransNo(request), getAccessToken(request));
        String userId = (String) responseVo.getData();
        String ticket = generateTicket(openId, phone, userId);
        String url = spliceIndexUrl(ticket);
        model.addAttribute("url", url);
        return "/person/accessIndex";
    }

    @RequestMapping("/createAccount")
    public String create(Model model, HttpServletRequest request){
        String phone = request.getParameter(CommomConstant.PHONE);
        String openId = request.
                getParameter(CommomConstant.OPEN_ID);
        ilog.info(logger, null, null, "注册账号");
        Map<String, String> params = new HashMap<>(2);
        params.put("phone", phone);
        params.put("openId", openId);
        wxApiClient.personRegister(params);
        model.addAttribute("openId", openId);
        model.addAttribute("phone", phone);
        return "/person/verifiedLogin";
    }

    @RequestMapping("/error")
    public String error(Model model, @RequestParam String type){
        switch (type){
            case "1":
                //获取OpenId失败
                model.addAttribute("msg", "获取OpenId失败，请重新进入");
                break;
            case "2":
                //账号信息出错
                model.addAttribute("msg", "账号信息有误，请联系管理员处理");
                break;
            case "3":
                //非正常入口进入
                model.addAttribute("msg", "不允许访问");
                break;
            default:
                model.addAttribute("msg", "未知错误");
        }
        return "/person/error";
    }

    @RequestMapping("/transfer")
    public String transfer(Model model, HttpServletRequest request){
        String baseUrl = cache.getSysParams("WX_BASE_URL", "");
        String url = baseUrl + "/service/person/index.html";
        model.addAttribute("url", url);
        return "/person/transfer";
    }


    private String chooseMsg(String msgId){
        switch (msgId) {
            case "1":
                return "新公众号接入，请登录";
            case "2":
                return "登录已注销，请重新登录";
            case "3":
                return "该账号已在别处登录，请检查账号并重新登录";
            case "4":
                return "登录已注销，请重新登录";
            case "5":
                return "该账号已注销，请重新注册登录";
            default:
                return "";
        }
    }

    private String spliceIndexUrl(String ticket){
        String baseUrl = cache.getSysParams("WX_BASE_URL", "");
        StringBuilder url = new StringBuilder(baseUrl);
        url.append("/service/person/index.html#!/").append("?")
                .append("ticket").append("=").append(ticket);
        return url.toString();
    }

    /**
     * 生成临时票据(key)，保存数据到缓存中(5分钟)
     */
    private String generateTicket(String openId, String phone, String userId){

        String ticket = UUID.randomUUID().toString();
        String value = new StringBuilder(openId).append(",").append(phone).append(",").append(userId).toString();
        cache.put(CacheManager.PublicNameSpace.TEMP, CommomConstant.CAHCE_LOGIN_TICKET_PRE + ticket, value, 300);
        logger.info("临时ticket已生成:{}，有效时间5分钟",ticket);
        return ticket;
    }

    /**
     * 查询实名认证结果
     *
     * @param model
     * @param busiSeq
     * @return
     */
    @RequestMapping("/getRealNameAuthResult")
    public String getRealNameAuthResult(Model model, @RequestParam String busiSeq){
        Map map = new HashMap(1);
        map.put("busiSeq", busiSeq);
        Map respMap = wxApiClient.getRealNameAuthResult(map, getTransNo(request) , getAccessToken(request));
        String baseUrl = cache.getSysParams("WX_BASE_URL", "");
        StringBuilder redirectUrl = new StringBuilder(baseUrl).append("/service/person/index.html#!/authResult");
        logger.info("实名认证结果跳转地址：{}", redirectUrl.toString());
        model.addAttribute("url", redirectUrl.toString());
        if(MapUtils.isEmpty(respMap)){
            model.addAttribute("code", "5001");
            model.addAttribute("msg", "获取审核结果信息失败，请重试！");
            return "/person/transferAuthResult";
        }
        //pb物联卡认证流程
        ResponseVo vo = wxApiClient.orderNumCheck(map, getTransNo(request));
        if(vo!=null&&"0".equals(vo.getCode())){
            if("0".equals(vo.getData())){
                logger.info("pb-H5材料提交成功，回调url:{}",redirectUrl.toString());
                return "/person/transferAuthResultH5";
            }else {
                logger.info("pb-公众号材料提交成功，回调url:{}",redirectUrl.toString());
                model.addAttribute("code", "5050");
                model.addAttribute("msg", "登记结果稍后以短信方式通知！");
                return "/person/transferAuthResult";
            }
        }
        String returnCode = (String) respMap.get("returnCode");
        String returnMessage = (String) respMap.get("returnMessage");
        String auditStatus = (String) respMap.get("auditStatus");
        String auditMessage = (String) respMap.get("auditMessage");
        //认证失败（系统或业务错误）
        if(org.springframework.util.StringUtils.isEmpty(returnCode)){
            model.addAttribute("code", "5002");
            model.addAttribute("msg", "系统错误，认证失败！");
            //身份证件无效
        }else if("0001".equals(returnCode)){
            model.addAttribute("code", "5003");
            model.addAttribute("msg", returnMessage);
            //审核不通过
        }else if("2".equals(auditStatus)){
            model.addAttribute("code", "5004");
            model.addAttribute("msg", "对不起，您本次认证信息审核不通过！" + (org.springframework.util.StringUtils.isEmpty(auditMessage)?"":"原因："+auditMessage));
            //待审核
        }else if("1".equals(auditStatus)){
            model.addAttribute("code", "5005");
            model.addAttribute("msg", "本次认证正在人工审核中！");
            //认证成功
        }else{
            model.addAttribute("code", "5000");
            model.addAttribute("msg", "认证成功！");
        }
        return "/person/transferAuthResult";
    }
}
