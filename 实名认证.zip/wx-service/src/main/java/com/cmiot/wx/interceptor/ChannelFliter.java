package com.cmiot.wx.interceptor;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * @author xiapeicheng
 * @date 2019/1/24 14:28
 * @email xiapeicheng@cmiot.chinamobile.com
 */

public class ChannelFliter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        ServletRequest requestWrapper = null;
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        /**
         * 放过微信访问过来的推送接口
         * */
        if(request.getRequestURI().contains("/wxMsg/receiveMsg")){
            filterChain.doFilter(servletRequest, servletResponse);
            return;
        }

        if(servletRequest instanceof HttpServletRequest) {
            requestWrapper = new RequestWrapper((HttpServletRequest) servletRequest);
        }
        if(requestWrapper == null) {
            filterChain.doFilter(servletRequest, servletResponse);
        } else {
            filterChain.doFilter(requestWrapper, servletResponse);
        }
    }

    @Override
    public void destroy() {

    }

}

