package com.cmiot.wx.util;

import com.alibaba.fastjson.JSONObject;
import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.cache.impl.CacheManager;
import com.cmiot.commons.common.constants.ParamConstants;
import com.cmiot.commons.common.utils.HttpRequestClient;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.log.ILog;
import com.cmiot.commons.response.ResponseCode;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.commons.vo.MsisdnCacheVo;
import com.cmiot.wx.api.client.WxApiClient;
import com.cmiot.wx.constant.CommomConstant;
import com.cmiot.wx.service.RsaService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

@Component
public class PublicUtils {

    Logger logger = LoggerFactory.getLogger(PublicUtils.class);

    @Autowired
    ICache cache;

    @Autowired
    WxApiClient wxApiClient;

    @Autowired
    private ILog ilog;

    @Autowired
    RsaService rsaService;

    @Autowired
    HttpRequestClient httpRequestClient;

    private static final String WX_USER_LOGIN_TIME = "WX_LOGIN_";

    //登录过期时间
    private static final Integer LOGIN_TIMEOUT_TIME = 30;

    private final String CT_TYPE_MSISDN = "1";
    private final String CT_TYPE_ICCID = "2";
    private final String CT_TYPE_IMSI = "3";

    /**
     * 获取时间天数差值 传入起始时间字符串
     */
    public int getTimeDiff(String boginTime) {
        SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String toDate = simpleFormat.format(System.currentTimeMillis());
        long from = 0;
        int days = 0;
        long to = 0;
        try {
            from = simpleFormat.parse(boginTime).getTime();
            to = simpleFormat.parse(toDate).getTime();
            days = (int) ((to - from) / (1000 * 60 * 60 * 24));
        } catch (ParseException e) {
            ilog.error(logger, null, null, "get wx login time diff error :" + e);
        }
        return days;
    }

    /**
     * 设置或更新 微信用户登陆时间
     */
    public void setUserLoginCache(String openId) {
        SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        cache.put(CacheManager.PublicNameSpace.USERAUTH, WX_USER_LOGIN_TIME + openId, simpleFormat.format(System.currentTimeMillis()), -1);
    }

    public void removeUserLoginCache(String openId) {
        cache.remove(CacheManager.PublicNameSpace.USERAUTH, WX_USER_LOGIN_TIME + openId);
    }

    /**
     * 检验用户是否需要重新验证码登录
     */
    public boolean checkUserLogin(String openId) {
        boolean loginFlag = false;
        String lastLoginTime = cache.get(CacheManager.PublicNameSpace.USERAUTH, WX_USER_LOGIN_TIME + openId);
        if (lastLoginTime == null || StringUtils.isEmpty(lastLoginTime)) {
            //设置wx用户登陆时间 缓存 -1 不过期
            //首次登录直接 设置登陆时间
            setUserLoginCache(openId);
            return false;
        }

        if (CommomConstant.PUBLIC_LOGOUT_STRING.equals(lastLoginTime)) {
            loginFlag = true;
        }

        //测试情况
        if (getTimeDiff(lastLoginTime) > LOGIN_TIMEOUT_TIME) {
            loginFlag = true;
        }
        return loginFlag;
    }

    public boolean checkUserBindPhone(String openId, String phone, String transNo, String token) {
        boolean isBindFlag = false;
        Map map = new HashMap(1);
        map.put("openId", openId);
        ResponseVo responseVo = wxApiClient.getUserPhoneByOpenId(map, transNo, token);
        String bindPhone = (String) responseVo.getData();
        if (phone.equals(bindPhone)) {
            isBindFlag = true;
        }

        return isBindFlag;
    }

    /**
     * 记录EC账户密码错误次数
     */
    public int checkPwdErrorTimes(String userId, String ecName) {
        //记录密码错误次数
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        String timeStr = format.format(System.currentTimeMillis());
        String key = userId + ecName;
        String hisValue = cache.get(CacheManager.PublicNameSpace.USERAUTH, key);
        int newValue;
        String[] values = StringUtils.isEmpty(hisValue) ? new String[]{"0"} : hisValue.split("-");
        if (Long.valueOf(timeStr) > Long.valueOf(values[0])) {
            //检查是否已经跨天
            cache.remove(CacheManager.PublicNameSpace.USERAUTH, key);
            hisValue = null;
        }
        if (hisValue != null) {
            int oldTimes = Integer.valueOf(hisValue.split("-")[1]);
            newValue = oldTimes + 1;
        } else {
            newValue = 1;
        }
        /**
         * TODO 账户密码错误次数，记录24小时
         **/
        cache.put(CacheManager.PublicNameSpace.USERAUTH, key, timeStr + "-" + newValue, 24 * 60 * 60);
        return newValue;
    }

    /**
     * 根据用户类型返回首页地址
     */
    public String getLoginReturnPath(String type, Model model) {
        String returnUri = "";
        switch (type) {
            case "0":
                //个人用户首页
                returnUri = "/person/index";
                break;
            case "1":
                //企业用户首页
                returnUri = "/search/search";
                break;
            case "2":
                returnUri = "/setting/bindCompany";
                rsaService.getKeyPair(model);
                break;
            default:
                break;
        }
        return returnUri;
    }

    /**
     * 图片验证码校验
     */
    public ResponseVo checkImageCode(String openId, String imgCode, String transNo) {
        logger.info("transNo is [{}]，check imageCode start", transNo);
        // 校验图片验证码
        String imgCode1 = cache.get(CacheManager.PublicNameSpace.USERAUTH, openId);
        if (imgCode1 == null) {
            ResponseVo responseVo = ResponseVo.fail("555");
            responseVo.setData("验证码错误，请重新输入！");
            return responseVo;
        }
        //对比小写
        if (!imgCode1.toLowerCase().equals(imgCode.toLowerCase())) {
            ResponseVo responseVo = ResponseVo.fail(ResponseCode.ERROR_INVALID_PARAMS);
            responseVo.setData("验证码错误，请重新输入！");
            return responseVo;
        }
        //验证通过 移除验证码
        cache.remove(CacheManager.PublicNameSpace.USERAUTH, openId);
        return ResponseVo.success("");
    }

    /**
     * 校验账号为CT OR PB
     */
    public static boolean isPBOper(String operId) {
        boolean isPb = true;
        if (operId.startsWith("OU") || operId.startsWith("BE")) {
            isPb = false;
        }
        return isPb;
    }

    /**
     * 获取CT物联卡基础信息
     */
    private Map getCTMsisdnVo(String msisdn) {
        //缓存中不存在卡号，CT物联卡
        logger.info("CT物联卡信息转换成卡号，msisdn is:[{}]", msisdn);
        ResponseVo responseVo = wxApiClient.getStatusByMsisdn(msisdn, "wx-service");
        if (responseVo == null || !responseVo.isSuccess()) {
            logger.info("查询CT物联卡信息失败,msisdn is:[{}]", msisdn);
            return null;
        }
        Map resData = JsonUtils.parseObjectToMap(responseVo.getData());
        logger.info("CT物联卡信息查询返回，data is:[{}],msisdn is:[{}]", JsonUtils.parseString(resData), msisdn);
        return resData;
    }

    /**
     * 判断物联卡参数类型
     */
    public String initMsisdn(String cardNumber) {
        if (cardNumber.startsWith("1")) {
            //MSISDN
            return CT_TYPE_MSISDN;
        } else if (cardNumber.startsWith("4")) {
            //IMSI
            return CT_TYPE_IMSI;
        } else if (cardNumber.startsWith("8")) {
            //ICCID
            return CT_TYPE_ICCID;
        }
        return CT_TYPE_MSISDN;
    }

    /**
     * 物联卡转换
     */
    public String getMisidn(String cardNumber) {
        String msisdn = cardNumber;
        char firstChar = cardNumber.charAt(0);
        if (firstChar == '8') {
            cardNumber = cache.getMsisdnByIccid(cardNumber);
            if (StringUtils.isEmpty(cardNumber)) {
                Map ctVo = getCTMsisdnVo(msisdn);
                if (ctVo != null && ctVo.size() > 0) {
                    cardNumber = String.valueOf(ctVo.get(ParamConstants.MSISDN));
                }
            }
        } else if (firstChar == '4') {
            cardNumber = cache.getMsisdnByImsi(cardNumber);
            if (StringUtils.isEmpty(cardNumber)) {
                Map ctVo = getCTMsisdnVo(msisdn);
                if (ctVo != null && ctVo.size() > 0) {
                    cardNumber = String.valueOf(ctVo.get(ParamConstants.MSISDN));
                }
            }
        } else if (firstChar == '1') {
            cardNumber = cardNumber;
        } else {
            cardNumber = null;
        }
        return cardNumber;
    }

    public Map getMsisdnMap(String cardNumber) {
        String msisdn = cardNumber;
        Map datas = new HashMap();
        char firstChar = cardNumber.charAt(0);
        if (firstChar == '8') {
            cardNumber = cache.getMsisdnByIccid(cardNumber);
            if (StringUtils.isEmpty(cardNumber)) {
                Map ctVo = getCTMsisdnVo(msisdn);
                if (ctVo != null && ctVo.size() > 0) {
                    return ctVo;
                }
            } else {
                datas.put(ParamConstants.MSISDN, cardNumber);
            }
        } else if (firstChar == '4') {
            cardNumber = cache.getMsisdnByImsi(cardNumber);
            if (StringUtils.isEmpty(cardNumber)) {
                Map ctVo = getCTMsisdnVo(msisdn);
                if (ctVo != null && ctVo.size() > 0) {
                    return ctVo;
                }
            } else {
                datas.put(ParamConstants.MSISDN, cardNumber);
            }
        } else if (firstChar == '1') {
            MsisdnCacheVo msisdnCacheVo = cache.getByMsisdn(cardNumber);
            Map msisdnMap = (msisdnCacheVo == null) ? null : JsonUtils.parseObjectToMap(msisdnCacheVo);
            if (msisdnMap == null || msisdnMap.size() < 2) {
                Map ctVo = getCTMsisdnVo(msisdn);
                if (ctVo != null && ctVo.size() > 0) {
                    return ctVo;
                }
            } else {
                datas.put(ParamConstants.MSISDN, cardNumber);
                return datas;
            }
        }
        return datas;
    }

    /**
     * 人像图片处理
     * 个人业务实名登记图像长宽比转换
     * 16:9
     */
    public File translateFile(File sourceFile) throws Exception{
        String newFileName = sourceFile.getPath();
        if (StringUtils.isEmpty(newFileName)) {
            logger.error("未获取到源文件存储路径");
            throw new Exception("未获取到源文件");
        }
        String sourceFilePath;

        if (FileUtil.getBytes(sourceFile).length < CommomConstant.REAL_NAME_FILE_MIN) {
            //原始图片小于50KB，直接报错
            logger.info("源文件小于50KB，提示错误,file Path is:[{}]", sourceFile.getPath());
            throw new Exception("人像图片小于50KB，不符合系统规范，请重新选择文件上传");
        }

        if (FileUtil.getBytes(sourceFile).length > CommomConstant.REAL_NAME_FILE_MAX) {
            //只有图像大于的时候压缩，如果小于了50KB，直接报错。图像压缩
            logger.info("源文件大于300KB,进行图像压缩处理");
            sourceFilePath = reScaleImg(false, sourceFile);
        } else {
            sourceFilePath = sourceFile.getPath();
        }
        if (StringUtils.isEmpty(sourceFilePath)) {
            logger.error("图像压缩失败");
            throw new Exception("人像图片压缩失败，请重新上传文件");
        }
        File source = new File(sourceFilePath);
        if (FileUtil.getBytes(source).length < CommomConstant.REAL_NAME_FILE_MIN || FileUtil.getBytes(source).length > CommomConstant.REAL_NAME_FILE_MAX) {
            logger.info("人像照处理后仍不满足大于50KB，小于300KB的系统要求");
            throw new Exception("人像图片处理后仍不满足系统要求，请重新上传文件");
        }
        newFileName = sourceFilePath.split("\\.")[0].concat("_new.jpg");
        BufferedImage image = ImageHandleUtils.getImage(source);
        if (image == null) {
            logger.error("读取图像对象失败，获得内容为null");
            throw new Exception("人像图片长宽比处理失败，请重新上传");
        }
        int width = image.getWidth();
        int height = image.getHeight();
        if (width < height) {
            logger.info("图像宽度小于高度，不符合横向拍摄要求");
            throw new Exception("人像图片不满足横向拍摄要求");
        }
        int newWidth;
        int newHeight;
        int divisor = maxDivisor(width, height); //获取最大公约数
        int times = width / divisor;
        int times1 = times / 16;
        if (times1 >= 1) {
            newWidth = divisor * times1 * 16;
            newHeight = divisor * times1 * 9;
        } else {
            int timesA = times / 4;
            if (timesA == 0) {
                //当倍数达不到最小公约诉4倍时，强制转成4倍
                timesA = 1;
            }
            newWidth = divisor * timesA * 4;
            newHeight = divisor * timesA * 3;
        }
        try {
            ImageHandleUtils.scale2(source, newFileName, newHeight, newWidth, true);
            return new File(newFileName);
        } catch (Exception e) {
            logger.error("实名登记图像转换失败：", e);
            throw new Exception("人像图片长宽比处理失败，请重新上传");
        }
    }

    /**
     * 个人业务图片大小压缩处理
     */
    public String scaleSize(File file) {
        int idx = file.getPath().indexOf(".");
        String imgdist = file.getPath().substring(0, idx) + "_modify.jpg";//压缩图地址
        int[] size = ImageUtil.getImgWidthHeight(file);//压缩图宽高
        long srcSiz = file.length();
        //TODO 缩放比率这里需要做细节优化调整
        Float rate = 1f;
        if (srcSiz > 1.5 * 1024 * 1024) {
            rate = 0.5f;
        } else if (srcSiz > 1 * 1024 * 1024 && srcSiz < 1.5 * 1024 * 1024) {
            rate = 0.6f;
        } else if (srcSiz > 0.5 * 1024 * 1024 && srcSiz < 1 * 1024 * 1024) {
            rate = 0.7f;
        } else if (srcSiz > 307200 && srcSiz < 0.5 * 1024 * 1024) {
            rate = 0.98f;
        } else if (srcSiz > 51200 && srcSiz < 307200) {
            rate = 2.2f;
        } else if (srcSiz < 51200) {
            rate = 3.2f;
        }
        ImageUtil.reduceImg(file.getPath(), imgdist, size[0], size[1], rate);//生成压缩图
        return imgdist;
    }

    /**
     * 递归压缩文件
     */
    public String reScaleImg(boolean delSource, File file) {
        String destFile = scaleSize(file);
        File newFile = new File(destFile);
        if (delSource && file.exists()) {
            //删除递归过程产生的文件
            file.delete();
        }
        if (FileUtil.getBytes(newFile).length > CommomConstant.REAL_NAME_FILE_MAX) {
            return reScaleImg(true, newFile);
        } else {
            return destFile;
        }
    }

    /**
     * 计算最大公约数
     */
    public int maxDivisor(int dividend1, int dividend2) {
        int begin = dividend1 >= dividend2 ? dividend2 : dividend1;
        int divisor = 1;
        for (int i = begin; i >= 1; i--) {
            if (dividend1 % i == 0 && dividend2 % i == 0) {
                divisor = i;
                break;
            }
        }
        return divisor;
    }

    /**
     * 读取实名登记第二步上传的临时图像文件
     */
    public File getTempFile(String sourcePath, String newFile) {
        File file = new File(newFile);
        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
        }
        try (
                FileChannel sourceFile = FileChannel.open(Paths.get(sourcePath), new StandardOpenOption[]{StandardOpenOption.READ});
                FileChannel destFile = FileChannel.open(Paths.get(newFile), new StandardOpenOption[]{StandardOpenOption.CREATE, StandardOpenOption.WRITE})
        ) {
            destFile.transferFrom(sourceFile, 0, sourceFile.size());
        } catch (IllegalStateException | IOException e) {
            logger.error("物联卡实名登记，OCR文件复制错误", e);
            return null;
        }
        logger.info("OCR临时文件复制完成，删除临时文件");
        File oldFile = new File(sourcePath);
        if (oldFile.exists()) {
            oldFile.delete();
        }
        return new File(newFile);
    }

    /**
     * 测试环境获取模拟OCR数据
     */
    public Map getTestOcrData(String transNo, String type) {
        logger.info("transNo:[{}],>>> 开启模拟OCR扫描", transNo);
        Map ocrResultMap;
        switch (type) {
            case "Front":
                ocrResultMap = JSONObject.parseObject(cache.getSysParams("WX.OCR.OCR_TEST_CERT_FRONT_JSON", ""), Map.class);
                break;
            case "Back":
                ocrResultMap = JSONObject.parseObject(cache.getSysParams("WX.OCR.OCR_TEST_CERT_BACK_JSON", ""), Map.class);
                break;
            default:
                logger.info("transNo:[{}],未知的图像识别类型，type is:[{}]", transNo, type);
                return new HashMap<>();
        }
        //模拟微信服务返回失败的情况
        return ocrResultMap;
    }
}