package com.cmiot.wx.constant;

/**
 * @author xiapeicheng
 * @date 2019/1/9 11:05
 * @email xiapeicheng@cmiot.chinamobile.com
 */
public class PersonalConstant {

    /**
     *微信个人用户在缓存中设置登录时间前缀
     */
    public static final String PERSONAL_LOGIN_TIME_PREFIX = "personal_login_time_";

    /**
     * 微信个人用户登录过期时间
     */
    public static final Integer PERSONAL_LOGIN_TIMEOUT_TIME = 30;

    public static final String EXCEPTION_RETURN_CODE ="2999";

    public static final String CMIOT_CODE = "230030";

    public static final String ONLINE_CODE = "1085"; //在线公司的

    public static final String RESULT_BUSI_CODE ="RETURN_CERT_RESULT_BACK";

    public static final String DESKEY_BUSI_CODE ="PUSH_KEY";

    public static final String AUTH_BUSI_TYPE ="23"; //视频认证

    public static final String MSG_VERSION="1.0";

}
