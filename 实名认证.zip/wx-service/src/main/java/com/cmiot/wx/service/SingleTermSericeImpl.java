package com.cmiot.wx.service;

import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.common.constants.ParamConstants;
import com.cmiot.commons.common.utils.HttpRequestClient;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.log.ILog;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.commons.rest.RestBase;
import com.cmiot.commons.vo.MsisdnCacheVo;
import com.cmiot.wx.api.client.INetStatusWxHlrClient;
import com.cmiot.wx.api.client.WxApiClient;
import com.cmiot.wx.model.SingleTermStateEntity;
import com.cmiot.wx.vo.ReTmOnLineWxVo;
import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Created by zhyou on 2017/6/16.
 */
@Service
public class SingleTermSericeImpl extends RestBase {
    static Logger logger = LoggerFactory.getLogger(SingleTermSericeImpl.class);

    @Autowired
    HttpServletRequest request;

    @Autowired
    ILog iLog;

    @Autowired
    ICache cache;

    @Autowired
    WxApiClient wxApiClient;

    SingleTermStateEntity singleTermStateEntity = new SingleTermStateEntity();

    @Autowired
    HttpRequestClient httpRequestClient;

    @Autowired
    INetStatusWxHlrClient netStatusWxHlrClient;

    /**
     * map 里面需要包含 msisdn oper对象
     */
    public ResponseVo querySingleTermState(Map map, String transNo) {
        if (StringUtils.isBlank(map.get(ParamConstants.MSISDN).toString())) {
            return null;
        }
        String imsi = "";
        MsisdnCacheVo msisdnCacheVo = cache.getByMsisdn(map.get(ParamConstants.MSISDN).toString());
        //物联卡归属省份
        String cardProvinceId = "";
        if (msisdnCacheVo != null) {
            imsi = msisdnCacheVo.getImsi();
            cardProvinceId = msisdnCacheVo.getProvinceId();
        } else {
            //缓存中不存在卡号，CT物联卡
            ResponseVo responseVo = wxApiClient.getStatusByMsisdn(String.valueOf(map.get(ParamConstants.MSISDN)), transNo);
            if (responseVo == null || !responseVo.isSuccess()) {
                return null;
            }
            Map resData = JsonUtils.parseObjectToMap(responseVo.getData());
            imsi = String.valueOf(resData.get(ParamConstants.IMSI));
            cardProvinceId = String.valueOf(resData.get(ParamConstants.CCMP_BEID));
        }
        singleTermStateEntity.setImsi(imsi);
        //调用hlr-service 查询卡实时在线状态
        ReTmOnLineWxVo realTimeOnLineVo = new ReTmOnLineWxVo();
        realTimeOnLineVo.setImsi(imsi);
        realTimeOnLineVo.setMsisdn(map.get(ParamConstants.MSISDN).toString());
        realTimeOnLineVo.setProvinceId(cardProvinceId);
        iLog.info(logger, transNo, null, "method querySingleTermState query RealTime online status from hlr-service params is:[{}]", realTimeOnLineVo);
        ResponseVo onLineRe = netStatusWxHlrClient.queryReTmOnlineStatus(realTimeOnLineVo, transNo);
        iLog.info(logger, transNo, null, "method querySingleTermState query RealTime online status from hlr-service end result is:[{}]", onLineRe.getData());
        String onlineStatus = (String) onLineRe.getData();
        singleTermStateEntity.setStatus(onlineStatus);
        return ResponseVo.success(singleTermStateEntity);
    }

}
