package com.cmiot.wx.constant;

public class WxConstant {
    public static String PUSH_MSG_CONTENT = "Content";
    public static String PUSH_MSG_MSGTYPE = "MsgType";
    public static String PUSH_MSG_FROMUSERNAME = "FromUserName";
    public static String PUSH_MSG_TOUSERNAME = "ToUserName";
    public static String PUSH_MSG_STATUS = "Status";

    public static String MSGTYPE_EVENT = "event";

    public static String PARAM_AUTOKEY = "autoKey";
    public static String PARAM_MSGTYPE = "MSGTYPE";
    public static String PARAM_CONTENT = "CONTENT";
    public static String PARAM_MEDIAID = "MEDIAID";
    public static String PARAM_ID = "ID";

    public static String PARAM_TITLE = "TITLE";
    public static String PARAM_DESCRIPTION = "DESCRIPTION";
    public static String PARAM_PICURL = "PICURL";
    public static String PARAM_URL = "URL";
    public static String PARAM_Event = "Event";
}
