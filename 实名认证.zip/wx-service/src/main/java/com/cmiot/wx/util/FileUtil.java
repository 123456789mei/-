package com.cmiot.wx.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;

public class FileUtil {
    private FileUtil() {

    }

    private static final Logger LOGGER = LoggerFactory.getLogger(FileUtil.class);

    /**
     * 获得指定文件的byte数组
     */
    public static byte[] getBytes(File file) {
        byte[] buffer = null;
        try (FileInputStream fis = new FileInputStream(file);) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream(1000);
            byte[] b = new byte[1000];
            int n;
            while ((n = fis.read(b)) != -1) {
                bos.write(b, 0, n);
            }
            buffer = bos.toByteArray();
        } catch (FileNotFoundException e) {
            LOGGER.error("转换身份图形异常：{}", e);
        } catch (IOException e) {
            LOGGER.error("转换身份图形IO异常：{}", e);
        }
        return buffer;
    }
}
