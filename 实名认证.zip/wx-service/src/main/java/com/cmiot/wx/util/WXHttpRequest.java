package com.cmiot.wx.util;

import com.cmiot.commons.log.ILog;
import com.cmiot.wx.constant.CommomConstant;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import static org.apache.catalina.manager.Constants.CHARSET;

/**
 * 微信http请求
 */
public class WXHttpRequest {

    @Autowired
    private static ILog ilog;

    private static final Logger LOGGER = LoggerFactory.getLogger(WXHttpRequest.class);

    private WXHttpRequest() {

    }

    /**
     * 表单提交参数和文件
     *
     * @param urlPath
     * @param params
     * @param file
     * @param conTimeOut
     * @param soTimeOut
     * @return
     */
    public static String postForm(String urlPath, Map<String, String> params, File file, int conTimeOut, int soTimeOut, String transNo) {
        try (CloseableHttpClient httpClient = HttpClients.createDefault();) {
            HttpPost httpPost = new HttpPost(urlPath);
            MultipartEntityBuilder entityBuilder = MultipartEntityBuilder.create();
            entityBuilder.addPart("img", new FileBody(file)); // 文件参数

            Iterator<Map.Entry<String, String>> it = params.entrySet().iterator();
            while (it.hasNext()) {// 字符串参数
                Map.Entry<String, String> entry = it.next();
                String key = entry.getKey();
                String value = entry.getValue();
                StringBody stringBody = new StringBody(value, ContentType.create("text/plain", CHARSET));
                entityBuilder.addPart(key, stringBody);
            }

            HttpEntity httpEntity = entityBuilder.build();
            httpPost.setEntity(httpEntity);
            RequestConfig config = RequestConfig.custom()
                    .setConnectTimeout(conTimeOut)
                    .setSocketTimeout(soTimeOut) // read time out
                    .build();
            httpPost.setConfig(config); // 请求配置
            CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
            InputStream in = httpResponse.getEntity().getContent();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(in));
            StringBuilder sb = new StringBuilder();
            String readLine = null;
            while ((readLine = bufferedReader.readLine()) != null) {
                sb.append(readLine);
            }
            return sb.toString();
        } catch (Exception e) {
            LOGGER.error("OCR扫描异常 transNO：{}, error：{}", transNo, e);
            return null;
        }
    }

    /**
     * 将文件下载到指定地址
     *
     * @param downURL
     * @param downDir
     * @param fileName
     * @param method
     * @return
     */
    public static File downloadFile(String downURL, String downDir, String fileName, String method) {
        File file = null;
        try {
            // 统一资源
            URL url = new URL(downURL);
            // 连接类的父类，抽象类
            URLConnection urlConnection = url.openConnection();
            // http的连接类
            HttpURLConnection httpURLConnection = (HttpURLConnection) urlConnection;
            // 设定请求的方法，默认是GET
            httpURLConnection.setRequestMethod(StringUtils.isEmpty(method) ? "GET" : "POST");
            // 设置字符编码
            httpURLConnection.setRequestProperty("Charset", "UTF-8");
            // 打开到此 URL 引用的资源的通信链接（如果尚未建立这样的连接）。
            httpURLConnection.connect();
            //获取文件扩展名
            String ext = getExt(httpURLConnection.getContentType());
            if (StringUtils.isEmpty(ext)) {
                LOGGER.error("获取微信临时素材文件后缀名为null");
                return null;
            }
            String path = new StringBuilder(downDir)
                    .append(File.separatorChar)
                    .append(CommomConstant.PLATFORM_WX_OA)
                    .append(File.separator)
                    .append(new SimpleDateFormat("yyyy-MM-dd").format(new Date()))
                    .append(File.separatorChar)
                    .append(fileName).append(ext).toString();
            file = new File(path);
            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }
            try (BufferedInputStream bin = new BufferedInputStream(httpURLConnection.getInputStream()); OutputStream out = new FileOutputStream(file);) {
                int size = 0;
                byte[] buf = new byte[1024];
                while ((size = bin.read(buf)) != -1) {
                    out.write(buf, 0, size);
                }
            }
            httpURLConnection.disconnect();
        } catch (MalformedURLException e) {
            LOGGER.error("MalformedURLException error:{}", e);
        } catch (IOException e) {
            LOGGER.error("获取微信素材文件错误：{}", e);
        }
        return file;
    }

    private static String getExt(String contentType) {
        if ("image/jpeg".equals(contentType)) {
            return ".jpg";
        } else if ("image/png".equals(contentType)) {
            return ".png";
        } else if ("image/gif".equals(contentType)) {
            return ".gif";
        }
        return null;
    }
}
