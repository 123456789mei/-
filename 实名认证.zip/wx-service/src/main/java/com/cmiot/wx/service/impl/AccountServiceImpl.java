package com.cmiot.wx.service.impl;

import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.common.constants.ParamConstants;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.response.ResponseCode;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.commons.vo.MsisdnCacheVo;
import com.cmiot.wx.api.client.AppCoreClient;
import com.cmiot.wx.api.client.IAccountClient;
import com.cmiot.wx.api.client.WxApiClient;
import com.cmiot.wx.api.degraded.AccountClientImpl;
import com.cmiot.wx.model.MsisdnAccountEntity;
import com.cmiot.wx.service.AccountService;
import com.cmiot.wx.service.SingleTermSericeImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("AccountServiceImpl")
public class AccountServiceImpl implements AccountService {

    Logger logger = LoggerFactory.getLogger(AccountClientImpl.class);

    @Autowired
    AppCoreClient appCoreClient;

    @Autowired
    IAccountClient accountClient;

    @Autowired
    ICache cache;

    @Autowired
    SingleTermSericeImpl singleTermSerice;

    @Autowired
    WxApiClient apiClient;

    @Override
    public ResponseVo getBalanceByMsisdn(Map msisdnMap, String token, String transNo) {
        String msisdn = String.valueOf(msisdnMap.get(ParamConstants.MSISDN));
        // 校验账户权限
        ResponseVo isAuthVo = appCoreClient.cardIsGroup(msisdn, token, transNo);
        if (isAuthVo == null || !"0".equals(isAuthVo.getCode())) {
            return isAuthVo != null ? isAuthVo : ResponseVo.fail("账户无权限查询该物联卡号");
        }
        MsisdnAccountEntity msisdnAccountEntity = new MsisdnAccountEntity();
        //获取余额信息（PB&CT）
        Map params = new HashMap();
        params.put(ParamConstants.MSISDN, msisdn);
        logger.info("transNo is:[{}],wx getBalance, param is:[{}]", transNo, params);
        MsisdnCacheVo msisdnCacheVo = cache.getByMsisdn(msisdn);
        ResponseVo responseVo;
        Map msisdnVoMap = (msisdnCacheVo == null) ? null : JsonUtils.parseObjectToMap(msisdnCacheVo);
        if (msisdnVoMap == null || msisdnVoMap.size() < 2) {
            params.put(ParamConstants.CCMP_BEID, msisdnMap.get(ParamConstants.CCMP_BEID));
            params.put(ParamConstants.CUSTID, msisdnMap.get(ParamConstants.CUSTID));
            logger.info("查询CT物联卡余额信息，msisdn is:[{}],param is:[{}]", msisdn, JsonUtils.parseString(params));
            responseVo = apiClient.getBalanceCT(params, transNo);
            logger.info("查询CT物联卡余额信息，msisdn is:[{}],result is:[{}]", msisdn, JsonUtils.parseString(responseVo));
        } else {
            responseVo = accountClient.getAccountInfo(params, transNo);
        }
        logger.info("transNo is:[{}],wx getBalance, result is:[{}]", transNo, JsonUtils.parseString(responseVo));
        if (responseVo != null && responseVo.isSuccess()) {
            Map balanceData = (Map) responseVo.getData();
            if (!StringUtils.isEmpty(balanceData.get("balance"))) {
                msisdnAccountEntity.setBalance(String.valueOf(balanceData.get("balance")));
            }
            //TODO PB个人充值需优化,增加的充值地址
            msisdnAccountEntity.setRechargeUrl("https://shop.10086.cn/i/?f=rechargeinterofth");
            return ResponseVo.success(msisdnAccountEntity);
        }
        //TODO 物联卡GPRS在离线状态(缓存获取)，CT的物联卡无法从缓存中获取到
//        if (msisdnCacheVo != null) {
//            msisdnAccountEntity.setStatus(msisdnCacheVo.getStatus());
//            String custId = msisdnCacheVo.getCustId();
//            if (StringUtils.isEmpty(custId)) {
//                logger.error("transNo is:[{}],wx getBalance custId is null msisdn is:[{}]", transNo, msisdn);
//                return ResponseVo.fail(ResponseCode.ERROR_SYS, "系统繁忙，请稍后再试！");
//            }
//            CustomerCacheVo customerCacheVo = cache.getCustomer(custId);
//            if (customerCacheVo != null && !StringUtils.isEmpty(customerCacheVo.getCustName())) {
//                msisdnAccountEntity.setCustName(customerCacheVo.getCustName());
//            } else {
//                logger.info("transNo is:[{}],wx getBalanceByMsisdn 从缓存获取集团信息失败", transNo);
//            }
//        }
        //获取开关机数据(实时接口)（PB&CT）
//        ResponseVo netStatusVo = singleTermSerice.querySingleTermState(params, transNo);
//        if (netStatusVo != null) {
//            SingleTermStateEntity singleTermStateEntity = (SingleTermStateEntity) netStatusVo.getData();
//            if (!StringUtils.isEmpty(singleTermStateEntity.getStatus())) {
//                msisdnAccountEntity.setNetStatus(singleTermStateEntity.getStatus());
//                logger.info("transNo is:[{}],wx getBalance info getNetStatus success is:[{}]", transNo, JsonUtils.parseString(netStatusVo));
//                return ResponseVo.success(msisdnAccountEntity);
//            }
//        }
        return ResponseVo.fail(ResponseCode.ERROR_SYS, "系统繁忙，请稍后再试！");
    }

    @Override
    public ResponseVo getNetStatusByMsisdn(String msisdn, String token, String transNo) {
        Map params = new HashMap(1);
        params.put(ParamConstants.MSISDN, msisdn);
        ResponseVo netStatusVo = singleTermSerice.querySingleTermState(params, transNo);
        return netStatusVo;
    }

    @Override
    public ResponseVo getSimFlowByMsisdn(Map msisdnMap, String token, String transNo) {
        // 校验账户权限
        String msisdn = String.valueOf(msisdnMap.get(ParamConstants.MSISDN));
        String provinceId = cache.getMsisdnProvince(msisdn);
        ResponseVo isAuthVo = appCoreClient.cardIsGroup(msisdn, token, transNo);
        if (isAuthVo == null || !"0".equals(isAuthVo.getCode())) {
            return isAuthVo != null ? isAuthVo : ResponseVo.fail("账户无权限查询该物联卡号");
        }
        Map params = new HashMap();
        params.put(ParamConstants.MSISDN, msisdn);
        logger.info("transNois:[{}],wx getSimFlow success, param is:[{}]", transNo, params);
        MsisdnCacheVo msisdnCacheVo = cache.getByMsisdn(msisdn);
        ResponseVo responseVo;
        Map msisdnVoMap = (msisdnCacheVo == null) ? null : JsonUtils.parseObjectToMap(msisdnCacheVo);
        if (msisdnVoMap == null || msisdnVoMap.size() < 2) {
            //CT物联卡
            params.put(ParamConstants.CCMP_BEID, msisdnMap.get(ParamConstants.CCMP_BEID));
            params.put(ParamConstants.CUSTID, msisdnMap.get(ParamConstants.CUSTID));
            logger.info("查询CT物联卡余量信息，msisdn is:[{}],param is:[{}]", msisdn, JsonUtils.parseString(params));
            responseVo = apiClient.getSimFlowCT(params, "wx-service");
            logger.info("查询CT物联卡余量信息，msisdn is:[{}],result is:[{}]", msisdn, JsonUtils.parseString(responseVo));
        } else {
            responseVo = accountClient.getSimFlowInfo(params, transNo);
        }
        logger.info("transNo is:[{}],account service 响应数据{}", transNo, JsonUtils.parseString(responseVo));
        if (responseVo != null && responseVo.isSuccess() && responseVo.getData() != null) {
            //处理返回值
            List<Map> dataList = (List<Map>) responseVo.getData();
            Map servList = dataList.get(0);
            if (servList != null && servList.size() > 0) {
                List<Map> productList = (List<Map>) servList.get("servDataAmountArrayList");
                List<Map> returnList = new ArrayList<>();
                for (int index = 0; index < productList.size(); index++) {
                    Map returnData = productList.get(index);
                    //dataTotal(总量0.00) dataAmount(使用kb) setAmount(剩余kb)
                    String prodName = (String) returnData.get("prodName");
                    if (prodName.contains("机器卡")) {
                        logger.info("套餐名带有机器卡，过滤：{}", prodName);
                        continue;
                    }
                    // 当前产品的instId
                    String prodInstID = String.valueOf(returnData.get("prodInstID"));
                    Map prodInstIDMap = new HashMap(2);
                    prodInstIDMap.put(ParamConstants.PRODINSTID, prodInstID);
                    prodInstIDMap.put(ParamConstants.MSISDN, msisdn);
                    ResponseVo prodInfo = apiClient.getProductInfoByInstId(prodInstIDMap, transNo);

                    if (prodInfo.getCode().equals(ResponseCode.SUCCESS)) {
                        logger.info("获取卡号订购信息成功，msg is:[{}]", JsonUtils.parseString(prodInfo));
                        Map prodInfoMap = JsonUtils.parseObjectToMap(prodInfo.getData());
                        String currentEndStr = prodInfoMap.get("endDate") == null ? "" : String.valueOf(prodInfoMap.get("endDate")).replace("-", "");
                        returnData.put("endTime", currentEndStr);
                    } else {
                        logger.info("查询物联卡订购信息失败,参数:[{}]，错误信息:[{}]", JsonUtils.parseString(prodInstIDMap), JsonUtils.parseString(prodInfo));
                    }

                    if ("02".equals(returnData.get("dataAmountType"))) {
                        double dataAmount = Double.valueOf(String.valueOf(returnData.get("dataAmount")));
                        dataAmount = dataAmount / 1024;
                        double setAmount = Double.valueOf(String.valueOf(returnData.get("setAmount")));
                        setAmount = setAmount / 1024;
                        returnData.put("dataAmount", String.valueOf(dataAmount));
                        returnData.put("setAmount", String.valueOf(setAmount));
                    }
                    if ("03".equals(returnData.get("dataAmountType"))) {
                        double dataAmount = Double.valueOf(String.valueOf(returnData.get("dataAmount")));
                        dataAmount = dataAmount / 60;
                        double setAmount = Double.valueOf(String.valueOf(returnData.get("setAmount")));
                        setAmount = setAmount / 60;
                        returnData.put("dataAmount", String.valueOf(dataAmount));
                        returnData.put("setAmount", String.valueOf(setAmount));
                    }
                    returnList.add(returnData);
                }
                responseVo.setData(returnList);
            } else {
                //返回空数组
                responseVo.setData(new ArrayList<>());
            }
            return responseVo;
        }
        return ResponseVo.fail(ResponseCode.ERROR_SYS, "系统繁忙，请稍后再试！");
    }
}
