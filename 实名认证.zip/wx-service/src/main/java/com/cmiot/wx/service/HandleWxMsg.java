package com.cmiot.wx.service;

import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.response.ResponseCode;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.wx.api.client.WxApiClient;
import com.cmiot.wx.constant.WxConstant;
import com.cmiot.wx.model.wxmsg.resp.*;
import com.cmiot.wx.util.MessageUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.*;

/**
 * @author lxc
 * 微信消息处理服务
 */
@Service
public class HandleWxMsg {

    Logger logger = LoggerFactory.getLogger(HandleWxMsg.class);

    @Autowired
    WxApiClient apiClient;

    @Autowired
    ICache cache;

    public String handle(Map params, String transNo) {
        String fromUserName = String.valueOf(params.get(WxConstant.PUSH_MSG_FROMUSERNAME));
        // 公众帐号
        String toUserName = String.valueOf(params.get(WxConstant.PUSH_MSG_TOUSERNAME));
        // 消息类型
        String msgType = String.valueOf(params.get(WxConstant.PUSH_MSG_MSGTYPE));
        if (!msgType.equals(WxConstant.MSGTYPE_EVENT)) {
            //普通推送
            String content = String.valueOf(params.get(WxConstant.PUSH_MSG_CONTENT));
            //根据关键字，查询消息回复数据
            Map msgParam = new HashMap();
            msgParam.put(WxConstant.PARAM_AUTOKEY, content);
            ResponseVo msgVo = apiClient.getAutoMsg(msgParam, transNo);
            if (!ResponseCode.SUCCESS.equals(msgVo.getCode())) {
                logger.info("transNo is:[{}],查询自动回复信息失败,params is:[{}],result is:[{}]", transNo, JsonUtils.parseString(params), JsonUtils.parseString(msgVo));
                return "";
            }
            if(msgVo.getData() == null){
                logger.info("transNo is:[{}],未查询到关键字回复消息",transNo);
                String defaultMsg = cache.getSysParams("WX.AUTOMSG_DEFAULT","");
                if(StringUtils.isEmpty(defaultMsg)){
                    return "";
                }
                TextMessage textMessage = new TextMessage();
                textMessage.setToUserName(fromUserName);
                textMessage.setFromUserName(toUserName);
                textMessage.setCreateTime(new Date().getTime());
                textMessage.setFuncFlag(0);
                textMessage.setContent(defaultMsg);
                return MessageUtil.textMessageToXml(textMessage);
            }
            Map msgInfo = (Map) msgVo.getData();
            logger.info("transNo is:[{}],回复内容是：[{}]",transNo,JsonUtils.parseString(msgInfo));
            switch (String.valueOf(msgInfo.get(WxConstant.PARAM_MSGTYPE))) {
                case "text":
                    //文字
                    TextMessage textMessage = new TextMessage();
                    textMessage.setToUserName(fromUserName);
                    textMessage.setFromUserName(toUserName);
                    textMessage.setCreateTime(new Date().getTime());
                    textMessage.setFuncFlag(0);
                    String msg = String.valueOf(msgInfo.get(WxConstant.PARAM_CONTENT));
                    textMessage.setContent(msg.replace("\\n","\n"));
                    return MessageUtil.textMessageToXml(textMessage);
                case "news":
                    //图文消息,查询图文消息列表
                    ResponseVo newsVo = apiClient.getNewsList(String.valueOf(msgInfo.get(WxConstant.PARAM_ID)), transNo);
                    if (!ResponseCode.SUCCESS.equals(newsVo.getCode()) || newsVo.getData() == null) {
                        logger.info("transNo is:[{}],查询图文消息详情失败,msgId is:[{}],result is:[{}]", transNo, msgInfo.get(WxConstant.PARAM_ID), JsonUtils.parseString(msgVo));
                        return "";
                    }
                    List<Map> items = JsonUtils.parseList(newsVo.getData(), Map.class);
                    if (items.size() == 0) {
                        logger.info("transNo is:[{}],查询到的图文消息无列表信息，放弃回复消息", transNo);
                        return "";
                    }
                    NewsMessage newsMessage = new NewsMessage();
                    newsMessage.setCreateTime(new Date().getTime());
                    newsMessage.setToUserName(fromUserName);
                    newsMessage.setFromUserName(toUserName);
                    newsMessage.setArticleCount(items.size());
                    List<Article> articleList = new ArrayList<>();
                    for (Map item : items) {
                        Article article = new Article();
                        article.setTitle(String.valueOf(item.get(WxConstant.PARAM_TITLE)));
                        article.setDescription(String.valueOf(item.get(WxConstant.PARAM_DESCRIPTION)));
                        article.setPicUrl(String.valueOf(item.get(WxConstant.PARAM_PICURL)));//图片地址
                        article.setUrl(String.valueOf(item.get(WxConstant.PARAM_URL)));//点击跳转地址
                        articleList.add(article);
                    }
                    newsMessage.setArticles(articleList);
                    return MessageUtil.newsMessageToXml(newsMessage);
                case "image":
                    // 图片消息
                    ImageMessage imageMessage = new ImageMessage();
                    imageMessage.setCreateTime(new Date().getTime());
                    imageMessage.setToUserName(fromUserName);
                    imageMessage.setFromUserName(toUserName);
                    Image image = new Image();
                    image.setMediaId(String.valueOf(msgInfo.get(WxConstant.PARAM_MEDIAID)));
                    imageMessage.setImage(image);
                    return MessageUtil.imageMessageToXml(imageMessage);
                case "voice":
                    //语音
                    VoiceMessage voiceMessage = new VoiceMessage();
                    voiceMessage.setCreateTime(new Date().getTime());
                    voiceMessage.setToUserName(fromUserName);
                    voiceMessage.setFromUserName(toUserName);
                    Voice voice = new Voice();
                    voice.setMediaId(String.valueOf(msgInfo.get(WxConstant.PARAM_MEDIAID)));
                    voiceMessage.setVoice(voice);
                    return MessageUtil.voiceMessageToXml(voiceMessage);
                case "music":
                    //音乐
                    // TODO 暂时不开放音乐类
                    MusicMessage musicMessage = new MusicMessage();
                    musicMessage.setCreateTime(new Date().getTime());
                    musicMessage.setToUserName(fromUserName);
                    musicMessage.setFromUserName(toUserName);
                    Music music = new Music();
                    music.setThumbMediaId(String.valueOf(msgInfo.get(WxConstant.PARAM_MEDIAID)));
                    musicMessage.setMusic(music);
                    return MessageUtil.musicMessageToXml(musicMessage);
                case "video":
                    //视频
                    VideoMessage videoMessage = new VideoMessage();
                    videoMessage.setCreateTime(new Date().getTime());
                    videoMessage.setToUserName(fromUserName);
                    videoMessage.setFromUserName(toUserName);
                    Video video = new Video();
                    video.setMediaId(String.valueOf(msgInfo.get(WxConstant.PARAM_MEDIAID)));
                    videoMessage.setVideo(video);
                    return MessageUtil.videoMessageToXml(videoMessage);
                default:
                    return "";
            }
        } else {
            if("subscribe".equals(params.get(WxConstant.PARAM_Event))){
                //订阅公众号后自动推送一条
                Map msgParam = new HashMap();
                msgParam.put(WxConstant.PARAM_Event, params.get(WxConstant.PARAM_Event));
                ResponseVo msgVo = apiClient.getAutoMsg(msgParam, transNo);
                Map msgInfo = (Map) msgVo.getData();
                logger.info("transNo is:[{}],订阅推送内容是：[{}]",transNo,JsonUtils.parseString(msgInfo));
                TextMessage textMessage = new TextMessage();
                textMessage.setToUserName(fromUserName);
                textMessage.setFromUserName(toUserName);
                textMessage.setCreateTime(new Date().getTime());
                textMessage.setFuncFlag(0);
                String msg = String.valueOf(msgInfo.get(WxConstant.PARAM_CONTENT));
                textMessage.setContent(msg.replace("\\n","\n"));
                return MessageUtil.textMessageToXml(textMessage);
            }else {
                //事件推送
                String eventType = String.valueOf(params.get(WxConstant.MSGTYPE_EVENT));
                String userOpenId = String.valueOf(params.get(WxConstant.PUSH_MSG_FROMUSERNAME));
                String status = String.valueOf(params.get(WxConstant.PUSH_MSG_STATUS));
                switch (eventType) {
                    case "TEMPLATESENDJOBFINISH":
                        //TODO 模板消息结果处理
                        logger.info("transNo is:[{}],模板消息发送结果：[{}],user is:[{}]", transNo, status, userOpenId);
                        break;
                    case "":
                    default:
                        break;
                }
                return "";
            }
        }
    }
}
