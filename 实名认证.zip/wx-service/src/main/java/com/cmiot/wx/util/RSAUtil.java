//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.cmiot.wx.util;

import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPrivateKeySpec;
import java.util.Locale;

public class RSAUtil {
    private static final Provider DEFAULT_PROVIDER = new BouncyCastleProvider();
    private static final Logger LOGGER = LoggerFactory.getLogger(com.cmiot.commons.encrypt.RSAUtils.class);
    private static final String CHARSET_UTF8 = "UTF-8";

    private RSAUtil() {}

    public static String decryptString(KeyPair keyPair, String encryptText) {
        if (StringUtils.isBlank(encryptText)) {
            return null;
        } else {
            LOGGER.debug("encrypted password:{} will be decrypted", encryptText);

            try {
                byte[] e = parseHexStr2Byte(encryptText);
                byte[] data = decrypt(keyPair.getPrivate(), e);
                String decryptStr = URLEncoder.encode(StringUtils.reverse(new String(data)), CHARSET_UTF8);
                return URLDecoder.decode(decryptStr, CHARSET_UTF8);
            } catch (DataLengthException var6) {
                LOGGER.error("DataLengthException,the length String is {}", encryptText, var6);
            } catch (UnsupportedEncodingException var7) {
                LOGGER.error("decryptString encryptText {}", encryptText, var7);
            }

            return null;
        }
    }

    public static String decryptString(PrivateKey privateKey, String encryptText) {
        if (StringUtils.isBlank(encryptText)) {
            return null;
        } else {
            LOGGER.debug("encrypted password:{} will be decrypted", encryptText);

            try {
                byte[] e = parseHexStr2Byte(encryptText);
                byte[] data = decrypt(privateKey, e);
                String decryptStr = URLEncoder.encode(StringUtils.reverse(new String(data)), CHARSET_UTF8);
                return URLDecoder.decode(decryptStr, CHARSET_UTF8);
            } catch (DataLengthException var6) {
                LOGGER.error("DataLengthException,the length String is {}", encryptText, var6);
            } catch (UnsupportedEncodingException var7) {
                LOGGER.error("decryptString encryptText {}", encryptText, var7);
            }

            return "";
        }
    }

    public static String encryptString(PublicKey publicKey, String data) {
        byte[] enResult = encrypt(publicKey, data.getBytes());
        return bytesToHexString(enResult);
    }

    private static byte[] encrypt(PublicKey publicKey, byte[] data) {
        try {
            Cipher e = Cipher.getInstance("RSA", DEFAULT_PROVIDER);
            e.init(1, publicKey);
            int blockSize = e.getBlockSize();
            int outputSize = e.getOutputSize(data.length);
            int leavedSize = data.length % blockSize;
            int blocksSize = leavedSize != 0 ? data.length / blockSize + 1 : data.length / blockSize;
            byte[] raw = new byte[outputSize * blocksSize];

            for (int i = 0; data.length - i * blockSize > 0; ++i) {
                if (data.length - i * blockSize > blockSize) {
                    e.doFinal(data, i * blockSize, blockSize, raw, i * outputSize);
                } else {
                    e.doFinal(data, i * blockSize, data.length - i * blockSize, raw, i * outputSize);
                }
            }

            return raw;
        } catch (NoSuchAlgorithmException var10) {
            LOGGER.error("NoSuchAlgorithmException error:", var10);
        } catch (NoSuchPaddingException var11) {
            LOGGER.error("NoSuchPaddingException error:", var11);
        } catch (IllegalBlockSizeException var12) {
            LOGGER.error("IllegalBlockSizeException error:", var12);
        } catch (BadPaddingException var13) {
            LOGGER.error("BadPaddingException error:", var13);
        } catch (InvalidKeyException var14) {
            LOGGER.error("InvalidKeyException error:", var14);
        } catch (ShortBufferException var15) {
            LOGGER.error("ShortBufferException error:", var15);
        }

        return new byte[1];
    }

    public static KeyPair getKeyPair() {
        try {
            KeyPairGenerator e = KeyPairGenerator.getInstance("RSA", DEFAULT_PROVIDER);
            e.initialize(1024, new SecureRandom(String.valueOf(System.currentTimeMillis()).getBytes()));
            return e.generateKeyPair();
        } catch (NoSuchAlgorithmException var2) {
            LOGGER.error("init RSA key failed", var2);
            return null;
        }
    }

    /**
     * 生成私钥
     * @param modulus
     * @param privateExponent
     * @return RSAPrivateKey
     * @throws Exception
     */
    public static RSAPrivateKey generateRSAPrivateKey(BigInteger modulus, BigInteger privateExponent)
            throws InvalidKeySpecException {
        KeyFactory keyFac;
        try {
            keyFac = KeyFactory.getInstance("RSA", new BouncyCastleProvider());
        } catch (NoSuchAlgorithmException ex) {
            LOGGER.error("", ex);
            throw new InvalidKeySpecException(ex.getMessage());
        }
        RSAPrivateKeySpec priKeySpec = new RSAPrivateKeySpec(modulus, privateExponent);
        try {
            return (RSAPrivateKey) keyFac.generatePrivate(priKeySpec);
        } catch (InvalidKeySpecException ex) {
            LOGGER.error("", ex);
            throw new InvalidKeySpecException(ex.getMessage());
        }
    }

    private static byte[] decrypt(PrivateKey privateKey, byte[] data) {
        try {
            Cipher exception = Cipher.getInstance("RSA", DEFAULT_PROVIDER);
            exception.init(2, privateKey);
            int blockSize = exception.getBlockSize();
            ByteArrayOutputStream bout = new ByteArrayOutputStream(256);

            for (int j = 0; data.length - j * blockSize > 0; ++j) {
                if (data.length - j * blockSize > blockSize) {
                    bout.write(exception.doFinal(data, j * blockSize, blockSize));
                } else {
                    bout.write(exception.doFinal(data, j * blockSize, data.length - j * blockSize));
                }
            }

            return bout.toByteArray();
        } catch (NoSuchAlgorithmException var7) {
            LOGGER.error("NoSuchAlgorithmException error:", var7);
        } catch (NoSuchPaddingException var8) {
            LOGGER.error("NoSuchPaddingException error:", var8);
        } catch (IllegalBlockSizeException var9) {
            LOGGER.error("IllegalBlockSizeException error:", var9);
        } catch (BadPaddingException var10) {
            LOGGER.error("BadPaddingException error:", var10);
        } catch (InvalidKeyException var11) {
            LOGGER.error("InvalidKeyException error:", var11);
        } catch (IOException var12) {
            LOGGER.error("IOException error:", var12);
        }

        return new byte[0];
    }

    private static String bytesToHexString(byte[] buf) {
        StringBuilder stringBuilder = new StringBuilder("");
        if (buf != null && buf.length > 0) {
            byte[] arr = buf;
            int length = buf.length;

            for (int i$ = 0; i$ < length; ++i$) {
                byte b = arr[i$];
                int v = b & 255;
                String hv = Integer.toHexString(v);
                if (hv.length() < 2) {
                    stringBuilder.append(0);
                }

                stringBuilder.append(hv);
            }

            return stringBuilder.toString();
        } else {
            return null;
        }
    }

    private static byte[] parseHexStr2Byte(String hexString) {
        if (hexString != null && !"".equals(hexString)) {
            String uppCaseString = hexString.toUpperCase(Locale.getDefault());
            int length = uppCaseString.length() / 2;
            char[] hexChars = uppCaseString.toCharArray();
            byte[] result = new byte[length];

            for (int i = 0; i < length; ++i) {
                int pos = i * 2;
                result[i] = (byte) (charToByte(hexChars[pos]) << 4 | (charToByte(hexChars[pos + 1]) & 0xff));
            }

            return result;
        } else {
            return new byte[0];
        }
    }

    public static String decrypt(KeyPair keyPair, String password) {
        return com.cmiot.commons.encrypt.RSAUtils.decryptString(keyPair, password);
    }


    private static byte charToByte(char c) {
        return (byte) "0123456789ABCDEF".indexOf(c);
    }
}
