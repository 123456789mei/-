var $tooltips = $(".charge_tooltips");
var $cardNumber = $("#card_num_input");
var $cardNumberClear = $("#card_num_input_clear");
var $cardNumCell = $("#card_num_cell");
var $customMoney = $("#custom_input");
var $loadingToast = $("#loadingToast");
var chargeMoney = 10;
$(".button-charge").on("tap", function(event) {
    if( $("#custom_input").val()){
        $("#custom_input").val("");
    }
    $(".button-charge").removeClass("checked");
    $(event.target).addClass("checked");
    var targetVal = $(event.target).data("value");
    modifyTip(targetVal, targetVal);
    chargeMoney = targetVal;
});

$cardNumberClear.on("tap", function() {
    $cardNumber.val("");
    $("#confirmCharge").addClass("weui-btn_disabled");
});

$("#custom_input_clear").on("tap", function() {
    $("#custom_input").val("");
    $("#defaultVal").trigger("tap");
});

$cardNumber.on("input", function() {
    var $value = $cardNumber.val();
    if ($cardNumCell.hasClass("weui-cell_warn")) {
        $cardNumCell.removeClass("weui-cell_warn");
    }
    if ($value && Number(chargeMoney) !== 0) {
        $("#confirmCharge").removeClass("weui-btn_disabled");
    } else {
        $("#confirmCharge").addClass("weui-btn_disabled");
    }
});

$customMoney.on("input", function() {
    $(".button-charge").removeClass("checked");
    var $value = $customMoney.val();
    $value = $value.replace(/^0|[^0-9]+/g, "")
    if ($value > 500) {
        $value = "500";
    }
    $customMoney.val($value);
    modifyTip($value, $value);
});

$("#confirmCharge").on("tap", function() {
    if ($(this).hasClass("weui-btn_disabled")){
        return;
    }
    if ($tooltips.css("display") !== "none") {
        return;
    }
    var $value = $cardNumber.val();
    var checkMsisdnErrorInfo = checkMsisdn($value);
    if (!checkMsisdnErrorInfo.flag) {
        $cardNumCell.addClass("weui-cell_warn");
        $tooltips.text(checkMsisdnErrorInfo.text).fadeIn(100);
        setTimeout(function() {
            $tooltips.text("").fadeOut(100);
        }, 2000);
    } else {
        if (!chargeMoney) {
            $("#custom_cell").addClass("weui-cell_warn");
            $tooltips.text("请选择或输入充值金额").fadeIn(100);
            setTimeout(function() {
                $tooltips.text("").fadeOut(100);
            }, 2000);
            return;
        }
        //发起充值...
        payForCharge($cardNumber.val(),chargeMoney);
    }
});

function checkMsisdn(msisdn) {
    var val = msisdn.trim();
    var errorInfo = { flag: false, text: "" };
    if (val === "") {
        errorInfo.text = "卡号不能为空";
        return errorInfo;
    }
    if (isNaN(Number(msisdn))) {
        errorInfo.text = "卡号格式不正确";
        return errorInfo;
    }
    if (val.length !== 11 && val.length !== 13) {
        errorInfo.text = "卡号位数不正确";
        return errorInfo;
    }
    errorInfo.flag = true;
    return errorInfo;
}

function modifyTip(payment, account) {
    var $realPayment = $("#realPayment");
    var $realAccount = $("#realAccount");
    $realPayment.text(payment || 0);
    $realAccount.text(account || 0);
    chargeMoney = Number(payment || 0);
    if ($cardNumber.val().trim() && chargeMoney !== 0) {
        $("#confirmCharge").removeClass("weui-btn_disabled");
    } else {
        $("#confirmCharge").addClass("weui-btn_disabled");
    }
}

function payForCharge(msisdn,payment){
    if(!Number(payment)){
        $tooltips.text("请选择或输入充值金额").fadeIn(100);
        setTimeout(function() {
            $tooltips.text("").fadeOut(100);
        }, 2000);
    }else {
        $loadingToast.fadeIn(50);
        var chargeData= {
            msisdn: msisdn,
            chargeMoney: String(payment),
            paymentType:"WEIXIN-JSAPI",
            channelId:"WX_OA"
        };
        $.ajax({
            type: "POST",
            url: "/service/wx/access/chargeApi",
            data: JSON.stringify(chargeData),
            dataType: "json",
            contentType: "application/json",
            headers:{
                authId:authId
            },
            success: function (resp) {
                if (resp.code === "0" && resp.data) {
                    $loadingToast.hide();
                    location.href = resp.data;
                } else {
                    $loadingToast.hide();
                    if(resp.errParams && resp.errParams[0]) {
                        $tooltips.text(resp.errParams[0]).fadeIn(100);
                    }else{
                        $tooltips.text("充值调用失败").fadeIn(100);
                    }
                    setTimeout(function () {
                        $tooltips.text("").fadeOut(100);
                    }, 2000);
                }
            },
            error:function(){
                $loadingToast.hide();
                $tooltips.text("发起充值失败").fadeIn(100);
                setTimeout(function() {
                    $tooltips.text("").fadeOut(100);
                }, 2000);
            }
        });
    }
}