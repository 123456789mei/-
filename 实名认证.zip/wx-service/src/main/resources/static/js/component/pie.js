var  allowanceObject = function(){
  var currentObj = this;
  this.bgColor = "#ffffff";
  this.value = 0;
  this.option = {
    backgroundColor: this.bgColor,
    legend: {
      orient: 'vertical',
      right: 15,
      top: 55,
      selectedMode:false,
      data: [{name:'总量：',icon:'none'},
      {name:'已使用：',icon:'none'},
      {name:'剩余：',icon:'none'}],
      formatter:function(name){
		  var dataAll = currentObj.dataAll;
		  var dataUsed = currentObj.dataUsed;
		  var dataLeft = currentObj.dataLeft;

		  var unit = "MB";
		  if(currentObj.dataType == '01'){
			unit = "条";
			
		  }else if(currentObj.dataType == '03'){
			unit = "Min";
		  }else{
			dataAll = dataAll.toFixed(2);
			dataUsed = dataUsed.toFixed(2);
			dataLeft = dataLeft.toFixed(2);
		  }

        if(name == "总量："){
          //TODO 量大的时候是否需要转换单位
          return "总   量：" + dataAll + unit;
        }
        if(name == "已使用："){
          return name + dataUsed + unit;
        }
        if(name == "剩余："){
          return "剩   余：" + dataLeft + unit;
        }
      },
      itemGap:10,
      textStyle:{
        fontSize:15,
      },
      align:'left'
    },
    graphic: [
		{
		type: 'rect',
		shape: {
			x: 10,
			y: 10,
			width: 5,
			height: 20,
			r:[10, 10, 10, 10]
		},
		style:{
			fill: '#00cefc'
		}
        },{
        type: 'text',
        left: 35,
        top: 10,
        style: {
          fill: '#333',
          text: [
            ''
          ],
		 textAlign:'center',
         font: '16px Microsoft YaHei'
        }
      }
    ],
    title: {
      text: `${this.value}%`,
      subtext: '已使用',
      left: 36,
      top: 70, //top待调整
      textStyle: {
        color: '#000',
        fontSize: 22,
        fontFamily: 'DINAlternate-Bold'
      },
      subtextStyle: {
        color: '#00',
        fontSize: 14,
        fontFamily: 'PingFangSC-Regular',
        top: 'center'
      },
      itemGap: 4
    },
    series: [{
      name: '余量使用量',
      type: 'pie',
      clockWise: true,
      radius: ['35px', '40px'],
      center:[65,95],
      itemStyle: {
        normal: {
          label: {
            show: false
          },
          labelLine: {
            show: false
          }
        }
      },
      animation:false,
      hoverAnimation: false,
      data: [{
        value: this.value,
        name: '总量：',
        itemStyle: {
          normal: {
            borderWidth: 5,
            borderColor: {
              colorStops: [{
                offset: 0,
                color: '#1d54f7' || '#00cefc' // 0% 处的颜色
              }, {
                offset: 1,
                color: '#68eaf9' || '#367bec' // 100% 处的颜色
              }]
            },
            color: { // 完成的圆环的颜色
              colorStops: [{
                offset: 0,
                color: '#1d54f7' || '#00cefc' // 0% 处的颜色
              }, {
                offset: 1,
                color: '#68eaf9' || '#367bec' // 100% 处的颜色
              }]
            },
            label: {
              show: false
            },
            labelLine: {
              show: false
            }
          }
        }
      }, {
        name: '已使用：',
        value: 100 - this.value,
        itemStyle: {
          normal: {
            label: {
              show: false
            },
            labelLine: {
              show: false
            },
            color: '#65E4F8',
            borderColor: '#65E4F8',
            borderWidth: 1
          }
        }
      },{
        name:"剩余：",
        value:0
      }]
    }]
  };
  this.init = function(el){
    this.myChart = echarts.init(el);
  }
  this.setData = function(per,type,used,left,all,name){
    this.option.title.text = per + '%';
    this.option.series[0].data[0].value = used;
    this.option.series[0].data[1].value = all - used;
    this.option.graphic[1].style.text = this.changeNames(name).join('\n');
    //赋值
    this.dataAll = all;
    this.dataUsed = used;
    this.dataLeft = left;
	this.dataType = type; 
    this.myChart.setOption(this.option);
  }
  this.destroy = function(){
    this.myChart.dispose();
  }
  this.changeNames = function(name){
    var names = [];
    var length = name.length;
    var times = (length/20).toFixed(0);
    if(Number(times) == 0){
        names.push(name);
		return names;
    }
    for(var i=0;i < times;i++){
      names.push(name.substr(20*i,20));
    }
    if(length%20 > 0){
      names.push(name.substr(20*times,20));
    }
    return names;
  }
};
