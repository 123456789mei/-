package com.cmiot.wx.util;

import com.google.inject.internal.cglib.core.$Constants;
import org.junit.Test;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;

public class ImageHandleUtilsTest {

    @Test
    public void scale2() {
        String fileStr = "C:\\Users\\Administrator\\Desktop\\2.jpg";
        File file = new File(fileStr);
//        if (file != null) {
//            BufferedImage image = ImageHandleUtils.getImage(file);
//            int width = image.getWidth();
//            int height = image.getHeight();
//            System.out.println("宽度"+width+",高度："+ height);
//            double newHeight = (double)(width/16) * 9;
//            System.out.println("新高度："+ newHeight);
//            System.out.println(file.getPath());
//            System.out.println(file.getPath().split("\\.")[0]);
//            String result = file.getPath().split("\\.")[0];
//            result = result.concat("_new.jpg");
//            int scaleHeight = (int) Math.floor(newHeight);
//            try {
//                ImageHandleUtils.scale2(file,result,scaleHeight,width,true);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
        PublicUtils publicUtils = new PublicUtils();
//        publicUtils.translateFile(file);
    }

    @Test
    public void chargeTimes (){
        String baseStr = "1";
        BigDecimal chargeMoney = new BigDecimal(baseStr).setScale(0,BigDecimal.ROUND_DOWN);
        BigDecimal times = new BigDecimal(100);
        chargeMoney = chargeMoney.multiply(times);
        System.out.println("baseCharge is :".concat(baseStr).concat(",Times Charge is:".concat(String.valueOf(chargeMoney))));
    }

    @Test
    public void maxNum(){
        int a = 768;
        int b = 432;

        int divisor = 1;
        for (int i =b; i>=1;i--){
            if(a%i == 0 && b%i == 0){
                System.out.println("最大公约数:"+i);
                divisor = i;
                break;
            }
        }
        int times_a = a/divisor;
        int times_a1 = times_a/16;
        if(times_a1 >= 1){
            int a_new = divisor * 16 *times_a1;
            int b_new = divisor * 9 *times_a1;
            System.out.println("new a is:"+ a_new + ",new b is:"+ b_new);
        }else {
            int time2 = times_a/4;
            int a_new = divisor * 4 * time2;
            int b_new = divisor * 3 * time2;
            System.out.println("new a is:"+ a_new + ",new b is:"+ b_new);
        }
    }

    @Test
    public void fileCopy(){
        String src ="C:\\Users\\Administrator\\Desktop\\2.jpg";
        String dest="C:\\Users\\Administrator\\Desktop\\2_1.jpg";
        new PublicUtils().getTempFile(src,dest);
    }

    @Test
    public void reScaleImg(){
        String src ="C:\\Users\\Administrator\\Desktop\\IMG_20201128_151729.jpg";
//        String dest = PublicUtils.reScaleImg(false,new File(src));
//        System.out.println("结果文件：".concat(dest));
    }

}