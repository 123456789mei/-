package com.cmiot.tasks;

import com.cmiot.commons.common.utils.UUID4Long;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class PersonTaskServiceTest {

    @Autowired
    PersonTaskService taskService;

    @Autowired
    UUID4Long uuid;

    @Test
    public void runUnBindTest() {
        String userId = "";
        String transNo = String.valueOf(uuid.nextId());
        taskService.runUnBind(userId,transNo);
    }

}