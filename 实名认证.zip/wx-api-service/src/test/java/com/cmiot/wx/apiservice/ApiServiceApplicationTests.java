package com.cmiot.wx.apiservice;

import com.cmiot.commons.common.utils.HttpRequestClient;
import com.cmiot.mybatis.service.WxPersonUserInfoService;
import com.cmiot.wx.apiservice.utiles.CommonConstant;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.HashMap;
import java.util.Map;

@SpringBootTest(classes = ApiServiceApplication.class)
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootConfiguration
@EnableAutoConfiguration
public class ApiServiceApplicationTests {

    @Autowired
    WxPersonUserInfoService service;

    @Test
    public void contextLoads() {
    }

    @Test
    public void synchronizeTest() {
//        String url = "http://localhost:8824/personUser/syncMsisdnList";
        Map params = new HashMap(8);
        params.put(CommonConstant.USERID , "560885177785786368");
        params.put(CommonConstant.PHONE , "18883985992");
        HttpRequestClient client = new HttpRequestClient();
        service.syncPbMsisdnList(params);

//        client.post("1122334455667788" , url , params , HttpRequestClient.CONTENT_TYPE_JSON);

    }

}
