package com.cmiot.wx.apiservice.service.impl;

import com.cmiot.mybatis.vo.CtCmCertInfoVo;
import com.cmiot.mybatis.vo.CtPersonalIdentityDetailVo;
import com.cmiot.mybatis.vo.CtSysOperPersonalIdentityVo;
import com.cmiot.wx.apiservice.ApiServiceApplication;
import com.cmiot.wx.apiservice.service.IMsisdnAutoBindService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

@SpringBootTest(classes = ApiServiceApplication.class)
@RunWith(SpringRunner.class)
@ActiveProfiles({"dev"})
@WebAppConfiguration
public class MsisdnAutoBindServiceImplTest {

    private CtCmCertInfoVo vo1;
    private CtPersonalIdentityDetailVo vo2;
    private CtSysOperPersonalIdentityVo vo3;

    @Autowired
    IMsisdnAutoBindService msisdnAutoBindService;

    @Before
    public void initData(){
        vo1 = new CtCmCertInfoVo();
        vo1.setCustId("211000008915001");
        vo1.setBeId("771");
        vo1.setSubsId("211000297363437");
        vo1.setIdNumber("500228199008138750");
        vo1.setAddr("南宁市西乡塘区西关路85号B座11层1103号房");
        vo1.setName("林苑萍");
        vo1.setMobilePhone("13557579207");
        vo1.setOpCode("01");

        vo2 = new CtPersonalIdentityDetailVo();
        vo2.setCustCertNo("500228199008138750");
        vo2.setIccid("123234515424");
        vo2.setMsisdn("17296514322");
        vo2.setBeId("771");
        vo2.setCustPhoneNo("13557579207");
        vo2.setRealNameTransId("10020200520124558048911");
        vo2.setCustId("211000008915001");

        vo3 = new CtSysOperPersonalIdentityVo();
        vo3.setCustCertNo("500228199008138750");
        vo3.setCustName("林苑萍");
        vo3.setCustCertAddr("南宁市西乡塘区西关路85号B座11层1103号房");
        vo3.setGender("0");
        vo3.setNation("汉");
        vo3.setIssuingAuthority("南宁市公安局西乡塘分局");
    }

    @Test
    public void exct(){
        try {
            msisdnAutoBindService.exct(vo1,vo2,vo3);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}