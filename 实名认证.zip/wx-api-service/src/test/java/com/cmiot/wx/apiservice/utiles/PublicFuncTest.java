package com.cmiot.wx.apiservice.utiles;

import com.alibaba.fastjson.JSONObject;
import com.cmiot.mybatis.vo.CtPersonalIdentityDetailVo;
import org.junit.Test;

import static org.junit.Assert.*;

public class PublicFuncTest {

    @Test
    public void testStr(){
        String channelId = "OneNET,OneLinkApi";
        if(channelId.contains("OneNET")){
            System.out.println("yes");
        }else {
            System.out.println("no");
        }
    }

    @Test
    public void translateObj(){
        String data = "{\n" +
                "    \"meta\": {\n" +
                "        \"time\": \"2020-04-28T15:52:05\",\n" +
                "        \"op\": \"upd\",\n" +
                "        \"table\": \"COMMON.PERSONAL_IDENTITY_DETAIL\"\n" +
                "    },\n" +
                "    \"data\": {\n" +
                "        \"ICCID\": \"898604242119C0305527\",\n" +
                "        \"CUST_PHONE_NO\": \"15078862082\",\n" +
                "        \"REAL_NAME_TRANS_ID\": \"10020200428155155188901\",\n" +
                "        \"CHANGE_INFO_TRANS_ID\": \"CRM_subInf20200428155202750674\",\n" +
                "        \"MODIFY_TIME\": \"2020-04-28T15:52:05\",\n" +
                "        \"CUST_PHOTO_IDENTITY\": 359326,\n" +
                "        \"CUST_PHOTO_SCENE\": 359327,\n" +
                "        \"CUST_PHOTO_FRONT\": 359328,\n" +
                "        \"CUST_PHOTO_BACK\": 359329\n" +
                "    },\n" +
                "    \"key\": {\n" +
                "        \"CUST_CERT_NO\": \"452323197706205541\",\n" +
                "        \"ICCID\": \"898604242119C0305527\",\n" +
                "        \"MSISDN\": \"1440245041027\",\n" +
                "        \"BE_ID\": \"771\",\n" +
                "        \"CUST_PHONE_NO\": \"15078862082\",\n" +
                "        \"BILL_ID\": null,\n" +
                "        \"REAL_NAME_TRANS_ID\": \"10020200428155155188901\",\n" +
                "        \"CHANNEL_ID\": null,\n" +
                "        \"OPER_CODE\": null,\n" +
                "        \"KEEP_PARAM\": null,\n" +
                "        \"OPER_TEL\": null,\n" +
                "        \"SOURCE_TYPE\": null,\n" +
                "        \"CUST_ID\": 211000008915001,\n" +
                "        \"CHANGE_INFO_TRANS_ID\": null,\n" +
                "        \"AUTH_CHANNEL\": null,\n" +
                "        \"CREATE_TIME\": \"2020-04-28T15:52:05\",\n" +
                "        \"MODIFY_TIME\": \"2020-04-28T15:52:05\",\n" +
                "        \"RECORD_STATUS\": \"1\",\n" +
                "        \"CUST_PHOTO_IDENTITY\": null,\n" +
                "        \"CUST_PHOTO_SCENE\": null,\n" +
                "        \"CUST_PHOTO_FRONT\": null,\n" +
                "        \"CUST_PHOTO_BACK\": null\n" +
                "    }\n" +
                "}";
        JSONObject jsonObject = JSONObject.parseObject(data);
        JSONObject dataInfo = jsonObject.getJSONObject("data");
        dataInfo.put("CUST_PHOTO_IDENTITY",null);
        dataInfo.put("CUST_PHOTO_SCENE",null);
        dataInfo.put("CUST_PHOTO_FRONT",null);
        dataInfo.put("CUST_PHOTO_BACK",null);
        jsonObject.put("data",dataInfo);
        CtPersonalIdentityDetailVo ctPersonalIdentityDetail = JSONObject.toJavaObject(jsonObject.getJSONObject("data"), CtPersonalIdentityDetailVo.class);
    }

    @Test
    public void translateStr(){
        String dataStr = "31343235313332302C20302E30342C2D302E39382C20302E30302C7C2C20302E30332C2D302E39382C20302E30312C7C2C20302E30342C2D302E39382C20302E30312C7C2C20302E30332C2D302E39382C20302E30322C7C2C20302E30342C2D302E39382C20302E30312C7C2C20302E30352C2D302E39382C20302E30322C7C2C20302E30342C2D302E39382C20302E30322C7C2C20302E30342C2D302E39382C20302E30322C7C2C20302E30352C2D302E39382C20302E30312C7C2C20302E30332C2D302E39382C20302E30312C7C2C20302E30342C2D302E39382C20302E30312C7C2C20302E30332C2D302E39392C20302E30322C7C2C20302E30332C2D302E39382C20302E30312C7C2C20302E30332C2D302E39382C20302E30322C7C2C20302E30332C2D302E39382C20302E30322C7C2C20302E30332C2D302E39382C20302E30312C7C2C20302E30342C2D302E39382C20302E30322C7C2C20302E30332C2D302E39392C20302E30312C7C2C20302E30332C2D302E39382C20302E30312C7C000000000000000000000000000000000000000000";
        System.out.println(hexStringToString(dataStr));
    }


    public static String hexStringToString(String s) {
        if (s == null || s.equals("")) {
            return null;
        }
        s = s.replace(" ", "");
        byte[] baKeyword = new byte[s.length() / 2];
        for (int i = 0; i < baKeyword.length; i++) {
            try {
                baKeyword[i] = (byte) (0xff & Integer.parseInt(
                        s.substring(i * 2, i * 2 + 2), 16));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            s = new String(baKeyword, "gbk");
            new String();
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return s;
    }


}