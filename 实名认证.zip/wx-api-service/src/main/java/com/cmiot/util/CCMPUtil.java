package com.cmiot.util;

import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.response.ResponseVo;
import org.apache.commons.lang.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/*
 * 定义CCMP相关公共资源，方法等
 * */
public class CCMPUtil {

    //活体采集验证页面跳转URL获取
    public static final String STARTREGISTER = "getLiveCollectJumpKey";
    public static final String STARTREGISTER_URL = "/ccmp/realNameAuth/getLiveCollectJumpKey";

    //活体认证结果查询
    public static final String QUERYREALNAMERESULT = "queryLiveCollectResult";
    public static final String QUERYREALNAMERESULT_URL = "/ccmp/realNameAuth/queryLiveCollectResult";

    //使用人实名信息变更
    public static final String MODIFYREALNAMEINFO = "modifySubsRealNameInfo";
    public static final String MODIFYREALNAMEINFO_URL = "/ccmp/realNameAuth/modifySubsRealNameInfo";

    //根据卡号获取subsid
    public static final String GETSUBSID = "getSubsId";
    public static final String GETSUBSID_URL = "/ccmp/realNameAuth/getSubsId";



    //生成CCMP操作流水号
    public static final String getCcmpSeq(String code, String transNo) {
        return code + "_" + transNo;
    }

    //生成14位时间戳
    public static final String getTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
        long l = System.currentTimeMillis();
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(l);
        Date date = c.getTime();
        return sdf.format(date);
    }

    //CCMP通用响应处理
    public static ResponseVo ccmpResponse(String result) {
        if (StringUtils.isEmpty(result)) {
            return ResponseVo.fail("2009");
        }
        CCMPResult ccmpResult = JsonUtils.parseObject(result, CCMPResult.class);
        if(StringUtils.isEmpty(ccmpResult.getCode())){
            return ResponseVo.fail("2008");
        }
        if (!ccmpResult.isSuccess()) {
            return ResponseVo.fail(ccmpResult.getCode());
        }
        return ResponseVo.success(ccmpResult);
    }

}
