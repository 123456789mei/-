package com.cmiot.util.signtj;


import com.asiainfo.openplatform.utils.AIESBConfig;
import com.asiainfo.openplatform.utils.MD5Util;
import com.asiainfo.openplatform.utils.RSAUtils;
import org.apache.commons.lang.StringUtils;

import java.util.Arrays;
import java.util.Map;

public class RSASignEngineImplTj implements ISignEngineTj {
    private static RSASignEngineImplTj instance;

    private RSASignEngineImplTj() {
    }

    public static RSASignEngineImplTj getSingleton() {
        if (instance == null) {
            Class var0 = RSASignEngineImplTj.class;
            synchronized(RSASignEngineImplTj.class) {
                if (instance == null) {
                    instance = new RSASignEngineImplTj();
                }
            }
        }

        return instance;
    }

    public String generateSign(Map<String, String> paramsMap,String json) throws Exception {
        String signSecret = AIESBConfig.getRsaPublicKey();
        String md5Str = getMD5Str(paramsMap,json);
        return RSAUtils.encryptByPublicKey(md5Str, signSecret);
    }

    private static String getMD5Str(Map<String, String> paramMap,String json) throws Exception {
        String[] paramArr = (String[])paramMap.keySet().toArray(new String[paramMap.size()]);
        Arrays.sort(paramArr);
        StringBuilder keyBuf = new StringBuilder();
        StringBuilder buf = new StringBuilder();
        String[] var7 = paramArr;
        int var6 = paramArr.length;

        String param;
        for(int var5 = 0; var5 < var6; ++var5) {
            param = var7[var5];
            if (!"sign".equals(param)) {
                if("content".equals(param)){
                    keyBuf.append(param).append("|");
                    buf.append(json);
                }else {
                    String value = (String)paramMap.get(param.trim());
                    if (StringUtils.isNotBlank(value)) {
                        keyBuf.append(param).append("|");
                        buf.append(value.trim());
                    }
                }
            }
        }

        param = "";
        if (buf.length() > 0) {
            param = MD5Util.MD5(buf.toString());
        }

        return param;
    }
}
