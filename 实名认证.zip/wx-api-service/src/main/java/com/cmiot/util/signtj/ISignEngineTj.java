package com.cmiot.util.signtj;

import java.util.Map;

public interface ISignEngineTj {
    String generateSign(Map<String, String> var1,String json) throws Exception;
}
