package com.cmiot.util;

public class RegisterCode {

    //实名认证成功
    public static final String REALNAME_SUCCESS="00000";

    //验证结果不通过
    public static final String REALNAME_FIRST_FAIL="1001";

    //验证结果二次稽核不通过
    public static final String REALNAME_SECOND_FAIL="1002";

    public static final String REALNAME_10="1003";
    public static final String REALNAME_10_DESC="用户不存在";

    public static final String REALNAME_20="1004";
    public static final String REALNAME_20_DESC="使用人的用户名字/证件类型/证件号码同实名制信息不一致，不允许业务受理";

    public static final String REALNAME_30="1005";
    public static final String REALNAME_30_DESC="用户信息与实名认证信息不匹配";

    public static final String REALNAME_40="1006";
    public static final String REALNAME_40_DESC="实名制工单已绑定，不允许重复受理";

    public static final String REALNAME_50="1007";
    public static final String REALNAME_50_DESC="实名制工单不存在，不允许业务受理";

    public static final String REALNAME_60="1008";
    public static final String REALNAME_60_DESC="实名制工单归属客户与授理业务客户不一致，不允许业务受理";

    public static final String REALNAME_99_A="1009";
    public static final String REALNAME_99_A_DESC="实名绑定总量超过上限（5张）";

    public static final String REALNAME_99_B="1010";
    public static final String REALNAME_99_B_DESC="用户实名权限关闭，该业务办理失败";

    public static final String REALNAME_99_C="1011";
    public static final String REALNAME_99_C_DESC="业务暂停，请24:00后重试";

    public static final String REALNAME_99_D="1012";
    public static final String REALNAME_99_D_DESC="实名绑定总量超过上限（10张）";

    public static final String REALNAME_99_E="1013";
    public static final String REALNAME_99_E_DESC="证件号码有不良信息，该业务办理失败";

    public static final String REALNAME_70="1014";
    public static final String REALNAME_70_DESC="物联卡管理停机，请联系营业厅恢复后重试";

    public static final String REALNAME_5="1015";
    public static final String REALNAME_5_DESC="业务繁忙，请30分钟后重试";

    //cmpp返回未知错误
    public static final String REALNAME_UNKNOWN="9999";

    public static String getResult(String code){
        switch (code){
            case REALNAME_5:
                return REALNAME_5_DESC;
            case REALNAME_70:
                return REALNAME_70_DESC;
            case REALNAME_99_E:
                return REALNAME_99_E_DESC;
            case REALNAME_99_D:
                return REALNAME_99_D_DESC;
            case REALNAME_99_C:
                return REALNAME_99_C_DESC;
            case REALNAME_99_B:
                return REALNAME_99_B_DESC;
            case REALNAME_99_A:
                return REALNAME_99_A_DESC;
            case REALNAME_60:
                return REALNAME_60_DESC;
            case REALNAME_50:
                return REALNAME_50_DESC;
            case REALNAME_40:
                return REALNAME_40_DESC;
            case REALNAME_30:
                return REALNAME_30_DESC;
            case REALNAME_20:
                return REALNAME_20_DESC;
            case REALNAME_10:
                return REALNAME_10_DESC;
            default:
                return "未知原因";
        }
    }

    public static String getmsg(String code){
        switch (code){
            case "1009":
                return "绑定总量超上限";
            case "1011":
                return "业务暂停";
            case "1012":
                return "绑定总量超上限";
            case "1014":
                return "物联卡管理停机";
            case "1015":
                return "业务繁忙";
            default:
                return "其他错误";
        }
    }

    public static String getmsgDetail(String code){
        switch (code){
            case "1009":
                return "该类物联卡可以绑定的最大数量为5张，超过后将无法新增绑定物联卡，请联系附近营业厅确认已绑定物联卡数量";
            case "1011":
                return "月末最后一天22:00~24：00将暂停实名认证业务办理，请24:00后重试";
            case "1012":
                return "该类物联卡可以绑定的最大数量为10张，超过后将无法新增绑定物联卡，请联系附近营业厅确认已绑定物联卡数量";
            case "1014":
                return "该物联卡处于管理停机状态，无法进行实名认证，请联系营业厅恢复后再进行实名";
            case "1015":
                return "该物联卡存在其他业务正在处理中，请30分钟后重试";
            default:
                return "该实名订单存在其他错误，请在“意见反馈”功能中反馈您的卡号及故障时间，我们将尽快为您处理";
        }
    }
}
