package com.cmiot.util;

/**
 * pb实名认证错误响应码
 */
public class PbRegisterCode {
    //认证成功
    public  static final String SUCCESS="00000";
    //在线公司回传内容缺少
    public  static final String PARAMMISS="00001";
    //在线公司返回审核未通过
    public  static final String CHECKFAIL="00002";
    //前后身份证号不一致
    public  static final String IDCARDFAIL="00003";
    //省公司未能正常接收同步信息
    public static final String SYNCFAIL="00004";
    //省公司未能正确返回结果
    public static final String RETURNEMPTY="00005";
    //请输入登记用户的服务号码
    public static final String MISS_SERVICE_NUMBER="10010020201062968";
    //输入证件类型不能为空
    public static final String MISS_ID_TYPE="10010020201062935";
    //输入证件号码不能为空
    public static final String MISS_ID_NUMBER="10010020201062936";
    //客户名称不能为空
    public static final String MISS_CUSTOMER_NAME="10010020201062937";
    //对不起，您输入的身份证号码不是18位有效身份证号码
    public static final String ID_CARD_FAIL="10010020201062939";
    //无对应的用户信息
    public static final String MISS_USER_INFO="10010020201062940";
    //获取服务号码对应的获取用户付费模式失败，请确认服务号码
    public static final String GET_PAY_MODEL_FAIL="10010020201060285";
    //获取客户标识失败
    public static final String GET_CUSTOMER_FLAG_FAIL="10010020201062950";
    //获取创建客户资料对应服务提供ID错误
    public static final String GET_OFFER_ID_FAIL="10010020201062951";
    //客户开户姓名必须大于等于2个汉字，请到客户资料变更模块做修改
    public static final String OPEN_NAME_LENGTH_FAIL="10010020201062974";
    //客户证件地址必须大于等于8个汉字
    public static final String ID_ADDRESS_LENGTH_FAIL="10010020201062975";
    //调用订单处理函数出错
    public static final String ORDER_DEAL_FUNC_FAIL="10010020201062954";
    //获取系统时间失败
    public static final String GET_SYSTEM_TIME_FAIL="10010020201069324";
    //只允许单位证件下物联网用户进行补登记
    public static final String ONLY_IOT_USER="10010020201062999";
    //该证件属于员工证件，不允许使用此证件入网!
    public static final String NOT_WORKER_ID="10011020100061104";
    //该证件已作为其他单位证件的使用人/责任人/经办人，不允许使用此证件入网!
    public static final String NOT_OHTER_ID="10011020100061118";
    //北京pb实名认证失败（具体原因由省公司返回）
    public static final String BJPB_FAIL="10001";
    //江苏pb实名认证失败（具体原因由省公司返回）
    public static final String JSPB_FAIL="10002";

    public static String getResult(String code){
        switch (code){
            case SUCCESS:
                return "认证成功";
            case PARAMMISS:
                return "在线公司回传内容缺少";
            case CHECKFAIL:
                return "在线公司返回审核未通过";
            case IDCARDFAIL:
                return "前后身份证号不一致";
            case MISS_SERVICE_NUMBER:
                return "请输入登记用户的服务号码";
            case MISS_ID_TYPE:
                return "输入证件类型不能为空";
            case MISS_ID_NUMBER:
                return "输入证件号码不能为空";
            case MISS_CUSTOMER_NAME:
                return "客户名称不能为空";
            case ID_CARD_FAIL:
                return "对不起，您输入的身份证号码不是18位有效身份证号码";
            case MISS_USER_INFO:
                return "无对应的用户信息";
            case GET_PAY_MODEL_FAIL:
                return "获取服务号码对应的获取用户付费模式失败，请确认服务号码";
            case GET_CUSTOMER_FLAG_FAIL:
                return "获取客户标识失败";
            case GET_OFFER_ID_FAIL:
                return "获取创建客户资料对应服务提供ID错误";
            case OPEN_NAME_LENGTH_FAIL:
                return "客户开户姓名必须大于等于2个汉字，请到客户资料变更模块做修改";
            case ID_ADDRESS_LENGTH_FAIL:
                return "客户证件地址必须大于等于8个汉字";
            case ORDER_DEAL_FUNC_FAIL:
                return "调用订单处理函数出错";
            case GET_SYSTEM_TIME_FAIL:
                return "获取系统时间失败";
            case SYNCFAIL:
                return "省公司未能正常接收同步信息";
            case ONLY_IOT_USER:
                return "只允许单位证件下物联网用户进行补登记";
            case NOT_WORKER_ID:
                return "该证件属于员工证件，不允许使用此证件入网!";
            case NOT_OHTER_ID:
                return "该证件已作为其他单位证件的使用人/责任人/经办人，不允许使用此证件入网!";
            default:
                return "未知原因错误";
        }
    }
}
