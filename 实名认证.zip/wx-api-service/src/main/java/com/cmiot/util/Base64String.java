package com.cmiot.util;

import java.util.Base64;

public class Base64String {
    /**
     * Base64加密
     * @param str 加密前字符串
     * @return 加密后字符串
     */
    public static String getBase64EncodeString(String str) {
        String result = null;
        if (null != str) {
            try {
                result = new String(Base64.getEncoder().encode(str.getBytes("utf-8")), "utf-8");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    /**
     * Base64解密
     * @param str Base64加密后的字符串
     * @return 解密后的字符串
     */
    public static String getBase64DecodeString(String str) {
        String result = null;
        if (null != str) {
            try {
                result = new String(Base64.getDecoder().decode(str.getBytes("utf-8")), "utf-8");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return result;
    }
}
