package com.cmiot.util;
/**
 * CCMP接口调用返回接口
 * */
public class CCMPResult {

    //接口平台返回码
    private String code;
    //接口平台返回码描述
    private String msg;
    //数据总数
    private Long total;
    //当前返回数据总数
    private Integer count;
    //返回数据，可以是任意对象，如：JsonObject、JSONArray、String等
    private Object rows;

    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Object getRows() {
        return rows;
    }

    public void setRows(Object rows) {
        this.rows = rows;
    }

    public boolean isSuccess(){
        return "2001".equals(this.code);
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
