package com.cmiot.util.signtj;

import java.util.HashMap;
import java.util.Map;

public class SignEngineFactoryTj {
    private static Map<String, ISignEngineTj> signEngineMap = new HashMap();

    public SignEngineFactoryTj() {
    }

    public static ISignEngineTj getSignEngine() {
        String signMethod = AIESBConfigTj.getSignMethod();
        ISignEngineTj signEngine = (ISignEngineTj) signEngineMap.get(signMethod);
        if (signEngine != null) {
            return (ISignEngineTj) signEngine;
        } else {
            if ("RSA".equalsIgnoreCase(signMethod)) {
                signEngine = RSASignEngineImplTj.getSingleton();
            }
            signEngineMap.put(signMethod, signEngine);
            return (ISignEngineTj) signEngine;
        }
    }
}
