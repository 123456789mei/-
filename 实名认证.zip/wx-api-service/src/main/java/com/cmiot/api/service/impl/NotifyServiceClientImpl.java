package com.cmiot.api.service.impl;

import com.cmiot.api.service.INotifyServiceClient;
import com.cmiot.commons.common.constants.RequestConstants;
import com.cmiot.commons.response.ResponseCode;
import com.cmiot.commons.response.ResponseVo;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.Map;

/**
 * @author Created by WULEI on 2017/7/18.
 * @version 1.0
 */
@Component
public class NotifyServiceClientImpl implements INotifyServiceClient {
    /**
     * 默认返回 TaskServiceErrorCode.ERROR_ACCESS_DB
     * @return
     */
    private ResponseVo defaultResponse() {
        return ResponseVo.fail(ResponseCode.ERROR_SERVICE_UNAVAILABLE);
    }

    @Override
    public ResponseVo sendEmail(@RequestBody Map email,
                                @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo) {
        return defaultResponse();
    }

    @Override
    public ResponseVo sendFileEmail(@RequestBody Map<String, Object> email,
                                    @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo) {
        return defaultResponse();
    }

    @Override
    public ResponseVo sendSms(@RequestBody Map sms,
                              @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo) {
        return defaultResponse();
    }
}
