package com.cmiot.api.service.impl;

import com.cmiot.api.service.UserService;
import com.cmiot.commons.response.ResponseCode;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.mybatis.vo.MsisdnBindingVo;
import com.cmiot.mybatis.vo.ProductInfoVo;
import com.cmiot.mybatis.vo.UserMsisdnDetail;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class UserServiceImpl  implements UserService {

    private ResponseVo defaultResponse() {
        return ResponseVo.fail(ResponseCode.ERROR_SERVICE_UNAVAILABLE);
    }

    @Override
    public ResponseVo register(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo updateType(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getWxUserInfo(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo bind(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo accountlist(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo deleteAccount(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo deleteAllAccount(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getEcList(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getEcOper(String operId, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getCustIdByMsisdn(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo querySubsProduct(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo queryMsisdnByPhone(Map<String, String> map, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getUserStatus(Map<String, String> map, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getUserType(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getUserPhoneByOpenId(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo getProdInfoByProdInstID(Map map, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo queryRegionId(Map map, String transNo) {
        return defaultResponse();
    }

    @Override
    public String getRealNameAuthDailyLimit(Map map) {
        return null;
    }
    @Override
    public String querySysParam(String paramId) {
        return null;
    }
    @Override
    public String selectValueByKey(String key) {
        return null;
    }
    @Override
    public String getOpenTime(Map map) {
        return null;
    }
    @Override
    public Map getDbSimInfo(Map map) {
        return null;
    }
    @Override
    public String getSubsId(Map map) {
        return null;
    }
    @Override
    public MsisdnBindingVo getMsisdnIccid(Map map) {
        return null;
    }
    @Override
    public List<MsisdnBindingVo> batchQryStatus(Map map) {
        return null;
    }
    @Override
    public List querySubsProduct(Map map) {
        return null;
    }
    @Override
    public String getCustIdByMsisdn(Map map) {
        return null;
    }
    @Override
    public List<UserMsisdnDetail> queryMsisdnByPhone(Map map) {
        return null;
    }
    @Override
    public String getMsisdnStatus(String params) {
        return null;
    }
    @Override
    public String getIMEI(Map map) {
        return null;
    }
    @Override
    public ProductInfoVo getProductInfoByInstId(Map map) {
        return null;
    }
    @Override
    public List<String> getProdInstIds(Map map) {
        return null;
    }
    @Override
    public List<Map> getDicts(Map map) {
        return null;
    }



}
