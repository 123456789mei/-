package com.cmiot.api.service.impl;

import com.cmiot.api.service.SysClient;
import com.cmiot.commons.response.ResponseCode;
import com.cmiot.commons.response.ResponseVo;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class SysClientImpl implements SysClient {

    private ResponseVo defaultResponse() {
        return ResponseVo.fail(ResponseCode.ERROR_SERVICE_UNAVAILABLE);
    }

    @Override
    public ResponseVo msisdnQuery(Map paramMap, String transNo, String accessToken) {
        return defaultResponse();
    }

    @Override
    public ResponseVo sendMsg(Map paramMap) {
        return defaultResponse();
    }
}
