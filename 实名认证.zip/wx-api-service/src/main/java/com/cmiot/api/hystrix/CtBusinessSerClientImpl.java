package com.cmiot.api.hystrix;


import com.cmiot.api.client.ICtBusinessSerClient;
import com.cmiot.commons.response.ResponseCode;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class CtBusinessSerClientImpl implements ICtBusinessSerClient {

    private String defaultResponse(){
        return ResponseCode.ERROR_SERVICE_UNAVAILABLE;
    }

    @Override
    public String getLiveCollectJumpKey(String transNo, Map map) {
        return defaultResponse();
    }

    @Override
    public String getSubsId(String transNo, Map map) {
        return defaultResponse();
    }

    @Override
    public String queryLiveCollectResult(String transNo, Map map) {
        return defaultResponse();
    }

    @Override
    public String modifySubsRealNameInfo(String transNo, Map map) {
        return defaultResponse();
    }
    @Override
    public String queryOrderStatus(String transNo, Map map) {
        return defaultResponse();
    }
    @Override
    public String queryCardStatus(String transNo, Map map) {
        return defaultResponse();
    }
}
