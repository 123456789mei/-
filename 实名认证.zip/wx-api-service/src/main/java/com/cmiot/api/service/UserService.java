package com.cmiot.api.service;

import com.cmiot.commons.common.constants.ParamConstants;
import com.cmiot.commons.common.constants.RequestConstants;
import com.cmiot.commons.common.constants.ServiceNames;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.mybatis.vo.MsisdnBindingVo;
import com.cmiot.mybatis.vo.ProductInfoVo;
import com.cmiot.mybatis.vo.UserMsisdnDetail;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@FeignClient(value = ServiceNames.DAL_SERVICE_NAME)
public interface UserService {

    /**
     * 微信绑定移动手机号码
     * */
    @RequestMapping(value = "/wx/register")
    ResponseVo register(Map paramMap, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,
                                   @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);
    /**
     * 微信用户类型修改
     * */
    @RequestMapping(value = "/wx/updateType")
    ResponseVo updateType(Map paramMap, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,
                                   @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);
    /**
     * 获取账户基本信息 也用作检验微信是否注册
     */
    @RequestMapping(value = "/wx/getWxUserInfo")
    ResponseVo getWxUserInfo(Map paramMap, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,
                             @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);
    /**
     * 绑定EC账户
     * */
    @RequestMapping(value = "/wx/bind")
    ResponseVo bind(Map paramMap, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,
                    @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);
    /**
     * 获取账户绑定的EC账户
     * */
    @RequestMapping(value = "/wx/accountlist")
    ResponseVo accountlist(Map paramMap, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,
                    @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);
    /**
     * 移除账户绑定的EC账户
     * */
    @RequestMapping(value = "/wx/deleteAccount")
    ResponseVo deleteAccount(Map paramMap, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,
                           @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 移除账户绑定的 全部EC账户
     * */
    @RequestMapping(value = "/wx/deleteAllAccount")
    ResponseVo deleteAllAccount(Map paramMap, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,
                             @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 获取微信绑定的EC账户列表
     * */
    @RequestMapping(value = "/wx/getEcList")
    ResponseVo getEcList(Map paramMap, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,
                                @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 获取ec用户信息--使用系统登录的查询sql
     * */
    @RequestMapping(value = "/ssoAuth/getEcOper",method = RequestMethod.GET)
    ResponseVo getEcOper(@RequestParam(ParamConstants.OPERID) String operId, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,
                         @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 获取 集团ID
     * */
    @RequestMapping(value = "/wx/getCustIdByMsisdn")
    ResponseVo getCustIdByMsisdn(Map paramMap, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,
                         @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 获取卡号订购产品
     * */
    @RequestMapping(value = "/wx/querySubsProduct")
    ResponseVo querySubsProduct(Map paramMap, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,
                                 @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 个人用户查询卡号
     * @return
     */
    @RequestMapping("/wx/queryMsisdnByPhone")
    ResponseVo queryMsisdnByPhone(@RequestBody Map<String, String> map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,
                                  @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 个人用户状态查询
     * @param map
     * @return
     */
    @RequestMapping("/wx/getUserStatus")
    ResponseVo getUserStatus(@RequestBody Map<String, String> map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,
                             @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    @RequestMapping("/wx/getUserType")
    ResponseVo getUserType(Map paramMap, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,
                           @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);
    @RequestMapping("/wx/getUserPhone")
    ResponseVo getUserPhoneByOpenId(Map paramMap, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,
                                    @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     *  PB卡套餐查询
     *
     */
    @RequestMapping(value = "/prodOrderMgr/getOrderdProdInfoByProdInstID",method = RequestMethod.POST)
    ResponseVo getProdInfoByProdInstID(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,
                                       @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    /**
     * 地市id查询
     *
     */
    @RequestMapping(value = "/pbRegister/queryRegionId",method = RequestMethod.POST)
    ResponseVo queryRegionId(@RequestBody Map map, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);


    /*-------------个人业务数据库迁移改造,全局库查询改为调dal接口------------------------*/


    @RequestMapping(value = "/wxApiDao/getRealNameAuthDailyLimit",method = RequestMethod.POST)
    String getRealNameAuthDailyLimit(@RequestBody Map map);

    @RequestMapping(value = "/wxApiDao/querySysParam",method = RequestMethod.POST)
    String querySysParam(@RequestParam("paramId") String paramId);

    @RequestMapping(value = "/wxApiDao/selectValueByKey",method = RequestMethod.POST)
    String selectValueByKey(@RequestParam("key") String keyo);

    @RequestMapping(value = "/wxApiDao/getOpenTime",method = RequestMethod.POST)
    String getOpenTime(@RequestBody Map map);

    @RequestMapping(value = "/wxApiDao/getDbSimInfo",method = RequestMethod.POST)
    Map getDbSimInfo(@RequestBody Map map);

    @RequestMapping(value = "/wxApiDao/getSubsId",method = RequestMethod.POST)
    String getSubsId(@RequestBody Map map);

    @RequestMapping(value = "/wxApiDao/getMsisdnIccid",method = RequestMethod.POST)
    MsisdnBindingVo getMsisdnIccid(@RequestBody Map map);

    @RequestMapping(value = "/wxApiDao/batchQryStatus",method = RequestMethod.POST)
    List<MsisdnBindingVo> batchQryStatus(@RequestBody Map map);

    @RequestMapping(value = "/wxApiDao/querySubsProduct",method = RequestMethod.POST)
    List querySubsProduct(@RequestBody Map map);

    @RequestMapping(value = "/wxApiDao/getCustIdByMsisdn",method = RequestMethod.POST)
    String getCustIdByMsisdn(@RequestBody Map map);

    @RequestMapping(value = "/wxApiDao/queryMsisdnByPhone",method = RequestMethod.POST)
    List<UserMsisdnDetail> queryMsisdnByPhone(@RequestBody Map map);

    @RequestMapping(value = "/wxApiDao/getMsisdnStatus",method = RequestMethod.POST)
    String getMsisdnStatus(@RequestParam("params") String params);

    @RequestMapping(value = "/wxApiDao/getIMEI",method = RequestMethod.POST)
    String getIMEI(@RequestBody Map map);

    @RequestMapping(value = "/wxApiDao/getProductInfoByInstId",method = RequestMethod.POST)
    ProductInfoVo getProductInfoByInstId(@RequestBody Map map);

    @RequestMapping(value = "/wxApiDao/getProdInstIds",method = RequestMethod.POST)
    List<String> getProdInstIds(@RequestBody Map map);

    @RequestMapping(value = "/wxApiDao/getDicts",method = RequestMethod.POST)
    List<Map> getDicts(@RequestBody Map map);
}
