package com.cmiot.api.service;

import com.cmiot.api.service.impl.SysClientImpl;
import com.cmiot.commons.common.constants.RequestConstants;
import com.cmiot.commons.common.constants.ServiceNames;
import com.cmiot.commons.response.ResponseVo;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;

@FeignClient(value = ServiceNames.SYS_SERVICE_NAME, fallback = SysClientImpl.class)
public interface SysClient {

    @RequestMapping(value = "/memberAuth/msisdnQuery")
    ResponseVo msisdnQuery(Map paramMap, @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,
                              @RequestHeader(RequestConstants.HEADER_PARAMS_TOKEN) String accessToken);

    @RequestMapping(value = "/sms/send")
    ResponseVo sendMsg(Map paramMap);
}
