package com.cmiot.api.service;

import com.cmiot.api.service.impl.SMSNotifyDalServiceClientImpl;
import com.cmiot.commons.common.constants.RequestConstants;
import com.cmiot.commons.common.constants.ServiceNames;
import com.cmiot.commons.response.ResponseVo;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.Map;

/**
 * 东软
 * Created by Bai jitai on 2017/6/20.
 * 描述：手机短信下发查询
 * ***************更新历史*******************
 */
@FeignClient(value = ServiceNames.DAL_SERVICE_NAME, fallback = SMSNotifyDalServiceClientImpl.class)
public interface ISMSNotifyDalServiceClient {
    /**
     * 手机短信下发列表查询
     * 接口编号：SYS0605
     *
     * @param params  键值对：{pageNo:"",pageSize:"",telNum:"",beginTime:"",endTime:"",roletype:"",operBelong:""
     *                       ,provinceId:""}
     * @param transNo
     * @return response.data格式：{content:'',formNum:'',inTime:'',msgId:'',realDate:'',region:'',relatedFormNum:''
     * ,reportStatus:'', retCode:'',retMsg:'', sFrom:'',sendDate:'' ,status:'',telNum:'',templateNo:''}
     */
    @RequestMapping(value = "/smsNotifyDal/querySMSnotifyListDal", method = RequestMethod.POST)
    ResponseVo querySMSnotifyList(Map<String, Object> params,
                                  @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);

    /**
     * 根据msfid获得特定的短信回执
     * 接口编号：SYS0606
     *
     * @param params  键值对：{msgId:""}
     * @param transNo
     * @return response.data格式：{doneTime:'',inTime:'',msgId:'',port:'',region:'',status:'',submitTime:'',telNum:''}
     */
    @RequestMapping(value = "/smsNotifyDal/getReportDal", method = RequestMethod.POST)
    ResponseVo getReport(Map<String, Object> params,
                         @RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo);
}
