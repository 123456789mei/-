package com.cmiot.api.client;

import com.cmiot.api.hystrix.CtBusinessSerClientImpl;
import com.cmiot.commons.common.constants.RequestConstants;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.Map;

@FeignClient(value = "ct-business-service",fallback = CtBusinessSerClientImpl.class)
public interface ICtBusinessSerClient {

    /**
     * 活体采集验证页面跳转URL获取
     *
     * @param map
     * @param transNo
     * @return
     */
    @RequestMapping(value = "/mobileCcmpAccess/getLiveCollectJumpKey", method = RequestMethod.GET)
    String getLiveCollectJumpKey(@RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo, Map map);

    /**
     * msisdn（卡号）查询subsId（用户ID）
     *
     * @param map
     * @param transNo
     * @return
     */
    @RequestMapping(value = "/mobileCcmpAccess/getSubsId", method = RequestMethod.GET)
    String getSubsId(@RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,Map map);

    /**
     * 活体认证结果查询
     *
     * @param map
     * @param transNo
     * @return
     */
    @RequestMapping(value = "/mobileCcmpAccess/queryLiveCollectResult", method = RequestMethod.GET)
    String queryLiveCollectResult(@RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,Map map);

    /**
     * 使用人实名信息变更
     *
     * @param map
     * @param transNo
     * @return
     */
    @RequestMapping(value = "/mobileCcmpAccess/modifySubsRealNameInfo", method = RequestMethod.GET)
    String modifySubsRealNameInfo(@RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,Map map);

    /**
     * 使用人实名信息变更
     *
     * @param map
     * @param transNo
     * @return
     */
    @RequestMapping(value = "/mobileCcmpAccess/queryOrderStatus", method = RequestMethod.GET)
    String queryOrderStatus(@RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,Map map);


    /**
     * 管理停机查询
     *
     * @param map
     * @param transNo
     * @return
     */
    @RequestMapping(value = "/mobileCcmpAccess/queryCardStatus", method = RequestMethod.GET)
    String queryCardStatus(@RequestHeader(RequestConstants.HEADER_PARAMS_TRANSNO) String transNo,Map map);

}
