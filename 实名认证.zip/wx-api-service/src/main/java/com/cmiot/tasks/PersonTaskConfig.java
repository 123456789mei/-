package com.cmiot.tasks;

import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.cache.impl.CacheManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Random;

@Component
public class PersonTaskConfig {

    static Logger logger = LoggerFactory.getLogger(PersonTaskConfig.class);

    @Autowired
    PersonTaskService taskService;

    @Autowired
    ICache cache;

    private static final String WX_PERSON_AUTO_UNBIND = "WX_PERSON_AUTO_UNBIND";
    private static final String TASK_FREE = "FREE";

    /**
     * 释放缓存锁
     * */
    public void releaseLock() {
        cache.put(CacheManager.PublicNameSpace.TEMP, WX_PERSON_AUTO_UNBIND, TASK_FREE);
    }

    /**
     * pb卡实名登记-每3分钟定时遍历wx-api的nas目录/data_realname/auth/data下的.tar.gz压缩包，解压
     * xiajunchen
     */
    @Scheduled(cron = "0 0/3 * * * ?")
    public void UpdatePicUrl() {
        //设置一个随机延迟
        try {
            int delay=new Random().nextInt(5000);
            Thread.currentThread().sleep(delay);
            //设置redis锁,防止同一张卡重复发起
            if(cache.containsKey(CacheManager.PublicNameSpace.TEMP, "UPDATEPICURLSYNC")){
                return;
            }
            cache.put(CacheManager.PublicNameSpace.TEMP,"UPDATEPICURLSYNC","y",1200);
            taskService.UpdatePicUrl();
        }catch (Exception e){
            logger.info("解压UpdatePicUrl报错");
        }finally {
            cache.remove(CacheManager.PublicNameSpace.TEMP,"UPDATEPICURLSYNC");
        }
    }

    /**
     * pb卡实名登记-每4分钟定时遍历wx-api的nas目录/data_realname/auth/data下的图片，解密并根据流水号入库
     */
    @Scheduled(cron = "0 0/4 * * * ?")
    public void savePicUrl() {
        //设置一个随机延迟
        try {
            int delay=new Random().nextInt(5000);
            Thread.currentThread().sleep(delay);
            //设置redis锁,防止同一张卡重复发起
            if(cache.containsKey(CacheManager.PublicNameSpace.TEMP, "SAVEPICURLSYNC")){
                return;
            }
            cache.put(CacheManager.PublicNameSpace.TEMP,"SAVEPICURLSYNC","y",1200);
            taskService.savePicUrl();
        }catch (Exception e){
            logger.info("解密savePicUrl报错");
        }finally {
            cache.remove(CacheManager.PublicNameSpace.TEMP,"SAVEPICURLSYNC");
        }
    }

    /**
     * pb卡实名登记-每4分钟定时遍历CM_PS_PB_REGISTER表，将符合要求的数据同步到省侧
     */
    @Scheduled(cron = "0 0/7 * * * ?")
    public void syncInfo() {
        //设置一个随机延迟
        try {
            int delay=new Random().nextInt(60000);
            Thread.currentThread().sleep(delay);
        }catch (Exception e){
        }
        taskService.syncInfo();
    }

    /**
     * pb卡实名登记-每12小时删除一次/data_realname/auth/data的无用文件（已解压的压缩包、非pb卡实名登记途径的图片）
     */
    @Scheduled(cron = "0 0 0/12 * * ?")
    public void deleteFromRealNameTask() {
        //设置一个随机延迟
        try {
            int delay=new Random().nextInt(120000);
            Thread.currentThread().sleep(delay);
        }catch (Exception e){
        }
        taskService.deleteFromRealName();
    }


    /**配合kafka
     * CT卡实名-每30分钟定时执行一次：活体认证结果查询
     */
    @Scheduled(cron = "0 0/30 * * * ?")
    public void ctRealName() {
        //设置一个随机延迟
        try {
            int delay=new Random().nextInt(120000);
            Thread.currentThread().sleep(delay);
        }catch (Exception e){
        }
        taskService.ctRealName();
    }

    /**
     * CT卡实名-每3分钟定时执行一次：使用人实名信息变更
     */
    @Scheduled(cron = "0 0/3 * * * ?")
    public void modifyCtRealNameInfo() {
        //设置一个随机延迟
        try {
            int delay=new Random().nextInt(60000);
            Thread.currentThread().sleep(delay);
        }catch (Exception e){
        }
        taskService.modifyCtRealNameInfo();
    }

//    @Scheduled(cron = "0 0/30 * * * ?")
//    public void dealRegiterH5InfoTask() {
//        //设置一个随机延迟
//        try {
//            int delay=new Random().nextInt(60000);
//            Thread.currentThread().sleep(delay);
//        }catch (Exception e){
//        }
//        taskService.dealRegiterH5Info();
//    }

}
