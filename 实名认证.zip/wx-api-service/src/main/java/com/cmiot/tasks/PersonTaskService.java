package com.cmiot.tasks;

import com.alibaba.fastjson.JSONArray;
import com.cmiot.api.client.ICtBusinessSerClient;
import com.cmiot.api.service.AuthenticationServiceClient;
import com.cmiot.common.ct.access.entity.CTRequestFactory;
import com.cmiot.common.ct.access.entity.CTResponse;
import com.cmiot.commons.cache.impl.CacheManager;
import com.cmiot.commons.common.utils.FileZip;
import com.cmiot.commons.common.utils.HttpRequestClient;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.common.utils.UUID4Long;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.commons.response.vo.PageResultVo;
import com.cmiot.commons.vo.MsisdnCacheVo;
import com.cmiot.ms.dal.common.orcl.NormalBaseService;
import com.cmiot.mybatis.dao.AutoUnBindDao;
import com.cmiot.mybatis.dao.PbRegisterDao;
import com.cmiot.mybatis.dao.RealNameRegisterDao;
import com.cmiot.mybatis.service.RealNameAuthService;
import com.cmiot.mybatis.service.RealNameRegisterService;
import com.cmiot.mybatis.service.WxPersonUserInfoService;
import com.cmiot.mybatis.vo.*;
import com.cmiot.util.*;
import com.cmiot.util.signtj.SignUtilTj;
import com.cmiot.wx.apiservice.entity.PbResultVo;
import com.cmiot.wx.apiservice.service.CTUserService;
import com.cmiot.wx.apiservice.service.CommonSmsService;
import com.cmiot.wx.apiservice.service.HnPbRegisterService;
import com.cmiot.wx.apiservice.service.impl.BjPbRegisterService;
import com.cmiot.wx.apiservice.utiles.*;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sun.misc.BASE64Decoder;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PersonTaskService extends NormalBaseService {

    static Logger logger = LoggerFactory.getLogger(PersonTaskService.class);

    private HttpRequestClient client = new HttpRequestClient();

    @Autowired
    AutoUnBindDao autoUnBindDao;

    @Autowired
    WxPersonUserInfoService userInfoService;

    @Autowired
    UUID4Long uuid;

    @Autowired
    PersonTaskConfig tasks;

    @Autowired
    PbRegisterDao pbRegisterDao;

    @Autowired
    RealNameAuthService realNameAuthService;

    @Autowired
    RealNameRegisterDao realNameRegisterDao;

    @Autowired
    CommonSmsService commonSmsService;

    @Autowired
    CTUserService ctUserService;

    @Autowired
    AuthenticationServiceClient authenticationServiceClient;

    @Autowired
    RealNameRegisterService registerService;

    @Autowired
    HnPbRegisterService hnPbRegisterService;

    @Autowired
    BjPbRegisterService bjPbRegisterService;

    @Autowired
    ICtBusinessSerClient ctBusinessSerClient;

    @Autowired
    CTRequestFactory ctRequestFactory;

    static final String APPID="1083846";

    static final String APPKEY="a9c8113b2271b9e8edccfb7b7eecfa63";




    public void autoUnBind() {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        List<RealNameInfoRecord> usedUserList = autoUnBindDao.getUserList();
        if (usedUserList.size() == 0) {
            logger.info("transNo is:[{}],未查询到有效的操作账户列表，任务结束", "自动解绑定时任务");
            tasks.releaseLock();
            return;
        }
        usedUserList.forEach(item -> {
            if (item.getUserId() != null) {
                String transNo = String.valueOf(uuid.nextId());
                runUnBind(item.getUserId(), transNo);
            }
        });
        tasks.releaseLock();
    }

    public void runUnBind(String userId, String transNo) {
        Map qryLocalList = new HashMap(4, 0.8F);
        qryLocalList.put(CommonConstant.USERID, userId);
        qryLocalList.put(CommonConstant.FIELD_BIND_STATUS, CommonConstant.WX_BIND_STATUS_BIND);
        long start = System.currentTimeMillis();
        PageResultVo pageResultVo = userInfoService.getMsisdnList(qryLocalList);
//        logger.info("transNo is:[{}],[耗时：{} ms] 数据库查询结果：[{}] ", "自动解绑定时任务:".concat(transNo), (System.currentTimeMillis() - start), JsonUtils.parseString(pageResultVo));
        if (pageResultVo == null) {
            logger.error("transNo is:[{}],查询本地用户绑定卡列表异常！,params is:[{}]", "自动解绑定时任务".concat(transNo), JsonUtils.parseString(qryLocalList));
        } else {
            List<MsisdnBindingVo> bindingVos = pageResultVo.getList();
            if (bindingVos != null && bindingVos.size() > 0) {
                List<MsisdnBindingVo> autoUnbind = new ArrayList<>();
                start = System.currentTimeMillis();
                bindingVos.parallelStream()
                        // 查询 PB 省份ID
                        .map(msisdnBindingVo -> {
                            if (CommonConstant.WX_CARD_BELONG_PB.equals(msisdnBindingVo.getCardBelong())) {
                                MsisdnCacheVo cacheVo = cache.getByMsisdn(msisdnBindingVo.getMsisdn());
                                if (cacheVo != null) {
                                    msisdnBindingVo.setBeId(cacheVo.getProvinceId());
                                    msisdnBindingVo.setCustId(cacheVo.getCustId());
                                } else {
                                    msisdnBindingVo.setBeId("");
                                }
                            } else {
                                msisdnBindingVo.setBeId("CT");
                            }
                            return msisdnBindingVo;
                        })
                        // 根据 省份ID 分组
                        .collect(Collectors.groupingByConcurrent(MsisdnBindingVo::getBeId))
                        .forEach((provinceId, list) -> {
                            list = userInfoService.batchQryStatus(provinceId, list, "自动解绑定时任务".concat(transNo));
                            // 筛选出销户卡
                            autoUnbind.addAll(list.parallelStream().filter(userInfoService::isCancel).collect(Collectors.toList()));
                        });
                logger.info("transNo is:[{}],[耗时：{} ms] 遍历查询状态", "自动解绑定时任务".concat(transNo), (System.currentTimeMillis() - start));
                //将筛选出来的销户卡做自动解绑
                Map setParams = new HashMap(4, 0.8F);
                setParams.put(CommonConstant.FIELD_BIND_STATUS, CommonConstant.WX_BIND_STATUS_AUTO_UNBIND);
                setParams.put(CommonConstant.USERID, userId);
                setParams.put(CommonConstant.TRANSNO, transNo);
                start = System.currentTimeMillis();
                try {
                    userInfoService.batchAutoHandle(autoUnbind, setParams);
                } catch (Exception e) {
                    logger.error("transNo is:[{}],批量解绑失败，msisdnList is:[{}],params is:[{}]", "自动解绑定时任务".concat(transNo), JsonUtils.parseString(autoUnbind), JsonUtils.parseString(setParams), e);
                } finally {
                    logger.info("transNo is:[{}],[耗时：{} ms] 批量自动绑定/自动解绑列表：[{}] ", "自动解绑定时任务".concat(transNo), (System.currentTimeMillis() - start), JsonUtils.parseString(autoUnbind));
                }
            }
        }
    }

    public void UpdatePicUrl() {
        String url=cache.getSysParams("REAL_NAME_FTP_LOCAL", "/data_realname/auth/data");
        try {
            File file = new File(url);
            File[] tempList = file.listFiles();
            //解压.gz包
            for (File zipFile : tempList) {
                if (zipFile.getName().endsWith(".gz") && !zipFile.getName().startsWith("isFinished")) {
                    try {
                        List<String> z = FileZip.unGzipFile(zipFile);
                        //给解压过的压缩包名打标签
                        File newFile = new File(zipFile.getParent() + File.separator + "isFinished" + zipFile.getName());
                        zipFile.renameTo(newFile);
                    }catch (Exception e){
                        logger.info("解压.gz包报错...{}",zipFile.getName());
                    }
                }
            }
            //解压.tar包
            File fileTar = new File(url);
            List<File> tarList=getFileList(fileTar);
            for (File zipFile : tarList) {
                if(zipFile.getName().endsWith(".tar")){
                    try {
                        TarArchiveInputStream tais = new TarArchiveInputStream(new FileInputStream(zipFile));
                        deTarFile(url, tais);
                        tais.close();
                        //解压后删除.tar包
                        zipFile.delete();
                    }catch (Exception e){
                        logger.info("解压.tar包报错...{}",zipFile.getName());
                    }
                }
            }
        }catch (Exception e){
            logger.info("UpdatePicUrl遍历文件报错");
        }finally {
            cache.remove(CacheManager.PublicNameSpace.TEMP,"UPDATEPICURLSYNC");
        }
    }

    public void savePicUrl(){
        String url=cache.getSysParams("REAL_NAME_FTP_LOCAL", "/data_realname/auth/data");
        try {
            //图片解密
            File PicUncode = new File(url);
            List<File> PicUncodeList=getFileList(PicUncode);
            for (File pic :
                    PicUncodeList) {
                if((pic.getName().contains("_Z") || pic.getName().contains("_F")
                        || pic.getName().contains("_R.")
                        || pic.getName().contains("_V2"))&&!pic.getName().contains("isFinished")&&pic.getName().contains("WX_OA")){
                    try {
                        //解密
                        File file1 = new File(pic.getPath());
                        File file_2 = new File(url+File.separator+pic.getName());
                        FileInputStream fis = new FileInputStream(file1);
                        RealNameMsDesPlus Ms = new RealNameMsDesPlus(cache.getSysParams("551.deskey",""));//创建加密对象
                        BASE64Decoder decoder = new BASE64Decoder();
                        String str = IOUtils.toString(fis,"ISO8859-1");//将输入流转为字符串
                        String decryptStr = Ms.decrypt(str);//解密
                        byte[] encodeByte =decoder.decodeBuffer(decryptStr);
                        FileOutputStream fos = new FileOutputStream(file_2);
                        fos.write(encodeByte);
                        fos.close();
                        fis.close();
                        //给已经解密的图片打标签
                        File newFile = new File(file_2.getParent() + File.separator + "isFinished" + file_2.getName());
                        file_2.renameTo(newFile);
                    }catch (Exception e){
                        logger.info("图片解密报错...{}",pic.getName());
                    }
                }
            }
        }catch (Exception e){
            logger.info("savePicUrl遍历文件报错");
        }
        //图片路径入库
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        File filePic = new File(url);
        List<File> PicList=getFileList(filePic);
        Map<String, String> map = new HashMap<>();
        for (File pic :
                PicList) {
            try {
                if ((pic.getName().contains("_Z") || pic.getName().contains("_F")
                        || pic.getName().contains("_R.")
                        || pic.getName().contains("_R_V2"))&&pic.getName().contains("isFinished")) {
                    //获取订单号
                    String picName = pic.getName();
                    String orderNum = "";
                    if(picName.contains("230_WX")){
                        orderNum=picName.substring(18, pic.getName().indexOf("_",28));
                    }
                    if(picName.contains("230WX")){
                        orderNum=picName.substring(17, pic.getName().indexOf("_",28));
                    }
                    map.put("orderNum", orderNum);
                    map.put("url", pic.getPath());
                    if (picName.contains("_Z")) {
                        map.put("type", "z");
                        pbRegisterDao.updateUrl(map);
                    } else if (picName.contains("_F")) {
                        map.put("type", "f");
                        pbRegisterDao.updateUrl(map);
                    } else if (picName.contains("_R.")) {
                        map.put("type", "v1");
                        pbRegisterDao.updateUrl(map);
                    } else if (picName.contains("_R_V2")) {
                        map.put("type", "v2");
                        pbRegisterDao.updateUrl(map);
                    }
                }
            }catch (Exception e){
                logger.info("图片入库失败...{}",pic.getName());
            }
        }
        cache.remove(CacheManager.PublicNameSpace.TEMP,"SAVEPICURLSYNC");
    }

    public void syncInfo() {
        try {
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
            List<PbRegisterVo> list = pbRegisterDao.querySyncInfo();
            for (PbRegisterVo vo : list) {
                try {
                    //设置redis锁,防止同一张卡重复发起
                    if(cache.containsKey(CacheManager.PublicNameSpace.TEMP, "realname_" + vo.getMsisdn())){
                        logger.info("实名信息同步,卡号{}重复请求,跳过",vo.getMsisdn());
                        continue;
                    }
                    cache.put(CacheManager.PublicNameSpace.TEMP,"realname_"+vo.getMsisdn(),"y",1200);
                    logger.info("实名信息同步,卡号{}继续请求",vo.getMsisdn());
                    //防止订单重复发起请求
                    if(querySameOrderNum(vo.getOrderNum(),vo.getMsisdn()))continue;
                    String index = cache.get(CacheManager.PublicNameSpace.TEMP, vo.getOrderNum());
                    vo.setNameZ(vo.getOrderNum()+"_Z"+vo.getPicZ().substring(vo.getPicZ().indexOf(".")));
                    vo.setNameF(vo.getOrderNum()+"_F"+vo.getPicF().substring(vo.getPicF().indexOf(".")));
                    vo.setNameV1(vo.getOrderNum()+"_V1"+vo.getPicV1().substring(vo.getPicV1().indexOf(".")));
                    //根据路径获取图片,base64编码
                    if(!"250".equals(vo.getBeid())){
                        vo.setPicZ(Base64Utils.encodeFile(vo.getPicZ()));
                        vo.setPicF(Base64Utils.encodeFile(vo.getPicF()));
                        vo.setPicV1(Base64Utils.encodeFile(vo.getPicV1()));
                    }
                    //设置证件类型
                    vo.setType("1");
                    switch (vo.getBeid()){
                        case "551":
                            pbRealName551(vo,index);
                            break;
                        case "371":
                            pbRealName371(vo,index);
                            break;
                        case "100":
                            if(vo.getPicV2()==null||"".equals(vo.getPicV2()))break;
                            vo.setNameV2(vo.getOrderNum()+"_V2"+vo.getPicV2().substring(vo.getPicV2().indexOf(".")));
                            vo.setPicV2(Base64Utils.encodeFile(vo.getPicV2()));
                            if(StringUtils.isNotBlank(vo.getPicZ())&&StringUtils.isNotBlank(vo.getPicF())&&
                                    StringUtils.isNotBlank(vo.getPicV1())&&StringUtils.isNotBlank(vo.getPicV2())){
                                pbRealName100(vo,index);
                            }else {
                                logger.info("100pb syncInfo 缺少图片msisdn:{}",vo.getMsisdn());
                            }
                            break;
                        case "250":
                            if(vo.getPicV2()==null||"".equals(vo.getPicV2()))break;
                            String url=cache.getSysParams("REAL_NAME_FTP_LOCAL_250", "/data_realname/auth/data250");
                            Double size = Double.valueOf(cache.getSysParams("PIC_ZIP_SIZE", "1200"));
                            vo.setNameV2(vo.getOrderNum()+"_V2"+vo.getPicV2().substring(vo.getPicV2().indexOf(".")));
                            //图片压缩处理
                            String picV1 = saveMinPhoto(vo.getPicV1(), url + File.separator + vo.getNameV1(), size, 1);
                            String picV2 = saveMinPhoto(vo.getPicV2(), url + File.separator + vo.getNameV2(), size, 1);
                            String picZ = saveMinPhoto(vo.getPicZ(), url + File.separator + vo.getNameZ(), size, 1);
                            String picF = saveMinPhoto(vo.getPicF(), url + File.separator + vo.getNameF(), size, 1);
                            vo.setPicZ(Base64Utils.encodeFile(picZ));
                            vo.setPicF(Base64Utils.encodeFile(picF));
                            vo.setPicV1(Base64Utils.encodeFile(picV1));
                            vo.setPicV2(Base64Utils.encodeFile(picV2));
                            if(StringUtils.isNotBlank(vo.getPicZ())&&StringUtils.isNotBlank(vo.getPicF())&&
                                    StringUtils.isNotBlank(vo.getPicV1())&&StringUtils.isNotBlank(vo.getPicV2())){
                                pbRealName250(vo,index);
                            }else {
                                logger.info("250pb syncInfo 缺少图片msisdn:{}",vo.getMsisdn());
                            }
                            break;
                        case "220":
                            pbRealName220(vo,index);
                            break;
                        case "898":
                            pbRealName898(vo,index);
                            break;
                        default:
                            break;
                    }
                }catch (Exception e){
                    logger.info("{}pb物联卡:{}实名登记-同步信息报错...{}",vo.getOrderNum(),vo.getMsisdn(),e);
                }finally {
                    cache.remove(CacheManager.PublicNameSpace.TEMP,"realname_"+vo.getMsisdn());
                }
            }

        }catch (Exception e){
            logger.info("send msg to province fail...{}",e.getMessage());
        }
    }

    private boolean querySameOrderNum(String orderNum,String msisdn){
        //已经发起过请求的订单号跳过
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        int sameBusiseq = pbRegisterDao.querySameOrderNum(orderNum);
        if(sameBusiseq>0){
            logger.info("pb卡号：{},订单号：{}重复请求，跳过",msisdn,orderNum);
            return true;
        }else {
            return false;
        }
    }

    /**
     * 安徽pb处理
     */
    private void pbRealName551(PbRegisterVo vo,String index){
        try {
            if(!StringUtils.isNotBlank(vo.getLoginAccept())||!StringUtils.isNotBlank(vo.getSubOrderId())){
                logger.info("msisdn:{},orderNum:{},pbRealName551 未获取到LoginAccept orSubOrderId",vo.getMsisdn(),vo.getOrderNum());
                return;
            }
            SimpleDateFormat sdf=new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            Date now=new Date(System.currentTimeMillis());
            //封装图片接口参数
            PbPicVo picVo=new PbPicVo();
            picVo.setOnlineCompanySerialNo(vo.getOrderNum());
            picVo.setPhone(vo.getMsisdn());
            picVo.setTime(hnPbRegisterService.getTime());
            picVo.setOrderNumber(vo.getSubOrderId());
            picVo.setSerialNo(vo.getLoginAccept());
            picVo.setBeiyongOne(vo.getNameZ());
            picVo.setBeiyongTwo(vo.getNameF());
            picVo.setBeiyongThr(vo.getNameV1());
            picVo.setIdCardZJpg(vo.getPicZ());
            picVo.setIdCardFJpg(vo.getPicF());
            picVo.setFaceJpg(vo.getPicV1());
            SimpleDateFormat sdf1=new SimpleDateFormat("yyyyMMddHHmmss");
            String json = JSONArray.toJSONString(picVo);
            logger.info("551ready sync info to province...msidn:{},time:{}",vo.getMsisdn(),picVo.getTime());
            String url = cache.getSysParams("551.syncPic","http://192.168.104.37/pbRegister/rest/1.0/recordData");
            String ss ="pin={ROOT:"+json+"}";
            ss = URLEncoder.encode(ss, "UTF-8");
            String time=sdf1.format(now);
            String requestParameters=ss+cache.getSysParams("551.syncInfo.param","")+"&timeStamp="+time;
            String sign = HttpUtil.toSign(requestParameters,"/data_realname/auth/key/pb_private_key.pem");
            logger.info("551send msg to province check...msisdn:{}...url:{}...sign:{}",vo.getMsisdn(),url,sign);
            requestParameters = requestParameters + "&sign=" + sign;
            String x = HttpUtil.sendPost(url, requestParameters);
            x=new String(x.getBytes(),"UTF-8");
            logger.info("551send msg to province...msisdn:{}...get result:{}",vo.getMsisdn(),x);
            //更新调用记录
            Map result = JsonUtils.parseObject(x, Map.class);
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
            if(result.get("ROOT")!=null&&JsonUtils.parseObject(result.get("ROOT"), PbResultVo.class)!=null){
                PbResultVo pbResultVo = JsonUtils.parseObject(result.get("ROOT"), PbResultVo.class);
                if("0".equals(pbResultVo.getResult())){
                    logger.info("551 同步图片success...{}",JsonUtils.parseString(pbResultVo.getResult()));
                    PbRegisterVo resultVo=new PbRegisterVo();
                    resultVo.setStatus("1");
                    resultVo.setOrderNum(vo.getOrderNum());
                    pbRegisterDao.updateResult(resultVo);
                }else {
                    //调在线公司失败的情况，尝试三次
                    if(index!=null&&!"".equals(index)){
                        int num=Integer.valueOf(index);
                        if(num>3){
                            logger.info("sync 551province fail time>3...msisdn:{}",vo.getMsisdn());
                            PbRegisterVo resultVo=new PbRegisterVo();
                            resultVo.setStatus("3");
                            resultVo.setOrderNum(vo.getOrderNum());
                            pbRegisterDao.updateResult(vo);
                        }else {
                            num+=1;
                            cache.put(CacheManager.PublicNameSpace.TEMP,vo.getOrderNum(),num+"",86400);
                            return;
                        }
                    }else {
                        cache.put(CacheManager.PublicNameSpace.TEMP,vo.getOrderNum(),"1",86400);
                        return;
                    }
                }
            }else {
                //调在线公司失败的情况，尝试三次
                if(index!=null&&!"".equals(index)){
                    int num=Integer.valueOf(index);
                    if(num>3){
                        logger.info("sync 551province fail time>3...msisdn:{}",vo.getMsisdn());
                        PbRegisterVo resultVo=new PbRegisterVo();
                        resultVo.setStatus("3");
                        resultVo.setOrderNum(vo.getOrderNum());
                        pbRegisterDao.updateResult(vo);
                    }else {
                        num+=1;
                        cache.put(CacheManager.PublicNameSpace.TEMP,vo.getOrderNum(),num+"",86400);
                        return;
                    }
                }else {
                    cache.put(CacheManager.PublicNameSpace.TEMP,vo.getOrderNum(),"1",86400);
                    return;
                }
            }
        }catch (Exception e){
            logger.info("{}pb物联卡:{}实名登记-同步信息报错...{}",vo.getOrderNum(),vo.getMsisdn(),e);
        }finally {
            cache.remove(CacheManager.PublicNameSpace.TEMP,"realname_"+vo.getMsisdn());
        }
    }


    /**
     * 天津pb处理
     */
    private void pbRealName220(PbRegisterVo vo,String index){
        try {
            boolean flag=false;
            Map<String,Object> smsMap=new HashMap<>();
            String appId = cache.getSysParams("TJ_APPID", "");
            String appKey = cache.getSysParams("TJ_APPKEY", "");
            String publicKey = cache.getSysParams("TJ_PUBLICKEY", "");
            Map param=new HashMap();
            param.put("Req_seq",vo.getTransId());
            param.put("msisdn",vo.getMsisdn());
            param.put("idType","0");
            param.put("idCard",vo.getIdCard());
            param.put("Cust_name",vo.getName());
            param.put("Pspt_Address",vo.getAddress());
            param.put("Nation",vo.getNation());
            param.put("Sex",vo.getSex());
            param.put("Birthday",vo.getBirthday());
            param.put("Pspt_Startdate",vo.getStartDate());
            param.put("Pspt_Enddate",vo.getEndDate());
            param.put("Pspt_info",vo.getInfo());
            param.put("nameV1",vo.getNameV1());
            param.put("nameZ",vo.getNameZ());
            param.put("nameF",vo.getNameF());
            param.put("orderNum",vo.getOrderNum());
            param.put("Channelid","022");
            param.put("Req_time",getTime());
            param.put("picV1",URLEncoder.encode(vo.getPicV1(),"utf-8"));
            param.put("picZ",URLEncoder.encode(vo.getPicZ(),"utf-8"));
            param.put("picF",URLEncoder.encode(vo.getPicF(),"utf-8"));
            param.put("X_TRANS_CODE","TJ_UNHT_SynchroRealName");
            param.put("PROVINCE_CODE","TJIN");
            param.put("ROUTE_EPARCHY_CODE","0022");
            param.put("TRADE_EPARCHY_CODE","0022");
            param.put("EPARCHY_CODE","0022");
            param.put("TRADE_CITY_CODE","INTF");
            String publicParams = cache.getSysParams("TJ_PUBLICPARAMS", "");
            if(StringUtils.isNotBlank(publicParams)){
                Map publicMap = JsonUtils.parseObject(publicParams, Map.class);
                param.putAll(publicMap);
            }
            String json = JsonUtils.parseString(param);
            //获取环境配置
            String urlParam = cache.getSysParams("PBREGISTER_TJ_URL", "");
            String baseUrl=urlParam.split(",")[0];
            String status=urlParam.split(",")[1];
            logger.info("天津参数检查...appId:{},appKey:{},publicKey:{},urlParam:{}",appId,appKey,publicKey,urlParam);
            Map<String, String> sysParam = new HashMap();
            sysParam.put("method", "TJ_UNHT_SynchroRealName");
            sysParam.put("appId", appId);
            sysParam.put("timestamp", getTime());
            sysParam.put("format", "json");
            // 请根据实际业务创建流水号
            sysParam.put("flowId", getTime());
            sysParam.put("status", status);
            sysParam.put("appKey", appKey);
            // 生成sign签名
            String sign = SignUtilTj.generateSign(sysParam, json);
            logger.info("天津签名检查...sign:{}",sign);
            String url = baseUrl+"?method=" + sysParam.get("method") + "&appId="
                    + sysParam.get("appId") + "&flowId=" + sysParam.get("flowId") + "&status=" + sysParam.get("status")
                    + "&format=" + sysParam.get("format") + "&appKey=" + sysParam.get("appKey") + "&timestamp="
                    + sysParam.get("timestamp") + "&sign=" + URLEncoder.encode(sign, "utf-8");
            if(json.contains("\"picF\":\"\"")||json.contains("\"picZ\":\"\"")||json.contains("\"picV1\":\"\"")){
                logger.info("{}天津入参缺少图片{}",vo.getMsisdn(),json);
                return;
            }
            if("0".equals(cache.getSysParams("PB_REGISTER_LOG_CONTROL",""))){
                logger.info("天津pb卡信息同步接口请求前检查...url:{},params:{}",url,json);
            }
            String x = HttpUtil.sendPostTj(url,json);
            logger.info("天津pb卡信息同步接口返回参数检查...{}",x);
            if(x!=null&&!"".equals(x)){
                Map reMap = JsonUtils.parseObject(x, Map.class);
                Map result = JsonUtils.parseObject(reMap.get("result"), Map.class);
                List content = JsonUtils.parseObject(result.get("SVC_CONTENT"), List.class);
                Map resultParams = JsonUtils.parseObject(content.get(0), Map.class);
                if(resultParams.containsKey("Verify_result")&&resultParams.containsKey("Verify_resultMsg")){
                    if("0".equals(resultParams.get("Verify_result"))){
                        vo.setRegisterCode(PbRegisterCode.SUCCESS);
                        vo.setStatus("1");
                        pbRegisterDao.updateResult(vo);
                        flag=true;
                        smsMap.put("1",vo.getMsisdn());
                        //TODO PB实名登记信息同步省侧成功，推送给接入渠道
                        pushPBRegisterResult(vo,"00000");
                    }else {
                        vo.setRegisterCode(resultParams.getOrDefault("Verify_result","99999").toString());
                        vo.setStatus("3");
                        pbRegisterDao.updateResult(vo);
                        flag=false;
                        smsMap.put("1",vo.getMsisdn());
                        smsMap.put("2",resultParams.getOrDefault("Verify_resultMsg","未知错误").toString());
                        //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                        pushPBRegisterResult(vo,"001");
                    }
                }else{
                    //调在线公司失败的情况，尝试三次
                    if(index!=null&&!"".equals(index)){
                        int num=Integer.valueOf(index);
                        if(num>3){
                            logger.info("sync 220 province fail time>3...msisdn:{}",vo.getMsisdn());
                            vo.setRegisterCode(PbRegisterCode.SYNCFAIL);
                            vo.setStatus("3");
                            pbRegisterDao.updateResult(vo);
                            smsMap.put("1",vo.getMsisdn());
                            smsMap.put("2",PbRegisterCode.getResult(PbRegisterCode.SYNCFAIL));
                            //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                            pushPBRegisterResult(vo,"004");
                        }else {
                            num+=1;
                            cache.put(CacheManager.PublicNameSpace.TEMP,vo.getOrderNum(),num+"",86400);
                            return;
                        }
                    }else {
                        cache.put(CacheManager.PublicNameSpace.TEMP,vo.getOrderNum(),"1",86400);
                        return;
                    }
                }
            }else {
                //调在线公司失败的情况，尝试三次
                if(index!=null&&!"".equals(index)){
                    int num=Integer.valueOf(index);
                    if(num>3){
                        logger.info("sync 220 province fail time>3...msisdn:{}",vo.getMsisdn());
                        vo.setRegisterCode(PbRegisterCode.SYNCFAIL);
                        vo.setStatus("3");
                        pbRegisterDao.updateResult(vo);
                        smsMap.put("1",vo.getMsisdn());
                        smsMap.put("2",PbRegisterCode.getResult(PbRegisterCode.SYNCFAIL));
                        //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                        pushPBRegisterResult(vo,"004");
                    }else {
                        num+=1;
                        cache.put(CacheManager.PublicNameSpace.TEMP,vo.getOrderNum(),num+"",86400);
                        return;
                    }
                }else {
                    cache.put(CacheManager.PublicNameSpace.TEMP,vo.getOrderNum(),"1",86400);
                    return;
                }
            }
            realNameAuthService.sendMessage(vo.getPhone(),smsMap,flag);
        }catch (Exception e){
            logger.info("{}...pb物联卡:{}实名登记-同步信息报错...{}",vo.getOrderNum(),vo.getMsisdn(),e);
        }finally {
            cache.remove(CacheManager.PublicNameSpace.TEMP,"realname_"+vo.getMsisdn());
        }
    }

    /**
     * 河南pb处理
     */
    private void pbRealName371(PbRegisterVo vo,String index){
        try {
            PbRegisterVo pbRegisterVo=new PbRegisterVo();
            pbRegisterVo.setType("1");
            pbRegisterVo.setIdCard(vo.getIdCard());
            pbRegisterVo.setName(vo.getName());
            pbRegisterVo.setAddress(vo.getAddress());
            pbRegisterVo.setNation(vo.getNation());
            pbRegisterVo.setSex(vo.getSex());
            pbRegisterVo.setBirthday(vo.getBirthday());
            pbRegisterVo.setStartDate(vo.getStartDate());
            pbRegisterVo.setEndDate(vo.getEndDate());
            pbRegisterVo.setInfo(vo.getInfo());
            pbRegisterVo.setMsisdn(vo.getMsisdn());
            pbRegisterVo.setPicV1(vo.getPicV1());
            pbRegisterVo.setPicZ(vo.getPicZ());
            pbRegisterVo.setPicF(vo.getPicF());
            pbRegisterVo.setNameV1(vo.getNameV1());
            pbRegisterVo.setNameZ(vo.getNameZ());
            pbRegisterVo.setNameF(vo.getNameF());
            pbRegisterVo.setOrderNum(vo.getOrderNum());
            boolean flag=false;
            Map<String,Object> smsMap=new HashMap<>();
            String json = JSONArray.toJSONString(pbRegisterVo);
            logger.info("371ready sync info to province...msidn:{}",vo.getMsisdn());
            //业务参数加密
            String encyptBusiParam = SecurityUtils.encodeAES256HexUpper(json, SecurityUtils.decodeHexUpper(APPKEY));
            //生成时间戳
            String now = hnPbRegisterService.getTime();
            //能力编码
            String method="OSP_SAVE_REAL_USER_MSG";
            //请求token
            String token=hnPbRegisterService.getToken();
            //生成数字签名
            Map<String, String> sysParam = new HashMap<String, String>();
            sysParam.put("method", "OSP_SAVE_REAL_USER_MSG");
            sysParam.put("format", "json");
            sysParam.put("timestamp", now);
            sysParam.put("appId", APPID);
            sysParam.put("version", "1.0");
            sysParam.put("accessToken",token);
            sysParam.put("busiSerial","1");
            String sign = SignUtil.sign(sysParam, encyptBusiParam, "HmacSHA256", APPKEY);
            String url=cache.getSysParams("371.registerUrl","http://192.168.195.31/pbRegisterHN");
            String sys=String.format("%s?method=%s&format=json&appId=%s&busiSerial=1&version=1.0&accessToken=%s&timestamp=%s" +
                    "&sign=%s",url,method,APPID,token,now,sign);
            logger.info("msisdn:{},371同步前url检查:{}",pbRegisterVo.getMsisdn(),sys);
            String x = HttpUtil.sendPost(sys,encyptBusiParam);
            logger.info("河南pbRealName371...msisdn:{}返回:{}",vo.getMsisdn(),x);
            Map resultMap = JsonUtils.parseObject(x, Map.class);
            if(!"00000".equals(resultMap.get("respCode"))){
                //调在线公司失败的情况，尝试三次
                if(index!=null&&!"".equals(index)){
                    int num=Integer.valueOf(index);
                    if(num>3){
                        logger.info("sync province fail time>3...msisdn:{}",vo.getMsisdn());
                        vo.setRegisterCode(PbRegisterCode.SYNCFAIL);
                        vo.setStatus("3");
                        pbRegisterDao.updateResult(vo);
                        smsMap.put("1",vo.getMsisdn());
                        smsMap.put("2",PbRegisterCode.getResult(PbRegisterCode.SYNCFAIL));
                        //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                        pushPBRegisterResult(vo,"004");
                    }else {
                        num+=1;
                        cache.put(CacheManager.PublicNameSpace.TEMP,vo.getOrderNum(),num+"",86400);
                        return;
                    }
                }else {
                    cache.put(CacheManager.PublicNameSpace.TEMP,vo.getOrderNum(),"1",86400);
                    return;
                }
            }else {
                //参数解密
                Map result = JsonUtils.parseObject(SecurityUtils.decodeAES256HexUpper(resultMap.get("result").toString(), SecurityUtils.decodeHexUpper(APPKEY)), Map.class);
                logger.info("{}解密后的返回内容:{}",vo.getMsisdn(),JsonUtils.parseString(result));
                List<Map> list = JsonUtils.parseList(result.get("SO_MEMBER_DEAL").toString(), Map.class);
                result.put("status",list.get(0).get("STATUS"));
                result.put("statusMsg",list.get(0).get("STATUSMSG"));
                if("00".equals(result.get("status"))){
                    vo.setRegisterCode(PbRegisterCode.SUCCESS);
                    vo.setStatus("1");
                    pbRegisterDao.updateResult(vo);
                    flag=true;
                    smsMap.put("1",vo.getMsisdn());
                    //TODO PB实名登记信息同步省侧成功，推送给接入渠道
                    pushPBRegisterResult(vo,"00000");
                }else {
                    vo.setRegisterCode(result.getOrDefault("status","99999").toString());
                    vo.setStatus("3");
                    pbRegisterDao.updateResult(vo);
                    flag=false;
                    smsMap.put("1",vo.getMsisdn());
                    smsMap.put("2",result.getOrDefault("statusMsg","未知错误").toString());
                    //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                    pushPBRegisterResult(vo,"001");
                }
            }
            realNameAuthService.sendMessage(vo.getPhone(),smsMap,flag);
        }catch (Exception e){
            logger.info("{}...pb物联卡:{}实名登记-同步信息报错...{}",vo.getOrderNum(),vo.getMsisdn(),e);
        }finally {
            cache.remove(CacheManager.PublicNameSpace.TEMP,"realname_"+vo.getMsisdn());
        }
    }

    /**
     * 北京pb处理
     */
    private void pbRealName100(PbRegisterVo vo,String index){
        try {
            Map p=new HashMap();
            p.put("TYPE","1");
            p.put("IDCARD",vo.getIdCard());
            p.put("NAME",vo.getName());
            p.put("ADDRESS",vo.getAddress());
            p.put("NATION",vo.getNation());
            p.put("SEX",vo.getSex());
            p.put("BIRTHDAY",vo.getBirthday());
            p.put("STARTDATE",vo.getStartDate());
            p.put("ENDDATE",vo.getEndDate());
            p.put("INFO",vo.getInfo());
            p.put("MSISDN",vo.getMsisdn());
            p.put("PICV1",vo.getPicV1());
            p.put("PICV2",vo.getPicV2());
            p.put("PICZ",vo.getPicZ());
            p.put("PICF",vo.getPicF());
            p.put("NAMEV1",vo.getNameV1());
            p.put("NAMEV2",vo.getNameV2());
            p.put("NAMEZ",vo.getNameZ());
            p.put("NAMEF",vo.getNameF());
            p.put("ORDERNUM",vo.getOrderNum());
            boolean flag=false;
            Map request=new HashMap();
            request.put("BUSICODE","OPF_SO_GROU_WLW_SYNREALNAME_001");
            request.put("BUSIPARAMS",p);
            Map PUBINFO=new HashMap();
            PUBINFO.put("OPCODE","27010385");
            PUBINFO.put("OPORGID","14");
            PUBINFO.put("TRANSACTIONTIME",bjPbRegisterService.getTime());
            PUBINFO.put("INTERFACEID","100000000001");
            PUBINFO.put("CHNLTYPE","1");
            Map AICRMSERVICE=new HashMap();
            AICRMSERVICE.put("PUBINFO",PUBINFO);
            AICRMSERVICE.put("REQUEST",request);
            Map Req=new HashMap();
            Req.put("AICRMSERVICE",AICRMSERVICE);
//            logger.info("pb100信息同步参数转换前检查：{}",JsonUtils.parseString(Req));
            String params = XmlUtil.map2XmlString(Req).toString();
//            logger.info("pb100信息同步xml检查：{}",params);
            if(params.contains("<PICV1></PICV1>")||params.contains("<PICV2></PICV2>")||
                    params.contains("<PICZ></PICZ>")||params.contains("<PICF></PICF>")){
                logger.info("pb100图片丢失，msisdn：{}",vo.getMsisdn());
                return;
            }
            //从缓存获取参数
            String url=cache.getSysParams("100.url","");
            String openId=cache.getSysParams("100.openId","");
            String appId=cache.getSysParams("100.appId","");
            String privateKey=cache.getSysParams("100.privateKey","");
            String publicKey=cache.getSysParams("100.publicKey","");
            Map<String,Object> smsMap=new HashMap<>();
            //业务参数加密
            String busiparam = bjPbRegisterService.encryptBusiXml(params,publicKey,privateKey);
            Map systemParam = bjPbRegisterService.createSysParam("OPF_SO_GROU_WLW_SYNREALNAME_001", busiparam,appId,openId,url,privateKey);
            url = bjPbRegisterService.createUrl(systemParam,url);
            if("0".equals(cache.getSysParams("PB_REGISTER_LOG_CONTROL",""))){
                logger.info("pb100信息同步调用前检查url：{},params:{}",url,busiparam);
            }
            String result = HttpUtil.bjPost(url,busiparam);
            logger.info("pbRealName100能开返回结果...{}",result);
            //返回结果xml转map
            Map<String, Object> objectMap = XmlUtil.multilayerXmlToMap(result);
            Map descMap=(Map) objectMap.get("root");
            if("00000".equals(descMap.get("respCode"))){
                result = SecurityUtils.decodeAES256HexUpper(descMap.get("result").toString(), SecurityUtils.decodeHexUpper(privateKey));
                logger.info("pbRealName100解密后的结果...{}",result);
                Map<String, Object> resultMap = XmlUtil.multilayerXmlToMap(result);
                //获取结果
                Map response = (Map) resultMap.get("RESPONSE");
                Map retinfo = (Map) response.get("RETINFO");
                if("0".equals(retinfo.get("STATUS"))){
                    vo.setRegisterCode(PbRegisterCode.SUCCESS);
                    vo.setStatus("1");
                    pbRegisterDao.updateResult(vo);
                    flag=true;
                    smsMap.put("1",vo.getMsisdn());
                    //TODO PB实名登记信息同步省侧成功，推送给接入渠道
                    pushPBRegisterResult(vo,"00000");
                }else if("1".equals(retinfo.get("STATUS"))){
                    vo.setRegisterCode(PbRegisterCode.BJPB_FAIL);
                    vo.setStatus("3");
                    pbRegisterDao.updateResult(vo);
                    flag=false;
                    smsMap.put("1",vo.getMsisdn());
                    smsMap.put("2",retinfo.getOrDefault("STATUSMSG","未知错误").toString());
                    //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                    pushPBRegisterResult(vo,"001");
                }
            }else {
                //调在线公司失败的情况，尝试三次
                if(index!=null&&!"".equals(index)){
                    int num=Integer.valueOf(index);
                    if(num>3){
                        logger.info("sync province100 fail time>3...msisdn:{}",vo.getMsisdn());
                        vo.setRegisterCode(PbRegisterCode.SYNCFAIL);
                        vo.setStatus("3");
                        pbRegisterDao.updateResult(vo);
                        smsMap.put("1",vo.getMsisdn());
                        smsMap.put("2",PbRegisterCode.getResult(PbRegisterCode.SYNCFAIL));
                        //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                        pushPBRegisterResult(vo,"004");
                    }else {
                        num+=1;
                        cache.put(CacheManager.PublicNameSpace.TEMP,vo.getOrderNum(),num+"",86400);
                        return;
                    }
                }else {
                    cache.put(CacheManager.PublicNameSpace.TEMP,vo.getOrderNum(),"1",86400);
                    return;
                }
            }
            realNameAuthService.sendMessage(vo.getPhone(),smsMap,flag);
        }catch (Exception e){
            logger.info("{}...pb物联卡:{}实名登记-同步信息报错...{}",vo.getOrderNum(),vo.getMsisdn(),e);
        }finally {
            cache.remove(CacheManager.PublicNameSpace.TEMP,"realname_"+vo.getMsisdn());
        }
    }

    /**
     * 江苏pb处理
     */
    private void pbRealName250(PbRegisterVo vo,String index){
            Map p=new HashMap();
            p.put("type","1");
            p.put("idCard",vo.getIdCard());
            p.put("name",Base64Util.getBase64EncodeString(vo.getName()));
            p.put("address",Base64Util.getBase64EncodeString(vo.getAddress()));
            p.put("nation",Base64Util.getBase64EncodeString(vo.getNation()));
            p.put("sex",vo.getSex());
            p.put("birthday",vo.getBirthday());
            p.put("startDate",vo.getStartDate());
            p.put("endDate",vo.getEndDate());
            p.put("info",Base64Util.getBase64EncodeString(vo.getInfo()));
            p.put("msisdn",vo.getMsisdn());
            p.put("picV1",vo.getPicV1());
            p.put("picV2",vo.getPicV2());
            p.put("picV3",vo.getPicV2());
            p.put("picZ",vo.getPicZ());
            p.put("picF",vo.getPicF());
            p.put("nameV1",vo.getNameV1());
            p.put("nameV2",vo.getNameV2());
            p.put("NameV3",vo.getNameV2());
            p.put("nameZ",vo.getNameZ());
            p.put("nameF",vo.getNameF());
            p.put("orderNum",vo.getOrderNum());
            String paramsXml = XmlUtil.map2XmlString(p).toString();
            String url = cache.getSysParams("PBREGISTER_JS_URL", "");
            String APP_ID="109000000461";
            String ACCESS_TOKEN="gvx2az1Y3HsXHKvP6p7c";
            String XML_HEADER="<?xml version=\"1.0\" encoding=\"GBK\" ?>";
            Map PUBINFO=new HashMap();
            PUBINFO.put("app_id",APP_ID);
            PUBINFO.put("access_token",ACCESS_TOKEN);
            PUBINFO.put("sign","");
            PUBINFO.put("verify_code","");
            PUBINFO.put("terminal_id","");
            PUBINFO.put("accept_seq","");
            PUBINFO.put("req_time",getTime());
            PUBINFO.put("req_seq",vo.getTransId());
            PUBINFO.put("req_type","01");
            PUBINFO.put("process_code","cc_wlw_userInput");
        PUBINFO.put("org_id","");
        PUBINFO.put("req_source","1");
        PUBINFO.put("oper_id","");
            PUBINFO.put("content",paramsXml);
            Map AICRMSERVICE=new HashMap();
            AICRMSERVICE.put("operation_in",PUBINFO);
            String params = XmlUtil.map2XmlString(AICRMSERVICE).toString();
            Map<String,Object> smsMap=new HashMap<>();
            boolean flag=false;
            try{
                params=XML_HEADER+params;
            if("0".equals(cache.getSysParams("PB_REGISTER_LOG_CONTROL",""))){
                logger.info("虚拟机250syncInfo请求参数检查url:{}params:{}",url,params);
            }
            String result = HttpUtil.sendPostJS(url,params);
            logger.info("虚拟机250syncInfo能开返回结果...{}",result);
            //返回结果xml转map
            Map<String, Object> objectMap = XmlUtil.multilayerXmlToMap(result);

                if(objectMap!=null&&objectMap.get("operation_out")!=null){
                    Map operationOut = JsonUtils.parseObject(objectMap.get("operation_out"), Map.class);
                    if(operationOut!=null&&operationOut.get("content")!=null){
                        Map reMap = JsonUtils.parseObject(operationOut.get("content"), Map.class);
                        if(StringUtils.isNotBlank(reMap.getOrDefault("status","").toString())&&
                                StringUtils.isNotBlank(reMap.getOrDefault("statusMsg","").toString())){
                            if("0".equals(reMap.get("status"))){
                                logger.info("250syncInfo success...{}",vo.getMsisdn());
                                vo.setRegisterCode(PbRegisterCode.SUCCESS);
                                vo.setStatus("1");
                                pbRegisterDao.updateResult(vo);
                                flag=true;
                                smsMap.put("1",vo.getMsisdn());
                                //TODO PB实名登记信息同步省侧成功，推送给接入渠道
                                pushPBRegisterResult(vo,"00000");
                            }else{
                                vo.setRegisterCode(PbRegisterCode.JSPB_FAIL);
                                vo.setStatus("3");
                                pbRegisterDao.updateResult(vo);
                                flag=false;
                                smsMap.put("1",vo.getMsisdn());
                                smsMap.put("2",reMap.getOrDefault("statusMsg","未知错误").toString());
                                //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                                pushPBRegisterResult(vo,"001");
                            }
                        }else {
                            vo.setRegisterCode(PbRegisterCode.RETURNEMPTY);
                            vo.setStatus("3");
                            pbRegisterDao.updateResult(vo);
                            flag=false;
                            smsMap.put("1",vo.getMsisdn());
                            smsMap.put("2",reMap.getOrDefault("statusMsg","省侧响应异常").toString());
                            //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                            pushPBRegisterResult(vo,"001");
                        }
                    }else {
                        logger.info("sync province250 fail time>3...msisdn:{}",vo.getMsisdn());
                        vo.setRegisterCode(PbRegisterCode.SYNCFAIL);
                        vo.setStatus("3");
                        pbRegisterDao.updateResult(vo);
                        smsMap.put("1",vo.getMsisdn());
                        smsMap.put("2",PbRegisterCode.getResult(PbRegisterCode.SYNCFAIL));
                        //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                        pushPBRegisterResult(vo,"004");
                    }
                }else {
                    logger.info("sync province250 fail time>3...msisdn:{}",vo.getMsisdn());
                    vo.setRegisterCode(PbRegisterCode.SYNCFAIL);
                    vo.setStatus("3");
                    pbRegisterDao.updateResult(vo);
                    smsMap.put("1",vo.getMsisdn());
                    smsMap.put("2",PbRegisterCode.getResult(PbRegisterCode.SYNCFAIL));
                    //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                    pushPBRegisterResult(vo,"004");
                }

            realNameAuthService.sendMessage(vo.getPhone(),smsMap,flag);
        }catch (Exception e){
            logger.info("{}...江苏pb物联卡:{}实名登记-同步信息报错",vo.getOrderNum(),vo.getMsisdn());
                vo.setRegisterCode(PbRegisterCode.SYNCFAIL);
                vo.setStatus("3");
                pbRegisterDao.updateResult(vo);
                smsMap.put("1",vo.getMsisdn());
                smsMap.put("2",PbRegisterCode.getResult(PbRegisterCode.SYNCFAIL));
                //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                pushPBRegisterResult(vo,"004");
        }finally {
            cache.remove(CacheManager.PublicNameSpace.TEMP,"realname_"+vo.getMsisdn());
        }
    }

    /**
     * 海南pb处理
     */
    private void pbRealName898(PbRegisterVo vo,String index){
        try {
            String appId = cache.getSysParams("HAINAN_APPID", "");
            String appKey = cache.getSysParams("HAINAN_APPKEY", "");
            String url = cache.getSysParams("HAINAN_URL", "");
            Map<String,Object> smsMap=new HashMap<>();
            boolean flag=false;
            Map param=new HashMap();
            param.put("type","0");
            param.put("msisdn",vo.getMsisdn());
            param.put("idCard",vo.getIdCard());
            param.put("name",vo.getName());
            param.put("address",vo.getAddress());
            param.put("nation",vo.getNation());
            param.put("sex",vo.getSex());
            param.put("birthday",vo.getBirthday());
            param.put("startDate",vo.getStartDate());
            param.put("endDate",vo.getEndDate());
            param.put("info",vo.getInfo());
            param.put("nameV1",vo.getNameV1());
            param.put("nameZ",vo.getNameZ());
            param.put("nameF",vo.getNameF());
            param.put("orderNum",vo.getOrderNum());
            param.put("picV1",vo.getPicV1());
            param.put("picZ",vo.getPicZ());
            param.put("picF",vo.getPicF());
            String json = JsonUtils.parseString(param);
            String flowId=getTime()+((Math.random()*9+1)*1000000);
            String method="HAIN_UNHT_modifyIotCustInfo";
            url = url+"?flowId=" + flowId + "&appId="
                    + appId + "&appKey=" + appKey + "&method=" + method;
            if(json.contains("\"picF\":\"\"")||json.contains("\"picZ\":\"\"")||json.contains("\"picV1\":\"\"")){
                logger.info("{}海南入参缺少图片{}",vo.getMsisdn(),json);
                return;
            }
            logger.info("海南卡信息同步接口参数检查...appId:{},appKey:{},url:{}",appId,appKey,url);
            String x = HttpUtil.sendPost(url,json);
            logger.info("海南pb卡信息同步接口返回参数检查...{}",x);
            if(x!=null&&!"".equals(x)){
                Map reMap = JsonUtils.parseObject(x, Map.class);
                Map result = JsonUtils.parseObject(reMap.get("result"), Map.class);
                List content = JsonUtils.parseObject(result.get("SVC_CONTENT"), List.class);
                Map resultParams = JsonUtils.parseObject(content.get(0), Map.class);
                if(resultParams.containsKey("Verify_result")&&resultParams.containsKey("Verify_resultMsg")){
                    if("0".equals(resultParams.get("Verify_result"))){
                        vo.setRegisterCode(PbRegisterCode.SUCCESS);
                        vo.setStatus("1");
                        pbRegisterDao.updateResult(vo);
                        flag=true;
                        smsMap.put("1",vo.getMsisdn());
                        //TODO PB实名登记信息同步省侧成功，推送给接入渠道
                        pushPBRegisterResult(vo,"00000");
                    }else {
                        vo.setRegisterCode(resultParams.getOrDefault("Verify_result","99999").toString());
                        vo.setStatus("3");
                        pbRegisterDao.updateResult(vo);
                        flag=false;
                        smsMap.put("1",vo.getMsisdn());
                        smsMap.put("2",resultParams.getOrDefault("Verify_resultMsg","未知错误").toString());
                        //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                        pushPBRegisterResult(vo,"001");
                    }
                }else{
                    logger.info("sync 898 province fail time>3...msisdn:{}",vo.getMsisdn());
                    vo.setRegisterCode(PbRegisterCode.SYNCFAIL);
                    vo.setStatus("3");
                    pbRegisterDao.updateResult(vo);
                    smsMap.put("1",vo.getMsisdn());
                    smsMap.put("2",PbRegisterCode.getResult(PbRegisterCode.SYNCFAIL));
                    //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                    pushPBRegisterResult(vo,"004");
                }
            }else {
                logger.info("sync 898 province fail time>3...msisdn:{}",vo.getMsisdn());
                vo.setRegisterCode(PbRegisterCode.SYNCFAIL);
                vo.setStatus("3");
                pbRegisterDao.updateResult(vo);
                smsMap.put("1",vo.getMsisdn());
                smsMap.put("2",PbRegisterCode.getResult(PbRegisterCode.SYNCFAIL));
                //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                pushPBRegisterResult(vo,"004");
            }
            realNameAuthService.sendMessage(vo.getPhone(),smsMap,flag);
        }catch (Exception e){
            logger.info("{}...pb物联卡:{}实名登记-同步信息报错...{}",vo.getOrderNum(),vo.getMsisdn(),e);
        }finally {
            cache.remove(CacheManager.PublicNameSpace.TEMP,"realname_"+vo.getMsisdn());
        }
    }

    /**
     * 生成时间戳
     */
    public static String getTime(){
        Date date=new Date(System.currentTimeMillis());
        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
        return sdf.format(date);
    }

    public void deleteFromRealName() {
        long t1=System.currentTimeMillis();
        String url=cache.getSysParams("REAL_NAME_FTP_LOCAL", "/data_realname/auth/data");
        try {
            File file = new File(url);
            File[] tempList = file.listFiles();
            for (File zipFile : tempList) {
                if ((!zipFile.getName().contains("WX_OA")&&zipFile.getName().contains("jpg")) || (zipFile.getName().startsWith("isFinished")&&zipFile.getName().contains("tar.gz"))) {
                    try {
                        zipFile.delete();
                    }catch (Exception e){
                        logger.info("删除文件报错...{}",zipFile.getName());
                    }
                }
            }
            logger.info("{}删除文件耗时...{}",tempList.length,System.currentTimeMillis()-t1);
        }catch (Exception e){
            logger.info("deleteFromRealName 报错...");
        }
    }


    /**
     * xiajunchen
     * 解压.tar包
     * @param destPath
     * @param tais
     * @throws Exception
     */

    private static void deTarFile(String destPath, TarArchiveInputStream tais) throws Exception {

        TarArchiveEntry tae = null;
        while ((tae = tais.getNextTarEntry()) != null) {

            String dir = destPath + File.separator + tae.getName();//tar档中文件
            File dirFile = new File(dir);
            BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(dirFile));

            int count;
            byte data[] = new byte[1024];
            while ((count = tais.read(data, 0, 1024)) != -1) {
                bos.write(data, 0, count);
            }

            bos.close();
        }

    }

    /**
     * 遍历目录下所有文件
     */
    private static List<File> getFileList(File file){
        List<File> list=new ArrayList<>();
        File[] fs = file.listFiles();
        for(File f:fs){
            if(f.isDirectory())getFileList(f);
            if(f.isFile())list.add(f);

        }
        return list;
    }


    /**
     * CT卡实名-活体认证结果查询
     */

    public void ctRealName(){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        List<CtRealNameVo> list = realNameRegisterDao.queryCtRealNameInfo();
        for (CtRealNameVo v : list) {
            if (v.getAuditStatus() == null||"1".equals(v.getAuditStatus())) {
                //发起活体认证结果查询
                String transNo=v.getTransNo();
                Map<String,String> params=new HashMap<>();
                //生成流水与时间戳
                //String ccmpSeq = CCMPUtil.getCcmpSeq(CCMPUtil.QUERYREALNAMERESULT, transNo);
                params.put("beId",v.getBeId());
                params.put("custId",v.getCustId());
                params.put("busiSeq",v.getBusiSeq());

                Map pMap=new HashMap();
                //平台校验id
                //pMap.put("appid", cache.getSysParams("CCMP_APPID", ""));
                //平台校验密码串
                //pMap.put("appsecret", cache.getSysParams("CCMP_APPSECRET", ""));
                //pMap.put(ParamConstants.CCMP_SEQ, ccmpSeq);
                //pMap.put(ParamConstants.CCMP_REQUEST_TIME, CCMPUtil.getTime());
                pMap.put("params",params);
                //String baseUrl = cache.getSysParams(ParamConstants.CCMP_URL, "");
                //String url = baseUrl + CCMPUtil.QUERYREALNAMERESULT_URL;
                try {
                    logger.info("准备请求ccmp queryLiveCollectResult,参数检查busiseq:{}",v.getBusiSeq());
                    //String ctresOut = client.post(transNo, url, pMap, client.CONTENT_TYPE_JSON);
                    String ctresOut = ctBusinessSerClient.queryLiveCollectResult(transNo,pMap);
                    logger.info("流水号:{}...ccmp返回结果...{}",v.getBusiSeq(),ctresOut);
                    ResponseVo response = CCMPUtil.ccmpResponse(ctresOut);
                    if(response!=null&&response.isSuccess()&&response.getData()!=null){
                        CCMPResult ccmpResult = JsonUtils.parseObject(response.getData(), CCMPResult.class);
                        List<CtRealNameVo> voList = JsonUtils.parseList(ccmpResult.getRows(), CtRealNameVo.class);
                        if(voList!=null&&voList.size()>0){
                            logger.info("请求活体认证结果...{}",JsonUtils.parseString(voList));
                            v.setAuditStatus(voList.get(0).getAuditStatus());
                            v.setAuditMessage(voList.get(0).getAuditMessage());
                            //ct完成采集埋点
                            try {
                                registerService.innerStatisService("threect");
                            }catch (Exception e){
                                logger.info("ct卡完成采集埋点报错...{}",e);
                            }
                            try {
                                if("2".equals(v.getAuditStatus())){
                                    //审核不通过，结束流程，发短信
                                    v.setRegisterCode(RegisterCode.REALNAME_FIRST_FAIL);
                                    commonSmsService.sendRegisterResult(v.getPhone(),v.getMsisdn(),v.getRegisterCode(),v.getAuditMessage(),transNo);
                                    //h5推送实名结果
//                                    pushCTRegisterResult(v,"88888");
                                    if("oneLinkApiPb".equals(v.getUserId())){
                                        //api推送实名结果
                                        CtRealNameVo vo=new CtRealNameVo();
                                        vo.setRegisterMsg(v.getAuditMessage());
                                        vo.setMsisdn(v.getMsisdn());
                                        vo.setPhone(v.getPhone());
                                        //获取实名时间
                                        SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                        Date now=new Date(System.currentTimeMillis());
                                        String time=sdf1.format(now);
                                        vo.setRegisterTime(time);
                                        vo.setBusiSeq(v.getBusiSeq());
                                        vo.setTransNo(v.getTransNo());
                                        pushApiRegisterResult(vo,RegisterCode.REALNAME_FIRST_FAIL);
                                    }
                                }
                                if ("4".equals(v.getAuditStatus())){
                                    //二次稽核不通过，结束流程，发短信
                                    v.setRegisterCode(RegisterCode.REALNAME_SECOND_FAIL);
                                    commonSmsService.sendRegisterResult(v.getPhone(),v.getMsisdn(),v.getRegisterCode(),v.getAuditMessage(),transNo);
                                    //h5推送实名结果
//                                    pushCTRegisterResult(v,"88888");
                                    if("oneLinkApiPb".equals(v.getUserId())){
                                        //api推送实名结果
                                        CtRealNameVo vo=new CtRealNameVo();
                                        vo.setRegisterMsg(v.getAuditMessage());
                                        vo.setMsisdn(v.getMsisdn());
                                        vo.setPhone(v.getPhone());
                                        //获取实名时间
                                        SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                        Date now=new Date(System.currentTimeMillis());
                                        String time=sdf1.format(now);
                                        vo.setRegisterTime(time);
                                        vo.setBusiSeq(v.getBusiSeq());
                                        vo.setTransNo(v.getTransNo());
                                        pushApiRegisterResult(vo,RegisterCode.REALNAME_SECOND_FAIL);
                                    }
                                }
                            }catch (Exception e){
                                logger.info("审核不通过，发送短信报错...{}",e);
                            }
                            //信息第二次入库
                            realNameRegisterDao.updateCtRealNameResult(v);
                        }
                    }
                } catch (Exception e) {
                    logger.info("ctRealName exception...{}",e);
                }
            }
        }
    }

    /**
     * CT卡实名-使用人实名信息变更
     */
    public void modifyCtRealNameInfo(){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        List<CtRealNameVo> list = realNameRegisterDao.queryModifyInfo();

        for (CtRealNameVo v : list) {
            //设置redis锁,防止同一张卡重复发起
            if(cache.containsKey(CacheManager.PublicNameSpace.TEMP, "realname_" + v.getMsisdn())){
                logger.info("使用人实名信息变更,卡号{}重复请求,跳过",v.getMsisdn());
                continue;
            }
            cache.put(CacheManager.PublicNameSpace.TEMP,"realname_"+v.getMsisdn(),"y",1200);
            logger.info("使用人实名信息变更,卡号{}继续请求",v.getMsisdn());
            //发起使用人信息变更请求
            String transNo=v.getTransNo();
            Map<String,String> params=new HashMap<>();
            //生成流水与时间戳
            //String ccmpSeq = CCMPUtil.getCcmpSeq(CCMPUtil.MODIFYREALNAMEINFO, transNo);
            params.put("beId",v.getBeId());
            params.put("custId",v.getCustId());
            params.put("msisdn",v.getMsisdn());
            params.put("realNameTransId",v.getBusiSeq());
            params.put("realNameScene","01");

            Map pMap=new HashMap();
            //平台校验id
            //pMap.put("appid", cache.getSysParams("CCMP_APPID", ""));
            //平台校验密码串
            //pMap.put("appsecret", cache.getSysParams("CCMP_APPSECRET", ""));
            //pMap.put(ParamConstants.CCMP_SEQ, ccmpSeq);
            //pMap.put(ParamConstants.CCMP_REQUEST_TIME, CCMPUtil.getTime());
            pMap.put("params", params);

            //String baseUrl = cache.getSysParams(ParamConstants.CCMP_URL, "");
            //String url = baseUrl + CCMPUtil.MODIFYREALNAMEINFO_URL;
            try {
                //已经发起过请求的订单号跳过
                int sameBusiseq = realNameRegisterDao.querySameBusiseq(v.getBusiSeq());
                if(sameBusiseq>0){
                    logger.info("卡号：{},订单号：{}重复请求，跳过",v.getMsisdn(),v.getBusiSeq());
                    continue;
                }
//                logger.info("准备请求ccmp modifySubsRealNameInfo,参数检查params:{}",JsonUtils.parseString(pMap));
                String ctresOut = ctBusinessSerClient.modifySubsRealNameInfo(transNo,pMap);
                //String ctresOut = client.post(transNo, url, pMap, client.CONTENT_TYPE_JSON);
                logger.info("流水号：{},modifySubsRealNameInfo...ccmp返回结果...{}",v.getBusiSeq(),ctresOut);
                ResponseVo response = CCMPUtil.ccmpResponse(ctresOut);
                if(response!=null){
                    String code="";
                    String reason="";
                    if(response.isSuccess()){
                        //获取cmiot订单号
                        if(response.getData()!=null){
                            CCMPResult ccmpResult = JsonUtils.parseObject(response.getData(), CCMPResult.class);
                            if(ccmpResult!=null&&ccmpResult.getRows()!=null){
                                List<Map> voList = JsonUtils.parseList(ccmpResult.getRows(), Map.class);
                                if(voList!=null&&voList.size()>0&&voList.get(0)!=null&&!"".equals(voList.get(0).get("jobId"))){
                                    v.setJobId(voList.get(0).getOrDefault("jobId","").toString());
                                }
                            }
                        }
                        logger.info("使用人实名信息变更请求成功,busiSeq:{},jobId:{}",v.getBusiSeq(),v.getJobId());
                        v.setRegisterCode(RegisterCode.REALNAME_SUCCESS);
                        //登记结果入库
                        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
                        logger.info("卡号{}使用人实名信息入库检查{}",v.getMsisdn(),JsonUtils.parseString(v));
                        realNameRegisterDao.updateCtRealNameResult(v);
                        code="0";
//                        if("0".equals(v.getIsActive())){
//                            //ct卡激活
//                            try {
//                                Map<String,String> activeMap=new HashMap<>();
//                                activeMap.put("msisdn",v.getMsisdn());
//                                activeMap.put("beId",v.getBeId());
//                                activeMap.put("custId",v.getCustId());
//                                //获取卡状态
//                                ResponseVo basicInfo = ctUserService.queryCardBasicInfo(activeMap);
//                                if(basicInfo.isSuccess()&&basicInfo.getData()!=null){
//                                    Map obj = JsonUtils.parseObject(basicInfo.getData(), Map.class);
//                                    logger.info("获取卡状态 success...msisdn:{},status:{}",v.getMsisdn(),JsonUtils.parseString(basicInfo));
//                                    activeMap.put("status",obj.getOrDefault("status","").toString());
//                                    activeMap.put("realname","1");
//                                }
//                                ResponseVo activateResp = ctUserService.activateCardFromCT(activeMap, transNo);
//                                logger.info("卡激活结果msisdn:{}...{}",v.getMsisdn(),JsonUtils.parseString(activateResp));
//                                if (activateResp.isSuccess()) {
//                                    //CT卡激活成功
//                                    code="040";
//                                } else if (activateResp.getCode().equals(ResponseCode.ERROR_NOTALLOW_REQUEST)) {
//                                    //CT卡激活失败，当前卡状态不支持激活
//                                    code="041";
//                                    reason=activateResp.getData().toString();
//                                } else {
//                                    //CT卡激活失败，系统错误
//                                    code="042";
//                                    reason=activateResp.getData().toString();;
//                                }
//
//                            }catch (Exception e){
//                                logger.info("ct卡激活报错{}...{}",v.getMsisdn(),e);
//                            }
//                        }
                        if(v.getPhone()!=null&&!"".equals(v.getPhone())){
                            //实名成功，发送短信
                            commonSmsService.sendRegisterResult(v.getPhone(),v.getMsisdn(),code,reason,transNo);
                        }
//                        dealH5Traffic(v.getMsgId(),2,transNo);

//                        //查询订单是否处理完成:1完成 0未完成
//                        Map orderReqMap=new HashMap();
//                        orderReqMap.put("beId",v.getBeId());
//                        orderReqMap.put("custId",v.getCustId());
//                        orderReqMap.put("orderId",v.getBusiSeq());
//                        String statusResult = ctBusinessSerClient.queryOrderStatus(v.getTransNo(), orderReqMap);
//                        logger.info("查询订单状态msisdn:{},status:{}",v.getMsisdn(),statusResult);
//                        if("1".equals(statusResult)){
//                            //实名状态变更成功，发送短信
//                            commonSmsService.sendRegisterResult(v.getPhone(),v.getMsisdn(),"00000","",transNo);
//                        }else {
//                            //存入表，定时任务执行
//                            orderReqMap.put("msisdn",v.getMsisdn());
//                            orderReqMap.put("phone",v.getPhone());
//                            orderReqMap.put("status","0");
//                            orderReqMap.put("transNo",v.getTransNo());
//                            realNameRegisterDao.insertRegisterStatusOrder(orderReqMap);
//                        }
                        
                        //api接口测试
//                        if("oneLinkApiPb".equals(v.getUserId())){
//                            //api推送实名结果
//                            CtRealNameVo vo=new CtRealNameVo();
//                            vo.setRegisterMsg("");
//                            vo.setMsisdn(v.getMsisdn());
//                            vo.setPhone(v.getPhone());
//                            //获取实名时间
//                            SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//                            Date now=new Date(System.currentTimeMillis());
//                            String time=sdf1.format(now);
//                            vo.setRegisterTime(time);
//                            vo.setBusiSeq(v.getBusiSeq());
//                            vo.setTransNo(v.getTransNo());
//                            vo.setName(Base64Util.getBase64EncodeString("夏骏辰"));
//                            vo.setIdCard(Base64Util.getBase64EncodeString("500107199205262012"));
//                            pushApiRegisterResult(vo,"00000");
//                        }else if("YWJ".equals(v.getChannelId())){
//                            pushCTRegisterResult(v,"99999");
//                        }
                        //h5推送实名结果
//                        pushCTRegisterResult(v,"00000");
                    }else {
                        CCMPResult ccmpResult = JsonUtils.parseObject(ctresOut, CCMPResult.class);
                        String desc=ccmpResult.getMsg()!=null?ccmpResult.getMsg():"";
                        //暂时解决多实例并发请求问题
                        if("-40".equals(response.getCode())||desc.contains("实名制工单已绑定")){
                            logger.info("ct实名使用人重复请求msisdn:{},busiseq:{}，跳过",v.getMsisdn(),v.getBusiSeq());
                            realNameRegisterDao.updateSameCode(v.getBusiSeq());
                            continue;
                        }
                        switch (response.getCode()){
                            case "-10":
                                v.setRegisterCode(RegisterCode.REALNAME_10);
                                code=v.getRegisterCode();
                                reason=RegisterCode.REALNAME_10_DESC;
                                break;
                            case "-20":
                                v.setRegisterCode(RegisterCode.REALNAME_20);
                                code=v.getRegisterCode();
                                reason=RegisterCode.REALNAME_20_DESC;
                                break;
                            case "-30":
                                v.setRegisterCode(RegisterCode.REALNAME_30);
                                code=v.getRegisterCode();
                                reason=RegisterCode.REALNAME_30_DESC;
                                break;
                            case "-40":
                                v.setRegisterCode(RegisterCode.REALNAME_40);
                                code=v.getRegisterCode();
                                reason=RegisterCode.REALNAME_40_DESC;
                                break;
                            case "-50":
                                v.setRegisterCode(RegisterCode.REALNAME_50);
                                code=v.getRegisterCode();
                                reason=RegisterCode.REALNAME_50_DESC;
                                break;
                            case "-60":
                                v.setRegisterCode(RegisterCode.REALNAME_60);
                                code=v.getRegisterCode();
                                reason=RegisterCode.REALNAME_60_DESC;
                                break;
                            case "-99":
                                if(desc.contains("一证五号")){
                                    v.setRegisterCode(RegisterCode.REALNAME_99_A);
                                    code=v.getRegisterCode();
                                    reason=RegisterCode.REALNAME_99_A_DESC;
                                }else if(desc.contains("权限关闭")){
                                    v.setRegisterCode(RegisterCode.REALNAME_99_B);
                                    code=v.getRegisterCode();
                                    reason=RegisterCode.REALNAME_99_B_DESC;
                                }else if(desc.contains("月末最后")){
                                    v.setRegisterCode(RegisterCode.REALNAME_99_C);
                                    code=v.getRegisterCode();
                                    reason=RegisterCode.REALNAME_99_C_DESC;
                                }else if(desc.contains("一证十号")){
                                    v.setRegisterCode(RegisterCode.REALNAME_99_D);
                                    code=v.getRegisterCode();
                                    reason=RegisterCode.REALNAME_99_D_DESC;
                                }else if(desc.contains("不良信息")){
                                    v.setRegisterCode(RegisterCode.REALNAME_99_E);
                                    code=v.getRegisterCode();
                                    reason=RegisterCode.REALNAME_99_E_DESC;
                                }
                                break;
                            case "-70":
                                v.setRegisterCode(RegisterCode.REALNAME_70);
                                code=v.getRegisterCode();
                                reason=RegisterCode.REALNAME_70_DESC;
                                break;
                            case "-5":
                                v.setRegisterCode(RegisterCode.REALNAME_5);
                                code=v.getRegisterCode();
                                reason=RegisterCode.REALNAME_5_DESC;
                                break;
                            default:
                                v.setRegisterCode(response.getCode()!=null?response.getCode():RegisterCode.REALNAME_UNKNOWN);
                                code=v.getRegisterCode();
                                reason=desc!=null?desc:"未知错误";
                                logger.info("使用人信息变更失败msisdn:{},code:{},reason:{}",v.getMsisdn(),code,reason);
                                break;
                        }
                        //登记结果入库
                        realNameRegisterDao.updateCtRealNameResult(v);
                        if(v.getPhone()!=null&&!"".equals(v.getPhone())){
                            commonSmsService.sendRegisterResult(v.getPhone(),v.getMsisdn(),code,reason,transNo);
                        }
                        dealH5Traffic(v.getMsgId(),3,transNo);
                        if("oneLinkApiPb".equals(v.getUserId())){
                            //api推送实名结果
                            CtRealNameVo vo=new CtRealNameVo();
                            vo.setRegisterMsg(reason);
                            vo.setMsisdn(v.getMsisdn());
                            vo.setPhone(v.getPhone());
                            //获取实名时间
                            SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                            Date now=new Date(System.currentTimeMillis());
                            String time=sdf1.format(now);
                            vo.setRegisterTime(time);
                            vo.setBusiSeq(v.getBusiSeq());
                            vo.setTransNo(v.getTransNo());
                            pushApiRegisterResult(vo,code);
                        }else {
                            //h5推送实名结果
                            pushCTRegisterResult(v,"99999");
                        }
                    }
                }
            } catch (Exception e) {
                logger.info("msisdn:{},modifyCtRealNameInfo exception...{}",v.getMsisdn(),e);
            }finally {
                cache.remove(CacheManager.PublicNameSpace.TEMP,"realname_"+v.getMsisdn());
            }
        }
    }

//    public void  dealRegiterH5Info(){
//        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
//        List<RegisterH5Info> list = realNameRegisterDao.queryNeedSendH5Info();
//        for (RegisterH5Info v :
//                list) {
//                try {
//                    String subsId=v.getSubsId();
//                    CtRealNameVo infoBySubsId = realNameRegisterDao.getInfoBySubsId(subsId);
//                    if(infoBySubsId==null){
//                        logger.info("没有匹配数据{}",JsonUtils.parseString(v));
//                        continue;
//                    }else {
//                        infoBySubsId.setIdCard(v.getIdNumber());
//                        infoBySubsId.setName(v.getName());
//                        logger.info("数据已匹配，准备推送{}",JsonUtils.parseString(infoBySubsId));
//                        if("oneLinkApiPb".equals(infoBySubsId.getUserId())){
//                            pushApiRegisterResult(infoBySubsId,"00000");
//                        }else {
//                            pushCTRegisterResult(infoBySubsId,infoBySubsId.getRegisterCode());
//                        }
//                        logger.info("已推送完成，修改数据库状态{}",JsonUtils.parseString(infoBySubsId));
//                        realNameRegisterDao.modifyH5Info(v);
//                    }
//                }catch (Exception e){
//                    logger.info("定时推送h5报错...{}",e);
//                }
//        }
//    }

    /**
     * 实名登记H5，流控回收处理
     * */
    public void dealH5Traffic(int msgId, int status, String transNo) {
        if (msgId != 0) {
            //存在消息流水号，消费调用次数
            Map<String, Integer> param = new HashMap<>(2);
            param.put("msgId", msgId);
            param.put("status", status); //2:有效调用 3:无效调用
            ResponseVo verifyStatusVo = authenticationServiceClient.changeVerifyStatus(param);
            if (verifyStatusVo.isSuccess()) {
                logger.info("transNo is:[{}],实名登记H5，限流状态更新成功,msgId is:[{}],status is:[{}]", transNo, msgId, (status == 2) ? "有效调用" : "无效调用");
            } else {
                logger.info("transNo is:[{}],实名登记H5，限流状态更新失败,msgId is:[{}],status is:[{}]", transNo, msgId, (status == 2) ? "有效调用" : "无效调用");
            }
        }
    }

    /**
     * 推送PB物联卡登记结果
     * */
    private void pushPBRegisterResult(PbRegisterVo pbRegisterVo,String status){
        if(!StringUtils.isEmpty(pbRegisterVo.getChannelId())){
            try {
                //具备渠道编码，确定是从H5渠道发起的认证
                Map<String,String> pushData = new HashMap<>();
                pushData.put("channelId",pbRegisterVo.getChannelId());
                pushData.put(CommonConstant.FIELD_MSISDN,pbRegisterVo.getMsisdn());
                pushData.put(CommonConstant.REAL_NAME_PUSH_NAME,pbRegisterVo.getName());
                pushData.put(CommonConstant.REAL_NAME_PUSH_CUSTCERTNO,pbRegisterVo.getIdCard());
                pushData.put(CommonConstant.REAL_NAME_PUSH_REGISTERCODE,status); //登记结果 0 或 00000 成功，其他 登记失败
                pushData.put(CommonConstant.PHONE,pbRegisterVo.getPhone());
                registerService.sendRegisterResult(pushData);
            }catch (Exception e){
                logger.info("推送PB物联卡登记结果报错:{}...{}",pbRegisterVo.getMsisdn(),e);
            }
        }
    }

    private void pushCTRegisterResult(CtRealNameVo ctRegisterVo,String status){
        if(!StringUtils.isEmpty(ctRegisterVo.getChannelId())){
            try {
                //具备渠道编码，确定是从H5渠道发起的认证
                Map<String,String> pushData = new HashMap<>();
                pushData.put("channelId",ctRegisterVo.getChannelId());
                pushData.put(CommonConstant.FIELD_MSISDN,ctRegisterVo.getMsisdn());
                pushData.put(CommonConstant.REAL_NAME_PUSH_NAME,StringUtils.isNotBlank(ctRegisterVo.getName())?ctRegisterVo.getName():"");
                pushData.put(CommonConstant.REAL_NAME_PUSH_CUSTCERTNO,StringUtils.isNotBlank(ctRegisterVo.getIdCard())?ctRegisterVo.getIdCard():"");
                pushData.put(CommonConstant.REAL_NAME_PUSH_REGISTERCODE,status); //登记结果 0 或 00000 成功，其他 登记失败
                pushData.put(CommonConstant.PHONE,ctRegisterVo.getPhone());
                logger.info("ct实名登记h5推送结果msisdn:{}",ctRegisterVo.getMsisdn());
                registerService.sendRegisterResult(pushData);
            }catch (Exception e){
                logger.info("推送CT物联卡登记结果报错:{}...{}",ctRegisterVo.getMsisdn(),e);
            }
        }
    }

    private void pushApiRegisterResult(CtRealNameVo ctRegisterVo,String status){
        Map map=new HashMap();
        map.put("registerCode",status);
        map.put("registerMsg",ctRegisterVo.getRegisterMsg());
        map.put("msisdn",ctRegisterVo.getMsisdn());
        map.put("name",ctRegisterVo.getName());
        map.put("custCertNo",ctRegisterVo.getIdCard());
        map.put("phone",ctRegisterVo.getPhone());
        map.put("registerTime",ctRegisterVo.getRegisterTime());
        map.put("busiSeq",ctRegisterVo.getBusiSeq());
        String transNo=ctRegisterVo.getTransNo();
        if(transNo==null||"".equals(transNo)||transNo.contains("know")){
            transNo= UUID.randomUUID().toString().replace("-","");
        }
        logger.info("{},pushApiRegisterResult回传前检查",ctRegisterVo.getMsisdn());
        CTResponse response = ctRequestFactory.pushRegisterApi(map, transNo);
        logger.info("{},pushApiRegisterResult结果:{}",ctRegisterVo.getMsisdn(),JsonUtils.parseString(response));
    }


    /**
     * 等比例压缩算法：
     * 算法思想：根据压缩基数和压缩比来压缩原图，生产一张图片效果最接近原图的缩略图
     * @param srcURL 原图地址
     * @param deskURL 缩略图地址
     * @param comBase 压缩基数
     * @param scale 压缩限制(宽/高)比例  一般用1：
     * 当scale>=1,缩略图height=comBase,width按原图宽高比例;若scale<1,缩略图width=comBase,height按原图宽高比例
     * @throws Exception
     * @author xiajunchen
     * @createTime 2021-07-05
     */
    public static String saveMinPhoto(String srcURL, String deskURL, double comBase,
                                    double scale){
        try {
            File srcFile = new java.io.File(srcURL);
            Image src = ImageIO.read(srcFile);
            int srcHeight = src.getHeight(null);
            int srcWidth = src.getWidth(null);
            int deskHeight = 0;// 缩略图高
            int deskWidth = 0;// 缩略图宽
            double srcScale = (double) srcHeight / srcWidth;
            /**缩略图宽高算法*/
            if ((double) srcHeight > comBase || (double) srcWidth > comBase) {
                if (srcScale >= scale || 1 / srcScale > scale) {
                    if (srcScale >= scale) {
                        deskHeight = (int) comBase;
                        deskWidth = srcWidth * deskHeight / srcHeight;
                    } else {
                        deskWidth = (int) comBase;
                        deskHeight = srcHeight * deskWidth / srcWidth;
                    }
                } else {
                    if ((double) srcHeight > comBase) {
                        deskHeight = (int) comBase;
                        deskWidth = srcWidth * deskHeight / srcHeight;
                    } else {
                        deskWidth = (int) comBase;
                        deskHeight = srcHeight * deskWidth / srcWidth;
                    }
                }
            } else {
                deskHeight = srcHeight;
                deskWidth = srcWidth;
            }
            BufferedImage tag = new BufferedImage(deskWidth, deskHeight, BufferedImage.TYPE_3BYTE_BGR);
            tag.getGraphics().drawImage(src, 0, 0, deskWidth, deskHeight, null); //绘制缩小后的图
            String formatName = deskURL.substring(deskURL.lastIndexOf(".") + 1);
            ImageIO.write(tag,formatName, new File(deskURL));
            return deskURL;
        }catch (Exception e){
            logger.info("江苏pb图片压缩失败:{}",srcURL);
            return srcURL;
        }
    }

//    public static void main(String[] args){
//        saveMinPhoto("C:\\Users\\Lenovo\\Desktop\\isFinishedBOSS230_WX_OA20201127094621000320_R_V2.jpg","C:\\Users\\Lenovo\\Desktop\\现网日志\\qq1.jpg",1200,1);
//    }

}