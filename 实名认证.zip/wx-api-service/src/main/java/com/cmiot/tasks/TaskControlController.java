package com.cmiot.tasks;

import com.cmiot.commons.response.ResponseVo;
import com.cmiot.commons.rest.RestBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("taskControl")
public class TaskControlController extends RestBase {
    static Logger logger = LoggerFactory.getLogger(TaskControlController.class);

    @Autowired
    PersonTaskService taskService;

    @RequestMapping("autoUnBind")
    public ResponseVo autoUnBind(){
        taskService.autoUnBind();
        return new ResponseVo();
    }
}
