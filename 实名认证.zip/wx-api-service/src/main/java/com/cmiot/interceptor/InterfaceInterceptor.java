package com.cmiot.interceptor;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.log.ILog;
import com.cmiot.kafka.sender.portal2bigdata.Portal2BigDataProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

/**
 * 接口调用监控
 * xiajunchen 2021/03/10
 */
@Component
public class InterfaceInterceptor extends KafkaConfig implements HandlerInterceptor {

    private static Logger logger = LoggerFactory.getLogger(InterfaceInterceptor.class);

    @Autowired
    ILog iLog;

    @Autowired
    Portal2BigDataProducer portal2BigDataProducer;




    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o) throws Exception {
        String uri = httpServletRequest.getRequestURI();
        String transNo=httpServletRequest.getHeader("transNo");
        try{
            JSONObject map = JSON.parseObject(new BodyReaderHttpServletRequestWrapper(httpServletRequest).getBody());
            MonitorWxVo vo = new MonitorWxVo(serviceName);
            vo.setTransNo(transNo);
            vo.setSuccess(true);
            vo.setData(JsonUtils.parseString(map));
            vo.setContent(uri);
            logger.info("preHandle卡号接口监控准备send kafka,transNo:{},uri:{},data:{}",transNo,uri,JsonUtils.parseString(map));
            sendKafka(transNo,"TOPIC_MB_ALL",JsonUtils.parseString(vo));
        }catch (Exception e){
            logger.info("preHandle卡号接口监控报错,transNo:{}...{}",transNo,e);
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {
        String uri = httpServletRequest.getRequestURI();
        String transNo=httpServletRequest.getHeader("transNo");
        try{
            Map object = JsonUtils.parseObject(httpServletRequest.getSession().getAttribute("body"), Map.class);
//            logger.info("transNo:{},uri:{},卡号拦截器postHandle获取返回参数:{}",transNo,uri,JsonUtils.parseString(object));
            Map requestMap=new HashMap();
            if("0".equals(object.get("code"))){
                requestMap.put("responseCode","0");
                requestMap.put("responseMsg","成功");
            }else {
                Map data = JsonUtils.parseObject(object.get("data"), Map.class);
                requestMap.put("responseCode",data.get("respCode"));
                requestMap.put("responseMsg",data.get("respDesc"));
            }
            MonitorWxVo vo = new MonitorWxVo(serviceName);
            vo.setTransNo(transNo);
            vo.setSuccess(true);
            vo.setData(JsonUtils.parseString(requestMap));
            vo.setContent(uri);
//            logger.info("postHandle卡号接口监控准备send kafka,transNo:{},uri:{},data:{}",transNo,uri,JsonUtils.parseString(object));
            sendKafka(transNo,"TOPIC_MB_ALL",JsonUtils.parseString(vo));
        }catch (Exception e){
            logger.info("postHandle卡号接口监控报错,transNo:{}...{}",transNo,e);
        }
    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {

    }
}
