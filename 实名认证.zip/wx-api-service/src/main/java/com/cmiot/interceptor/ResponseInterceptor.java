package com.cmiot.interceptor;

import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@ControllerAdvice
public class ResponseInterceptor implements ResponseBodyAdvice {

    private static final String LOGIN_URI = "/personUser/checkMsisdnIccid";

    @Override
    public boolean supports(MethodParameter returnType, Class converterType) {
        return true;
    }

    @Override
    public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType, Class selectedConverterType, ServerHttpRequest request, ServerHttpResponse response) {

        String requestPath = request.getURI().getPath();

        //获取指定访问接口的返回值
        if(requestPath.equals(LOGIN_URI)){
            //通过RequestContextHolder获取request
            HttpServletRequest httpServletRequest =
                    ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();

            HttpSession httpSession = httpServletRequest.getSession(true);
            httpSession.setAttribute("body", body);

            return body;
        }
        return body;
    }
}