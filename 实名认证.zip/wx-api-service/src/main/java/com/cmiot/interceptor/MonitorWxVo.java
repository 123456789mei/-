package com.cmiot.interceptor;

public class MonitorWxVo {
    //服务名
    private String serviceName;
    //流水号
    private String transNo;
    //上报实体
    private Object data;
    //耗时
    private long time;
    //是否成功的处理(异常时为false)
    private boolean isSuccess = true;
    //被监控的内容
    private String content;
    //异常信息(类型原因只能转为String,根据业务自行转换为具体对象)
    private String err;

    public MonitorWxVo() {
    }

    public MonitorWxVo(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getTransNo() {
        return transNo;
    }

    public void setTransNo(String transNo) {
        this.transNo = transNo;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public boolean isSuccess() {
        return isSuccess;
    }

    public void setSuccess(boolean success) {
        isSuccess = success;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getErr() {
        return err;
    }

    public void setErr(String err) {
        this.err = err;
    }
}
