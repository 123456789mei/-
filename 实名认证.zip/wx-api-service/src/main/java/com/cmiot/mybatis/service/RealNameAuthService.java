package com.cmiot.mybatis.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cmiot.api.service.AuthenticationServiceClient;
import com.cmiot.api.service.SysClient;
import com.cmiot.api.service.UserService;
import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.cache.impl.CacheManager;
import com.cmiot.commons.common.constants.ParamConstants;
import com.cmiot.commons.common.utils.HttpRequestClient;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.common.utils.UUID4Long;
import com.cmiot.commons.log.ILog;
import com.cmiot.commons.response.ResponseCode;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.commons.vo.MsisdnCacheVo;
import com.cmiot.ms.dal.common.orcl.NormalBaseService;
import com.cmiot.mybatis.dao.*;
import com.cmiot.mybatis.vo.*;
import com.cmiot.util.HttpUtil;
import com.cmiot.util.PbRegisterCode;
import com.cmiot.wx.apiservice.config.AddrConfig;
import com.cmiot.wx.apiservice.constant.RealNameConstant;
import com.cmiot.wx.apiservice.utiles.*;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;

import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class RealNameAuthService extends NormalBaseService {

    private static final Logger logger = LoggerFactory.getLogger(RealNameAuthService.class);
    private static boolean allowPull = false;

    @Autowired
    ILog iLog;

    @Autowired
    ICache cache;

    @Autowired
    RealNameAuthKeyDao realNameAuthKeyDao;

    @Autowired
    RealNameAuditResultDao realNameAuditResultDao;

    @Autowired
    CustInfoDao custInfoDao;

    @Autowired
    WxPersonUserInfoDao wxPersonUserInfoDao;

    @Autowired
    HttpRequestClient httpClient;

    @Autowired
    ThreadPoolTaskExecutor pushExecutor;

    @Autowired
    AddrConfig addrConfig;

    @Autowired
    HttpUtils httpUtils;

    @Autowired
    PbRegisterDao pbRegisterDao;

    @Autowired
    SysClient sysClient;

    @Autowired
    UserService userService;

    @Autowired
    AuthenticationServiceClient authenticationServiceClient;

    @Autowired
    RealNameRegisterService registerService;

    @Autowired
    RealNameAuthService realNameAuthService;



    /**
     * @param requestMap
     * @param transNo
     * @return the url of real name auth from online company
     *
     * 发起活体认证
     */
    public ResponseVo getRealNameAuthURL(Map<String, String> requestMap, String transNo) {
        String phone = requestMap.get("phone");
        String channelId = StringUtils.isEmpty(requestMap.get("channelId")) ? RealNameAuthConstant.WX_OFFICIAL_ACCOUNT : requestMap.get("channelId");
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        boolean withinAuthLimit = withinAuthLimit(phone);
        // 认证次数 小于6
        if (withinAuthLimit) {
            Map<String, String> desKeyInfo = getDesKeyFromLocal(transNo);
            if (desKeyInfo != null) {
                String signatureKey = getSignatureKeyFromLocal(transNo);
                boolean allowModify = Boolean.valueOf(cache.getSysParams(RealNameAuthConstant.ALLOW_MODIFY_SIGNATUREKEY, "false"));
                if (signatureKey == null || allowModify) {
                    allowPull = true;
                    signatureKey = pullSignatureKey(transNo);
                }
                if (signatureKey != null) {
                    //组装业务流水 和transactionID
                    Date nowDate = new Date();
                    String dateSeq = DateFormatUtils.format(nowDate, RealNameAuthConstant.BUSISEQ_DATE_FORMAT) + BusiNumGenerator.generateBusiNum();
                    String busiSeq = channelId + dateSeq;
                    String transactionID = RealNameAuthConstant.CMIOT_CODE + dateSeq;
                    Map<String, Object> params = new HashMap<>(6);

                    params.put("busiSeq", busiSeq);
                    params.put("billId", phone);
                    params.put("requestType", RealNameAuthConstant.MP_REQUEST_TYPE);
                    params.put("busiCategory", RealNameAuthConstant.REQUEST_BUSI_CATEGORY);
                    params.put("checkType", RealNameAuthConstant.CHECK_TYPE);
                    params.put("provCode", RealNameAuthConstant.REAL_NAME_PROVCODE);

                    String signature = new StringBuilder(RealNameAuthConstant.REQUEST_BUSI_CATEGORY).append(RealNameAuthConstant.CMIOT_CODE)
                            .append(transactionID).append(busiSeq).append(phone).append(RealNameAuthConstant.REAL_NAME_PROVCODE)
                            .append("|").append(DateFormatUtils.format(nowDate, RealNameAuthConstant.SIGNATURE_TIMESTAMP_FORMAT))
                            .toString();

                    try {
                        String encryptParams = new RealNameMsDesPlus(desKeyInfo.get(RealNameAuthConstant.DESKEY))
                                .encrypt(JSON.toJSONString(params));
                        logger.info("transNo is:[{}],生成请求加密参数,加密秘钥：[{}],参数：[{}]", transNo, signatureKey, signature);
                        String encryptSignature = URLEncoder.encode(new Rsa.Encoder(signatureKey).encode(signature));
                        logger.info("transNo is:[{}],参数加密完成，加密结果：[{}]", transNo, encryptSignature);
                        //缓存流水号与加密参数的关系
                        cache.put(CacheManager.PublicNameSpace.TEMP, transactionID, desKeyInfo.get(RealNameAuthConstant.DESKEY_ID), RealNameAuthConstant.TID_DESKEYID_BIND_EXPIRE);
                        String realNameH5 = cache.getSysParams(RealNameAuthConstant.RESERVATION_CERTIFICATION_H5, ""); //活体认证网页地址
                        //保留transactionID和接入渠道  匹配auditresult的channel
                        Map<String, Object> reqInfo = new HashMap<>(5);
                        String openChannels = cache.getSysParams("REAL_NAME_OPEN_CHANNEL", "OneNET,oneLinkAPI");
                        if (openChannels.contains(channelId)) {
                            //预留其他渠道的存储数据,活体能力开放渠道处理
                            MsgOlAuditResultOpen auditResultOpen = new MsgOlAuditResultOpen();
                            auditResultOpen.setTransactionID(transactionID);
                            auditResultOpen.setBusiSeq(busiSeq);
                            auditResultOpen.setChannelId(channelId);
                            auditResultOpen.setRequestTime(nowDate);
                            auditResultOpen.setPhone(phone);
                            auditResultOpen.setUserId(requestMap.get("userId"));
                            auditResultOpen.setCallBackUrl(requestMap.get("callBackUrl"));
                            if (requestMap.get(CommonConstant.REAL_NAME_BACK_URL) != null && !StringUtils.isEmpty(String.valueOf(requestMap.get(CommonConstant.REAL_NAME_BACK_URL)))) {
                                //添加非必须参数，web跳转地址
                                auditResultOpen.setReturnPage(requestMap.get(CommonConstant.REAL_NAME_BACK_URL));
                            }
                            realNameAuditResultDao.saveRealNameRequestForOpen(auditResultOpen);
                            //开放渠道的返回结果
                            String authUrl = new StringBuilder(realNameH5).append("?requestSource=").append(RealNameAuthConstant.CMIOT_CODE)
                                    .append("&transactionID=").append(transactionID).append("&param=").append(encryptParams)
                                    .append("&signature=").append(encryptSignature).toString();
                            Map<String, String> data = new HashMap<>();
                            data.put("busiSeq", busiSeq);
                            data.put("authUrl", authUrl);
                            return ResponseVo.success(data);
                        } else if ("WX_OA".equals(channelId) || "WX_MP".equals(channelId) || "OneLink_APP".equals(channelId)) {
                            reqInfo.put("transactionID", transactionID);
                            reqInfo.put("phone", phone);
                            reqInfo.put("channelId", channelId);
                            reqInfo.put("busiSeq", busiSeq);
                            reqInfo.put("requestTime", nowDate);
                            realNameAuditResultDao.saveRealNameRequestInfo(reqInfo);
                            if (requestMap.get("idcard") != null && !"".equals(requestMap.get("idcard"))) {
                                //2020-8-19 安徽pb物联卡认证信息入库
                                requestWithPb(requestMap, busiSeq, transactionID, transNo);
                            }
                            return ResponseVo.success(new StringBuilder(realNameH5).append("?requestSource=").append(RealNameAuthConstant.CMIOT_CODE)
                                    .append("&transactionID=").append(transactionID).append("&param=").append(encryptParams)
                                    .append("&signature=").append(encryptSignature).toString());
                        } else {
                            logger.error("transNo is:[{}],请求实名认证能力，渠道码错误，channelId is:[{}]", transNo, channelId);
                            return ResponseVo.fail(ResponseCode.ERROR_SYS, new String[]{"错误的接入渠道号"});
                        }
                    } catch (RuntimeException e) {//cache 或入库失败
                        iLog.error(logger, transNo, null, "wx get real name auth URL fail, fail to save transactionID", e);
                        ResponseVo responseVo = ResponseVo.fail(ResponseCode.ERROR_SYS, new String[]{"实名认证系统繁忙，请稍后"});
                        responseVo.setData("实名认证系统繁忙，请稍后");
                        return responseVo;
                    } catch (Exception e) {//加密失败
                        iLog.error(logger, transNo, null, "wx get real name auth URL fail, fail to encrypt param or signature", e);
                        ResponseVo responseVo = ResponseVo.fail(ResponseCode.ERROR_SYS, new String[]{"实名认证系统繁忙，请稍后"});
                        responseVo.setData("实名认证系统繁忙，请稍后");
                        return responseVo;
                    }
                } else {//signatureKey 获取失败
                    iLog.error(logger, transNo, null, "wx get real name auth URL fail, fail to pull signatureKey");
                    ResponseVo responseVo = ResponseVo.fail(ResponseCode.ERROR_SYS, new String[]{"实名认证系统繁忙，请稍后"});
                    responseVo.setData("实名认证系统繁忙，请稍后");
                    return responseVo;
                }
            } else {//deskey获取失败
                iLog.error(logger, transNo, null, "wx get real name auth URL fail, fail to get desKeyInfo");
                ResponseVo responseVo = ResponseVo.fail(ResponseCode.ERROR_SYS, new String[]{"实名认证系统繁忙，请稍后"});
                responseVo.setData("实名认证系统繁忙，请稍后");
                return responseVo;
            }
        } else { //认证次数大于5
            iLog.error(logger, transNo, null, "wx get real name auth URL fail,[{}] auth times excess the limit", phone);
            ResponseVo responseVo = ResponseVo.fail(ResponseCode.ERROR_SYS, new String[]{"当日实名认证次数超过限制，请明日再试"});
            responseVo.setData("当日实名认证次数超过限制，请明日再试");
            return responseVo;
        }
    }

    private boolean withinAuthLimit(String phone) {
        int authTimes = Integer.valueOf(cache.get(CacheManager.PublicNameSpace.TEMP, RealNameAuthConstant.REAL_NAME_DAILY_LIMIT + phone, "0"));
        int authLimit = Integer.valueOf(userService.getRealNameAuthDailyLimit(new HashMap()));   //SA_DB_SYSPARAM
        if (authTimes == 0) {
            int leftTimeInSecond = (int) (86400 - DateUtils.getFragmentInSeconds(Calendar.getInstance(), Calendar.DATE));
            cache.put(CacheManager.PublicNameSpace.TEMP, RealNameAuthConstant.REAL_NAME_DAILY_LIMIT + phone, "0", leftTimeInSecond);
        } else if (authTimes >= authLimit) {
            return false;
        }
        return true;
    }

    /**
     * PB物联卡登记，活体请求处理程序
     * */
    private void requestWithPb(Map<String, String> requestMap, String busiSeq,String transactionID,String transNo){
        logger.info("{}pb物联卡登记请求参数校验：{}",requestMap.get("msisdn"),JsonUtils.parseString(requestMap));
        PbRegisterVo pbRegisterVo=new PbRegisterVo();
        pbRegisterVo.setBeid(requestMap.get("beid"));
        pbRegisterVo.setIccid(requestMap.get("iccid"));
        pbRegisterVo.setMsisdn(requestMap.get("msisdn"));
        pbRegisterVo.setIdCard(requestMap.get("idcard"));
        pbRegisterVo.setOrderNum(busiSeq);
        pbRegisterVo.setPhone(requestMap.get("phone"));
        pbRegisterVo.setUserId(requestMap.get("userId"));
        pbRegisterVo.setTransId(transactionID);
        pbRegisterVo.setOrderNo(requestMap.get("orderno"));
        if(requestMap.get("msgFrom") != null && !"".equals(requestMap.get("msgFrom"))){
            //通过H5发起认证
            pbRegisterVo.setMsgId(Integer.valueOf(requestMap.get("msgFrom")));
        }
        if(requestMap.get("channelFrom") != null && !"".equals(requestMap.get("channelFrom"))){
            //通过H5发起认证
            pbRegisterVo.setChannelId(requestMap.get("channelFrom"));
        }
        //根据卡号和省份获取地市id
        Map<String,Object> paramMap=new HashMap<>();
        paramMap.put("msisdn",requestMap.get("msisdn"));
        paramMap.put("beid",requestMap.get("beid"));
        ResponseVo responseVo = userService.queryRegionId(paramMap, transNo);
        logger.info("transNo is:[{}],卡号：{}...地市id:{}",transNo,pbRegisterVo.getMsisdn(),JsonUtils.parseString(responseVo));
        if("0".equals(responseVo.getCode())&&responseVo.getData()!=null){
            List<PbRegisterVo> pbRegisterVoList = JsonUtils.parseList(responseVo.getData(), PbRegisterVo.class);
            if(pbRegisterVoList!=null&&pbRegisterVoList.size()>0&&pbRegisterVoList.get(0)!=null){
                pbRegisterVo.setRegionId(pbRegisterVoList.get(0).getRegionId());
                pbRegisterVo.setRegionName(pbRegisterVoList.get(0).getRegionName());
                pbRegisterVo.setCustName(pbRegisterVoList.get(0).getCustName());
            }else pbRegisterVo.setRegionId("");
        }else {
            pbRegisterVo.setRegionId("");
        }
        //根据卡号获取custid
        MsisdnCacheVo cacheVo = cache.getByMsisdn(pbRegisterVo.getMsisdn());
        logger.info("transNo is:[{}],卡号：{},orderNo:{}",transNo,pbRegisterVo.getMsisdn(),pbRegisterVo.getOrderNo());
        pbRegisterVo.setCustId(cacheVo!=null?cacheVo.getCustId():"");
        pbRegisterDao.registerInfoInsert(pbRegisterVo);
    }

    /**
     * 接收返回结果
     * 活体认证结果处理
     */
    public String receiveAuditResult(Map<String, String> params, String transNo) {
//        logger.info("pb接收活体认证结果transNo:{},params:{}",transNo,JsonUtils.parseString(params));
        JSONObject returnJson = new JSONObject(2);
        String auditStatus = params.get(RealNameConstant.REAL_NAME_RESULT_AUDIT_STATUS);
        String transactionID = params.get(RealNameConstant.REAL_NAME_RESULT_TRANSACTION_ID);
        String busiSeq = params.get(RealNameConstant.REAL_NAME_RESULT_BUSISEQ);
        String phone = params.get(RealNameConstant.REAL_NAME_RESULT_PHONE);
        String callBackUrl = cache.getSysParams(RealNameConstant.SYS_PARAM_WX_BASE_URL, "");
        String openChannels = cache.getSysParams(RealNameConstant.SYS_PARAM_REAL_NAME_OPEN_CHANNEL, "OneNET,oneLinkAPI");
        Date nowDate = new Date();
        if (busiSeq.startsWith(RealNameConstant.REAL_NAME_CHANNEL_WX_OA)) {
            //公众号个人业务
            callBackUrl += "/service/wx/person/getRealNameAuthResult" + "?busiSeq=" + busiSeq;
        } else if (busiSeq.startsWith(RealNameConstant.REAL_NAME_CHANNEL_ONE_LINK_APP) || busiSeq.startsWith(RealNameConstant.REAL_NAME_CHANNEL_WX_MP)) {
            //个人业务 APP&小程序
            callBackUrl += "/app/person/returnUrl/ReturnRealNameInfo" + "?busiSeq=" + busiSeq;
        } else if (PublicFunc.checkChannels(openChannels, busiSeq)) {
//            logger.info("openApi access,transNo is:[{}],实名认证结果回调,msg is:[{}]", transNo, JsonUtils.parseString(params));
            returnJson = dealAuitResult(params, transNo);
            return returnJson.toJSONString();
        } else {
            logger.error("transNo is:[{}],错误的渠道ID：[{}]",transNo,busiSeq);
            returnJson.put("returnCode", RealNameAuthConstant.EXCEPTION_RETURN_CODE);
            returnJson.put("returnMessage", "渠道ID错误");
            return returnJson.toJSONString();
        }

        logger.info("transNo is:[{}],实名认证回调地址：[{}]",transNo,callBackUrl);
        returnJson.put(RealNameConstant.BACK_REAL_SYS_CALLBACK_URL, callBackUrl);
        //缓存本日的验证次数  过期时间为明日凌晨 -2不更改缓存时间
        cache.incr(CacheManager.PublicNameSpace.TEMP, RealNameAuthConstant.REAL_NAME_DAILY_LIMIT + phone, -2);

        MsgOlAuditResult auditResult = new MsgOlAuditResult();
        auditResult.setTransactionID(transactionID);
        auditResult.setBusiSeq(busiSeq);
        auditResult.setPhone(phone);
        auditResult.setResponseTime(nowDate);
        auditResult.setAuditStatus(auditStatus);
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        List<PbRegisterVo> strList = pbRegisterDao.queryInfo(busiSeq);

        //TODO 回收实名登记H5调用次数
        if (strList != null && strList.size() > 0 && strList.get(0) != null && !"".equals(strList.get(0).getIdCard())) {
            PbRegisterVo registerVo = strList.get(0);
            if (registerVo.getMsgId() != 0) {
                //存在消息流水号，消费调用次数
                Map<String, Integer> param = new HashMap<>(2);
                param.put("msgId", registerVo.getMsgId());
                param.put("status", 2); //2:有效调用 3:无效调用
                ResponseVo verifyStatusVo = authenticationServiceClient.changeVerifyStatus(param);
                if (verifyStatusVo.isSuccess()) {
                    logger.info("transNo is:[{}],实名登记H5，限流状态更新成功,msgId is:[{}],status is:[{}]", transNo, registerVo.getMsgId(), "有效调用");
                } else {
                    logger.info("transNo is:[{}],实名登记H5，限流状态更新失败,msgId is:[{}],status is:[{}]", transNo, registerVo.getMsgId(), "有效调用");
                }
            }
        }

        if (auditStatus.equals(RealNameConstant.AUDIT_STATUS_SUCCESS)) {
            Map<String, String> desKeyInfo = getDesKeyFromLocal(transNo);
            if (desKeyInfo != null && desKeyInfo.size() == 2) {
                String keyId = cache.get(CacheManager.PublicNameSpace.TEMP, transactionID);
                if (StringUtils.isEmpty(keyId)) {
                    keyId = desKeyInfo.get(RealNameAuthConstant.DESKEY_ID);
                }
                try {
                    String infoStr = new RealNameMsDesPlus(desKeyInfo.get(RealNameAuthConstant.DESKEY)).decrypt(params.get(RealNameConstant.REAL_NAME_RESULT_INFORMATION));//解密  information
                    JSONObject info = JSON.parseObject(infoStr);
                    String custCertNo = info.getString("custCertNo");
                    auditResult.setPicNameZ(info.getString("picNameZ"));
                    auditResult.setPicNameF(info.getString("picNameF"));
                    auditResult.setPicNameT(info.getString("picNameT"));
                    auditResult.setPicNameV2(info.getString("picNameV2"));
                    auditResult.setReturnCode(RealNameAuthConstant.SUCCESS_RETURN_CODE);
                    auditResult.setKeyId(keyId);
                    auditResult.setReturnMessage("恭喜你，实名认证成功！");

                    SaPsCust custInfo = new SaPsCust();
                    custInfo.setBusiSeq(busiSeq);
                    custInfo.setModifyTime(nowDate);
                    custInfo.setCustName(info.getString("custName"));
                    custInfo.setCustCertNo(custCertNo);
                    custInfo.setCustCertAddr(info.getString("custCertAddr"));
                    custInfo.setGender(info.getString("gender"));
                    custInfo.setNation(info.getString("nation"));
                    custInfo.setIssuingAuthority(info.getString("issuingAuthority"));
                    custInfo.setBirthday(DateUtils.parseDate(info.getString("birthday"), new String[]{RealNameAuthConstant.DESKEY_CERTEXPDATE_FORMAT}));
                    custInfo.setCertValidDate(DateUtils.parseDate(info.getString("certValiddate"), new String[]{RealNameAuthConstant.DESKEY_CERTEXPDATE_FORMAT}));
                    custInfo.setCertExpDate(DateUtils.parseDate(info.getString("certExpdate"), new String[]{RealNameAuthConstant.DESKEY_CERTEXPDATE_FORMAT}));

                    if (strList != null && strList.size() > 0 && strList.get(0) != null && !"".equals(strList.get(0).getIdCard())) {
                        //pb物联卡处理流程,处理待处理的请求订单
                        returnJson = dealPbRegister(strList, custInfo, params, transNo);
                    } else {
                        //账户实名认证处理程序
                        returnJson = dealAccountAudit(auditResult, params, custInfo, transNo);
                    }
                    returnJson.put(RealNameConstant.BACK_REAL_SYS_CALLBACK_URL, callBackUrl);
                    return returnJson.toJSONString();
                } catch (Exception e) {
                    logger.error("transNo is:[{}],Fail to save passed audit result to DB", transNo, e);
                    returnJson.put("returnCode", RealNameAuthConstant.FAILURE_RETURN_CODE);
                    returnJson.put("returnMessage", "Fail to save passed audit result to DB");
                    return returnJson.toJSONString();
                } finally {
                    cache.remove(CacheManager.PublicNameSpace.TEMP, transactionID);
                }
            } else {
                logger.error("transNo is:[{}],Fail to save audit result, fail to getDesKeyFromLocal",transNo);
                cache.remove(CacheManager.PublicNameSpace.TEMP, transactionID);
                returnJson.put("returnCode", RealNameAuthConstant.FAILURE_RETURN_CODE);
                returnJson.put("returnMessage", "Fail to save audit result, fail to getDesKeyFromLocal");
                return returnJson.toJSONString();
            }
        } else {
            //审核不通过信息 入库
            returnJson = auditError(auditResult,params,strList,transNo);
            returnJson.put(RealNameConstant.BACK_REAL_SYS_CALLBACK_URL, callBackUrl);
            return returnJson.toJSONString();
        }
    }


    /**
     * 活体认证失败的处理程序
     * 认证结果对象
     * 在线公司回调参数
     * PB物联卡实名登记记录
     * */
    private JSONObject auditError(MsgOlAuditResult auditResult, Map<String, String> params, List<PbRegisterVo> strList, String transNo) {
        JSONObject returnJson = new JSONObject(2);
        String busiSeq = params.get(RealNameConstant.REAL_NAME_RESULT_BUSISEQ);
        String transactionID = params.get(RealNameConstant.REAL_NAME_RESULT_TRANSACTION_ID);
        try {
            auditResult.setReturnCode(RealNameAuthConstant.SUCCESS_RETURN_CODE);
            auditResult.setReturnMessage("对不起，您的信息审核不通过，不通过原因：" + params.get("auditMessage"));
            auditResult.setAuditMessage(params.get("auditMessage"));
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
            realNameAuditResultDao.updateAuditResult(auditResult);
            if (strList != null && strList.size() > 0 && strList.get(0) != null && !"".equals(strList.get(0))) {
                //pb物联卡实名登记结果入库
                PbRegisterVo registerVo = strList.get(0);
                PbRegisterVo pbRegisterVo = new PbRegisterVo();
                pbRegisterVo.setRegisterCode(PbRegisterCode.CHECKFAIL);
                pbRegisterVo.setStatus("3");
                pbRegisterVo.setOrderNum(busiSeq);
                pbRegisterDao.updateResult(pbRegisterVo);
                //发短信
                Map map = new HashMap();
                map.put("1", registerVo.getMsisdn());
                map.put("2", PbRegisterCode.getResult(PbRegisterCode.CHECKFAIL));
                sendMessage(registerVo.getPhone(), map, false);
            }
            returnJson.put("returnCode", RealNameAuthConstant.SUCCESS_RETURN_CODE);
            returnJson.put("returnMessage", "Success to receive unpassed audit result");
            return returnJson;
        } catch (RuntimeException e) {
            iLog.error(logger, transNo, null, "Fail to save unpassed audit result to DB", e);
            returnJson.put("returnCode", RealNameAuthConstant.FAILURE_RETURN_CODE);
            returnJson.put("returnMessage", "Fail to save unpassed audit result to DB");
            return returnJson;
        } finally {
            cache.remove(CacheManager.PublicNameSpace.TEMP, transactionID);
        }
    }

    /**
     * 公众号-账户活体认证处理
     * */
    private JSONObject dealAccountAudit(MsgOlAuditResult auditResult, Map<String, String> params, SaPsCust custInfo, String transNo) {
        JSONObject returnJson = new JSONObject(2);
        String phone = params.get(RealNameConstant.REAL_NAME_RESULT_PHONE);
        //先查询是否存在这个用户 返回custid 若为空则表示无 新建 否则更新
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        Map<String, String> oldCustInfo = custInfoDao.queryCustIdAndUserIdByCustCertNo(custInfo.getCustCertNo());
        //查询是否已有认证的账户存在
        String userId = wxPersonUserInfoDao.getUserIdByPhone(phone).get(0);
        Map<String, String> verifiedMap = new HashMap<>(2);
        verifiedMap.put("userId", userId);
        verifiedMap.put("verified", "01"); //账户认证状态：有效
        custInfo.setUserId(userId);
        //默认身份证有效
        boolean identityValid = true;
        String identityErrInfo = "";
        //查询用户是否已实名认证
        String verifiedUserId = wxPersonUserInfoDao.getVerifiedUserIdByPhone(phone);
        //已实名认证
        boolean alreadyAuthed = StringUtils.isNotEmpty(verifiedUserId);
        Map custCertMap = null;
        if (alreadyAuthed) {
            //查询已认证的身份信息
            custCertMap = custInfoDao.queryCustCertInfoByUserId(verifiedUserId);
            if (MapUtils.isEmpty(custCertMap)) {
                //如果查不到当前身份信息
                logger.info("transNo is:[{}],查询已认证身份信息失败，请重试！", transNo);
                identityValid = false;
                identityErrInfo = "查询登记身份信息失败，请重试！";
            } else if (!custInfo.getCustCertNo().equals(custCertMap.get("custCertID"))) {
                //账户当前注册身份证号与返回的身份证号不一致
                logger.info("transNo is:[{}],您本次认证的身份证号为[{}]与当前账户的身份账号不一致，身份信息更新失败！", transNo, Base64Util.getBase64EncodeString(custInfo.getCustCertNo()));
                identityValid = false;
                identityErrInfo = "您本次认证的身份证号与当前账户的身份账号不一致，身份信息更新失败！";
            } else if (((Date) custCertMap.get("certValidDate")).compareTo(custInfo.getCertValidDate()) > 0) {
                //已认证的身份证有效期大于新的身份证有效期，则新认证的身份证无效
                logger.info("transNo is:[{}],您本次认证的身份证[{}]有效期限早于当前账户身份信息，身份信息更新失败！", transNo, Base64Util.getBase64EncodeString(custInfo.getCustCertNo()));
                identityValid = false;
                identityErrInfo = "您本次认证的身份证有效期限早于当前账户身份信息，身份信息更新失败！";
            }
        }

        if (!alreadyAuthed && MapUtils.isEmpty(oldCustInfo)) {
            //账户未实名且身份证未被其他账户实名，新增账户实名记录
            String custId = new UUID4Long().generate();
            custInfo.setCustId(custId);
            custInfo.setCreateTime(custInfo.getModifyTime());
            auditResult.setCustId(custId);
            saveNewCust(auditResult, custInfo, verifiedMap);
        } else if (!alreadyAuthed && MapUtils.isNotEmpty(oldCustInfo)) {
            //账户未实名认证，但身份证已实名认证
            //接触已绑定的账户实名状态，新账户更新实名记录
            String custId = oldCustInfo.get("custId");
            custInfo.setCustId(custId);
            String oldUserId = oldCustInfo.get("userId");
            Map<String, String> unverifiedMap = new HashMap<>(2);
            unverifiedMap.put("verified", "00");//账户实名状态：失效
            unverifiedMap.put("userId", oldUserId);
            auditResult.setCustId(custId);
            updateCustInfo(auditResult, custInfo, verifiedMap, unverifiedMap);
        } else if (identityValid && alreadyAuthed) {
            //账户已实名认证并且身份证件有效
            String custId = oldCustInfo.get("custId");//这时候oldCustInfo肯定是存在的，因为新旧身份证匹配
            String oldUserId = oldCustInfo.get("userId");
            Map<String, String> unverifiedMap = new HashMap<>(2);
            unverifiedMap.put("userId", oldUserId);
            unverifiedMap.put("verified", "00");//失效
            custInfo.setCustId(custId);
            auditResult.setCustId(custId);
            auditResult.setReturnMessage("恭喜你，身份信息更新成功！");
            updateCustInfo(auditResult, custInfo, verifiedMap, unverifiedMap);
        } else if (!identityValid) {
            //账户已实名认证并且身份证件无效
            if (MapUtils.isEmpty(custCertMap)) {
                logger.info("transNo is:[{}],获取实名认证客户信息失败，请重试！", transNo);
                returnJson.put("returnCode", RealNameAuthConstant.EXCEPTION_RETURN_CODE);
                returnJson.put("returnMessage", "Fail to query user identity information from DB");
                return returnJson;
            }
            String custId = (String) custCertMap.get("custId");
            auditResult.setReturnMessage(identityErrInfo);
            auditResult.setReturnCode("0001");
            auditResult.setCustId(custId);
            realNameAuditResultDao.updateAuditResult(auditResult);
            //未知异常情况
        } else {
            iLog.info(logger, transNo, null, "出现未知异常情况！alreadyAuthed, oldCustInfo, identityValid", alreadyAuthed, oldCustInfo, identityValid);
            returnJson.put("returnCode", RealNameAuthConstant.FAILURE_RETURN_CODE);
            returnJson.put("returnMessage", "unkown error occurred");
            return returnJson;
        }
        returnJson.put("returnCode", RealNameAuthConstant.SUCCESS_RETURN_CODE);
        returnJson.put("returnMessage", "Success to receive passed audit result");
        return returnJson;
    }

    /**
     * PB物联卡实名登记回调处理
     * */
    private JSONObject dealPbRegister(List<PbRegisterVo> strList, SaPsCust custInfo, Map<String, String> params, String transNo) {
        //pb卡完成采集埋点
        try {
            registerService.innerStatisService("fourpb");
        }catch (Exception e){
            logger.info("pb卡完成采集埋点报错...{}",e);
        }
        JSONObject returnJson = new JSONObject(2);
        String busiSeq = params.get(RealNameConstant.REAL_NAME_RESULT_BUSISEQ);
//        logger.info("transNo is:[{}],活体回调，开始pb物联卡认证...[{}]", transNo, JsonUtils.parseString(params));
        PbRegisterVo registerVo = strList.get(0);
        PbRegisterVo vo = new PbRegisterVo();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //判断身份证号是否一致
        if (strList.get(0).getIdCard().equals(custInfo.getCustCertNo())) {
            if (custInfo.getCustCertAddr() == null || "".equals(custInfo.getCustCertAddr()) ||
                    custInfo.getBirthday() == null || "".equals(custInfo.getBirthday()) ||
                    custInfo.getCertValidDate() == null || "".equals(custInfo.getCertValidDate()) ||
                    custInfo.getCertExpDate() == null || "".equals(custInfo.getCertExpDate()) ||
                    custInfo.getGender() == null || "".equals(custInfo.getGender()) ||
                    custInfo.getNation() == null || "".equals(custInfo.getNation()) ||
                    custInfo.getCustName() == null || "".equals(custInfo.getCustName()) ||
                    custInfo.getIssuingAuthority() == null || "".equals(custInfo.getIssuingAuthority())
            ) {
                logger.info("transNo is:[{}],pb实名认证失败...在线公司回传内容缺少...{}", transNo, JSONArray.toJSONString(custInfo));
                returnJson.put("returnCode", RealNameAuthConstant.EXCEPTION_RETURN_CODE);
                returnJson.put("returnMessage", "缺少采集信息");
                return returnJson;
            }
            vo.setAddress(custInfo.getCustCertAddr());
            vo.setBirthday(sdf.format(custInfo.getBirthday()));
            vo.setStartDate(sdf.format(custInfo.getCertValidDate()));
            vo.setEndDate(sdf.format(custInfo.getCertExpDate()));
            vo.setSex(custInfo.getGender());
            vo.setNation(custInfo.getNation());
            vo.setName(custInfo.getCustName());
            vo.setStatus("0");
            vo.setOrderNum(busiSeq);
            vo.setInfo(custInfo.getIssuingAuthority());
            vo.setType("1");
            vo.setMsisdn(registerVo.getMsisdn());
            vo.setPhone(registerVo.getPhone());
            vo.setChannelId(registerVo.getChannelId());
            vo.setIdCard(custInfo.getCustCertNo());
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
            pbRegisterDao.updateInfoByOnline(vo);
            //安徽奇瑞定制-获取orderNo
            vo.setOrderNo(pbRegisterDao.queryOrderNoByBusiseq(vo.getOrderNum()));
            //安徽单独处理-将实名信息实时同步给安徽省侧
            if("551".equals(registerVo.getBeid())){
                //通过订单号获取卡号
                String msisdn = registerVo.getMsisdn();
                //拼接参数,调用省侧接口
                PbRegisterTransVo transVo=new PbRegisterTransVo();
                transVo.setCERTEFF_DATE(vo.getStartDate());
                transVo.setCERTEXP_DATE(vo.getEndDate());
                transVo.setCUST_BORN(vo.getBirthday());
                transVo.setCUST_NAME(vo.getName());
                transVo.setCUST_SEX(vo.getSex());
                transVo.setGRANT_DEPT(vo.getInfo());
                transVo.setID_ADDRESS(vo.getAddress());
                transVo.setID_ICCID(custInfo.getCustCertNo());
                transVo.setID_TYPE(vo.getType());
                transVo.setNATION(vo.getNation());
                transVo.setPHONE_NO(msisdn);
                transVo.setSERVICE_NO(msisdn);
                transVo.setTRANSACTION_ID(vo.getOrderNum());
                pbRealName551(transVo,vo);
            }
        } else {
            //身份证号信息不一致
            PbRegisterVo pbRegisterVo = new PbRegisterVo();
            pbRegisterVo.setOrderNum(busiSeq);
            pbRegisterVo.setRegisterCode(PbRegisterCode.IDCARDFAIL);
            pbRegisterVo.setStatus("3");
            pbRegisterDao.updateResult(pbRegisterVo);
            logger.info("transNo is:[{}],前后身份证不一致", transNo);
            //发短信通知
            Map<String, String> map = new HashMap<>();
            map.put("1", registerVo.getMsisdn());
            map.put("2", PbRegisterCode.getResult(PbRegisterCode.IDCARDFAIL));
            sendMessage(registerVo.getPhone(), map, false);
        }
        returnJson.put("returnCode", RealNameAuthConstant.SUCCESS_RETURN_CODE);
        returnJson.put("returnMessage", "Success to receive passed audit result pb");
        return returnJson;
    }

    /**
     * 安徽pb处理
     */
    private void pbRealName551(PbRegisterTransVo transVo,PbRegisterVo vo){
        try {
            String index = cache.get(CacheManager.PublicNameSpace.TEMP, vo.getOrderNum());
            SimpleDateFormat sdf1=new SimpleDateFormat("yyyyMMddHHmmss");
            boolean flag=false;
            Map<String,Object> smsMap=new HashMap<>();
            String json = JSONArray.toJSONString(transVo);
            logger.info("身份信息实时同步...msidn:{}",transVo.getPHONE_NO());
            String url = cache.getSysParams("551.syncInfo","");
            String ss ="pin={ROOT:"+json+"}";
            ss = URLEncoder.encode(ss, "UTF-8");
            Date now=new Date(System.currentTimeMillis());
            String time=sdf1.format(now);
            String requestParameters=ss+cache.getSysParams("551.syncInfo.param","")+"&timeStamp="+time;
            String sign = HttpUtil.toSign(requestParameters,"/data_realname/auth/key/pb_private_key.pem");
            requestParameters = requestParameters + "&sign=" + sign;
            String x = HttpUtil.sendPost(url, requestParameters);
            x=new String(x.getBytes(),"UTF-8");
            logger.info("身份信息实时同步返回结果...msisdn:{}...get result:{}",transVo.getPHONE_NO(),x);
            //更新调用记录
            Map result = JsonUtils.parseObject(x, Map.class);
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
            if(result.get("ROOT")!=null&&JsonUtils.parseObject(result.get("ROOT"), Map.class)!=null&&
                    JsonUtils.parseObject(result.get("ROOT"), Map.class).get("RETURN_CODE")!=null&&
                    "0".equals(JsonUtils.parseObject(result.get("ROOT"), Map.class).get("RETURN_CODE"))){
                //调在线公司成功，处理返回值
                Map resultMap = JsonUtils.parseObject(result.get("ROOT"), Map.class);
                Map outData = JsonUtils.parseObject(resultMap.get("OUT_DATA"), Map.class);
                if(outData!=null&&outData.get("status")!=null){
                    String status=outData.get("status").toString();
                    if("0".equals(status)){
                        logger.info("身份信息实时同步success,msisdn:{}",vo.getMsisdn());
                        vo.setRegisterCode(PbRegisterCode.SUCCESS);
                        //新增获取两个字段
                        vo.setSubOrderId(outData.get("subOrderId")!=null?outData.get("subOrderId").toString():"");
                        vo.setLoginAccept(outData.get("cnttLoginAccept")!=null?outData.get("cnttLoginAccept").toString():"");
                        pbRegisterDao.updateResult(vo);
                        flag=true;
                        smsMap.put("1",vo.getMsisdn());
                        //TODO PB实名登记信息同步省侧成功，推送给接入渠道
                        pushPBRegisterResult(vo,"00000","");
                    }else {
                        logger.info("身份信息实时同步fail,msisdn:{},status:{}",vo.getMsisdn(),status);
                        vo.setRegisterCode(outData.get("statusMsg")!=null?outData.get("statusMsg").toString():"");
                        vo.setStatus("3");
                        pbRegisterDao.updateResult(vo);
                        flag=false;
                        smsMap.put("1",vo.getMsisdn());
                        smsMap.put("2",outData.get("statusMsg")!=null?outData.get("statusMsg").toString():"");
                        //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                        pushPBRegisterResult(vo,"001",outData.get("statusMsg")!=null?outData.get("statusMsg").toString():"");
                    }
                }else {
                    logger.info("身份信息实时同步fail,OUT_DATA no message");
                    vo.setRegisterCode(PbRegisterCode.RETURNEMPTY);
                    vo.setStatus("3");
                    pbRegisterDao.updateResult(vo);
                    flag=false;
                    smsMap.put("1",vo.getMsisdn());
                    smsMap.put("2",PbRegisterCode.getResult(PbRegisterCode.RETURNEMPTY));
                    //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                    pushPBRegisterResult(vo,"002",PbRegisterCode.getResult(PbRegisterCode.RETURNEMPTY));
                }
            }else if(result.get("ROOT")!=null&&JsonUtils.parseObject(result.get("ROOT"), Map.class)!=null&&
                    JsonUtils.parseObject(result.get("ROOT"), Map.class).get("RETURN_CODE")!=null&&
                    !"0".equals(JsonUtils.parseObject(result.get("ROOT"), Map.class).get("RETURN_CODE"))){
                vo.setRegisterCode(JsonUtils.parseObject(result.get("ROOT"), Map.class).get("RETURN_CODE")
                        !=null?JsonUtils.parseObject(result.get("ROOT"), Map.class).get("RETURN_CODE").toString():"");
                vo.setStatus("3");
                pbRegisterDao.updateResult(vo);
                flag=false;
                smsMap.put("1",vo.getMsisdn());
                smsMap.put("2", PbRegisterCode.getResult(JsonUtils.parseObject(result.get("ROOT"), Map.class).get("RETURN_CODE")
                        !=null?JsonUtils.parseObject(result.get("ROOT"), Map.class).get("RETURN_CODE").toString():""));
                //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                pushPBRegisterResult(vo,"003",PbRegisterCode.getResult(JsonUtils.parseObject(result.get("ROOT"), Map.class).get("RETURN_CODE")
                        !=null?JsonUtils.parseObject(result.get("ROOT"), Map.class).get("RETURN_CODE").toString():""));
            }else {
                logger.info("身份信息实时同步fail time>3...msisdn:{}",vo.getMsisdn());
                vo.setRegisterCode(PbRegisterCode.SYNCFAIL);
                vo.setStatus("3");
                pbRegisterDao.updateResult(vo);
                flag=false;
                smsMap.put("1",vo.getMsisdn());
                smsMap.put("2",PbRegisterCode.getResult(PbRegisterCode.SYNCFAIL));
                //TODO PB实名登记信息同步省侧失败，推送给接入渠道
                pushPBRegisterResult(vo,"004",PbRegisterCode.getResult(PbRegisterCode.SYNCFAIL));
            }
            realNameAuthService.sendMessage(vo.getPhone(),smsMap,flag);
        }catch (Exception e){
            logger.info("{}pb物联卡:{}实名登记-身份信息实时同步报错...{}",vo.getOrderNum(),vo.getMsisdn(),e);
        }
    }

    /**
     * 推送PB物联卡登记结果
     * */
    private void pushPBRegisterResult(PbRegisterVo pbRegisterVo,String status,String msg){
        if(!StringUtils.isEmpty(pbRegisterVo.getChannelId())){
            try {
                //具备渠道编码，确定是从H5渠道发起的认证
                Map<String,String> pushData = new HashMap<>();
                if(pbRegisterVo.getOrderNo()!=null&&!"".equals(pbRegisterVo.getOrderNo())){
                    pushData.put("channelId",pbRegisterVo.getChannelId());
                    pushData.put("msisdn",pbRegisterVo.getMsisdn());
                    pushData.put("orderNo",pbRegisterVo.getOrderNo());
                    pushData.put("isAuth","00000".equals(status)?"0":"1");
                    pushData.put("msg","00000".equals(status)?"":msg);
                    pushData.put("phone",pbRegisterVo.getPhone());
                    pushData.put(CommonConstant.REAL_NAME_PUSH_NAME,pbRegisterVo.getName());
                    pushData.put("idCard",pbRegisterVo.getIdCard());
                    registerService.sendRegisterResult551(pushData);
                }else {
                    pushData.put("channelId",pbRegisterVo.getChannelId());
                    pushData.put(CommonConstant.FIELD_MSISDN,pbRegisterVo.getMsisdn());
                    pushData.put(CommonConstant.REAL_NAME_PUSH_NAME,pbRegisterVo.getName());
                    pushData.put(CommonConstant.REAL_NAME_PUSH_CUSTCERTNO,pbRegisterVo.getIdCard());
                    pushData.put(CommonConstant.REAL_NAME_PUSH_REGISTERCODE,status); //登记结果 0 或 00000 成功，其他 登记失败
                    pushData.put(CommonConstant.PHONE,pbRegisterVo.getPhone());
                    registerService.sendRegisterResult(pushData);
                }
            }catch (Exception e){
                logger.info("推送PB物联卡登记结果报错:{}...{}",JsonUtils.parseString(pbRegisterVo),e);
            }
        }
    }


    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
    public void saveNewCust(MsgOlAuditResult auditResult, SaPsCust custInfo, Map verifiedMap) {
        realNameAuditResultDao.updateAuditResult(auditResult); //update
        custInfoDao.saveCustInfo(custInfo);
        wxPersonUserInfoDao.updateVerifiedByUserId(verifiedMap);
    }

    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
    public void updateCustInfo(MsgOlAuditResult auditResult, SaPsCust custInfo, Map verifiedMap, Map unverifiedMap) {
        realNameAuditResultDao.updateAuditResult(auditResult);  //update
        custInfoDao.updateCustInfo(custInfo);
        //将新user的verified改为有效
        wxPersonUserInfoDao.updateVerifiedByUserId(verifiedMap);
        //将原user的verfified改为失效
        if (!verifiedMap.get("userId").equals(unverifiedMap.get("userId"))) {
            wxPersonUserInfoDao.updateVerifiedByUserId(unverifiedMap);
        }
    }

    public String receiveDesKey(Map<String, String> params, String transNo) { //params -> reqInfo
        JSONObject returnJson = new JSONObject(2);
        Map localDesKey = getDesKeyFromLocal(transNo);
        boolean allowModify = Boolean.valueOf(cache.getSysParams(RealNameAuthConstant.ALLOW_MODIFY_DESKEY, "false"));
        String key = params.get("key");
        MsgOlAuthKey remoteDesKey = new MsgOlAuthKey();
        remoteDesKey.setBusiCode(RealNameAuthConstant.DESKEY_BUSI_CODE);
        remoteDesKey.setKey(key);
        remoteDesKey.setInsertTime(new Date());
        remoteDesKey.setTransactionID(params.get("transactionID"));

        try {
            remoteDesKey.setCertExpDate(DateUtils.parseDate(params.get("certExpdate"), new String[]{RealNameAuthConstant.DESKEY_CERTEXPDATE_FORMAT}));
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
            if (localDesKey != null && !allowModify) { //不允许更新desKey
                remoteDesKey.setReturnCode(RealNameAuthConstant.FAILURE_RETURN_CODE);
                remoteDesKey.setReturnMessage("PUSH_KEY Is Not Allowed");
                //入库
                realNameAuthKeyDao.saveFailedDesKey(remoteDesKey);
                returnJson.put("returnCode", RealNameAuthConstant.FAILURE_RETURN_CODE);
                returnJson.put("returnMessage", "PUSH_KEY Is Not Allowed");
                return returnJson.toJSONString();
            } else {
                String id = new UUID4Long().generate();
                remoteDesKey.setId(id);
                remoteDesKey.setValid("01");
                remoteDesKey.setReturnCode(RealNameAuthConstant.SUCCESS_RETURN_CODE);
                remoteDesKey.setReturnMessage("Success to receive DesKey");

                //入库并更改有效的key
                saveAndUpdateDesKey(remoteDesKey);

                //redis 缓存
                Map<String, String> keyCache = new HashMap<>(2);
                keyCache.put(RealNameAuthConstant.DESKEY, key);
                keyCache.put(RealNameAuthConstant.DESKEY_ID, id);
                cache.hmset(CacheManager.PublicNameSpace.USERAUTH, RealNameAuthConstant.CACHED_DESKEY_INFO, keyCache, -1);

                returnJson.put("returnCode", RealNameAuthConstant.SUCCESS_RETURN_CODE);
                returnJson.put("returnMessage", "Success to receive DesKey");
                return returnJson.toJSONString();
            }
        } catch (Exception e) {
            iLog.error(logger, transNo, null, "Fail to save DesKey to DB", e);
            returnJson.put("returnCode", RealNameAuthConstant.FAILURE_RETURN_CODE);
            returnJson.put("returnMessage", "Fail to save DesKey to DB");
            return returnJson.toJSONString();
        }
    }

    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
    public void saveAndUpdateDesKey(MsgOlAuthKey desKeyInfo) {
        realNameAuthKeyDao.saveSuccessDesKey(desKeyInfo);
        realNameAuthKeyDao.updateKeyStatus(desKeyInfo);
    }

    //返回明文SignatureKey
    private synchronized String pullSignatureKey(String transNo) {
        if (allowPull) { //去请求签名秘钥   失败时重复三次
            //封装请求参数
            JSONObject reqParam = new JSONObject(4);
            reqParam.put("busiCode", RealNameAuthConstant.SIGNATUREKEY_BUSI_CODE);
            reqParam.put("sourceCode", RealNameAuthConstant.CMIOT_CODE);//中移物联网 分配的号段
            reqParam.put("targetCode", RealNameAuthConstant.ONLINE_CODE);
            reqParam.put("version", RealNameAuthConstant.MSG_VERSION);

            Map<String, String> reqMap = new HashMap<>(1);
            reqMap.put("reqParam", JSON.toJSONString(reqParam));
            String encryptMachineURL = cache.getSysParams(RealNameAuthConstant.ENCRYPT_MACHINE, "");

            String signatureKey = null;
            for (int i = 0; i < 3; i++) {
                //立即获取
                String resultStr = httpClient.post(transNo, encryptMachineURL, reqMap, HttpRequestClient.CONTENT_TYPE_FORM, 30);
                JSONObject result = JSONObject.parseObject(resultStr);
                if (result == null) {
                    continue;
                }
                String returnCode = result.getString("returnCode");

                MsgOlAuthKey signatureKeyInfo = new MsgOlAuthKey();
                signatureKeyInfo.setBusiCode(RealNameAuthConstant.SIGNATUREKEY_BUSI_CODE);
                signatureKeyInfo.setInsertTime(new Date());
                signatureKeyInfo.setReturnCode(returnCode);
                signatureKeyInfo.setReturnMessage(result.getString("returnMessage"));
                try {
                    setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
                    if (returnCode.equals(RealNameAuthConstant.SUCCESS_RETURN_CODE)) {
                        signatureKey = result.getString("privateKey");
                        String id = new UUID4Long().generate();
                        signatureKeyInfo.setId(id);
                        signatureKeyInfo.setKey(signatureKey);
                        signatureKeyInfo.setValid("01");
                        //入库 先入库 再更新
                        saveAndUpdateSignatureKey(signatureKeyInfo);
                        cache.put(CacheManager.PublicNameSpace.USERAUTH, RealNameAuthConstant.CACHED_SIGNATUREKEY, signatureKey, -1);
                        allowPull = false;
                        break;
                    } else {
                        //入库
                        realNameAuthKeyDao.saveFailSignatureKey(signatureKeyInfo);
                    }
                } catch (RuntimeException e) {
                    iLog.error(logger, transNo, null, "Fail to save signatureKey to DB", e);
                }
            }
            return signatureKey;
        } else {  //已经获取秘钥
            return getSignatureKeyFromLocal(transNo);
        }
    }

    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
    public void saveAndUpdateSignatureKey(MsgOlAuthKey signatureKeyInfo) {
        realNameAuthKeyDao.saveSuccessSignatureKey(signatureKeyInfo);
        realNameAuthKeyDao.updateKeyStatus(signatureKeyInfo);
    }


    public Map<String, String> getDesKeyFromLocal(String transNo) { //获取解密的des key
        Map<String, String> desKeyInfo = cache.hgetAll(CacheManager.PublicNameSpace.USERAUTH, RealNameAuthConstant.CACHED_DESKEY_INFO);
        logger.info("获取缓存中的PUSH_KEY:{}",JsonUtils.parseString(desKeyInfo));
        if (desKeyInfo == null || desKeyInfo.size() != 2) {
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
            Map<String, String> keyInfo = realNameAuthKeyDao.queryValidKeyInfo(RealNameAuthConstant.DESKEY_BUSI_CODE);
            logger.info("获取数据库中的PUSH_KEY:{}",JsonUtils.parseString(keyInfo));
            if (keyInfo != null && keyInfo.size() == 2) {
                try {
                    desKeyInfo.put(RealNameAuthConstant.DESKEY, keyInfo.get("key"));
                    desKeyInfo.put(RealNameAuthConstant.DESKEY_ID, keyInfo.get("id"));
                    cache.hmset(CacheManager.PublicNameSpace.USERAUTH, RealNameAuthConstant.CACHED_DESKEY_INFO, desKeyInfo, -1);
                } catch (RuntimeException e) {
                    iLog.error(logger, transNo, null, "fail to get desKey from database", e);
                    return null;
                }
            }
        }
        return desKeyInfo;
    }

    private String getSignatureKeyFromLocal(String transNo) {
        String signatureKey = null;
        try {
            signatureKey = cache.get(CacheManager.PublicNameSpace.USERAUTH, RealNameAuthConstant.CACHED_SIGNATUREKEY, null);
            if (StringUtils.isEmpty(signatureKey)) {
                setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
                Map<String, String> keyInfo = realNameAuthKeyDao.queryValidKeyInfo(RealNameAuthConstant.SIGNATUREKEY_BUSI_CODE);
                if (keyInfo != null) {
                    signatureKey = keyInfo.get("key");
                    cache.put(CacheManager.PublicNameSpace.USERAUTH, RealNameAuthConstant.CACHED_SIGNATUREKEY, signatureKey, -1);
                }
            }
        } catch (RuntimeException e) {
            iLog.error(logger, transNo, null, "fail to get SignatureKey from local", e);
        }
        return signatureKey;
    }

    /**
     * 获取实名认证结果
     *
     * @param map
     * @return
     */
    public Map getRealNameAuthResult(@RequestBody Map map) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        String busiSeq = (String) map.get("busiSeq");
        return realNameAuditResultDao.getRealNameAuthResultBySeq(busiSeq);
    }

    /**
     * 处理其他渠道接入的实名认证处理
     */
    private JSONObject dealAuitResult(Map<String, String> params, String transNo) {
        JSONObject returnJson = new JSONObject();
        returnJson.put("returnCode", RealNameAuthConstant.SUCCESS_RETURN_CODE);
        returnJson.put("returnMessage", "Success to receive passed audit result");
        logger.info("openApi access,transNo is:[{}],wx api dealAuitResult", transNo);
        /**
         * 开放渠道，添加非彼传参数：web跳转地址
         * 4.300.8.2
         * lixiangcheng
         * */
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        MsgOlAuditResultOpen auditResultOpen1 = getAuitResult(params);
        if(!StringUtils.isEmpty(auditResultOpen1.getReturnPage())){
            returnJson.put("callBackUrl", auditResultOpen1.getReturnPage());
        }
        MsgOlAuditResultOpen auditResultOpen = getAuitResult(params);
        if ("0".equals(auditResultOpen.getAuditStatus())) {
            Map<String, String> desKeyInfo = getDesKeyFromLocal(transNo);
            if (desKeyInfo != null && desKeyInfo.size() == 2) {
                String keyId = cache.get(CacheManager.PublicNameSpace.TEMP, auditResultOpen.getTransactionID());
                if (StringUtils.isEmpty(keyId)) {
                    keyId = desKeyInfo.get(RealNameAuthConstant.DESKEY_ID);
                }
                try {
                    //解密  information
                    String infoStr = new RealNameMsDesPlus(desKeyInfo.get(RealNameAuthConstant.DESKEY)).decrypt(params.get("information"));
                    JSONObject info = JSON.parseObject(infoStr);
                    auditResultOpen.setPicNameZ(info.getString("picNameZ"));
                    auditResultOpen.setPicNameF(info.getString("picNameF"));
                    auditResultOpen.setPicNameT(info.getString("picNameT"));
                    auditResultOpen.setPicNameV2(info.getString("picNameV2"));
                    auditResultOpen.setReturnCode(RealNameAuthConstant.SUCCESS_RETURN_CODE);
                    auditResultOpen.setKeyId(keyId);
                    auditResultOpen.setReturnMessage("恭喜你，实名认证成功！");

                    SaPsCustOpen custInfo = getCustInfoFromResult(info, auditResultOpen);
                    setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
                    //记录认证客户信息
                    realNameAuditResultDao.updateAuditResultForOpen(auditResultOpen);
                    //更新认证结果
                    realNameAuditResultDao.saveCustInfoForOpen(custInfo);
                    //异步向业务系统推送认证结果
                    pushDataToChannel(auditResultOpen1, custInfo, transNo);
                } catch (Exception e) {
                    iLog.error(logger, transNo, null, "Fail to save passed audit result to DB", e);
                    returnJson.put("returnCode", RealNameAuthConstant.FAILURE_RETURN_CODE);
                    returnJson.put("returnMessage", "Fail to save passed audit result to DB");
                    logger.info("openApi access,transNo is:[{}],wx api dealAuitResult access error", transNo);
                    return returnJson;
                } finally {
                    cache.remove(CacheManager.PublicNameSpace.TEMP, auditResultOpen.getTransactionID());
                }
            } else {
                iLog.error(logger, transNo, null, "Fail to save audit result, fail to getDesKeyFromLocal");
                logger.info("openApi access,transNo is:[{}],wx api dealAuitResult access error", transNo);
                cache.remove(CacheManager.PublicNameSpace.TEMP, auditResultOpen.getTransactionID());
                returnJson.put("returnCode", RealNameAuthConstant.FAILURE_RETURN_CODE);
                returnJson.put("returnMessage", "Fail to save audit result, fail to getDesKeyFromLocal");
                return returnJson;
            }
        } else {
            //审核不通过信息 入库
            try {
                logger.info("openApi access,transNo is:[{}],实名认证审核未通过", transNo);
                auditResultOpen.setReturnCode(RealNameAuthConstant.SUCCESS_RETURN_CODE);
                auditResultOpen.setReturnMessage("对不起，您的信息审核不通过，不通过原因：" + params.get("auditMessage"));
                auditResultOpen.setAuditMessage(params.get("auditMessage"));
                setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
                realNameAuditResultDao.updateAuditResultForOpen(auditResultOpen);
                pushDataToChannel(auditResultOpen, null, transNo);
                return returnJson;
            } catch (RuntimeException e) {
                iLog.error(logger, transNo, null, "Fail to save unpassed audit result to DB", e);
                logger.info("openApi access,transNo is:[{}],实名认证失败，更新认证结果错误", transNo);
                returnJson.put("returnCode", RealNameAuthConstant.FAILURE_RETURN_CODE);
                returnJson.put("returnMessage", "Fail to save unpassed audit result to DB");
                return returnJson;
            } finally {
                //清除缓存关系
                cache.remove(CacheManager.PublicNameSpace.TEMP, auditResultOpen.getTransactionID());
            }
        }
        return returnJson;
    }

    /**
     * 从实名认证平台返回信息中获取用户信息
     */
    private SaPsCustOpen getCustInfoFromResult(JSONObject result, MsgOlAuditResultOpen auditResultOpen) throws ParseException {
        SaPsCustOpen custInfo = new SaPsCustOpen();
        custInfo.setBusiSeq(auditResultOpen.getBusiSeq());
        custInfo.setModifyTime(auditResultOpen.getResponseTime());
        custInfo.setCreateTime(auditResultOpen.getResponseTime());
        custInfo.setCustName(result.getString("custName"));
        custInfo.setCustCertNo(result.getString("custCertNo"));
        custInfo.setCustCertAddr(result.getString("custCertAddr"));
        custInfo.setGender(result.getString("gender"));
        custInfo.setNation(result.getString("nation"));
        custInfo.setIssuingAuthority(result.getString("issuingAuthority"));
        custInfo.setBirthday(DateUtils.parseDate(result.getString("birthday"), new String[]{RealNameAuthConstant.DESKEY_CERTEXPDATE_FORMAT}));
        custInfo.setCertValidDate(DateUtils.parseDate(result.getString("certValiddate"), new String[]{RealNameAuthConstant.DESKEY_CERTEXPDATE_FORMAT}));
        custInfo.setCertExpDate(DateUtils.parseDate(result.getString("certExpdate"), new String[]{RealNameAuthConstant.DESKEY_CERTEXPDATE_FORMAT}));

        return custInfo;
    }

    /**
     * 从实名认证平台返回信息获取认证结果
     */
    private MsgOlAuditResultOpen getAuitResult(Map<String, String> params) {
        MsgOlAuditResultOpen auditResult = new MsgOlAuditResultOpen();
        String auditStatus = params.get("auditStatus");
        String transactionID = params.get("transactionID");
        String busiSeq = params.get("busiSeq");
        String phone = params.get("phone");
        auditResult.setTransactionID(transactionID);
        auditResult.setBusiSeq(busiSeq);
        auditResult.setPhone(phone);
        auditResult.setResponseTime(new Date());
        auditResult.setAuditStatus(auditStatus);
        return auditResult;
    }

    /**
     * 子线程向渠道方推送数据
     */
    private void pushDataToChannel(MsgOlAuditResultOpen auditResultOpen, SaPsCustOpen custInfo, String transNo) {
        pushExecutor.execute(new Runnable() {
            @Override
            public void run() {
                setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
                MsgOlAuditResultOpen callBackVo = realNameAuditResultDao.getAuditRequestInfo(auditResultOpen);
                if (callBackVo == null) {
                    logger.error("transNo is:[{}],未获取到业务系统[{}]回调地址，放弃推送认证结果消息,业务流水：[{}]", transNo, auditResultOpen.getChannelId(), auditResultOpen.getBusiSeq());
                } else {
                    //TODO 数据推送
                    String url = callBackVo.getCallBackUrl();
                    logger.info("transNo is:[{}],推送地址：[{}]", transNo, url);
                    Map<String, Object> pushData = new HashMap<>();
                    pushData.put("auditResult", auditResultOpen);
                    pushData.put("custInfo", custInfo);
                    if (!StringUtils.isEmpty(url)) {
                        Map<String, String> header = new HashMap<String, String>(1);
                        header.put("PUSH-REMOTE", url);//真实的三方系统接口地址
                        String responseStr = httpUtils.post(transNo, addrConfig.getRealNamePushAddr(), JsonUtils.parseString(pushData), HttpRequestClient.CONTENT_TYPE_JSON, header);
                        logger.info("transNo is:[{}],推送结果给业务平台,业务流水号：[{}],result is:[{}]", transNo, auditResultOpen.getBusiSeq(), responseStr);
                    }
                }
            }
        });
    }

    //PB物联卡实名认证处理采集信息




    //PB物联卡实名认证发送认证结果短信
    public  void sendMessage(String phone,Map map,boolean isSuccess){
        Map params=new HashMap();
        params.put(ParamConstants.MSISDN,phone);
        params.put("parameterMap",map);
        params.put(ParamConstants.SENDTIME, new Date().getTime());
        params.put("templateNo",isSuccess?"821":"822");
        sysClient.sendMsg(params);
    }

    //定时任务 更新实名图片路径
    public void UpdatePicUrl(){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        List<PicVo> list=new ArrayList<>();
        Map<String,String> map=new HashMap<>();
        list.forEach(v->{
            String picName=v.getPicName();
            //获取订单号
            String orderNum=picName.substring(0,picName.indexOf("_"));
            map.put("orderNum",orderNum);
            map.put("url",v.getPicUrl());
            if(picName.contains("_Z")){
                map.put("type","1");
                pbRegisterDao.updateUrl(map);
            }else if(picName.contains("_F")){
                map.put("type","2");
                pbRegisterDao.updateUrl(map);
            }else if(picName.contains("_V1")){
                map.put("type","3");
                pbRegisterDao.updateUrl(map);
            }else if (picName.contains("_V2")){
                map.put("type","4");
                pbRegisterDao.updateUrl(map);
            }
        });
    }

    //定时任务 和省侧同步
    public void syncInfo(){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        List<PbRegisterVo> list = pbRegisterDao.querySyncInfo();
        for (PbRegisterVo vo :
                list) {
            //根据路径获取图片

            //base64编码和拼接参数

            //调用省侧接口

            //更新调用记录

        }
    }


}
