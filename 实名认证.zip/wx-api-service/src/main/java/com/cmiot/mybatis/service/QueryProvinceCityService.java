package com.cmiot.mybatis.service;

import com.cmiot.commons.response.ResponseVo;
import com.cmiot.ms.dal.common.orcl.NormalBaseService;
import com.cmiot.mybatis.dao.QueryProvinceCityDao;
import com.cmiot.wx.apiservice.utiles.CommonConstant;
import com.cmiot.wx.apiservice.utiles.DalServiceErrorCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * company ustcinfo.com
 * description 微信省市信息查询业务
 * date 2018/4/2
 *
 * @author yang.dehao@ustcinfo.com
 */
@Service
public class QueryProvinceCityService extends NormalBaseService {
    private static final Logger LOGGER = LoggerFactory.getLogger(QueryProvinceCityService.class);

    @Autowired
    private QueryProvinceCityDao queryProvinceCityDao;

    /**
     * 查询省份编码
     * @param map
     * @param transNo
     * @return
     */
    public ResponseVo getCodeByProvinceName(Map map, String transNo){
        try {
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
            return ResponseVo.success(queryProvinceCityDao.getCodeByProvinceName(map));
        } catch (Exception e) {
            LOGGER.error(transNo, null, "Failed to wx getCodeByProvinceName data:", e);
            return ResponseVo.fail(DalServiceErrorCode.ERROR_ACCESS_DB);
        }
    }

    /**
     * 查询地市编码
     * @param map
     * @param transNo
     * @return
     */
    public ResponseVo getCodeByCityName(Map map, String transNo){
        try {
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
            return ResponseVo.success(queryProvinceCityDao.getCodeByCityName(map));
        } catch (Exception e) {
            LOGGER.error(transNo, null, "Failed to wx getCodeByCityName data:", e);
            return ResponseVo.fail(DalServiceErrorCode.ERROR_ACCESS_DB);
        }
    }
}
