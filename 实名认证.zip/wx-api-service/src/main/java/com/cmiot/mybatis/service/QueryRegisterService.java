package com.cmiot.mybatis.service;

import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.ms.dal.common.orcl.NormalBaseService;
import com.cmiot.mybatis.dao.QueryRegisterDao;
import com.cmiot.mybatis.vo.CmPsRegisterVO;
import com.cmiot.wx.apiservice.utiles.CommonConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;


@Service
public class QueryRegisterService extends NormalBaseService {

    static Logger logger = LoggerFactory.getLogger(QueryRegisterService.class);



    @Autowired
    QueryRegisterDao dao;


    public long queryPbCount(Map map) {
        logger.info("queryPbCount:{}", JsonUtils.parseString(map));
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return dao.queryPbCount(map);
    }

    public long queryCtCount(Map map) {
        logger.info("queryCtCount:{}", JsonUtils.parseString(map));
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return dao.queryCtCount(map);
    }

    public List<CmPsRegisterVO> queryByPb(Map map) {
        logger.info("queryByPb:{}", JsonUtils.parseString(map));
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return dao.queryByPb(map);
    }

    public List<CmPsRegisterVO> queryByCt(Map map) {
        logger.info("queryByCt:{}", JsonUtils.parseString(map));
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return dao.queryByCt(map);
    }


}
