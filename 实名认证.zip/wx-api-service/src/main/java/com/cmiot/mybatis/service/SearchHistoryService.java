package com.cmiot.mybatis.service;

import com.cmiot.ms.dal.common.orcl.NormalBaseService;
import com.cmiot.mybatis.dao.SearchHistoryDao;
import com.cmiot.mybatis.vo.WxHistoryEntity;
import com.cmiot.wx.apiservice.utiles.CommonConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @deprecated 已废弃
 * */
@Service
public class SearchHistoryService extends NormalBaseService {

    @Autowired
    SearchHistoryDao searchHistoryDao;

    public List<Map<String,Object>> getSearchList(Map<String,String> params){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return searchHistoryDao.getSearchList(params);
    }

    public void saveHistory(Map params){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        //查询库里是否存在该卡的历史纪录
        WxHistoryEntity wxHistoryEntity = searchHistoryDao.getHistory(params);
        if (wxHistoryEntity != null) {
            //存在，则更新
            searchHistoryDao.updateHistory(wxHistoryEntity);
        }else{
            //不存在，则保存
            searchHistoryDao.saveSearchHistory(params);
        }
    }
}
