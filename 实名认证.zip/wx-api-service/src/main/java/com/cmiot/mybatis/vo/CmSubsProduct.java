package com.cmiot.mybatis.vo;

import com.cmiot.commons.common.utils.ReportUtil;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Xiang wenbo on 2017/6/21.
 * <p>
 * 描述：
 * ***************更新历史***************
 */
public class CmSubsProduct {

    private long oid;

    private String subsid;

    // 用户状态
    private String subsStatus;

    private String provinceid;

    private String prodid;

    private Date startdate;

    private String status;

    private Date statusdate;

    private String operSeq;

    private Date oprTime;

    private String operCode;

    private String applyChannel;

    private String prodInstid;

    private Date prodInstExptime;

    private String pkgProdid;

    private String ecSubsId;

    /**
     * 非库表字段 页面查询使用
     */

    private String custID;

    private String custName;

    private String custtype;

    private String msisdn;

    private String prodname;

    private String prodtype;

    private String preSeq;

    private String cardPhysicalType;

    /**
     * 订购用户的imsi属性
     */
    private String imsi;

    private Date openTime;

    private Date useTime;

    private String industryID;

    private String ecSource;

    /**
     * 即将发生的状态 01有效、02取消、03暂停
     */
    private String futureStatus;

    public String getFutureStatus() {
        return futureStatus;
    }

    public void setFutureStatus(String futureStatus) {
        this.futureStatus = futureStatus;
    }
    // Property accessors

    public long getOid() {
        return this.oid;
    }

    public void setOid(long oid) {
        this.oid = oid;
    }

    public void setSubsid(String subsid) {
        this.subsid = subsid;
    }

    public String getProvinceid() {
        return this.provinceid;
    }

    public String getSubsid() {
        return this.subsid;
    }

    public void setProvinceid(String provinceid) {
        this.provinceid = provinceid;
    }

    public String getProdid() {
        return this.prodid;
    }

    public void setProdid(String prodid) {
        this.prodid = prodid;
    }

    public Date getStartdate() {
        return this.startdate == null ? null : (Date) startdate.clone();
    }

    public void setStartdate(Date startdate) {
        this.startdate = startdate == null ? null : (Date) startdate.clone();
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getStatusdate() {
        return this.statusdate == null ? null : (Date) statusdate.clone();
    }

    public void setStatusdate(Date statusdate) {
        this.statusdate = statusdate == null ? null : (Date) statusdate.clone();
    }

    public String getCustID() {
        return custID;
    }

    public void setCustID(String custID) {
        this.custID = custID;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getProdname() {
        return prodname;
    }

    public void setProdname(String prodname) {
        this.prodname = prodname;
    }

    public String getProdtype() {
        return prodtype;
    }

    public void setProdtype(String prodtype) {
        this.prodtype = prodtype;
    }

    public String getCusttype() {
        return custtype;
    }

    public void setCusttype(String custtype) {
        this.custtype = custtype;
    }

    public String getStartdateString() {
        if (null == startdate) {
            return "";
        }
        DateFormat df = new SimpleDateFormat(ReportUtil.DATETIME_19);
        return df.format(startdate);
    }

    public String getProdInstExptimeString() {
        if (null == prodInstExptime) {
            return "";
        }
        DateFormat df = new SimpleDateFormat(ReportUtil.DATETIME_19);
        return df.format(prodInstExptime);
    }

    public String getOprTimeString() {
        if (null == oprTime) {
            return "";
        }
        DateFormat df = new SimpleDateFormat(ReportUtil.DATETIME_19);
        return df.format(oprTime);
    }

    public String getOperSeq() {
        return operSeq;
    }

    public void setOperSeq(String operSeq) {
        this.operSeq = operSeq;
    }

    public String getOperCode() {
        return operCode;
    }

    public void setOperCode(String operCode) {
        this.operCode = operCode;
    }

    public String getSubsStatus() {
        return subsStatus;
    }

    public void setSubsStatus(String subsStatus) {
        this.subsStatus = subsStatus;
    }

    public String getApplyChannel() {
        return applyChannel;
    }

    public void setApplyChannel(String applyChannel) {
        this.applyChannel = applyChannel;
    }

    public String getProdInstid() {
        return prodInstid;
    }

    public void setProdInstid(String prodInstid) {
        this.prodInstid = prodInstid;
    }

    public Date getProdInstExptime() {
        return prodInstExptime == null ? null : (Date) prodInstExptime.clone();
    }

    public void setProdInstExptime(Date prodInstExptime) {
        this.prodInstExptime = prodInstExptime == null ? null : (Date) prodInstExptime.clone();
    }

    public String getPkgProdid() {
        return pkgProdid;
    }

    public void setPkgProdid(String pkgProdid) {
        this.pkgProdid = pkgProdid;
    }

    public String getPreSeq() {
        return preSeq;
    }

    public void setPreSeq(String preSeq) {
        this.preSeq = preSeq;
    }

    public Date getOprTime() {
        return oprTime == null ? null : (Date) oprTime.clone();
    }

    public void setOprTime(Date oprTime) {
        this.oprTime = oprTime == null ? null : (Date) oprTime.clone();
    }

    public String getEcSubsId() {
        return ecSubsId;
    }

    public void setEcSubsId(String ecSubsId) {
        this.ecSubsId = ecSubsId;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getCardPhysicalType() {
        return cardPhysicalType;
    }

    public void setCardPhysicalType(String cardPhysicalType) {
        this.cardPhysicalType = cardPhysicalType;
    }

    public Date getOpenTime() {
        return openTime == null ? null : (Date) openTime.clone();
    }

    public void setOpenTime(Date openTime) {
        this.openTime = openTime == null ? null : (Date) openTime.clone();
    }

    public Date getUseTime() {
        return useTime == null ? null : (Date) useTime.clone();
    }

    public void setUseTime(Date useTime) {
        this.useTime = useTime == null ? null : (Date) useTime.clone();
    }

    public String getIndustryID() {
        return industryID;
    }

    public void setIndustryID(String industryID) {
        this.industryID = industryID;
    }

    public String getEcSource() {
        return ecSource;
    }

    public void setEcSource(String ecSource) {
        this.ecSource = ecSource;
    }

    @Override
    public String toString() {
        return "CmSubsProduct{" +
                "oid=" + oid +
                ", subsid='" + subsid + '\'' +
                ", subsStatus='" + subsStatus + '\'' +
                ", provinceid='" + provinceid + '\'' +
                ", prodid='" + prodid + '\'' +
                ", startdate=" + startdate +
                ", status='" + status + '\'' +
                ", statusdate=" + statusdate +
                ", operSeq='" + operSeq + '\'' +
                ", oprTime=" + oprTime +
                ", operCode='" + operCode + '\'' +
                ", applyChannel='" + applyChannel + '\'' +
                ", prodInstid='" + prodInstid + '\'' +
                ", prodInstExptime=" + prodInstExptime +
                ", pkgProdid='" + pkgProdid + '\'' +
                ", ecSubsId='" + ecSubsId + '\'' +
                ", custID='" + custID + '\'' +
                ", custName='" + custName + '\'' +
                ", custtype='" + custtype + '\'' +
                ", msisdn='" + msisdn + '\'' +
                ", prodname='" + prodname + '\'' +
                ", prodtype='" + prodtype + '\'' +
                ", preSeq='" + preSeq + '\'' +
                ", cardPhysicalType='" + cardPhysicalType + '\'' +
                ", imsi='" + imsi + '\'' +
                ", openTime=" + openTime +
                ", useTime=" + useTime +
                ", industryID='" + industryID + '\'' +
                ", ecSource='" + ecSource + '\'' +
                ", futureStatus='" + futureStatus + '\'' +
                '}';
    }
}
