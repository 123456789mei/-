package com.cmiot.mybatis.vo;

import com.alibaba.fastjson.annotation.JSONField;

public class PbPicVo {
    //订单流水号 对应数据库的orderNum
    @JSONField(name="onlineCompanySerialNo")
    private String onlineCompanySerialNo;
    //手机号码
    @JSONField(name="phone")
    private String phone;
    //时间
    @JSONField(name="time")
    private String time;
    //订单号 对应数据库的subOrderId
    @JSONField(name="orderNumber")
    private String orderNumber;
    //流水号 对应数据库的loginAccept
    @JSONField(name="serialNo")
    private String serialNo;
    //身份证正面图片名称
    @JSONField(name="beiyongOne")
    private String beiyongOne;
    //身份证反面图片名称
    @JSONField(name="beiyongTwo")
    private String beiyongTwo;
    //人像面图片名称
    @JSONField(name="beiyongThr")
    private String beiyongThr;
    //标记  固定值：saveImg
    @JSONField(name="flag")
    private String flag="saveImg";
    //身份证正面base64
    @JSONField(name="IdCardZJpg")
    private String IdCardZJpg;
    //身份证反面base64
    @JSONField(name="IdCardFJpg")
    private String IdCardFJpg;
    //人像面base64
    @JSONField(name="faceJpg")
    private String faceJpg;


    public String getOnlineCompanySerialNo() {
        return onlineCompanySerialNo;
    }

    public void setOnlineCompanySerialNo(String onlineCompanySerialNo) {
        this.onlineCompanySerialNo = onlineCompanySerialNo;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public String getBeiyongOne() {
        return beiyongOne;
    }

    public void setBeiyongOne(String beiyongOne) {
        this.beiyongOne = beiyongOne;
    }

    public String getBeiyongTwo() {
        return beiyongTwo;
    }

    public void setBeiyongTwo(String beiyongTwo) {
        this.beiyongTwo = beiyongTwo;
    }

    public String getBeiyongThr() {
        return beiyongThr;
    }

    public void setBeiyongThr(String beiyongThr) {
        this.beiyongThr = beiyongThr;
    }

    public String getIdCardZJpg() {
        return IdCardZJpg;
    }

    public void setIdCardZJpg(String idCardZJpg) {
        IdCardZJpg = idCardZJpg;
    }

    public String getIdCardFJpg() {
        return IdCardFJpg;
    }

    public void setIdCardFJpg(String idCardFJpg) {
        IdCardFJpg = idCardFJpg;
    }

    public String getFaceJpg() {
        return faceJpg;
    }

    public void setFaceJpg(String faceJpg) {
        this.faceJpg = faceJpg;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }
}
