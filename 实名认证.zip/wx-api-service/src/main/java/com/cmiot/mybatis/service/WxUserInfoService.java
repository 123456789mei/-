package com.cmiot.mybatis.service;

import com.cmiot.api.service.UserService;
import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.common.constants.ParamConstants;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.log.ILog;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.commons.response.vo.PageResultVo;
import com.cmiot.commons.vo.MsisdnCacheVo;
import com.cmiot.ms.dal.common.orcl.NormalBaseService;
import com.cmiot.mybatis.dao.ISubsProductDao;
import com.cmiot.mybatis.dao.WxUserInfoDao;
import com.cmiot.mybatis.vo.EcAccountEntity;
import com.cmiot.mybatis.vo.UserMsisdnDetail;
import com.cmiot.wx.apiservice.utiles.CommonConstant;
import com.cmiot.wx.apiservice.utiles.DalServiceErrorCode;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class WxUserInfoService  extends NormalBaseService {

    @Autowired
    WxUserInfoDao wxUserInfoDao;

    @Autowired
    ICache iCache;

    @Autowired
    ILog iLog;

    @Autowired
    UserService userService;

    static Logger logger = LoggerFactory.getLogger(WxUserInfoService.class);
    public static final String CUST_ID = "custID";

    private static final String PROD_STATUS = "status";

    private static final String PROD_NORMAL = "01";

    @Autowired
    ISubsProductDao iSubsProductDao;

    public void register(Map<String,String> params){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        wxUserInfoDao.register(params);
    }
    public void updateType(Map<String,String> params){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        wxUserInfoDao.updateType(params);
    }

    public void bind(Map<String,String> params){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        //先校验密码
        wxUserInfoDao.bind(params);
    }

    public List<EcAccountEntity> accountlist(Map<String,String> params){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxUserInfoDao.accountlist(params);
    }

    public void deleteAccount(Map<String,String> params){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        wxUserInfoDao.deleteAccount(params);
    }
    public Map getWxUserInfo(Map params){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxUserInfoDao.getWxUserInfo(params);
    }
    public long checkOpenId(Map params){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxUserInfoDao.checkOpenId(params);
    }
    public List<String> getEcList(Map params){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxUserInfoDao.getEcList(params);
    }
    public String getCustIdByMsisdn(Map params){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return userService.getCustIdByMsisdn(params);
    }

    /**
     * 产品订购查询
     * @param paramMap
     * @param transNo
     * @return
     */
    public ResponseVo querySubsProduct(Map<String, Object> paramMap, String transNo) {
        try {
            String provinceId;
            if (!StringUtils.isEmpty(JsonUtils.parseString(paramMap.get(ParamConstants.MSISDN)))) {
                provinceId = iCache.getMsisdnProvince(JsonUtils.parseString(paramMap.get(ParamConstants.MSISDN)));
            } else if (StringUtils.isNotEmpty(JsonUtils.parseString(paramMap.get(CUST_ID)))) {
                provinceId = iCache.getCustomerProvince(JsonUtils.parseString(paramMap.get(CUST_ID)));
            } else {
                provinceId = JsonUtils.parseString(paramMap.get("provinceid"));
            }
            if (provinceId == null) {
                iLog.info(logger, transNo, null, "required msisdn ,custID or provinceid as param");
                return ResponseVo.fail(DalServiceErrorCode.ERROR_INVALID_PARAMS);
            }
            //TODO 用全局库测试 提交打开注释
            setDatasourceByProvince(provinceId);
            Map<String, Object> entity = new HashMap<>(2);
            entity.put("provinceid",provinceId);
            entity.put(ParamConstants.MSISDN,paramMap.get(ParamConstants.MSISDN));
            entity.put(PROD_STATUS,PROD_NORMAL);
            //获取查询信息
            MsisdnCacheVo msisdnCacheVo = cache.getByMsisdn(String.valueOf(paramMap.get("msisdn")));
            if(msisdnCacheVo != null){
                String custId = msisdnCacheVo.getCustId();
                entity.put(CUST_ID,custId);
            }
            paramMap.put("entity",entity);
            setPageInfo(paramMap);
            //此处用isExport来判断当前查询操作是异步导出还是查询 只是查询 加一
            paramMap.put(PAGE_END,Integer.parseInt(paramMap.get(PAGE_END).toString())+1);
            PageResultVo pageResultVo = new PageResultVo();
            paramMap.put("provinceId",provinceId);
            pageResultVo.setList(userService.querySubsProduct(paramMap));
            return ResponseVo.success(pageResultVo);
        } catch (RuntimeException e) {
            iLog.error(logger, transNo, null, "Failed to querySubsProduct data:", e);
            return ResponseVo.fail(DalServiceErrorCode.ERROR_ACCESS_DB);
        }
    }

    public ResponseVo queryMsisdnByPhone(Map<String, String> map){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        List<UserMsisdnDetail> msisdnList = userService.queryMsisdnByPhone(map);
        return ResponseVo.success(msisdnList);
    }

    public String getUserStatus(Map<String, String> map){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxUserInfoDao.getUserStatus(map);
    }

    public ResponseVo getUserType(Map<String, String> map){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return ResponseVo.success(wxUserInfoDao.getUserType(map));
    }

    public ResponseVo getUserPhoneByOpenId(Map<String, String> map){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return ResponseVo.success(wxUserInfoDao.getUserPhoneByOpenId(map));
    }

    public ResponseVo getMsisdnStatus(String msisdn){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return ResponseVo.success(userService.getMsisdnStatus(msisdn));
    }

}
