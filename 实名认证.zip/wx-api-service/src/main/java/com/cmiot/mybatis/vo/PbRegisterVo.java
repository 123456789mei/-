package com.cmiot.mybatis.vo;

public class PbRegisterVo {
    //身份证号
    private String idCard;
    //证件类型
    private String type;
    //证件姓名
    private String name;
    //证件地址
    private String address;
    //证件名族
    private String nation;
    //证件性别
    private String sex;
    //证件出生日期
    private String birthday;
    //证件有效开始日期
    private String startDate;
    //证件有效结束日期
    private String endDate;
    //签发机关信息
    private String info;
    //物联卡号
    private String msisdn;
    //卡唯一标识
    private String iccid;
    //认证时间
    private String registerTime;
    //用户手机号
    private String phone;
    //卡归属省id（PB）
    private String beid;
    //认证响应码
    private String registerCode;
    //账户id
    private String userId;
    //照片_身份证正面
    private String picZ;
    //照片_身份证反面
    private String picF;
    //视频截图v1
    private String picV1;
    //视频截图v2
    private String picV2;
    //照片_身份证正面-图片名
    private String nameZ;
    //照片_身份证反面-图片名
    private String nameF;
    //视频截图v1-图片名
    private String nameV1;
    //视频截图v2-图片名
    private String nameV2;
    //订单号
    private String orderNum;
    //流程状态（0：待同步，1：已同步 2：等待信息补全 3：流程已结束）
    private String status;
    //订单流水号
    private String transId;
    //调在线公司接口的发起时间
    private String flowstartTime;
    //调省侧同步接口的时间
    private String syncTime;
    //归属地市
    private String regionId;
    //集团编码
    private String custId;
    //集团名称
    private String custName;
    //地市名称
    private String regionName;

    //实名登记H5渠道的调用标识，非必须
    private int msgId;
    //实名登记H5渠道使用的调用渠道号
    private String channelId;

    private String subOrderId;
    private String loginAccept;
    //安徽奇瑞定制需求
    private String orderNo;

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getIccid() {
        return iccid;
    }

    public void setIccid(String iccid) {
        this.iccid = iccid;
    }

    public String getRegisterTime() {
        return registerTime;
    }

    public void setRegisterTime(String registerTime) {
        this.registerTime = registerTime;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getBeid() {
        return beid;
    }

    public void setBeid(String beid) {
        this.beid = beid;
    }

    public String getRegisterCode() {
        return registerCode;
    }

    public void setRegisterCode(String registerCode) {
        this.registerCode = registerCode;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPicZ() {
        return picZ;
    }

    public void setPicZ(String picZ) {
        this.picZ = picZ;
    }

    public String getPicF() {
        return picF;
    }

    public void setPicF(String picF) {
        this.picF = picF;
    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


    public String getTransId() {
        return transId;
    }

    public void setTransId(String transId) {
        this.transId = transId;
    }


    public String getPicV1() {
        return picV1;
    }

    public void setPicV1(String picV1) {
        this.picV1 = picV1;
    }

    public String getPicV2() {
        return picV2;
    }

    public void setPicV2(String picV2) {
        this.picV2 = picV2;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getFlowstartTime() {
        return flowstartTime;
    }

    public void setFlowstartTime(String flowstartTime) {
        this.flowstartTime = flowstartTime;
    }

    public String getSyncTime() {
        return syncTime;
    }

    public void setSyncTime(String syncTime) {
        this.syncTime = syncTime;
    }

    public String getNameZ() {
        return nameZ;
    }

    public void setNameZ(String nameZ) {
        this.nameZ = nameZ;
    }

    public String getNameF() {
        return nameF;
    }

    public void setNameF(String nameF) {
        this.nameF = nameF;
    }

    public String getNameV1() {
        return nameV1;
    }

    public void setNameV1(String nameV1) {
        this.nameV1 = nameV1;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getRegionId() {
        return regionId;
    }

    public void setRegionId(String regionId) {
        this.regionId = regionId;
    }

    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    public int getMsgId() {
        return msgId;
    }

    public void setMsgId(int msgId) {
        this.msgId = msgId;
    }

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    public String getSubOrderId() {
        return subOrderId;
    }

    public void setSubOrderId(String subOrderId) {
        this.subOrderId = subOrderId;
    }

    public String getLoginAccept() {
        return loginAccept;
    }

    public void setLoginAccept(String loginAccept) {
        this.loginAccept = loginAccept;
    }

    public String getNameV2() {
        return nameV2;
    }

    public void setNameV2(String nameV2) {
        this.nameV2 = nameV2;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
}
