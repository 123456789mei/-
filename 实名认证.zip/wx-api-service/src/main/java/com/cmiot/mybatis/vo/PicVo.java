package com.cmiot.mybatis.vo;

public class PicVo {
    //图片名
    private String picName;
    //图片路径
    private String picUrl;

    public String getPicName() {
        return picName;
    }

    public void setPicName(String picName) {
        this.picName = picName;
    }

    public String getPicUrl() {
        return picUrl;
    }

    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }

}
