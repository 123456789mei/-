package com.cmiot.mybatis.service;

import com.cmiot.ms.dal.common.orcl.NormalBaseService;
import com.cmiot.mybatis.dao.MsisdnBindDao;
import com.cmiot.wx.apiservice.utiles.CommonConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * @author xiapeicheng
 * @date 2019/9/11 15:14
 * @email xiapeicheng@cmiot.chinamobile.com
 */
@Service
public class MsisdnBindService extends NormalBaseService {

    @Autowired
    MsisdnBindDao msisdnBindDao;

    public long queryMsisdnBindCount(Map map){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return msisdnBindDao.queryMsisdnBindCount(map);
    }

    public void updateBindMsisdnCustid(Map map){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        msisdnBindDao.updateBindMsisdnCustid(map);
    }

    public void changeBossMsisdnBindStatus(Map map){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        msisdnBindDao.changeBossMsisdnBindStatus(map);
    }

}
