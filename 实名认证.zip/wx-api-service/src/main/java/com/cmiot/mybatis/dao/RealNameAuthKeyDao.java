package com.cmiot.mybatis.dao;

import com.cmiot.mybatis.vo.MsgOlAuthKey;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * Created by zhang pengfei on 2019/1/17.
 * <p>
 * 描述：
 * ***************更新历史***************
 */
@Mapper
public interface RealNameAuthKeyDao {

    void updateKeyStatus(MsgOlAuthKey desKeyInfo);

    //can be integrated into one method
    void saveFailedDesKey(MsgOlAuthKey desKeyInfo);

    void saveSuccessDesKey(MsgOlAuthKey desKeyInfo);

    void saveFailSignatureKey(MsgOlAuthKey desKeyInfo);

    void saveSuccessSignatureKey(MsgOlAuthKey desKeyInfo);

     Map<String,String> queryValidKeyInfo(String busiCode);

    String queryKeyById(String id);
}
