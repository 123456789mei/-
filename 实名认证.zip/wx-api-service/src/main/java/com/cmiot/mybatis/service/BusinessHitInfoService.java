//package com.cmiot.mybatis.service;
//
//import com.alibaba.fastjson.JSONObject;
//import com.cmiot.commons.common.constants.RequestConstants;
//import com.cmiot.commons.log.ILog;
//import com.cmiot.commons.response.ResponseVo;
//import com.cmiot.ms.dal.common.orcl.NormalBaseService;
//import com.cmiot.mybatis.dao.BusinessHitInfoDao;
//import com.cmiot.wx.apiservice.utiles.CommonConstant;
//import com.cmiot.wx.apiservice.utiles.DalServiceErrorCode;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.Map;
//
///**
// * Created by HONG on 2019/4/18.
// */
//@Service
//public class BusinessHitInfoService extends NormalBaseService {
//
//    static Logger logger = LoggerFactory.getLogger(BusinessHitInfoService.class);
//
//    @Autowired
//    private BusinessHitInfoDao businessHitInfoDao;
//
//    @Autowired
//    ILog iLog;
//
//    public void insertBusinessHitInfo(Map params){
//        String transNo = params.get(CommonConstant.TRANSNO) == null ? "" : params.get(CommonConstant.TRANSNO).toString();
//        try {
//            setAsDefaultDatasource();
//            Integer number = businessHitInfoDao.insertBusinessHitInfo(params);
//            if (number > 0){
//                iLog.info(logger , transNo , params , "业务点击操作信息入库成功!");
//            } else {
//                iLog.error(logger , transNo , params , "业务点击操作信息入库失败!");
//            }
//        } catch (Exception e) {
//            iLog.trace(logger,transNo,params,"业务点击操作信息入库异常",e);
//        }
//    }
//}
