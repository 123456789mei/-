package com.cmiot.mybatis.dao;

import com.cmiot.mybatis.vo.CmPsRegisterVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface QueryRegisterDao {
    long queryPbCount(Map map);
    long queryCtCount(Map map);
    List<CmPsRegisterVO> queryByPb(Map map);
    List<CmPsRegisterVO> queryByCt(Map map);
    List<CmPsRegisterVO> listNoPageByPb(Map<String, Object> paramMap);

    List<CmPsRegisterVO> listNoPageByCt(Map<String, Object> paramMap);
}
