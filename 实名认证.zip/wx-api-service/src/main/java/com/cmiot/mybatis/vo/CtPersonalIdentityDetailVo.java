package com.cmiot.mybatis.vo;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.*;

import java.util.Date;

/**
 * @author S.j@onlying.cn
 * @date 2020/3/9 17:33:17
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CtPersonalIdentityDetailVo {

    @JSONField(name = "CUST_CERT_NO")
    private String custCertNo;//	String	V32	1	身份证号码
    @JSONField(name = "ICCID")
    private String iccid;//	String	V32	1	ICCID号码
    @JSONField(name = "MSISDN")
    private String msisdn;//	String	V32	1	卡号
    @JSONField(name = "BE_ID")
    private String beId;//	String	V10	1	省ID
    @JSONField(name = "CUST_PHONE_NO")
    private String custPhoneNo;//	String	V32	1	手机号
    @JSONField(name = "BILL_ID")
    private String billId;//	String	V32	1	办理业务的用户的电话号码，如果是开户操作，则是开户号码
    @JSONField(name = "REAL_NAME_TRANS_ID")
    private String realNameTransId;//	String	V32	1	实名认证流水号
    @JSONField(name = "CHANNEL_ID")
    private String channelId;//	String	V32	1	营业员所属渠道全网统一的渠道编号
    @JSONField(name = "OPER_CODE")
    private String operCode;//	String	V32	1	营业员的工号
    @JSONField(name = "KEEP_PARAM")
    private String keepParam;//	String	V32	1	预留业务字段
    @JSONField(name = "OPER_TEL")
    private String operTel;//	String	V32	1	电话
    @JSONField(name = "SOURCE_TYPE")
    private String sourceType;//	String	V3	1	1：二代证读卡器；2：实名制系统对接的工单 3：其它 填固定值“3”
    @JSONField(name = "CUST_ID")
    private String custId;//	NUMBER	v20	1	客户ID
    @JSONField(name = "CUST_PHOTO_IDENTITY")
    private byte[] custPhotoIdentity;//	BLOB	BLOB	1	用户身份证芯片头像图片
    @JSONField(name = "CUST_PHOTO_SCENE")
    private byte[] custPhotoScene;//	BLOB	BLOB	1	用户现场头像图片
    @JSONField(name = "CHANGE_INFO_TRANS_ID")
    private String changeInfoTransId;//	String	V60	1	信息登记订单号
    @JSONField(name = "AUTH_CHANNEL")
    private String authChannel;//	String	V4	1	认证渠道
    @JSONField(name = "CREATE_TIME", format = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;//	DATE	DATE	1	创建时间
    @JSONField(name = "MODIFY_TIME", format = "yyyy-MM-dd HH:mm:ss")
    private Date modifyTime;//	DATE	DATE	1	修改时间
    @JSONField(name = "RECORD_STATUS")
    private String recordStatus;//	String	V24	1	记录状态：0无效，1有效，默认1
    @JSONField(name = "CUST_PHOTO_FRONT")
    private byte[] custPhotoFront;//	BLOB	BLOB	1	用户证件正面图片
    @JSONField(name = "CUST_PHOTO_BACK")
    private byte[] custPhotoBack;//	BLOB	BLOB	1	用户证件反面图片

    private String id;
    private Integer used;
    private Date indexDate;
}
