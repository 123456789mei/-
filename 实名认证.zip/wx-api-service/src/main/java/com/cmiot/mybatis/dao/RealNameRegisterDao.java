package com.cmiot.mybatis.dao;

import com.cmiot.mybatis.vo.*;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface RealNameRegisterDao {
    /**
     * 查询已成功登记的物联卡信息
     *
     * @param msisdn
     * @return
     */
    Map<String, String> getRealNameRegisterWithSuccess(String msisdn);

    /**
     * 物联卡登记信息存储
     *
     * @param map
     */
    void saveRealNameRegisterInfo(Map<String, String> map);


    /**
     * 根据输入的用户身份信息（输入的身份证和姓名）查询是否存在
     * @param map
     * @return
     */
    long userIdentityInfoCount(Map<String, String> map);

    /**
     * 查询是否已实名认证
     * @param map
     * @return
     */
    long isAuthed(Map<String, String> map);

    void insertMsisdnRealNameInfo(Map<String, String> map);

    void updateRealNameInfo(Map<String, String> map);

    void insertRegisterInfo(Map map);

    /**
     * 获取ct实名记录
     */
    List<CtRealNameVo> queryCtRealNameInfo();

    /**
     * 更新活体认证结果
     */
    void updateCtRealNameResult(CtRealNameVo vo);

    /**
     * 获取活体认证使用人信息
     */
    List<CtRealNameVo> queryModifyInfo();

    /**
     * kafka获取实名结果
     * @return
     */
    CtRealNameVo queryCtRealNameByKafka(String busiSeq);

    /**
     * 获取活体url
     */
    String querySysParam(String paramId);

    /**
     * Ct活体认证判断是否存在重复记录
     */
    int queryWaitInfo(String msisdn);
	
    /**
     * 临时处理，给register_code打-40
     */
    void updateSameCode(String busiSeq);

    /**
     * 过滤相同订单号重复发起请求
     */
    int querySameBusiseq(String busiSeq);

    /**
     * 根据subsid获取卡号信息
     */
    CtRealNameVo getInfoBySubsId(String subsId);


    /**
     * 根据subsid获取卡号信息(H5)
     */
    CtRealNameVo getInfoBySubsIdH5(String subsId);

    /**
     * 实名登记埋点
     */
    void addInnerStatisRecord(Map map);

    void saveRegisterH5Info(RegisterH5Info registerH5Info );

    List<RegisterH5Info> queryNeedSendH5Info();

    void modifyH5Info(RegisterH5Info registerH5Info);

    void insertRegisterStatusOrder(Map map);

    List<CtRegisterOrderVo> queryWaitOrder();

    void updateOrderStatus(String orderId);

    void batchUpdateOrderStatus(List<String> list);

    List<CardRegisterVo> queryCtRegisterList(Map params);

    void updateChangeStatusByBusiSeq(String busiSeq);

    void updateChangeStatusByJobId(String jobId);

    void modifyChangeStatus(String busiSeq);

    List<CtRegisterOrderVo> queryJobId();

    int queryStatusIsChange(String jobId);

    List<String> queryTimeoutOrder();

    void batchUpdateTimeoutStatus(List<String> list);

    void UpdateTimeoutStatus(String jobId);

    void updateTrafficCount();

    void deleteTrafficCount();

    String queryH5custList(Map map);

    List<CardRegisterVo> queryPbRegisterList(Map map);

    int queryRegisterInfoDao(Map map);

    //ct集团信息处理
    List<CTCustomerVO> queryCt01();
    List<CTCustomerVO> queryCt03();
    void addCustomer(CTCustomerVO vo);
    int queryIsRepeat();

    //查询cust_code
    String queryCustIdBymsisdn(String msisdn);
    String queryCustCodeById(int custId);

    List<TrafficVo> queryTrafficHis();

    void updateTrafficHis(int id);

    void insertTrafficRecord(Map map);
}
