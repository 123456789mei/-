package com.cmiot.mybatis.service;

import com.cmiot.commons.log.ILog;
import com.cmiot.ms.dal.common.orcl.NormalBaseService;
import com.cmiot.mybatis.dao.WxLogDao;
import com.cmiot.wx.apiservice.utiles.CommonConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Map;
import java.util.UUID;

@Service
public class WxLogService extends NormalBaseService {

    @Autowired
    WxLogDao wxLogDao;

    @Autowired
    ILog iLog;

    static Logger logger = LoggerFactory.getLogger(WxLogService.class);

    public void insertWxLog(Map params) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        params.put("id", UUID.randomUUID().toString().replaceAll("-", "").toUpperCase());
        params.put("platType", "2");//平台 1:运管平台 2:API
        params.put("account", "");//设置账户为空
        params.put("createDate", new Date());
        logger.info("移动端API记录日志 params: {}", params);
        wxLogDao.insertWxLog(params);
    }

}
