package com.cmiot.mybatis.dao;

import com.cmiot.mybatis.vo.PbRegisterVo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * pb物联卡实名认证
 * xiajunchen
 * 2020-8-19
 */

@Mapper
public interface PbRegisterDao {

    /**
     * 调在线公司前的信息入库
     * */
    void registerInfoInsert(PbRegisterVo vo);

    /*
    在线公司回传时查询认证记录
     */
    List<PbRegisterVo> queryInfo(String orderNum);

    /*
    在线公司回传时更新认证记录
     */
    void updateInfoByOnline(PbRegisterVo vo);

    /*
    更新认证结果和修改状态
     */
    void updateResult(PbRegisterVo vo);

    /*
    定时任务：更新图片url
     */
    void updateUrl(Map map);

    List<PbRegisterVo> querySyncInfo();

    /**
     * 查询订单流水
     */
    List<PbRegisterVo> queryOrderNum(Map map);

    /**
     * 通过订单号获取卡号
     */
    String getMsisdnByOrderNum(String orderNum);

    /**
     *限制订单发起时间
     */
    int queryWaitInfoPb(String msisdn);

    /**
     * 限制订单重复发起请求
     * @return
     */
    int querySameOrderNum(String orderNum);

    int queryCountTest();

    int datasourcetest();

    void insertShPbRegister(Map map);

    String queryOrderNoByBusiseq(String orderNum);
}
