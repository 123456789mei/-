package com.cmiot.mybatis.service;

import com.cmiot.api.client.ICtBusinessSerClient;
import com.cmiot.api.service.AuthenticationServiceClient;
import com.cmiot.api.service.UserService;
import com.cmiot.common.ct.access.entity.CTRequestFactory;
import com.cmiot.common.ct.access.entity.CTResponse;
import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.cache.impl.CacheManager;
import com.cmiot.commons.common.constants.ParamConstants;
import com.cmiot.commons.common.utils.HttpRequestClient;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.response.ResponseCode;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.ftp.realname.SFTPUtil;
import com.cmiot.ftp.realname.SftpEntity;
import com.cmiot.ftp.realname.UpLoadFile;
import com.cmiot.ms.dal.common.orcl.NormalBaseService;
import com.cmiot.mybatis.dao.RealNameRegisterDao;
import com.cmiot.mybatis.vo.*;
import com.cmiot.util.CCMPResult;
import com.cmiot.util.CCMPUtil;
import com.cmiot.util.PbRegisterCode;
import com.cmiot.util.RegisterCode;
import com.cmiot.wx.apiservice.config.AddrConfig;
import com.cmiot.wx.apiservice.service.CTUserService;
import com.cmiot.wx.apiservice.service.CommonSmsService;
import com.cmiot.wx.apiservice.utiles.CommonConstant;
import com.cmiot.wx.apiservice.utiles.HttpUtils;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 实名登记信息数据操作
 */
@Service
public class RealNameRegisterService extends NormalBaseService {

    static Logger logger = LoggerFactory.getLogger(RealNameRegisterService.class);

    private HttpRequestClient client = new HttpRequestClient();

    @Autowired
    RealNameRegisterDao realNameRegisterDao;

    @Autowired
    ThreadPoolTaskExecutor pushExecutor;

    @Autowired
    ICache cache;

    @Autowired
    HttpUtils httpUtils;

    @Autowired
    AddrConfig addrConfig;

    @Autowired
    WxPersonUserInfoService wxPersonUserInfoService;

    @Autowired
    CTUserService ctUserService;

    @Autowired
    ICtBusinessSerClient iCtBusinessSerClient;

    @Autowired
    CommonSmsService commonSmsService;

    @Autowired
    UserService userService;

    @Autowired
    CTRequestFactory ctRequestFactory;

    @Autowired
    AuthenticationServiceClient authenticationServiceClient;

    /**
     * 是否已实名认证
     * @param map
     * @return
     */
    public boolean authed(Map map){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return realNameRegisterDao.isAuthed(map) == 0;
    }
    /**
     * 校验用户输入信息是否和账户实名信息一致
     *
     * @param map
     * @return
     */
    public boolean isUserIdentityInfo(Map map) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return realNameRegisterDao.userIdentityInfoCount(map) > 0;
    }

    /**
     * 查询物联卡是否已完成实名登记
     *
     * @param msisdn
     * @return
     */
    public Map<String, String> getSuccessRegisterInfo(String msisdn) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return realNameRegisterDao.getRealNameRegisterWithSuccess(msisdn);
    }

    /**
     * 存储实名认证登记信息
     * @deprecated 已废弃
     * 4.300.8.8版本
     * @param map
     */
    public void saveRealNameRegisterInfo(Map<String, String> map) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        //新增一个向业务系统推送结果的步奏
        if(map.get("channelId") !=null){
            sendRegisterResult(map);
        }
        //检查物联卡是否已存在有效登记记录
        if (CommonConstant.WX_CT_CODE_SUCCESS.equals(map.get("registerCode"))) {
            Map registerInfo = realNameRegisterDao.getRealNameRegisterWithSuccess(map.get(ParamConstants.MSISDN));
            if (registerInfo != null && registerInfo.size() > 0) {
                String custCerNo = String.valueOf(registerInfo.get("custCerNo"));
                if (registerInfo.get("custCerNo") != null && !StringUtils.isEmpty(custCerNo)) {
                    if (!custCerNo.equals(map.get(CommonConstant.FIELD_CUSTCERTNO))) {
//                        logger.info("已存在的身份证信息与登记信息不符，历史信息作废，保存新的信息，oldCust is:[{}]，newCustInfo is:[{}]", custCerNo, JsonUtils.parseString(map));
                        Map<String, String> updateMap = new HashMap<String, String>();
                        updateMap.put(CommonConstant.FIELD_MSISDN, map.get(CommonConstant.FIELD_MSISDN));
                        updateMap.put("registerCode", "40132"); //物联卡被他人登记
                        realNameRegisterDao.updateRealNameInfo(updateMap);
                        //入库新数据
                        realNameRegisterDao.insertMsisdnRealNameInfo(map);
                    } else {
                        logger.info("物联卡实名登记：与历史信息一致，放弃入库操作");
                    }
                } else {
                    logger.error("物联卡实名登记查询：有成功记录，但是身份信息缺失，数据异常，终止新数据入库，data is:[{}]", JsonUtils.parseString(map));
                }
            } else {
                //未发现已存在的成功记录，直接入库
                realNameRegisterDao.insertMsisdnRealNameInfo(map);
            }
        } else {
            //失败的认证记录，直接入库
            realNameRegisterDao.insertMsisdnRealNameInfo(map);
        }
    }

    /**
     * TODO 4.300.8.5.1 临时版本需求
     * 向实名登记H5接入的业务系统推送认证结果
     * @author lixiangcheng
     * */
    public void sendRegisterResult(Map map){
        String channelId = String.valueOf(map.get("channelId"));
        if("null".equals(channelId)||StringUtils.isEmpty(channelId)){
            logger.info("实名登记H5登记数据，参数中未获取到调用渠道，放弃推送登记结果:[{}]",map.get(CommonConstant.FIELD_MSISDN));
        }else {
            String backUrl = cache.getDictValueBy(ParamConstants.DEFAULT_LANG,"realNameH5",channelId);
            if(StringUtils.isEmpty(backUrl)){
                logger.info("实名登记H5登记数据，未查询到渠道回调地址，放弃推送登记结果:[{}]",map.get(CommonConstant.FIELD_MSISDN));
            }else {
                //推送数据
                pushExecutor.execute(new Runnable() {
                    @Override
                    public void run() {
                        Map pushMap = new HashMap<>();
                        pushMap.put(CommonConstant.FIELD_MSISDN,map.get(CommonConstant.FIELD_MSISDN)); //登记物联卡号
                        pushMap.put(CommonConstant.REAL_NAME_PUSH_NAME,map.get(CommonConstant.REAL_NAME_PUSH_NAME)); //登记使用人姓名
                        pushMap.put(CommonConstant.REAL_NAME_PUSH_CUSTCERTNO,map.get(CommonConstant.REAL_NAME_PUSH_CUSTCERTNO)); //登记使用人身份证号
                        pushMap.put(CommonConstant.REAL_NAME_PUSH_REGISTERCODE,map.get(CommonConstant.REAL_NAME_PUSH_REGISTERCODE)); //登记结果 0 或 00000 成功，其他 登记失败
                        pushMap.put(CommonConstant.REAL_NAME_PUSH_REGISTERTIME,new Date().getTime()); //登记时间
                        pushMap.put(CommonConstant.PHONE,map.get(CommonConstant.PHONE)); //登记人手机号
                        logger.info("实名登记H5登记数据,调用渠道：[{}],推送地址：[{}]", channelId, backUrl);
                        Map<String, String> header = new HashMap<String, String>(1);
                        header.put("PUSH-REMOTE", backUrl);//真实的三方系统接口地址
                        String responseStr = httpUtils.post("realNameH5_".concat(channelId), addrConfig.getRealNamePushAddr(), JsonUtils.parseString(pushMap), HttpRequestClient.CONTENT_TYPE_JSON, header);
                        logger.info("实名登记H5登记数据，推送业务平台,result is:[{}]",responseStr);
                    }
                });
            }
        }
    }

    public void sendRegisterResult551(Map map){
        String channelId = String.valueOf(map.get("channelId"));
        if("null".equals(channelId)||StringUtils.isEmpty(channelId)){
            logger.info("实名登记H5登记数据，参数中未获取到调用渠道，放弃推送登记结果:[{}]",map.get(CommonConstant.FIELD_MSISDN));
        }else {
            String backUrl = cache.getDictValueBy(ParamConstants.DEFAULT_LANG,"realNameH5",channelId);
            if(StringUtils.isEmpty(backUrl)){
                logger.info("实名登记H5登记数据，未查询到渠道回调地址，放弃推送登记结果:[{}]",map.get(CommonConstant.FIELD_MSISDN));
            }else {
                //推送数据
                pushExecutor.execute(new Runnable() {
                    @Override
                    public void run() {
                        Map pushMap = new HashMap<>();
                        pushMap.put(CommonConstant.FIELD_MSISDN,map.get(CommonConstant.FIELD_MSISDN)); //登记物联卡号
                        pushMap.put("orderNo",map.get("orderNo")); //订单号
                        pushMap.put("isAuth",map.get("isAuth")); //登记结果 00000成功
                        pushMap.put("msg",map.get("msg")); //失败详情
                        pushMap.put("name",map.get("name"));
                        pushMap.put("idCard",map.get("idCard"));
                        pushMap.put("phone",map.get("phone"));
                        pushMap.put(CommonConstant.REAL_NAME_PUSH_REGISTERTIME,new Date().getTime());
                        logger.info("实名登记H5登记数据,调用渠道：[{}],推送地址：[{}]", channelId, backUrl);
                        Map<String, String> header = new HashMap<String, String>(1);
                        header.put("PUSH-REMOTE", backUrl);//真实的三方系统接口地址
                        String responseStr = httpUtils.post("realNameH5_".concat(channelId), addrConfig.getRealNamePushAddr(), JsonUtils.parseString(pushMap), HttpRequestClient.CONTENT_TYPE_JSON, header);
                        logger.info("实名登记H5登记数据，推送业务平台,result is:[{}]",responseStr);
                    }
                });
            }
        }
    }

    /**
     * 查询卡状态和bbc授权
     */
    public ResponseVo queryBbccStatus(Map map){
        Map<String,Object> result=new HashMap<>();
        //bbc授权判断
        result.put("flag",wxPersonUserInfoService.validateBBC(map)?"0":"1");
        logger.info("{}授权状态（0已授权，1未授权）：{}",map.get("msisdn"),result.get("flag"));
        //卡状态
        ResponseVo basicInfo = ctUserService.queryCardBasicInfo(map);
        if(basicInfo.isSuccess()&&basicInfo.getData()!=null){
            Map obj = JsonUtils.parseObject(basicInfo.getData(), Map.class);
            result.put("custId",obj.get("custId"));
            result.put("beId",obj.get("beId"));
            result.put("status",obj.get("status"));
//            logger.info("queryBbccStatus success...{}",JsonUtils.parseString(result));
            return ResponseVo.success(result);
        }else {
            logger.info("queryBbccStatus fail...{}",JsonUtils.parseString(basicInfo));
            return ResponseVo.fail("99");
        }
    }

    /**
     * 获取实名登记url
     */
    public ResponseVo startCtRegister(Map map){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        Map<String,String> params=new HashMap<>();
        params.put("beId",map.get("beId").toString());
        params.put("custId",map.get("custId").toString());
        params.put("msisdn",map.get("msisdn").toString());

        String transNo=map.get("transNo")!=null?map.get("transNo").toString():"";
        Calendar calendar = Calendar.getInstance();
        Date date = calendar.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        if("".equals(transNo)){
            transNo=sdf.format(date)+map.get("msisdn");
            map.put("transNo",transNo);
        }
        //增加入库限制
        int waitCount = realNameRegisterDao.queryWaitInfo(map.get("msisdn").toString());
        if(waitCount>0){
            logger.info("startCtRegister存在重复记录，跳过...{}",map.get("msisdn").toString());
            return ResponseVo.fail("4014");
        };
        //生成流水与时间戳
        //String ccmpSeq = CCMPUtil.getCcmpSeq(CCMPUtil.STARTREGISTER, transNo);

        Map pMap=new HashMap();
        //平台校验id
        //pMap.put("appid", cache.getSysParams("CCMP_APPID", ""));
        //平台校验密码串
        //pMap.put("appsecret", cache.getSysParams("CCMP_APPSECRET", ""));
        //pMap.put(ParamConstants.CCMP_SEQ, ccmpSeq);
        //pMap.put(ParamConstants.CCMP_REQUEST_TIME, CCMPUtil.getTime());
        pMap.put("params", params);
        //String baseUrl = cache.getSysParams(ParamConstants.CCMP_URL, "");
        //String url = baseUrl + CCMPUtil.STARTREGISTER_URL;
        try {
//            logger.info("准备请求ccmp getLiveCollectJumpKey,参数检查params:{}",JsonUtils.parseString(pMap));
            String ctresOut = iCtBusinessSerClient.getLiveCollectJumpKey(transNo, pMap);
            //String ctresOut = client.post(transNo, url, pMap, client.CONTENT_TYPE_JSON);
            logger.info("msisdn:{},ccmp返回结果...{}",map.get("msisdn").toString(),ctresOut);
            ResponseVo response = CCMPUtil.ccmpResponse(ctresOut);
            //获取活体认证url
            String backUrl=cache.getSysParams("CT_REALNAME_URL","");
            if("".equals(backUrl)){
                setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
                backUrl= userService.querySysParam("CT_REALNAME_URL");
            }
            if(response!=null&&response.isSuccess()&&response.getData()!=null){
                CCMPResult ccmpResult = JsonUtils.parseObject(response.getData(), CCMPResult.class);
                List<CcmpRealNameVo> voList = JsonUtils.parseList(ccmpResult.getRows(), CcmpRealNameVo.class);
                if(voList!=null&&voList.size()>0){
                    if("0".equals(voList.get(0).getReturnCode())){
                        logger.info("获取url成功...{}",JsonUtils.parseString(voList));
                        map.put("busiSeq",voList.get(0).getBusiSeq());
                        //判断是否做卡激活操作
                        map.put("opts","0".equals(map.get("isActive"))?"0":"1");
                        map.put("plat","realNameH5".equals(map.get("userId").toString())?"03":"00");
                        backUrl=backUrl+voList.get(0).getVideoUrl();
                        ctresOut = iCtBusinessSerClient.getSubsId(transNo, pMap);
                        logger.info("msisdn:{},ccmp getSubsId返回结果...{}",map.get("msisdn").toString(),ctresOut);
                        ResponseVo res = CCMPUtil.ccmpResponse(ctresOut);
                        if(res!=null&&res.isSuccess()&&res.getData()!=null){
                            ccmpResult = JsonUtils.parseObject(res.getData(), CCMPResult.class);
                            voList = JsonUtils.parseList(ccmpResult.getRows(), CcmpRealNameVo.class);
                            if(voList!=null&&voList.size()>0){
                                map.put("subsId",voList.get(0).getSubsId());
                            }
                        }

                        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
                        //信息第一次入库
                        realNameRegisterDao.insertRegisterInfo(map);
                        return ResponseVo.success(backUrl);
                    }else {
                        return ResponseVo.fail("88",voList.get(0).getReturnMessage());
                    }
                }else {
                    logger.info("获取url失败...{}",JsonUtils.parseString(ccmpResult));
                    return ResponseVo.fail("99");
                }
            }else {
                return response;
            }
        } catch (Exception e) {
            logger.info("startCtRegister exception...{}",e);
            return ResponseVo.fail(ResponseCode.ERROR_SYS);
        }
    }

    /**
     * 获取实名登记url-API
     */
    public ResponseVo startCtRegisterApi(Map map){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        Map<String,String> params=new HashMap<>();
        params.put("beId",map.get("beId").toString());
        params.put("custId",map.get("custId").toString());
        params.put("msisdn",map.get("msisdn").toString());

        String transNo=map.get("transNo")!=null?map.get("transNo").toString():"";
        Calendar calendar = Calendar.getInstance();
        Date date = calendar.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        if("".equals(transNo)){
            transNo=sdf.format(date)+map.get("msisdn");
            map.put("transNo",transNo);
        }
        //增加入库限制
        int waitCount = realNameRegisterDao.queryWaitInfo(map.get("msisdn").toString());
        if(waitCount>0){
            logger.info("startCtRegisterApi存在重复记录，跳过...{}",map.get("msisdn").toString());
            return ResponseVo.fail("4014");
        };

        Map pMap=new HashMap();
        pMap.put("params", params);
        try {
//            logger.info("api准备请求ccmp getLiveCollectJumpKey,参数检查params:{}",JsonUtils.parseString(pMap));
            String ctresOut = iCtBusinessSerClient.getLiveCollectJumpKey(transNo, pMap);
            logger.info("msisdn:{},ccmp返回结果api...{}",map.get("msisdn").toString(),ctresOut);
            ResponseVo response = CCMPUtil.ccmpResponse(ctresOut);
            //获取活体认证url
            String backUrl=cache.getSysParams("CT_REALNAME_URL","");
            if("".equals(backUrl)){
                setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
                backUrl=userService.querySysParam("CT_REALNAME_URL");
            }
            if(response!=null&&response.isSuccess()&&response.getData()!=null){
                CCMPResult ccmpResult = JsonUtils.parseObject(response.getData(), CCMPResult.class);
                List<CcmpRealNameVo> voList = JsonUtils.parseList(ccmpResult.getRows(), CcmpRealNameVo.class);
                if(voList!=null&&voList.size()>0){
                    if("0".equals(voList.get(0).getReturnCode())){
                        logger.info("获取url成功api...{}",JsonUtils.parseString(voList));
                        map.put("busiSeq",voList.get(0).getBusiSeq());
                        //判断是否做卡激活操作
                        map.put("opts","0".equals(map.get("isActive"))?"0":"1");
                        map.put("plat","realNameH5".equals(map.get("userId").toString())?"03":"00");
                        backUrl=backUrl+voList.get(0).getVideoUrl();
//                        logger.info("api准备请求ccmp getSubsId,参数检查params:{}",JsonUtils.parseString(pMap));
                        ctresOut = iCtBusinessSerClient.getSubsId(transNo, pMap);
                        logger.info("msisdn:{},ccmp getSubsId返回结果api...{}",map.get("msisdn").toString(),ctresOut);
                        ResponseVo res = CCMPUtil.ccmpResponse(ctresOut);
                        if(res!=null&&res.isSuccess()&&res.getData()!=null){
                            ccmpResult = JsonUtils.parseObject(res.getData(), CCMPResult.class);
                            voList = JsonUtils.parseList(ccmpResult.getRows(), CcmpRealNameVo.class);
                            if(voList!=null&&voList.size()>0){
                                map.put("subsId",voList.get(0).getSubsId());
                            }
                        }

                        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
                        //信息第一次入库
                        realNameRegisterDao.insertRegisterInfo(map);
                        //封装返回参数
                        Map resultApi=new HashMap();
                        resultApi.put("videoUrl",backUrl);
                        resultApi.put("busiSeq",map.get("busiSeq"));
                        return ResponseVo.success(resultApi);
                    }else {
                        return ResponseVo.fail("88",new String[]{voList.get(0).getReturnMessage()});
                    }
                }else {
                    logger.info("获取url失败api...{}",JsonUtils.parseString(ccmpResult));
                    return ResponseVo.fail("99");
                }
            }else {
                return response;
            }
        } catch (Exception e) {
            logger.info("startCtRegisterApi exception...{}",e);
            return ResponseVo.fail(ResponseCode.ERROR_SYS);
        }
    }

    /**
     * 实名埋点
     */
    public void innerStatisService(String step){
        //存入缓存，0点刷入数据库
        switch (step){
            case "one":
                cache.incr(CacheManager.PublicNameSpace.TEMP, "INNERSTATIS_ONE", -1);
                return;
            case "twoct":
                cache.incr(CacheManager.PublicNameSpace.TEMP, "INNERSTATIS_TWOCT", -1);
                return;
            case "threect":
                cache.incr(CacheManager.PublicNameSpace.TEMP, "INNERSTATIS_THREECT", -1);
                return;
            case "twopb":
                cache.incr(CacheManager.PublicNameSpace.TEMP, "INNERSTATIS_TWOPB", -1);
                return;
            case "threepb":
                cache.incr(CacheManager.PublicNameSpace.TEMP, "INNERSTATIS_THREEPB", -1);
                return;
            case "fourpb":
                cache.incr(CacheManager.PublicNameSpace.TEMP, "INNERSTATIS_FOURPB", -1);
                return;
        }
    }

    /**
     * 埋点入库
     */
    public void saveCacheStatis(){
        try {
            //刷入数据库
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
            int one=Integer.parseInt(cache.get(CacheManager.PublicNameSpace.TEMP,"INNERSTATIS_ONE")!=null?
                    cache.get(CacheManager.PublicNameSpace.TEMP,"INNERSTATIS_ONE"):"0");
            int twoct=Integer.parseInt(cache.get(CacheManager.PublicNameSpace.TEMP,"INNERSTATIS_TWOCT")!=null?
                    cache.get(CacheManager.PublicNameSpace.TEMP,"INNERSTATIS_TWOCT"):"0");
            int threect=Integer.parseInt(cache.get(CacheManager.PublicNameSpace.TEMP,"INNERSTATIS_THREECT")!=null?
                    cache.get(CacheManager.PublicNameSpace.TEMP,"INNERSTATIS_THREECT"):"0");
            int twopb=Integer.parseInt(cache.get(CacheManager.PublicNameSpace.TEMP,"INNERSTATIS_TWOPB")!=null?
                    cache.get(CacheManager.PublicNameSpace.TEMP,"INNERSTATIS_TWOPB"):"0");
            int threepb=Integer.parseInt(cache.get(CacheManager.PublicNameSpace.TEMP,"INNERSTATIS_THREEPB")!=null?
                    cache.get(CacheManager.PublicNameSpace.TEMP,"INNERSTATIS_THREEPB"):"0");
            int fourpb=Integer.parseInt(cache.get(CacheManager.PublicNameSpace.TEMP,"INNERSTATIS_FOURPB")!=null?
                    cache.get(CacheManager.PublicNameSpace.TEMP,"INNERSTATIS_FOURPB"):"0");
            Map map=new HashMap();
            map.put("one",one);
            map.put("twoct",twoct);
            map.put("threect",threect);
            map.put("twopb",twopb);
            map.put("threepb",threepb);
            map.put("fourpb",fourpb);
            cache.remove(CacheManager.PublicNameSpace.TEMP,"INNERSTATIS_ONE");
            cache.remove(CacheManager.PublicNameSpace.TEMP,"INNERSTATIS_TWOCT");
            cache.remove(CacheManager.PublicNameSpace.TEMP,"INNERSTATIS_THREECT");
            cache.remove(CacheManager.PublicNameSpace.TEMP,"INNERSTATIS_TWOPB");
            cache.remove(CacheManager.PublicNameSpace.TEMP,"INNERSTATIS_THREEPB");
            cache.remove(CacheManager.PublicNameSpace.TEMP,"INNERSTATIS_FOURPB");
            realNameRegisterDao.addInnerStatisRecord(map);
            logger.info("埋点入库成功...{}",JsonUtils.parseString(map));
        }catch (Exception e){
            logger.info("埋点入库报错...{}",e);
        }
    }

    public void queryOrderStatusService(){
        //第一步：刷h5推送
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        List<RegisterH5Info> H5List = realNameRegisterDao.queryNeedSendH5Info();
        for (RegisterH5Info v :
                H5List) {
            try {
                String subsId=v.getSubsId();
                CtRealNameVo infoBySubsId = realNameRegisterDao.getInfoBySubsIdH5(subsId);
                if(infoBySubsId==null){
                    logger.info("没有匹配数据{}",JsonUtils.parseString(v));
                    continue;
                }else {
                    infoBySubsId.setIdCard(v.getIdNumber());
                    infoBySubsId.setName(v.getName());
                    logger.info("数据已匹配，准备推送{}",JsonUtils.parseString(infoBySubsId));
                    if("oneLinkApiPb".equals(infoBySubsId.getUserId())){
                        pushApiRegisterResult(infoBySubsId,"00000");
                    }else {
                        pushCTRegisterResult(infoBySubsId,infoBySubsId.getRegisterCode());
                    }
                    logger.info("已推送完成，修改数据库状态{}",JsonUtils.parseString(infoBySubsId));
                    realNameRegisterDao.modifyH5Info(v);
                }
            }catch (Exception e){
                logger.info("定时推送h5报错...{}",e);
            }
        }
        //第二步：刷订单状态
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        List<CtRegisterOrderVo> list = realNameRegisterDao.queryJobId();
        if(list!=null||list.size()>0){
            Map params=new HashMap();
            //获取ftp连接信息(ip,端口号,目录,用户名,密码)
            String ftpConnect = cache.getSysParams("register_ftp_connect", "");
            SFTPUtil ft=new SFTPUtil();
            SftpEntity sftpEntity = new SftpEntity(ft, ftpConnect.split(",")[0], Integer.parseInt(ftpConnect.split(",")[1]), ftpConnect.split(",")[3], ftpConnect.split(",")[4], "3000");
            ChannelSftp sftp =  sftpConnect(sftpEntity.getChannel(), ftpConnect.split(",")[2]);
            //写入appid和calling_nbr对应关系
//            String custList = cache.getSysParams("register_appid_custcode", "");
//            Map<String,String> map=JsonUtils.parseObject(custList,Map.class);
            for (CtRegisterOrderVo v:
                    list ) {
                try{
                    params.put("beId",v.getBeId());
                    params.put("custId",v.getCustId());
                    params.put("orderId",v.getJobId());
                    if(realNameRegisterDao.queryStatusIsChange(v.getJobId())>0){
                        continue;
                    }
                    String result = iCtBusinessSerClient.queryOrderStatus(v.getTransNo(), params);
                    if("1".equals(result)){
                        //实名状态变更成功,更新状态
                        realNameRegisterDao.updateChangeStatusByJobId(v.getJobId());
                        commonSmsService.sendRegisterResult(v.getPhone(),v.getMsisdn(),"00000","",v.getTransNo());
                        logger.info("ct订单状态已变更成功msisdn:{},jobId:{}",v.getMsisdn(),v.getJobId());
                        //流控处理
                        dealH5Traffic(v.getMsgId(),2,v.getTransNo());
                        if("0".equals(v.getIsActive())){
                            //卡激活操作
                            Map<String,String> activeMap=new HashMap<>();
                            activeMap.put("msisdn",v.getMsisdn());
                            activeMap.put("beId",v.getBeId());
                            activeMap.put("custId",v.getCustId());
                            //获取卡状态
                            ResponseVo basicInfo = ctUserService.queryCardBasicInfo(activeMap);
                            if(basicInfo.isSuccess()&&basicInfo.getData()!=null){
                                Map obj = JsonUtils.parseObject(basicInfo.getData(), Map.class);
                                logger.info("获取卡状态 success...msisdn:{},status:{}",v.getMsisdn(),JsonUtils.parseString(basicInfo));
                                activeMap.put("status",obj.getOrDefault("status","").toString());
                                activeMap.put("realname","1");
                            }
                            ResponseVo activateResp = ctUserService.activateCardFromCT(activeMap, v.getTransNo());
                            logger.info("卡激活结果msisdn:{}...{}",v.getMsisdn(),JsonUtils.parseString(activateResp));
                        }
                        //传话单
                        if(org.apache.commons.lang3.StringUtils.isNotBlank(v.getChannelId())
                                &&"0".equals(cache.getSysParams("register_ftp_control",""))){
                            long s1=System.currentTimeMillis();
//                            String custCode=map.get(v.getChannelId());
//                            if(org.apache.commons.lang3.StringUtils.isBlank(custCode)){
//                                logger.info("{}不存在，跳过",v.getChannelId());
//                                continue;
//                            }
                            //序列号自增
                            String seq = cache.get(CacheManager.PublicNameSpace.TEMP, "REALNAME_H5_SEQ");
                            if(seq==null||"".equals(seq)){
                                seq="0";
                            }
                            int count=Integer.parseInt(seq)+1;
                            cache.put(CacheManager.PublicNameSpace.TEMP,"REALNAME_H5_SEQ",count+"");
                            String fileName="IOT_0_0_"+getTime()+"_"+count;
                            //获取商品编码
                            String goods_code = cache.getSysParams("register_goods_code_ct", "");
                            logger.info("名称：{},商品编码:{}",fileName,goods_code);
                            Map paramMap=new HashMap();
                            paramMap.put("calling_nbr",v.getChannelId());
                            paramMap.put("goods_code",goods_code);
                            paramMap.put("frequency","1");
                            paramMap.put("called_nbr","");
                            paramMap.put("event_begin_time",System.currentTimeMillis()+"");
                            paramMap.put("event_end_time",System.currentTimeMillis()+"");
                            paramMap.put("location","");
                            paramMap.put("apn","");
                            paramMap.put("roaming_flag","");
                            String paramJson="["+JsonUtils.parseString(paramMap)+"]";
                            //写文件
                            String fName=fileName+".cdr";
                            if(null == sftpEntity.getChannel()){
                                 sftpEntity = new SftpEntity(ft, ftpConnect.split(",")[0], Integer.parseInt(ftpConnect.split(",")[1]), ftpConnect.split(",")[3], ftpConnect.split(",")[4], "3000");
                                 sftp =  sftpConnect(sftpEntity.getChannel(), ftpConnect.split(",")[2]);
                                 if(null == sftpEntity.getChannel()){
                                     logger.info("连接计费系统sftp失败");
                                     continue;
                                 }
                            }
                            if(sftp.isConnected()) {
                                logger.info("Connected {} : {} ",ftpConnect.split(",")[0], Integer.parseInt(ftpConnect.split(",")[1]));
                                sftp.put(UpLoadFile.getStrToStream(paramJson), fName);
                                Map p=new HashMap();
                                p.put("msisdn",v.getMsisdn());
                                p.put("fileName",fName);
                                p.put("channelId",v.getChannelId());
                                //成功上传话单后 入库记录
                                setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
                                realNameRegisterDao.insertTrafficRecord(p);
                                logger.info("{}上传成功,耗时:{}",v.getMsisdn(),System.currentTimeMillis()-s1);
                            }
                        }
                    }
                }catch (Exception e){
                    logger.info("ct定时更新实名状态失败，jobId:{}",v.getJobId());
                }
            }
            // 关闭sftp连接
            ft.closeAll(sftp, sftpEntity.getChannel(), sftpEntity.getSession());
        }
        //将超过两小时的订单设置为超时
        List<String> timeoutList = realNameRegisterDao.queryTimeoutOrder();
        if(timeoutList!=null&&timeoutList.size()>0){
            if(timeoutList.size()<1000){
                realNameRegisterDao.batchUpdateTimeoutStatus(timeoutList);
            }else {
                for (String v :
                        timeoutList) {
                    realNameRegisterDao.UpdateTimeoutStatus(v);
                }
            }
        }
    }
    //前端实名状态0：处理中 1：成功 2:处理超时，其他为具体失败代码
    public ResponseVo queryCardRegisterList(Map params){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        //ct
        List<CardRegisterVo> list = realNameRegisterDao.queryCtRegisterList(params);
        for (CardRegisterVo vo:
                list ) {
            if("1".equals(vo.getChangeStatus())){
                vo.setRegisterStatus("1");
            }else if("0".equals(vo.getChangeStatus())){
                vo.setRegisterStatus("2");
            }else if(StringUtils.isEmpty(vo.getRegisterCode())||"00000".equals(vo.getRegisterCode())&&!"1".equals(vo.getChangeStatus())){
                vo.setRegisterStatus("0");
            }else if("2".equals(vo.getAuditStatus())||"4".equals(vo.getAuditStatus())){
                vo.setRegisterStatus("1001");
                vo.setMsg(vo.getAuditMessage());
                vo.setMsgDetail(vo.getAuditMessage());
            }else if(!StringUtils.isEmpty(vo.getRegisterCode())&&!"00000".equals(vo.getRegisterCode())){
                vo.setRegisterStatus(vo.getRegisterCode());
                vo.setMsg(RegisterCode.getmsg(vo.getRegisterCode()));
                vo.setMsgDetail(RegisterCode.getmsgDetail(vo.getRegisterCode()));
            }
        }
        //pb
        List<CardRegisterVo> pbRegisterList = realNameRegisterDao.queryPbRegisterList(params);
        for (CardRegisterVo vo:
                pbRegisterList ) {
            if("00000".equals(vo.getRegisterCode())){
                vo.setRegisterStatus("1");
            }else if("0".equals(vo.getAuditStatus())||"2".equals(vo.getAuditStatus())){
                vo.setRegisterStatus("0");
            }else{
                vo.setRegisterStatus("1001");
                vo.setMsg("其他错误");
                vo.setMsgDetail(PbRegisterCode.getResult(vo.getRegisterCode()));
            }
        }
        try {
            list.addAll(pbRegisterList);
            list.sort(Comparator.comparing(CardRegisterVo::getStartTime));
            // (2)倒序排列
            Collections.reverse(list);
            logger.info("userId:{},卡实名查询size:{}",params.get("userId"),list.size());
            return ResponseVo.success(list);
        }catch (Exception e){
            return ResponseVo.success(new ArrayList<CardRegisterVo>());
        }
    }

    /**
     * 更新流控表
     */
    public void updateTrafficControl(){
        try {
            //刷入数据库
            setAsDefaultDatasource();
            realNameRegisterDao.updateTrafficCount();
            //删除记录
            realNameRegisterDao.deleteTrafficCount();
            logger.info("更新流控表完成...");
        }catch (Exception e){
            logger.info("更新流控表报错...{}",e);
        }
    }

    /**
     * 查询企业名称
     */
    public ResponseVo queryCustNameByAppId(Map map){
        try {
            //刷入数据库
            setAsDefaultDatasource();
            return   ResponseVo.success(realNameRegisterDao.queryH5custList(map));
        }catch (Exception e){
            logger.info("{}查询企业名称...{}",map.get("appId"),e);
        }
        return ResponseVo.success("");
    }

    /**
     * 实名查询
     */
    public ResponseVo queryRegisterInfoService(Map map){
        Map result=new HashMap();
        try {
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
            String count = realNameRegisterDao.queryRegisterInfoDao(map) > 0 ? "0" : "1";
            result.put("isAuth",count);
        }catch (Exception e){
            logger.info("{}实名查询接口报错...{}",map.get("msisdn"),e);
        }
        return   ResponseVo.success(result);
    }

    private void pushApiRegisterResult(CtRealNameVo ctRegisterVo,String status){
        Map map=new HashMap();
        map.put("registerCode",status);
        map.put("registerMsg",ctRegisterVo.getRegisterMsg());
        map.put("msisdn",ctRegisterVo.getMsisdn());
        map.put("name",ctRegisterVo.getName());
        map.put("custCertNo",ctRegisterVo.getIdCard());
        map.put("phone",ctRegisterVo.getPhone());
        map.put("registerTime",ctRegisterVo.getRegisterTime());
        map.put("busiSeq",ctRegisterVo.getBusiSeq());
        String transNo=ctRegisterVo.getTransNo();
        if(transNo==null||"".equals(transNo)||transNo.contains("know")){
            transNo= UUID.randomUUID().toString().replace("-","");
        }
        logger.info("{},pushApiRegisterResult回传前检查",ctRegisterVo.getMsisdn());
        CTResponse response = ctRequestFactory.pushRegisterApi(map, transNo);
        logger.info("{},pushApiRegisterResult结果:{}",ctRegisterVo.getMsisdn(),JsonUtils.parseString(response));
    }

    private void pushCTRegisterResult(CtRealNameVo ctRegisterVo,String status){
        if(!org.apache.commons.lang.StringUtils.isEmpty(ctRegisterVo.getChannelId())){
            try {
                //具备渠道编码，确定是从H5渠道发起的认证
                Map<String,String> pushData = new HashMap<>();
                pushData.put("channelId",ctRegisterVo.getChannelId());
                pushData.put(CommonConstant.FIELD_MSISDN,ctRegisterVo.getMsisdn());
                pushData.put(CommonConstant.REAL_NAME_PUSH_NAME, org.apache.commons.lang.StringUtils.isNotBlank(ctRegisterVo.getName())?ctRegisterVo.getName():"");
                pushData.put(CommonConstant.REAL_NAME_PUSH_CUSTCERTNO, org.apache.commons.lang.StringUtils.isNotBlank(ctRegisterVo.getIdCard())?ctRegisterVo.getIdCard():"");
                pushData.put(CommonConstant.REAL_NAME_PUSH_REGISTERCODE,status); //登记结果 0 或 00000 成功，其他 登记失败
                pushData.put(CommonConstant.PHONE,ctRegisterVo.getPhone());
                logger.info("ct实名登记h5推送结果msisdn:{}",ctRegisterVo.getMsisdn());
                sendRegisterResult(pushData);
            }catch (Exception e){
                logger.info("推送CT物联卡登记结果报错:{}...{}",ctRegisterVo.getMsisdn(),e);
            }
        }
    }

    public ResponseVo modifyCtService(){
        try {
            setAsDefaultDatasource();
            //判断是否反复执行
            if(realNameRegisterDao.queryIsRepeat()>0){
                logger.info("ct集团表修复不可重复执行，请先还原表数据");
                return ResponseVo.success("不可重复执行");
            }
            //opcode=1的数据去重
            logger.info("ct集团表修复开始");
            long start= System.currentTimeMillis();
            List<CTCustomerVO> list01 = realNameRegisterDao.queryCt01();
            Map<String,CTCustomerVO> map=new HashMap<>();
            for (CTCustomerVO v :
                    list01) {
                if (StringUtils.isEmpty(map.get(v.getCUST_CODE()))) {
                    map.put(v.getCUST_CODE(),v);
                }else if(timeToCompare(map.get(v.getCUST_CODE()).getCREATE_TIME(),v.getCREATE_TIME())){
                    map.put(v.getCUST_CODE(),v);
                }
            }
            //opcode=3的数据合并
            List<CTCustomerVO> list03 = realNameRegisterDao.queryCt03();
            Map<String,CTCustomerVO> map03=new HashMap<>();
            for (CTCustomerVO v:
                    list03) {
                if (StringUtils.isEmpty(map03.get(v.getCUST_CODE()))) {
                    map03.put(v.getCUST_CODE(),v);
                }else if(timeToCompare(map03.get(v.getCUST_CODE()).getMODIFY_TIME(),v.getMODIFY_TIME())){
                    CTCustomerVO old = map03.get(v.getCUST_CODE());
                    if(!"".equals(v.getCUST_ID())&&v.getCUST_ID()!=0){
                        old.setCUST_ID(v.getCUST_ID());
                    }
                    if(v.getCUST_CODE()!=null&&!"".equals(v.getCUST_CODE())){
                        old.setCUST_CODE(v.getCUST_CODE());
                    }
                    if(v.getCUST_NAME()!=null&&!"".equals(v.getCUST_NAME())){
                        old.setCUST_NAME(v.getCUST_NAME());
                    }
                    if(!"".equals(v.getCUST_TYPE())&&v.getCUST_TYPE()!=0){
                        old.setCUST_TYPE(v.getCUST_TYPE());
                    }
                    if(!"".equals(v.getCUST_STATUS())&&v.getCUST_STATUS()!=0){
                        old.setCUST_STATUS(v.getCUST_STATUS());
                    }
                    if(v.getMODIFY_TIME()!=null&&!"".equals(v.getMODIFY_TIME())){
                        old.setMODIFY_TIME(v.getMODIFY_TIME());
                    }
                    if(v.getREGION_ID()!=null&&!"".equals(v.getREGION_ID())){
                        old.setREGION_ID(v.getREGION_ID());
                    }
                    if(v.getOP_CODE()!=null&&!"".equals(v.getOP_CODE())){
                        old.setOP_CODE(v.getOP_CODE());
                    }
                    if(v.getSEX()!=null&&!"".equals(v.getSEX())){
                        old.setSEX(v.getSEX());
                    }
                    if(v.getACCT_TYPE()!=null&&!"".equals(v.getACCT_TYPE())){
                        old.setACCT_TYPE(v.getACCT_TYPE());
                    }
                    if(v.getEFFECT_TIME()!=null&&!"".equals(v.getEFFECT_TIME())){
                        old.setEFFECT_TIME(v.getEFFECT_TIME());
                    }
                    if(v.getEXPIRE_TIME()!=null&&!"".equals(v.getEXPIRE_TIME())){
                        old.setEXPIRE_TIME(v.getEXPIRE_TIME());
                    }
                    if(v.getORGID()!=null&&!"".equals(v.getORGID())){
                        old.setORGID(v.getORGID());
                    }
                    if(v.getBE_ID()!=null&&!"".equals(v.getBE_ID())){
                        old.setBE_ID(v.getBE_ID());
                    }
                    if(!"".equals(v.getP_CUST_ID())&&v.getP_CUST_ID()!=0){
                        old.setP_CUST_ID(v.getP_CUST_ID());
                    }
                    if(!"".equals(v.getDEF_ACCT_ID())&&v.getDEF_ACCT_ID()!=0){
                        old.setDEF_ACCT_ID(v.getDEF_ACCT_ID());
                    }
                    if(v.getCUST_SEGMENT()!=null&&!"".equals(v.getCUST_SEGMENT())){
                        old.setCUST_SEGMENT(v.getCUST_SEGMENT());
                    }
                    if(!"".equals(v.getCUST_CLASS())&&v.getCUST_CLASS()!=0){
                        old.setCUST_CLASS(v.getCUST_CLASS());
                    }
                    if(v.getCUST_LEVEL()!=null&&!"".equals(v.getCUST_LEVEL())){
                        old.setCUST_LEVEL(v.getCUST_LEVEL());
                    }
                    if(!"".equals(v.getCUST_LEVEL1())&&v.getCUST_LEVEL1()!=0){
                        old.setCUST_LEVEL1(v.getCUST_LEVEL1());
                    }
                    if(v.getSTATUS_REASON()!=null&&!"".equals(v.getSTATUS_REASON())){
                        old.setSTATUS_REASON(v.getSTATUS_REASON());
                    }
                    if(v.getCUST_CREDIT_LEVEL()!=null&&!"".equals(v.getCUST_CREDIT_LEVEL())){
                        old.setCUST_CREDIT_LEVEL(v.getCUST_CREDIT_LEVEL());
                    }
                    if(v.getCUST_GLOBAL_TRADE_ID()!=null&&!"".equals(v.getCUST_GLOBAL_TRADE_ID())){
                        old.setCUST_GLOBAL_TRADE_ID(v.getCUST_GLOBAL_TRADE_ID());
                    }
                    map03.put(old.getCUST_CODE(),old);
                }
            }
            //将op=3的数据根据cust_code更新到op=1上
            List<CTCustomerVO> result=new ArrayList<>();
            for(Map.Entry<String, CTCustomerVO> entry : map.entrySet()){
                if(StringUtils.isEmpty(map03.get(entry.getKey()))){
                    result.add(entry.getValue());
                }else {
                    CTCustomerVO old = entry.getValue();
                    CTCustomerVO v = map03.get(entry.getKey());
                    if(!"".equals(v.getCUST_ID())&&v.getCUST_ID()!=0){
                        old.setCUST_ID(v.getCUST_ID());
                    }
                    if(v.getCUST_CODE()!=null&&!"".equals(v.getCUST_CODE())){
                        old.setCUST_CODE(v.getCUST_CODE());
                    }
                    if(v.getCUST_NAME()!=null&&!"".equals(v.getCUST_NAME())){
                        old.setCUST_NAME(v.getCUST_NAME());
                    }
                    if(!"".equals(v.getCUST_TYPE())&&v.getCUST_TYPE()!=0){
                        old.setCUST_TYPE(v.getCUST_TYPE());
                    }
                    if(!"".equals(v.getCUST_STATUS())&&v.getCUST_STATUS()!=0){
                        old.setCUST_STATUS(v.getCUST_STATUS());
                    }
                    if(v.getMODIFY_TIME()!=null&&!"".equals(v.getMODIFY_TIME())){
                        old.setMODIFY_TIME(v.getMODIFY_TIME());
                    }
                    if(v.getREGION_ID()!=null&&!"".equals(v.getREGION_ID())){
                        old.setREGION_ID(v.getREGION_ID());
                    }
                    if(v.getOP_CODE()!=null&&!"".equals(v.getOP_CODE())){
                        old.setOP_CODE(v.getOP_CODE());
                    }
                    if(v.getSEX()!=null&&!"".equals(v.getSEX())){
                        old.setSEX(v.getSEX());
                    }
                    if(v.getACCT_TYPE()!=null&&!"".equals(v.getACCT_TYPE())){
                        old.setACCT_TYPE(v.getACCT_TYPE());
                    }
                    if(v.getEFFECT_TIME()!=null&&!"".equals(v.getEFFECT_TIME())){
                        old.setEFFECT_TIME(v.getEFFECT_TIME());
                    }
                    if(v.getEXPIRE_TIME()!=null&&!"".equals(v.getEXPIRE_TIME())){
                        old.setEXPIRE_TIME(v.getEXPIRE_TIME());
                    }
                    if(v.getORGID()!=null&&!"".equals(v.getORGID())){
                        old.setORGID(v.getORGID());
                    }
                    if(v.getBE_ID()!=null&&!"".equals(v.getBE_ID())){
                        old.setBE_ID(v.getBE_ID());
                    }
                    if(!"".equals(v.getP_CUST_ID())&&v.getP_CUST_ID()!=0){
                        old.setP_CUST_ID(v.getP_CUST_ID());
                    }
                    if(!"".equals(v.getDEF_ACCT_ID())&&v.getDEF_ACCT_ID()!=0){
                        old.setDEF_ACCT_ID(v.getDEF_ACCT_ID());
                    }
                    if(v.getCUST_SEGMENT()!=null&&!"".equals(v.getCUST_SEGMENT())){
                        old.setCUST_SEGMENT(v.getCUST_SEGMENT());
                    }
                    if(!"".equals(v.getCUST_CLASS())&&v.getCUST_CLASS()!=0){
                        old.setCUST_CLASS(v.getCUST_CLASS());
                    }
                    if(v.getCUST_LEVEL()!=null&&!"".equals(v.getCUST_LEVEL())){
                        old.setCUST_LEVEL(v.getCUST_LEVEL());
                    }
                    if(!"".equals(v.getCUST_LEVEL1())&&v.getCUST_LEVEL1()!=0){
                        old.setCUST_LEVEL1(v.getCUST_LEVEL1());
                    }
                    if(v.getSTATUS_REASON()!=null&&!"".equals(v.getSTATUS_REASON())){
                        old.setSTATUS_REASON(v.getSTATUS_REASON());
                    }
                    if(v.getCUST_CREDIT_LEVEL()!=null&&!"".equals(v.getCUST_CREDIT_LEVEL())){
                        old.setCUST_CREDIT_LEVEL(v.getCUST_CREDIT_LEVEL());
                    }
                    if(v.getCUST_GLOBAL_TRADE_ID()!=null&&!"".equals(v.getCUST_GLOBAL_TRADE_ID())){
                        old.setCUST_GLOBAL_TRADE_ID(v.getCUST_GLOBAL_TRADE_ID());
                    }
                    result.add(old);
                }
            }
            for(Map.Entry<String, CTCustomerVO> entry : map03.entrySet()){
                if(StringUtils.isEmpty(map.get(entry.getKey()))){
                    result.add(entry.getValue());
                }
            }
            logger.info("重新入库条数:{}",result.size());
            //解密入库
            for (CTCustomerVO v :
                    result) {
                try {
                    if (v.getCUST_NAME()==null||"".equals(v.getCUST_NAME().trim())||isContainChinese(v.getCUST_NAME())||isAllNumber(v.getCUST_NAME())){
                        realNameRegisterDao.addCustomer(v);
                        continue;
                    }
                    v.setCUST_NAME(getBase64DecodeString(v.getCUST_NAME()));
                }catch (Exception e){
                    logger.info("对象解密入库报错:{}",JsonUtils.parseString(v));
                }
                realNameRegisterDao.addCustomer(v);
            }
//        //分组导入
//        logger.info("需要解密数量:{}",result.size());
//        List<CTCustomerVO> paramsList = new ArrayList<>();
//        int mapIndex = 0, tempSize = 0;
//        Map<String, List> paramsMap= new HashMap<>(50);
//        for (CTCustomerVO v : result) {
//            paramsList.add(v);
//            tempSize ++;
//            if (paramsList.size() == 1000 || tempSize == result.size()) {
//                paramsMap.put(String.valueOf(mapIndex), paramsList);
//                mapIndex += 1;
//                paramsList = new ArrayList<>();
//            }
//        }
//        logger.info("需要解密集合数:{}",paramsMap.size());
//        for (int i = 0; i < paramsMap.size(); i++) {
//            realNameRegisterDao.insertCustomerTemp(paramsMap.get(i+""));
//        }
            logger.info("ct集团修复结束:{}",System.currentTimeMillis()-start);
            return ResponseVo.success("成功");
        }catch (Exception e){
            logger.info("ct集团修复报错:{}",e);
            return ResponseVo.success("失败");
        }
    }

    public ResponseVo sendHisOrderService(){
        setAsDefaultDatasource();
        List<TrafficVo> list = realNameRegisterDao.queryTrafficHis();
        logger.info("需要传话单条数：{}",list.size());
        long s1=System.currentTimeMillis();
        //写入appid和calling_nbr对应关系
//        String custList = cache.getSysParams("register_appid_custcode", "");
//        Map<String,String> map=JsonUtils.parseObject(custList,Map.class);
        //获取ftp连接信息(ip,端口号,目录,用户名,密码)
        String ftpConnect = cache.getSysParams("register_ftp_connect", "");
        SFTPUtil ft=new SFTPUtil();
        SftpEntity sftpEntity = new SftpEntity(ft, ftpConnect.split(",")[0], Integer.parseInt(ftpConnect.split(",")[1]), ftpConnect.split(",")[3], ftpConnect.split(",")[4], "3000");
        ChannelSftp sftp =  sftpConnect(sftpEntity.getChannel(), ftpConnect.split(",")[2]);
        for (TrafficVo v:
                list) {
            try {
//                String custCode=map.get(v.getAppId());
//                if(org.apache.commons.lang3.StringUtils.isBlank(custCode)){
//                    logger.info("{}不存在，跳过",v.getAppId());
//                    continue;
//                }
                //序列号自增
                String seq = cache.get(CacheManager.PublicNameSpace.TEMP, "REALNAME_H5_SEQ");
                if(seq==null||"".equals(seq)){
                    seq="0";
                }
                int count=Integer.parseInt(seq)+1;
                cache.put(CacheManager.PublicNameSpace.TEMP,"REALNAME_H5_SEQ",count+"");
                String fileName="IOT_0_0_"+getTime()+"_"+count;
                //获取商品编码
                String goods_code = cache.getSysParams("register_goods_code_ct", "");
                logger.info("名称：{},商品编码:{}",fileName,goods_code);
                Map paramMap=new HashMap();
                paramMap.put("calling_nbr",v.getAppId());
                paramMap.put("goods_code",goods_code);
                paramMap.put("frequency","1");
                paramMap.put("called_nbr","");
                paramMap.put("event_begin_time",System.currentTimeMillis()+"");
                paramMap.put("event_end_time",System.currentTimeMillis()+"");
                paramMap.put("location","");
                paramMap.put("apn","");
                paramMap.put("roaming_flag","");
                String paramJson="["+JsonUtils.parseString(paramMap)+"]";
                //写文件
                String fName=fileName+".cdr";
                if(null == sftpEntity.getChannel()){
                    sftpEntity = new SftpEntity(ft, ftpConnect.split(",")[0], Integer.parseInt(ftpConnect.split(",")[1]), ftpConnect.split(",")[3], ftpConnect.split(",")[4], "3000");
                    sftp =  sftpConnect(sftpEntity.getChannel(), ftpConnect.split(",")[2]);
                    if(null == sftpEntity.getChannel()){
                        logger.info("连接计费系统sftp失败");
                        continue;
                    }
                }
                if(sftp.isConnected()) {
                    logger.info("Connected {} : {} ",ftpConnect.split(",")[0], Integer.parseInt(ftpConnect.split(",")[1]));
                    sftp.put(UpLoadFile.getStrToStream(paramJson), fName);
                    realNameRegisterDao.updateTrafficHis(v.getId());
                }
            }catch (Exception e){
                logger.info("{}报错...",v.getAppId());
            }
        }
        // 关闭sftp连接
        ft.closeAll(sftp, sftpEntity.getChannel(), sftpEntity.getSession());
        logger.info("话单全部完成，耗时{}",System.currentTimeMillis()-s1);
        return ResponseVo.success("ok");
    }

//    public static void main(String[] strs){
//        List<TrafficVo> list = new ArrayList<>();
//        TrafficVo trafficVo =new TrafficVo();
//        trafficVo.setAppId("test");
//        trafficVo.setId(1);
//        list.add(trafficVo);
//        TrafficVo trafficVo2 =new TrafficVo();
//        trafficVo2.setAppId("test");
//        trafficVo2.setId(2);
//        list.add(trafficVo2);
//        long s1=System.currentTimeMillis();
//        Map<String,String> map=new HashMap();
//        //写入appid和calling_nbr对应关系
//        map.put("test","1234567890123");
//        //获取ftp连接信息(ip,端口号,目录,用户名,密码)
//        String ftpConnect = "10.19.103.71,22,/iot/cdrdispatch/apicall/,smrztest,!QAZ2wsx";
//        SFTPUtil ft=new SFTPUtil();
//        SftpEntity sftpEntity = new SftpEntity(ft, ftpConnect.split(",")[0], Integer.parseInt(ftpConnect.split(",")[1]), ftpConnect.split(",")[3], ftpConnect.split(",")[4], "3000");
//        ChannelSftp sftp =  sftpConnect(sftpEntity.getChannel(), ftpConnect.split(",")[2]);
//        int count=1;
//        for (TrafficVo v:
//                list) {
//            try {
//                count++;
//                String custCode=map.get(v.getAppId());
//                if(org.apache.commons.lang3.StringUtils.isBlank(custCode)){
//                    logger.info("{}不存在，跳过",v.getAppId());
//                    continue;
//                }
//                //序列号自增
//
//                Date date=new Date(System.currentTimeMillis());
//                SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
//                String fileName="IOT_0_0_"+sdf.format(date)+"_"+count;
//                Map paramMap=new HashMap();
//                paramMap.put("calling_nbr",custCode);
//                paramMap.put("goods_code","OneLink_realname");
//                paramMap.put("frequency",1);
//                paramMap.put("called_nbr","");
//                paramMap.put("event_begin_time",System.currentTimeMillis());
//                paramMap.put("event_end_time",System.currentTimeMillis());
//                paramMap.put("location","");
//                paramMap.put("apn","");
//                paramMap.put("roaming_flag","");
//                String paramJson="["+JsonUtils.parseString(paramMap)+"]";
//                //写文件
//                String fName=fileName+".txt";
//                if(null == sftpEntity.getChannel()){
//                    sftpEntity = new SftpEntity(ft, ftpConnect.split(",")[0], Integer.parseInt(ftpConnect.split(",")[1]), ftpConnect.split(",")[3], ftpConnect.split(",")[4], "3000");
//                    sftp =  sftpConnect(sftpEntity.getChannel(), ftpConnect.split(",")[2]);
//                    if(null == sftpEntity.getChannel()){
//                        logger.info("连接计费系统sftp失败");
//                        continue;
//                    }
//                }
//                if(sftp.isConnected()) {
//                    logger.info("Connected {} : {} ",ftpConnect.split(",")[0], Integer.parseInt(ftpConnect.split(",")[1]));
//                    sftp.put(UpLoadFile.getStrToStream(paramJson), fName);
//                }
//            }catch (Exception e){
//                logger.info("{}报错...",v.getAppId());
//            }
//        }
//        // 关闭sftp连接
//        ft.closeAll(sftp, sftpEntity.getChannel(), sftpEntity.getSession());
//        logger.info("话单全部完成，耗时{}",System.currentTimeMillis()-s1);
//    }

    public boolean timeToCompare(String left,String right){
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            Date l=sdf.parse(left);
            Date r=sdf.parse(right);
            long long1 =l.getTime();
            long long2= r.getTime();
            return long2>long1;
        }catch (Exception e){
            logger.info("时间比较报错{}",e);
            return false;
        }
    }

    public static boolean isContainChinese(String str) {

        Pattern p = Pattern.compile("[\u4e00-\u9fa5]");
        Matcher m = p.matcher(str);
        if (m.find()) {
            return true;
        }
        return false;
    }

    public static boolean isAllNumber(String str) {

        if (str.matches("[0-9]+")) {
            return true;
        }
        return false;
    }

    /**
     * Base64解密
     * @param str Base64加密后的字符串
     * @return 解密后的字符串
     */
    public static String getBase64DecodeString(String str) {
        String result = null;
        if (null != str) {
            try {
                result = new String(Base64.getDecoder().decode(str.getBytes("utf-8")), "utf-8");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    /**
     * 生成时间戳
     */
    public  String getTime(){
        Date date=new Date(System.currentTimeMillis());
        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
        return sdf.format(date);
    }

    /**
     * 获取sftp连接
     *
     * @param channel
     * @param filePath
     * @return
     */
    private static  ChannelSftp sftpConnect(Channel channel, String filePath) {
        ChannelSftp sftp = (ChannelSftp) channel;
        //判断是否存在该目录
        try {
            sftp.cd(filePath);
        } catch (SftpException e) {
            logger.error("sftp上传目录不存在：", e);
        }
        return sftp;
    }

    /**
     * 实名登记H5，流控回收处理
     * */
    public void dealH5Traffic(int msgId, int status, String transNo) {
        if (msgId != 0) {
            //存在消息流水号，消费调用次数
            Map<String, Integer> param = new HashMap<>(2);
            param.put("msgId", msgId);
            param.put("status", status); //2:有效调用 3:无效调用
            ResponseVo verifyStatusVo = authenticationServiceClient.changeVerifyStatus(param);
            if (verifyStatusVo.isSuccess()) {
                logger.info("transNo is:[{}],实名登记H5，限流状态更新成功,msgId is:[{}],status is:[{}]", transNo, msgId, (status == 2) ? "有效调用" : "无效调用");
            } else {
                logger.info("transNo is:[{}],实名登记H5，限流状态更新失败,msgId is:[{}],status is:[{}]", transNo, msgId, (status == 2) ? "有效调用" : "无效调用");
            }
        }
    }

}
