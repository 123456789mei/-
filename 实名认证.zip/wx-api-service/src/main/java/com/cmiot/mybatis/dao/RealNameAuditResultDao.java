package com.cmiot.mybatis.dao;

import com.cmiot.mybatis.vo.MsgOlAuditResult;
import com.cmiot.mybatis.vo.MsgOlAuditResultOpen;
import com.cmiot.mybatis.vo.SaPsCustOpen;
import org.apache.ibatis.annotations.Mapper;

import java.util.Map;

/**
 * Created by zhang pengfei on 2019/1/20.
 * <p>
 * 描述：
 * ***************更新历史***************
 */
@Mapper
public interface RealNameAuditResultDao {

    void updateAuditResult(MsgOlAuditResult auditResult);

    String queryKeyIdBySeq(String busiSeq);

    void saveRealNameRequestInfo(Map<String, Object> paramMap);

    String getRealNameAuthDailyLimit();

    Map getRealNameAuthResultBySeq(String busiSeq);

    /**
     * 保存实名认证开放API记录
     * */
    void saveRealNameRequestForOpen(MsgOlAuditResultOpen auditResultOpen);

    /**
     * 更新实名认证开发API调用结果
     * */
    void updateAuditResultForOpen(MsgOlAuditResultOpen auditResultOpen);

    /**
     * 根据业务Id获取业务系统回调信息
     * */
    MsgOlAuditResultOpen getAuditRequestInfo(MsgOlAuditResultOpen params);

    /**
     * 保存业务系统实名认证的结果信息
     * */
    void saveCustInfoForOpen(SaPsCustOpen cust);

    /**
     * 根据业务流水号获取客户信息
     * */
    SaPsCustOpen getCustInfoById(String busiSeq);
}
