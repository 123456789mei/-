package com.cmiot.mybatis.vo;

import com.alibaba.fastjson.annotation.JSONField;

public class PbRegisterTransVo {
    //身份证号
    @JSONField(name="ID_ICCID")
    private String ID_ICCID;
    //证件类型
    @JSONField(name="ID_TYPE")
    private String ID_TYPE;
    //证件姓名
    @JSONField(name="CUST_NAME")
    private String CUST_NAME;
    //证件地址
    @JSONField(name="ID_ADDRESS")
    private String ID_ADDRESS;
    //证件名族
    @JSONField(name="NATION")
    private String NATION;
    //证件性别
    @JSONField(name="CUST_SEX")
    private String CUST_SEX;
    //证件出生日期
    @JSONField(name="CUST_BORN")
    private String CUST_BORN;
    //证件有效开始日期
    @JSONField(name="CERTEFF_DATE")
    private String CERTEFF_DATE;
    //证件有效结束日期
    @JSONField(name="CERTEXP_DATE")
    private String CERTEXP_DATE;
    //签发机关信息
    @JSONField(name="GRANT_DEPT")
    private String GRANT_DEPT;
    //物联卡号
    @JSONField(name="PHONE_NO")
    private String PHONE_NO;
    //物联卡号
    @JSONField(name="SERVICE_NO")
    private String SERVICE_NO;
    //照片_身份证正面
    @JSONField(name="PICZ")
    private String PICZ;
    //照片_身份证反面
    @JSONField(name="PICF")
    private String PICF;
    //视频截图v1
    @JSONField(name="PICV1")
    private String PICV1;
    //照片_身份证正面-图片名
    @JSONField(name="PICZNAME")
    private String PICZNAME;
    //照片_身份证反面-图片名
    @JSONField(name="PICFNAME")
    private String PICFNAME;
    //视频截图v1-图片名
    @JSONField(name="PICV1NAME")
    private String PICV1NAME;
    //订单号
    @JSONField(name="TRANSACTION_ID")
    private String TRANSACTION_ID;
    //写死代码（调省侧需要）
    @JSONField(name="LOGIN_NO")
    private String LOGIN_NO="YzzzzpzHN";
    //写死代码（调省侧需要）
    @JSONField(name="UUC_LEVEL")
    private String UUC_LEVEL="WLW";

    public String getID_ICCID() {
        return ID_ICCID;
    }

    public void setID_ICCID(String ID_ICCID) {
        this.ID_ICCID = ID_ICCID;
    }

    public String getID_TYPE() {
        return ID_TYPE;
    }

    public void setID_TYPE(String ID_TYPE) {
        this.ID_TYPE = ID_TYPE;
    }

    public String getCUST_NAME() {
        return CUST_NAME;
    }

    public void setCUST_NAME(String CUST_NAME) {
        this.CUST_NAME = CUST_NAME;
    }

    public String getID_ADDRESS() {
        return ID_ADDRESS;
    }

    public void setID_ADDRESS(String ID_ADDRESS) {
        this.ID_ADDRESS = ID_ADDRESS;
    }

    public String getNATION() {
        return NATION;
    }

    public void setNATION(String NATION) {
        this.NATION = NATION;
    }

    public String getCUST_SEX() {
        return CUST_SEX;
    }

    public void setCUST_SEX(String CUST_SEX) {
        this.CUST_SEX = CUST_SEX;
    }

    public String getCUST_BORN() {
        return CUST_BORN;
    }

    public void setCUST_BORN(String CUST_BORN) {
        this.CUST_BORN = CUST_BORN;
    }

    public String getCERTEFF_DATE() {
        return CERTEFF_DATE;
    }

    public void setCERTEFF_DATE(String CERTEFF_DATE) {
        this.CERTEFF_DATE = CERTEFF_DATE;
    }

    public String getCERTEXP_DATE() {
        return CERTEXP_DATE;
    }

    public void setCERTEXP_DATE(String CERTEXP_DATE) {
        this.CERTEXP_DATE = CERTEXP_DATE;
    }

    public String getGRANT_DEPT() {
        return GRANT_DEPT;
    }

    public void setGRANT_DEPT(String GRANT_DEPT) {
        this.GRANT_DEPT = GRANT_DEPT;
    }

    public String getPHONE_NO() {
        return PHONE_NO;
    }

    public void setPHONE_NO(String PHONE_NO) {
        this.PHONE_NO = PHONE_NO;
    }

    public String getSERVICE_NO() {
        return SERVICE_NO;
    }

    public void setSERVICE_NO(String SERVICE_NO) {
        this.SERVICE_NO = SERVICE_NO;
    }

    public String getPICZ() {
        return PICZ;
    }

    public void setPICZ(String PICZ) {
        this.PICZ = PICZ;
    }

    public String getPICF() {
        return PICF;
    }

    public void setPICF(String PICF) {
        this.PICF = PICF;
    }

    public String getPICV1() {
        return PICV1;
    }

    public void setPICV1(String PICV1) {
        this.PICV1 = PICV1;
    }

    public String getPICZNAME() {
        return PICZNAME;
    }

    public void setPICZNAME(String PICZNAME) {
        this.PICZNAME = PICZNAME;
    }

    public String getPICFNAME() {
        return PICFNAME;
    }

    public void setPICFNAME(String PICFNAME) {
        this.PICFNAME = PICFNAME;
    }

    public String getPICV1NAME() {
        return PICV1NAME;
    }

    public void setPICV1NAME(String PICV1NAME) {
        this.PICV1NAME = PICV1NAME;
    }

    public String getTRANSACTION_ID() {
        return TRANSACTION_ID;
    }

    public void setTRANSACTION_ID(String TRANSACTION_ID) {
        this.TRANSACTION_ID = TRANSACTION_ID;
    }

    public String getLOGIN_NO() {
        return LOGIN_NO;
    }

    public void setLOGIN_NO(String LOGIN_NO) {
        this.LOGIN_NO = LOGIN_NO;
    }

    public String getUUC_LEVEL() {
        return UUC_LEVEL;
    }

    public void setUUC_LEVEL(String UUC_LEVEL) {
        this.UUC_LEVEL = UUC_LEVEL;
    }
}
