package com.cmiot.mybatis.vo;

/**
 * @author : 周世雄 <br>
 * @date : 2019/3/5 10:34 <br>
 * @E-mail : zhoushixiong@chinasoftinc.com
 * @description : 实名登记信息实体
 */
public class RealNameInfoRecord {

    /** 用户标识*/
    private String userId;
    /** 用户登记名称*/
    private String name;
    /** 用户登记身份证*/
    private String custCertNo;
    /** 物联卡号*/
    private String msisdn;
    /** ICCID*/
    private String iccid;
    /** 激活选项 00不激活，01激活*/
    private String activationOpts;
    /** 登记时间*/
    private String registerTime;
    /** 用户手机号码*/
    private String phone ;
    /** 图片ID 格式yyyy-MM-dd/pic_id*/
    private String registerPicId;
    /** 物联卡归属 PB为00,CT为01*/
    private String cardBelong;
    /** 省份编码 */
    private String beId;
    /** 省份编码 */
    private String registerCode;
    /**集团客户编码**/
    private String custId;

    /** 登记返回码
     00000	成功
     40009	请求参数节点缺失或节点名称错误
     40050	查询不到信息
     40130	ICCID和MSISDN对应关系错误
     40131	该卡实名登记请求次数已超过系统每日最大限制（10次）
     40132	该卡已被其他人实名登记
     40133	该卡你已实名登记，无需重复实名登记
     40134	人证比对不一致*/

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCustCertNo() {
        return custCertNo;
    }

    public void setCustCertNo(String custCertNo) {
        this.custCertNo = custCertNo;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getIccid() {
        return iccid;
    }

    public void setIccid(String iccid) {
        this.iccid = iccid;
    }

    public String getActivationOpts() {
        return activationOpts;
    }

    public void setActivationOpts(String activationOpts) {
        this.activationOpts = activationOpts;
    }

    public String getRegisterTime() {
        return registerTime;
    }

    public void setRegisterTime(String registerTime) {
        this.registerTime = registerTime;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getRegisterPicId() {
        return registerPicId;
    }

    public void setRegisterPicId(String registerPicId) {
        this.registerPicId = registerPicId;
    }

    public String getCardBelong() {
        return cardBelong;
    }

    public void setCardBelong(String cardBelong) {
        this.cardBelong = cardBelong;
    }

    public String getRegisterCode() {
        return registerCode;
    }

    public void setRegisterCode(String registerCode) {
        this.registerCode = registerCode;
    }

    public String getBeId() {
        return beId;
    }

    public void setBeId(String beId) {
        this.beId = beId;
    }

    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }

    @Override
    public String toString() {
        return "RealNameInfoRecord{" +
                "userId='" + userId + '\'' +
                ", name='" + name + '\'' +
                ", custCertNo='" + custCertNo + '\'' +
                ", msisdn='" + msisdn + '\'' +
                ", iccid='" + iccid + '\'' +
                ", activationOpts='" + activationOpts + '\'' +
                ", registerTime='" + registerTime + '\'' +
                ", phone='" + phone + '\'' +
                ", registerPicId='" + registerPicId + '\'' +
                ", cardBelong='" + cardBelong + '\'' +
                ", beId='" + beId + '\'' +
                ", registerCode='" + registerCode + '\'' +
                ", custId='" + custId + '\'' +
                '}';
    }
}
