package com.cmiot.mybatis.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cmiot.api.client.ICtBusinessSerClient;
import com.cmiot.api.service.AccountInfoService;
import com.cmiot.api.service.UserService;
import com.cmiot.common.ct.access.entity.CTResponse;
import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.cache.impl.CacheManager;
import com.cmiot.commons.common.constants.RequestConstants;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.common.utils.MapParamChecker;
import com.cmiot.commons.log.ILog;
import com.cmiot.commons.response.ResponseCode;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.commons.response.vo.PageResultVo;
import com.cmiot.commons.vo.MsisdnCacheVo;
import com.cmiot.ms.dal.common.orcl.NormalBaseService;
import com.cmiot.mybatis.dao.WxPersonUserInfoDao;
import com.cmiot.mybatis.vo.*;
import com.cmiot.util.CommonUtils;
import com.cmiot.wx.apiservice.handle.MsisdnAutoHandle;
import com.cmiot.wx.apiservice.service.CTUserService;
import com.cmiot.wx.apiservice.service.OuterNetInterface;
import com.cmiot.wx.apiservice.service.SingleTermSericeImpl;
import com.cmiot.wx.apiservice.utiles.CommonConstant;
import com.cmiot.wx.apiservice.utiles.DalServiceErrorCode;
import com.cmiot.wx.apiservice.utiles.ResponseData;
import com.cmiot.wx.apiservice.utiles.ResponseEnum;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

/**
 * @author xiapeicheng
 * @date 2019/1/4 17:14
 * @email xiapeicheng@cmiot.chinamobile.com
 */

@Service
public class WxPersonUserInfoService extends NormalBaseService {

    static Logger logger = LoggerFactory.getLogger(WxPersonUserInfoService.class);

    @Autowired
    WxPersonUserInfoDao wxPersonUserInfoDao;

    @Autowired
    AccountInfoService accountInfoService;

    @Autowired
    OuterNetInterface outerNetInterface;

    @Autowired
    UserService userService;

    @Autowired
    CTUserService ctUserService;

    @Autowired
    SingleTermSericeImpl termSerice;

    @Autowired
    RealNameRegisterService realNameRegisterService;

    @Autowired
    ICache iCache;

    @Autowired
    ILog iLog;

    @Autowired
    ICtBusinessSerClient iCtBusinessSerClient;

    int POOL_SIZE = Runtime.getRuntime().availableProcessors() << 1;
    BlockingQueue<Runnable> queue = new ArrayBlockingQueue<>(512);
    RejectedExecutionHandler rejectedPolicy = new ThreadPoolExecutor.DiscardOldestPolicy();
    ExecutorService executorService = new ThreadPoolExecutor(POOL_SIZE, POOL_SIZE << 1, 1, TimeUnit.SECONDS, queue, rejectedPolicy);

    static final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");


    public void uniteUserResgiter(Map<String, String> params) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        wxPersonUserInfoDao.uniteUserRegister(params);
    }


    public void unbindByMsisdn(String msisdn) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        wxPersonUserInfoDao.unbindCtByMsisdn(msisdn);
    }

    /**
     * 平台用户表账户注册
     *
     * @param params
     */
    public void platUserRegister(Map<String, String> params) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);

        wxPersonUserInfoDao.platUserRegister(params);
    }

    public void updateOperateTime(Map params) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        wxPersonUserInfoDao.updateOperateTime(params);
    }

    /**
     * 注销用户
     *
     * @param params
     */
    @Transactional(rollbackFor = Exception.class)
    public void invalidAllAccount(Map params) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        wxPersonUserInfoDao.invalidAccount(params);
        wxPersonUserInfoDao.invalidPlatAccount(params);
        wxPersonUserInfoDao.invalidAllBindMsisdn(params);
    }

    /**
     * 激活注销过的用户
     *
     * @param params
     */
    @Transactional(rollbackFor = Exception.class)
    public void openAllAccount(Map params) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        wxPersonUserInfoDao.openPlatAccount(params);
        wxPersonUserInfoDao.openAccount(params);
    }

    public void updateOpenId(Map<String, String> params) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        wxPersonUserInfoDao.updateOpenId(params);
    }

    public long checkOpenId(Map params) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.checkOpenId(params);
    }

    public long checkWeChatAccountExist(Map params) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.checkWeChatAccountExist(params);
    }

    public String getOpenIdByPhone(Map params) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.getOpenIdByPhone(params);
    }

    public Map getWxUserInfo(Map params) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.getWxUserInfo(params);
    }

    public ResponseVo getUserPhoneByOpenId(Map<String, String> map) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        String phone = wxPersonUserInfoDao.getUserPhoneByOpenId(map);
        logger.info("数据库中手机号为{}, 参数为{}", CommonUtils.mobileEncrypt(phone), map);
        return ResponseVo.success(phone);
    }

    public long checkPhoneRegister(Map<String, String> params) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.checkPhoneRegister(params);
    }

    public long checkInvalidRegister(Map<String, String> params) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.checkInvalidRegister(params);
    }

    public String getUserIdByPhone(String phone) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.getUserIdByPhone(phone).get(0);
    }

    /**
     * 获取绑定物联网卡列表
     *
     * @param map
     * @return
     */
    public PageResultVo getMsisdnList(Map<String, Object> map) {
        PageResultVo pageResultVo = PageResultVo.newInstance(0, Collections.EMPTY_LIST);
        Map params = new HashMap(16, 0.9F);
        params.putAll(map);
        String transNo = params.get(CommonConstant.TRANSNO) == null ? "" : params.get(CommonConstant.TRANSNO).toString();
        try {
            int pageSize = params.get(PAGESIZE) == null ? 10000 : Integer.parseInt(params.get(PAGESIZE).toString());
            int pageNo = params.get(PAGENO) == null ? 1 : Integer.parseInt(params.get(PAGENO).toString());
            params.put(PAGESIZE, pageSize);
            params.put(PAGENO, pageNo);
            // 指定数据源以及分页数据
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
            setPageInfo(params);
            //优化卡查询
            if(params.get("userId")==null||"".equals(params.get("userId"))||wxPersonUserInfoDao.bindStatusQuery(params)<=0){
                pageResultVo.setCount(0);
                pageResultVo.setList(new ArrayList());
                return pageResultVo;
            }
            // 从缓存获取数据总数
            long count = getCachedCount(this.getClass(), "getUserList", params);
            if (count <= 0) {
                count = wxPersonUserInfoDao.bindMsisdnCountQuery(params);
                setCachedCount(this.getClass(), "getUserList", params, count);
            }
            pageResultVo.setCount(count);
            if (count > 0) {
                pageResultVo.setList(wxPersonUserInfoDao.bindMsisdnListQuery(params));
            }
        } catch (Exception e) {
            iLog.error(logger, transNo, null, "查询绑定物联网卡列表失败！", e, params);
        }
        return pageResultVo;
    }



    @Transactional(rollbackFor = Exception.class)
    public int bindMsisdn(Map<String, String> map) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.bindMsisdn(map);
    }

    public RealNameInfoRecord checkRealName(Map<String, String> map) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.checkRealName(map);
    }

    /**
     * 获取物联网卡基本信息
     *
     * @param params 必要参数包括 msisdn
     * @return
     */
    public ResponseVo getMsisdnInfo(Map params) {
        long start = System.currentTimeMillis();
        String transNo = params.get(CommonConstant.TRANSNO) == null ? "" : params.get(CommonConstant.TRANSNO).toString();
        String msisdn = params.get(CommonConstant.FIELD_MSISDN) == null ? "" : params.get(CommonConstant.FIELD_MSISDN).toString();
        try {
            // 参数校验，msisdn 必须提供
            MapParamChecker mapParamChecker = MapParamChecker.instance(params)
                    .isNotBlank(CommonConstant.FIELD_MSISDN);
            if (!mapParamChecker.isValid()) {
                iLog.info(logger, transNo, null, "参数不完整", params);
                return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM, new String[]{"缺少必要参数！"});
            }
            MsisdnInfoEntity msisdnInfoEntity = new MsisdnInfoEntity();
            // 从缓存中查询ICCID、生命周期状态、IMSI、省份id、省份名称
            MsisdnCacheVo msisdnCacheVo = cache.getByMsisdn(msisdn);
            iLog.info(logger, transNo, params, String.format("[耗时 %s ms] 从缓存中查询ICCID、生命周期状态、IMSI、省份id、省份名称", System.currentTimeMillis() - start));
            if (msisdnCacheVo != null) {
                initMsisdnInfo(msisdnInfoEntity, msisdnCacheVo);
            }
            msisdnInfoEntity.setCardBelong(CommonConstant.WX_CARD_BELONG_PB);
            //  充值缴费URL
            msisdnInfoEntity.setChargeURL(CommonConstant.WX_CHARGE_URL_PB);

            // 从数据库查询出开卡日期、IMEI
            start = System.currentTimeMillis();
            msisdnInfoEntity.setImei(getIMEI(params));
            iLog.info(logger, transNo, params, String.format("[耗时 %s ms] 从数据库查询出IMEI：%s", System.currentTimeMillis() - start, msisdnInfoEntity.getImei()));
            start = System.currentTimeMillis();
            params.put(CommonConstant.FIELD_BEID, msisdnInfoEntity.getBeid());
            msisdnInfoEntity.setOpenTime(getOpenTime(msisdnInfoEntity.getMsisdn(), msisdnInfoEntity.getBeid()));
            iLog.info(logger, transNo, params, String.format("[耗时 %s ms] 从数据库查询出开卡日期：%s", System.currentTimeMillis() - start, msisdnInfoEntity.getOpenTime()));
            // 调接口查询账户余额
            start = System.currentTimeMillis();
            String balance = params.get(CommonConstant.FIELD_BALANCE) == null ? "" : params.get(CommonConstant.FIELD_BALANCE).toString();
            if (StringUtils.isEmpty(balance)) {
                balance = outerNetInterface.queryBalanceFromPB(params);
            }
            msisdnInfoEntity.setBalance(balance);
            iLog.info(logger, transNo, params, String.format("[耗时 %s ms] 调接口查询账户余额：%s", System.currentTimeMillis() - start, balance));
            // 调接口查询开关机状态
            start = System.currentTimeMillis();
            msisdnInfoEntity.setNetStatus(outerNetInterface.queryTerminalStatusFromPB(params));
            iLog.info(logger, transNo, params, String.format("[耗时 %s ms] 调接口查询开关机状态：%s", System.currentTimeMillis() - start, msisdnInfoEntity.getNetStatus()));
            iLog.info(logger, transNo, params, String.format("[耗时 %s ms] 获取 %s 基本信息", System.currentTimeMillis() - start, msisdn));
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
            if(wxPersonUserInfoDao.queryRegisterStatusPb(msisdn)>0){
                msisdnInfoEntity.setRegisterStatus("1");
            }else {
                msisdnInfoEntity.setRegisterStatus("0");
            }
            return ResponseVo.success(msisdnInfoEntity);
        } catch (Exception e) {
            iLog.error(logger, transNo, null, "查询物联卡基本信息异常", e, msisdn);
            return ResponseVo.fail(ResponseCode.ERROR_SYS);
        }
    }

    /**
     * 组装物联卡基本信息
     *
     * @param msisdnInfo
     * @param msisdnCacheVo
     */
    private void initMsisdnInfo(MsisdnInfoEntity msisdnInfo, MsisdnCacheVo msisdnCacheVo) {
        msisdnInfo.setMsisdn(StringUtils.isEmpty(msisdnCacheVo.getMsisdn()) ? "" : msisdnCacheVo.getMsisdn());
        msisdnInfo.setIccid(StringUtils.isEmpty(msisdnCacheVo.getIccid()) ? "" : msisdnCacheVo.getIccid());
        msisdnInfo.setImsi(StringUtils.isEmpty(msisdnCacheVo.getImsi()) ? "" : msisdnCacheVo.getImsi());
        String status = StringUtils.isEmpty(msisdnCacheVo.getStatus()) ? "" : msisdnCacheVo.getStatus();
        String provinceId = StringUtils.isEmpty(msisdnCacheVo.getProvinceId()) ? "" : msisdnCacheVo.getProvinceId();
        msisdnInfo.setBeid(provinceId);
        if (StringUtils.isEmpty(status)) {
            Map dbSimInfo = getDbSimInfo(msisdnCacheVo.getMsisdn(), provinceId, msisdnCacheVo.getCustId());
            status = dbSimInfo == null || dbSimInfo.get(CommonConstant.FIELD_STATUS) == null ? status : dbSimInfo.get(CommonConstant.FIELD_STATUS).toString();
        }
        msisdnInfo.setStatus(status);
        msisdnInfo.setProvinceName(cache.getProvinceName(provinceId));
    }

    public Map getDbSimInfo(String msisdn, String provinceId, String custId) {
        if (StringUtils.isEmpty(provinceId)) {
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        } else {
            setDatasourceByProvince(provinceId);
        }
        Map map=new HashMap();
        map.put("msisdn",msisdn);
        map.put("provinceId",provinceId);
        map.put("custId",custId);
        return userService.getDbSimInfo(map);
    }

    /**
     * 从数据库查询IMEI
     *
     * @param params 需要Msisdn或者IMSI
     * @return
     */
    private String getIMEI(Map params) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return userService.getIMEI(params);
    }

    /**
     * 从数据库查询开卡时间
     *
     * @param msisdn
     * @param provinceId
     * @return
     */
    private String getOpenTime(String msisdn, String provinceId) {
        iLog.info(logger, null, null, msisdn + "省份Id:" + provinceId);
        if (StringUtils.isEmpty(provinceId)) {
            iLog.info(logger, null, null, msisdn + "在全局库");
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        } else {
            iLog.info(logger, null, null, msisdn + "在分片库:" + provinceId);
            setDatasourceByProvince(provinceId);
        }
        Map map=new HashMap();
        map.put("msisdn",msisdn);
        map.put("provinceId",provinceId);
        return userService.getOpenTime(map);
    }

    /**
     * 根据Msisdn或者ICCID查询物联卡归属信息，判断是属于 PB 还是 CT
     *
     * @param params 需要Msisdn或者ICCID
     * @return
     */
    public MsisdnBindingVo getCardBelong(Map params) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.getBindMsisdnInfo(params);
    }

    public MsisdnBindingVo getBindMsisdnInfo(Map params) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.getBindMsisdnInfo(params);
    }

    /**
     * 修改绑定的物联卡信息
     *
     * @param msisdnBindingVo
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public int modifyBindMsisdn(MsisdnBindingVo msisdnBindingVo) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.modifyBindMsisdn(msisdnBindingVo);
    }

    /**
     * 用户操作权限校验
     *
     * @param map
     * @return
     */
    public boolean authorityCheck(Map map, String transNo) {
        try {
            MapParamChecker mapParamChecker = MapParamChecker.instance(map)
                    .isNotBlank(CommonConstant.USERID)
                    .isNotBlank(CommonConstant.FIELD_MSISDN);
            if (mapParamChecker.isValid()) {
                setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
                List<MsisdnBindingVo> msisdnBindingVo = wxPersonUserInfoDao.authorityCheck(map);
                return msisdnBindingVo != null&&msisdnBindingVo.size()>0;
            }
            iLog.info(logger, transNo, null, "缺少必要参数，请求参数:{}", map);
            return false;
        } catch (Exception e) {
            iLog.error(logger, transNo, null, String.format("校验用户{}操作物联卡{}权限失败", map.get(CommonConstant.USERID), map.get(CommonConstant.FIELD_MSISDN)), e);
            return false;
        }
    }

    /**
     * 查询PB卡用量信息
     *
     * @param params
     * @return
     */
    public ResponseVo getSimFlowInfo(Map params) {
        String transNo = params.get(CommonConstant.TRANSNO) == null ? "" : params.get(CommonConstant.TRANSNO).toString();
        String msisdn = params.get(CommonConstant.FIELD_MSISDN).toString();
        String provinceId = iCache.getMsisdnProvince(msisdn);
        ResponseVo responseVo = new ResponseVo();
        try {
            // 调用PB接口获取用量信息
            responseVo = accountInfoService.getSimFlowInfo(params, transNo, params.get(RequestConstants.HEADER_PARAMS_TOKEN).toString());
//            iLog.info(logger, transNo, null, "调接口查询PB卡用量信息返回结果", JSONObject.toJSON(responseVo));
        } catch (Exception e) {
            iLog.error(logger, transNo, null, "调用PB接口获取用量信息异常", e, JSONObject.toJSON(responseVo));
        }
        if (responseVo != null && responseVo.isSuccess() && responseVo.getData() != null) {
            iLog.info(logger, transNo, params, "wx getSimFlowInfo success, param is:{}");
            //处理返回值
            List<Map> dataList = (List<Map>) responseVo.getData();
            Map servList = null;
            if (dataList != null && dataList.size() > 0) {
                servList = dataList.get(0);
            } else {
                logger.error("wx getSimFlowInfo fail，PB返回用量信息列表为空！");
                responseVo.setData(new ArrayList<>());
                return responseVo;
            }
            if (servList != null && servList.size() > 0) {
                // 获取成员套餐列表->过滤主体产品
                List<String> prodInstIds = getProdInstIdsList(msisdn);

                // 获取流量信息排序规则及模板编号
                Map<String, SortInfoVo> sortMap = getSortMap();
                // 套餐用量信息列表(包含主体产品）
                List<Map> productList = (List<Map>) servList.get("servDataAmountArrayList");
                List<Map> returnList = new ArrayList<>();
                List<Map> flowInfoList = new ArrayList<>();
//                logger.info("查询PB卡 套餐用量信息列表:{},成员产品实例ID:{}", productList, prodInstIds);
                if (prodInstIds != null && productList != null && productList.size() > 0) {
                    // 数据格式化：保留2位小数
                    DecimalFormat decimalFormat = new DecimalFormat("#0.00");
                    // 对用量信息列表数据处理
                    for (Map returnData : productList) {
                        // 当前产品的instId
                        String prodInstID = returnData.get("prodInstID").toString();
                        // 过滤主体产品
                        if (!prodInstIds.contains(prodInstID)) {
                            // 不是成员套餐,对主体产品数据丢弃,处理下一个
                            continue;
                        }
                        /**
                         * 5.2.11.1版本修复用量查询页面，套餐到期时间错误缺陷
                         * */
                        Map prodInstIDMap = new HashMap(1);
                        prodInstIDMap.put("prodInstId", prodInstID);
                        if (!StringUtils.isEmpty(provinceId)) {
                            setDatasourceByProvince(provinceId); //设置数据源
                            prodInstIDMap.put("provinceId",provinceId);
                            ProductInfoVo prodInfo = wxPersonUserInfoDao.getProductInfoByInstId(prodInstIDMap);
                            if(prodInfo!=null){
                                String currentEndStr = StringUtils.isEmpty(prodInfo.getEndDate()) ? "" : prodInfo.getEndDate().replace("-", "");
                                returnData.put("endTime", currentEndStr);
                            }else {
                                logger.info("transNo is:[{}]，根据订购ID[{}]查询产品数据失败",transNo,prodInstID);
                            }
                        }else {
                            logger.info("transNo is:[{}]，缓存获取物联卡[{}]省份ID为空，不处理PB余量返回报文",transNo,msisdn);
                        }
                        /*******************************5.2.11.1**END************************************************/
                        // 01:短信; 02:流量; 03:通话
                        if ("01".equals(returnData.get("dataAmountType"))) {
                            String dataTotalString = String.valueOf(returnData.get("dataTotal"));
                            String dataAmountString = String.valueOf(returnData.get("dataAmount"));
                            String setAmountString = String.valueOf(returnData.get("setAmount"));
//                            logger.info("总量PBOSS:{}", dataTotalString);
                            double dataTotal;
                            double dataAmount;
                            double setAmount;
                            if (StringUtils.isEmpty(dataTotalString) || "null".equals(dataTotalString)) {
                                dataTotalString = "0";
                            }
                            if (StringUtils.isEmpty(dataAmountString) || "null".equals(dataTotalString)) {
                                dataAmountString = "0";
                            }
                            if (StringUtils.isEmpty(setAmountString) || "null".equals(dataTotalString)) {
                                setAmountString = "0";
                            }
                            logger.info("总量:{}, 使用量:{}, 剩余量:{}", dataTotalString, dataAmountString, setAmountString);
                            try {
                                dataTotal = Double.valueOf(dataTotalString);
                                dataAmount = Double.valueOf(dataAmountString);
                                setAmount = Double.valueOf(setAmountString);
                            } catch (Exception e) {
                                logger.error("用量总量处理出错，置为0");
                                dataTotal = 0.0;
                                dataAmount = Double.valueOf(dataAmountString);
                                setAmount = Double.valueOf(setAmountString);
                            }
                            returnData.put("usedPercentNum", getUsedPercentNum(dataTotal, dataAmount));
                            returnData.put("dataTotal", dataTotal);
                            returnData.put("dataAmount", dataAmount);
                            returnData.put("setAmount", setAmount);
                            returnData.put("valueUnit", "条");
                            returnList.add(returnData);
                        } else if ("02".equals(returnData.get("dataAmountType"))) {
                            String prodId = returnData.get("prodId").toString();
                            // 通过prodId获取当前套餐信息排序级别及模板编号，并绑定
                            SortInfoVo sortInfoVo = sortMap.get(prodId);
                            if (sortInfoVo == null) {
//                                logger.info("CT卡用量信息:{}处理时未获取到对应套餐排序信息", returnData.toString());
                                continue;
                            }
                            String sort = sortInfoVo.getSort();
                            String modelType = sortInfoVo.getModelType();
                            returnData.put("sort", sort);
                            returnData.put("type", modelType);
                            //dataTotal(总量0.00) dataAmount(使用kb) setAmount(剩余kb)
                            String dataTotalString = String.valueOf(returnData.get("dataTotal"));
                            String dataAmountString = String.valueOf(returnData.get("dataAmount"));
                            String setAmountString = String.valueOf(returnData.get("setAmount"));
                            double dataTotal;
                            double dataAmount;
                            double setAmount;
                            logger.info("总量PBOSS:{}", dataTotalString);
                            if (StringUtils.isEmpty(dataTotalString) || "null".equals(dataTotalString)) {
                                dataTotalString = "0.00";
                            }
                            if (StringUtils.isEmpty(dataAmountString) || "null".equals(dataTotalString)) {
                                dataAmountString = "0.00";
                            }
                            if (StringUtils.isEmpty(setAmountString) || "null".equals(dataTotalString)) {
                                setAmountString = "0.00";
                            }
                            logger.info("总量:{}, 使用量:{}, 剩余量:{}", dataTotalString, dataAmountString, setAmountString);

                            try {
                                dataTotal = Double.valueOf(dataTotalString);
                                dataAmount = Double.valueOf(dataAmountString);
                                setAmount = Double.valueOf(setAmountString);
                            } catch (Exception e) {
                                logger.error("用量总量处理出错，置为0");
                                dataTotal = 0.0;
                                dataAmount = Double.valueOf(dataAmountString);
                                setAmount = Double.valueOf(setAmountString);
                            }
                            dataAmount = dataAmount / 1024;
                            setAmount = setAmount / 1024;
                            returnData.put("usedPercentNum", getUsedPercentNum(dataTotal, dataAmount));
                            returnData.put("dataTotal", decimalFormat.format(dataTotal));
                            returnData.put("dataAmount", decimalFormat.format(dataAmount));
                            returnData.put("setAmount", decimalFormat.format(setAmount));
                            returnData.put("valueUnit", "MB");
                            //套餐添加至流量列表
                            flowInfoList.add(returnData);

                        } else if ("03".equals(returnData.get("dataAmountType"))) {
                            String dataTotalString = String.valueOf(returnData.get("dataTotal"));
                            String dataAmountString = String.valueOf(returnData.get("dataAmount"));
                            String setAmountString = String.valueOf(returnData.get("setAmount"));
                            double dataTotal;
                            double dataAmount;
                            double setAmount;
                            logger.info("总量PBOSS:{}", dataTotalString);
                            if (StringUtils.isEmpty(dataTotalString) || "null".equals(dataTotalString)) {
                                dataTotalString = "0";
                            }
                            if (StringUtils.isEmpty(dataAmountString) || "null".equals(dataTotalString)) {
                                dataAmountString = "0";
                            }
                            if (StringUtils.isEmpty(setAmountString) || "null".equals(dataTotalString)) {
                                setAmountString = "0";
                            }
                            logger.info("总量:{}, 使用量:{}, 剩余量:{}", dataTotalString, dataAmountString, setAmountString);
                            try {
                                dataTotal = Double.valueOf(dataTotalString);
                                dataAmount = Double.valueOf(dataAmountString);
                                setAmount = Double.valueOf(setAmountString);
                            } catch (Exception e) {
                                logger.error("用量总量处理出错，置为0");
                                dataTotal = 0.0;
                                dataAmount = Double.valueOf(dataAmountString);
                                setAmount = Double.valueOf(setAmountString);
                            }
                            dataAmount = dataAmount / 60;
                            setAmount = setAmount / 60;
                            returnData.put("usedPercentNum", getUsedPercentNum(dataTotal, dataAmount));
                            returnData.put("dataTotal", decimalFormat.format(dataTotal));
                            returnData.put("dataAmount", decimalFormat.format(dataAmount));
                            returnData.put("setAmount", decimalFormat.format(setAmount));
                            returnData.put("valueUnit", "分钟");
                            returnList.add(returnData);
                        }
                    }

                    // 流量列表排序
//                    logger.info("PB卡用量信息-流量信息排序前列表:{}", flowInfoList);
                    sort(flowInfoList);
//                    logger.info("PB卡用量信息-流量信息排序后列表:{}", flowInfoList);
                    // 合并用量信息列表（短信、流量、语音[暂无]）
                    returnList.addAll(flowInfoList);
//                    logger.info("wx getSimFlowInfo success, 返回用量信息列表 returnList is:{}", returnList);
                    responseVo.setData(returnList);
                } else {
                    //返回空数组
                    logger.info("wx getSimFlowInfo fail，PB返回用量信息列表为空！");
                    responseVo.setData(new ArrayList<>());
                }
            } else {
                //返回空数组
                logger.info("wx getSimFlowInfo fail，PB返回用量信息列表为空！");
                responseVo.setData(new ArrayList<>());
            }
            return responseVo;
        } else if (responseVo != null && CommonConstant.PB_RESPCODE_034.equals(responseVo.getCode())) {
            // PB访问频次限制
            logger.info("wx getSimFlowInfo fail，PB访问次数超出限制！", responseVo);
            return ResponseVo.fail(ResponseCode.ERROR_COMMUNICATION_EXTENAL_SYS, "访问次数受限，请稍候再试");
        } else {
            logger.info("wx getSimFlowInfo fail，系统异常！", responseVo);
            return ResponseVo.fail(ResponseCode.ERROR_SYS, "系统繁忙，请稍后再试！");
        }
    }

    /**
     * 获取套餐排序和模板映射map
     *
     * @return Map{key:"prodId",value:"sortInfoVo{"prodId":"I00010100046","sort"="1","modelType":"1"}"}
     */
    public Map<String, SortInfoVo> getSortMap() {
        //全局库查询
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.getSortMap();
    }

    /**
     * 流量信息列表排序
     *
     * @param list
     */
    public void sort(List<Map> list) {
        Collections.sort(list, new Comparator<Map>() {
            @Override
            public int compare(Map returnData1, Map returnData2) {
                int sort1 = Integer.valueOf(returnData1.get("sort").toString());
                int sort2 = Integer.valueOf(returnData2.get("sort").toString());
                if (sort1 != sort2) {
                    return sort1 - sort2;
                } else if (sort1 == 1) {
                    // 国内通用 按失效时间 升序排序（时间） 失效时间早，排在前
                    int endTime1 = Integer.valueOf(returnData1.get("endTime").toString());
                    int endTime2 = Integer.valueOf(returnData2.get("endTime").toString());
                    return endTime1 - endTime2;
                } else if (sort1 > 1 && sort1 <= 6) {
                    // 国内其他流量类型
                    int startTime1 = Integer.valueOf(returnData1.get("startTime").toString());
                    int startTime2 = Integer.valueOf(returnData2.get("startTime").toString());
                    return startTime1 - startTime2;
                } else {
                    // 国际港澳台流量
                    // 未明确激活/未激活状态标识（无法识别），统一按未激活：失效时间先后排序
                    int endTime1 = Integer.valueOf(returnData1.get("endTime").toString());
                    int endTime2 = Integer.valueOf(returnData2.get("endTime").toString());
                    return endTime1 - endTime2;
                }
            }
        });
    }


    /**
     * 获取卡成员套餐列表
     *
     * @param msisdn
     * @return
     */
    private List<String> getProdInstIdsList(String msisdn) {
        // 获取SubsId
        String subsId = iCache.getMsisdnSubsId(msisdn);
        String provinceId = iCache.getMsisdnProvince(msisdn);
        // 设置分片库
        setDatasourceByProvince(provinceId);
        if (StringUtils.isEmpty(subsId)) {
            Map map=new HashMap();
            map.put("msisdn",msisdn);
            map.put("provinceId",provinceId);
            subsId = userService.getSubsId(map);
        }
        // 成员套餐instId列表
        Map params=new HashMap();
        params.put("subsId",subsId);
        params.put("provinceId",provinceId);
        List<String> prodInstIds = userService.getProdInstIds(params);
        logger.info("数据库获取成员套餐列表 卡号MSISDN:{}, 省ID:{}, 用户标示SUBSID:{}, 成员套餐列表prodInstIds:{}", msisdn, provinceId, subsId, prodInstIds);
        return prodInstIds;
    }

    public ResponseVo getVerifiedInfo(Map params) throws ParseException {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        String userId = (String) params.get("userId");
        String verified = wxPersonUserInfoDao.getVerified(params);
        Map responseMap = new HashMap(2);
        responseMap.put("name", "未认证");
        responseMap.put("status", verified);
        if (!"00".equals(verified)) {
            //验证身份证信息是否过期
            String name = wxPersonUserInfoDao.getNameByUserId(userId);
            responseMap.put("name", name);
            if ("01".equals(verified) && verifiyExpired(userId)) {
                Map<String, String> updateParams = new HashMap<>(2);
                updateParams.put("userId", userId);
                updateParams.put("verified", "10");
                wxPersonUserInfoDao.updateVerifiedByUserId(updateParams);
                responseMap.put("status", "10");
            }
        }
        return ResponseVo.success(responseMap);
    }


    public String getAuthedUserId(String custCertNo) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.getAuthedUserId(custCertNo);
    }

    /**
     * 获取用量百分比
     *
     * @param total 总量
     * @param used  用量
     * @return “0.00”
     */
    private String getUsedPercentNum(Double total, Double used) {
        String percent;
        if (used > 0 && total > 0) {
            BigDecimal usedPercent = BigDecimal.valueOf(used).divide(BigDecimal.valueOf(total), 2, BigDecimal.ROUND_DOWN);
            // 用量为(0,1)时,百分比展示1%
            if ("0.00".equals(String.valueOf(usedPercent))) {
                percent = "0.01";
            } else if (new BigDecimal(1).compareTo(usedPercent) == -1) {
                percent = "1.00";
            } else {
                percent = String.valueOf(usedPercent);
            }
        } else {
            percent = "0.00";
        }
        return percent;
    }

    /**
     * 查询PB卡套餐信息
     *
     * @param params
     * @return
     */
    public ResponseVo getProductInfo(Map params) {
        String msisdn = String.valueOf(params.get(CommonConstant.FIELD_MSISDN));
        try {
            String provinceId = iCache.getMsisdnProvince(msisdn);
            setDatasourceByProvince(provinceId);
            String prodInstIdStrings = params.get("prodInstIds").toString();
            iLog.info(logger, null, null, "待查询的产品ids：{}", prodInstIdStrings);
            String[] prodInstIds = prodInstIdStrings.split(",");
            List<ProductInfoVo> listData = new ArrayList<>();
            Map map = new HashMap(2);
            Integer length = prodInstIds.length;
            if (length > 0) {
                for (int index = 0; index < length; index++) {
                    map.put("prodInstId", prodInstIds[index]);
                    map.put("provinceId",provinceId);
                    listData.add(wxPersonUserInfoDao.getProductInfoByInstId(map));
                }
//                iLog.info(logger, params.get(RequestConstants.HEADER_PARAMS_TRANSNO).toString(), null, "Success to query getProductInfo data,returnList is :[{}]", listData);
                return ResponseVo.success(listData);
            } else {
                iLog.error(logger, params.get(RequestConstants.HEADER_PARAMS_TRANSNO).toString(), null, "Failed to query getProductInfo data, getProductInfo's params is:[{}]", params);
                return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
            }
            // PB套餐接口返回处理
            // return userService.getProdInfoByProdInstID(params,params.get(RequestConstants.HEADER_PARAMS_TRANSNO).toString(),params.get(RequestConstants.HEADER_PARAMS_TOKEN).toString());
        } catch (Exception e) {
            iLog.error(logger, params.get(RequestConstants.HEADER_PARAMS_TRANSNO).toString(), null, "Failed to query getProductInfo data:", e);
            return ResponseVo.fail(DalServiceErrorCode.ERROR_ACCESS_DB);
        }
    }

    private boolean verifiyExpired(String userId) throws ParseException {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        String expiredTime = wxPersonUserInfoDao.getVerifyExpriedTime(userId);
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        long expiredMillis = format.parse(expiredTime).getTime();
        if (expiredMillis < System.currentTimeMillis()) {
            //过期
            logger.info("身份信息过期");
            return true;
        }
        return false;
    }

    public void saveSMSLog(Map params) {
        setAsDefaultDatasource();
        wxPersonUserInfoDao.saveSMSLog(params);
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
    }

    public void setLoginLog(Map params) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        wxPersonUserInfoDao.insertUserLoginLog(params);
    }

    public void updateSMSCodeStatus(Map params) {
        setAsDefaultDatasource();
        wxPersonUserInfoDao.updateSMSCodeStatus(params);
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
    }

    public Integer saveChargeLog(Map params) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.saveChargeLog(params);
    }

    public String getCertIdByUserId(String userId) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.getCertIdByUserId(userId);
    }


    /**
     * 批量分库查询卡状态
     *
     * @param provinceId
     * @param list
     * @param transNo
     * @return
     */
    public List<MsisdnBindingVo> batchQryStatus(String provinceId, List<MsisdnBindingVo> list, String transNo) {
        long start = System.currentTimeMillis();
        if (StringUtils.isEmpty(provinceId) || "CT".equals(provinceId)) {
            list.parallelStream().forEach(msisdnBindingVo -> {
                // CT 卡调接口查询，如果未查询到结果，则为销户卡
                Map map = new HashMap(4);
                map.put(CommonConstant.FIELD_MSISDN, msisdnBindingVo.getMsisdn());
                map.put(CommonConstant.TRANSNO, transNo);
                ResponseVo ctChecker = ctUserService.queryCardBasicInfo(map);
                if (ctChecker == null) {
                    iLog.error(logger, transNo, map, "调用CT接口查询卡状态异常！");
                } else if (!ctChecker.isSuccess() && ctChecker.getData() != null) {
                    CTResponse data = (CTResponse) ctChecker.getData();
                    if (CommonConstant.CT_API_CONSTANNTS.CT_STATUS_40050.equals(data.getRespCode())) {
                        msisdnBindingVo.setStatus(CommonConstant.PB_CARDSTATUS_CANCEL);
                    }
                } else {
                    Map data = (Map) ctChecker.getData();
                    if (data != null) {
                        msisdnBindingVo.setStatus(String.valueOf(data.get(CommonConstant.FIELD_STATUS)));
                        msisdnBindingVo.setBeId(String.valueOf(data.get(CommonConstant.FIELD_BEID)));
                        msisdnBindingVo.setCustId((String) data.computeIfAbsent(CommonConstant.FIELD_CUSTID, v -> ""));
                    }
                }
            });
        } else {
            setDatasourceByProvince(provinceId);
            Map map = new HashMap(2);
            map.put(CommonConstant.FIELD_MSISDN_LIST, list);
            map.put("provinceId",provinceId);
            list = userService.batchQryStatus(map);
        }
        iLog.info(logger, transNo, null, String.format("[耗时 %s ms] 批量查询卡状态，省份id: %s,卡列表：%s", System.currentTimeMillis() - start, provinceId, list));
        return list;
    }

    /**
     * 判断卡状态是否为销户
     *
     * @param msisdnBindingVo
     * @return
     */
    public boolean isCancel(MsisdnBindingVo msisdnBindingVo) {
        return CommonConstant.PB_CARDSTATUS_CANCEL.equals(msisdnBindingVo.getStatus())
                || StringUtils.isEmpty(msisdnBindingVo.getStatus())
                || "null".equalsIgnoreCase(msisdnBindingVo.getStatus())
                || "false".equals(msisdnBindingVo.getSameSubsId());
    }


    /**
     * PB 销户卡自动解绑（临时增加CT卡的判断）
     *
     * @param params
     * @return
     */
    public List<MsisdnBindingVo> syncPbMsisdnList(Map params) {
        String transNo = params.getOrDefault(CommonConstant.TRANSNO, "").toString();
        List<MsisdnBindingVo> result = new ArrayList<>();
        try {
            MapParamChecker mapParamChecker = MapParamChecker.instance(params)
                    .isNotBlank(CommonConstant.FIELD_CUSTCERTNO);
            if (mapParamChecker.isValid()) {
                Map qryLocalList = new HashMap(4, 0.8F);
                qryLocalList.put(CommonConstant.USERID, params.get(CommonConstant.USERID));
                qryLocalList.put(CommonConstant.FIELD_BIND_STATUS, CommonConstant.WX_BIND_STATUS_BIND);
//                qryLocalList.put(CommonConstant.FIELD_CARDBELONG , CommonConstant.WX_CARD_BELONG_PB);
                long start = System.currentTimeMillis();
                PageResultVo pageResultVo = getMsisdnList(qryLocalList);
//                iLog.info(logger, transNo, qryLocalList, String.format("[耗时：%s ms] 数据库查询结果：%s ", (System.currentTimeMillis() - start), JSON.toJSON(pageResultVo)));
                if (pageResultVo == null) {
                    throw new Exception("查询本地用户绑定卡列表异常！");
                } else {
                    List<MsisdnBindingVo> bindingVos = pageResultVo.getList();
                    if (bindingVos != null && bindingVos.size() > 0) {
                        List<MsisdnBindingVo> autoUnbind = new ArrayList<>();
                        start = System.currentTimeMillis();
                        bindingVos.parallelStream()
                                // 初始化充值路径
                                .map(MsisdnBindingVo::initUrl)
                                // 查询 PB 省份ID
                                .map(msisdnBindingVo -> {
                                    if (CommonConstant.WX_CARD_BELONG_PB.equals(msisdnBindingVo.getCardBelong())) {
                                        MsisdnCacheVo cacheVo = cache.getByMsisdn(msisdnBindingVo.getMsisdn());
                                        msisdnBindingVo.setBeId(cacheVo.getProvinceId());
                                        msisdnBindingVo.setCustId(cacheVo.getCustId());
                                    } else {
                                        msisdnBindingVo.setBeId("CT");
                                    }
                                    return msisdnBindingVo;
                                })
                                // 根据 省份ID 分组
                                .collect(Collectors.groupingByConcurrent(MsisdnBindingVo::getBeId))
                                .forEach((provinceId, list) -> {
                                    //查询物联卡状态
                                    list = batchQryStatus(provinceId, list, transNo);
                                    // 筛选出销户卡
//                                    autoUnbind.addAll(list.parallelStream().filter(this::isCancel).collect(Collectors.toList()));
//                                    result.addAll(list.parallelStream().filter(msisdnBindingVo -> !isCancel(msisdnBindingVo)).collect(Collectors.toList()));
                                    result.addAll(list);
                                });
                        iLog.info(logger, transNo, qryLocalList, String.format("[耗时：%s ms] 遍历查询状态", System.currentTimeMillis() - start));
                        //将筛选出来的销户卡做自动解绑
//                        Map setParams = new HashMap(4, 0.8F);
//                        setParams.put(CommonConstant.FIELD_BIND_STATUS, CommonConstant.WX_BIND_STATUS_AUTO_UNBIND);
//                        setParams.put(CommonConstant.USERID, params.get(CommonConstant.USERID));
//                        setParams.put(CommonConstant.TRANSNO, transNo);
//                        start = System.currentTimeMillis();
//                        batchAutoHandle(autoUnbind, setParams);
//                        iLog.info(logger, transNo, qryLocalList, String.format("[耗时：%s ms] 批量自动绑定/自动解绑列表：%s ", System.currentTimeMillis() - start, JsonUtils.parseString(autoUnbind)));
                    }
                }
            } else {
                iLog.error(logger, transNo, params, "缺少必要参数");
                throw new Exception("缺少必要参数");
            }
        } catch (Exception e) {
            iLog.error(logger, transNo, params, "PB 销户卡自动解绑发生异常", e);
        }
        return result;
    }

    /**
     * CT 同步账号实名认证的身份证下有效的非销户物联卡列表
     *
     * @param params
     * @return
     */
    public void syncCtMsisdnList(Map params) {
        String transNo = params.getOrDefault(CommonConstant.TRANSNO, "").toString();
        try {
            MapParamChecker mapParamChecker = MapParamChecker.instance(params)
                    .isNotBlank(CommonConstant.FIELD_CUSTCERTNO);
            if (mapParamChecker.isValid()) {
                String cretNo = String.valueOf(params.get(CommonConstant.FIELD_CUSTCERTNO));
                // 调用CT接口，以身份证号查询用户登记卡列表
                Map qry = new HashMap();
                qry.put(CommonConstant.CT_API_CONSTANNTS.CRET_NO, cretNo);
                List<Map> msisdnList = outerNetInterface.queryMsisdnByCretNo(qry);
                iLog.info(logger, transNo, qry, "CT 接口查询结果：", msisdnList);
                if (msisdnList != null && msisdnList.size() > 0) {
                    Map qryLocalList = new HashMap(4);
                    qryLocalList.put(CommonConstant.USERID, params.get(CommonConstant.USERID));
                    qryLocalList.put(CommonConstant.FIELD_CARDBELONG, CommonConstant.WX_CARD_BELONG_CT);
                    PageResultVo pageResultVo = getMsisdnList(qryLocalList);
                    iLog.info(logger, transNo, qryLocalList, "数据库查询结果：{}", JSON.toJSON(pageResultVo));
                    if (pageResultVo == null) {
                        throw new Exception("查询本地用户绑定卡列表异常！");
                    } else {
                        Map setParams = new HashMap(4, 0.8F);
                        setParams.put(CommonConstant.USERID, params.get(CommonConstant.USERID));
                        setParams.put(CommonConstant.FIELD_CARDBELONG, CommonConstant.WX_CARD_BELONG_CT);
                        setParams.put(CommonConstant.TRANSNO, transNo);
                        List<MsisdnBindingVo> localCt = pageResultVo.getList();
                        if (localCt == null || localCt.size() <= 0) {
                            // 本地未绑定任何CT卡，将接口查询的卡全部自动绑定
                            setParams.put(CommonConstant.FIELD_BIND_STATUS, CommonConstant.WX_BIND_STATUS_AUTO_BIND);
                            batchAutoHandle(msisdnList, setParams);
                        } else {
                            /**
                             * 将查询的卡列表与数据库绑定列表比对
                             * 比对原则：
                             *  设：CT查询集合为C，本地查询集合为L，另外，本地查询集合中手动绑定集合为Lmb，自动绑定集合为Lab，手动解绑集合为Lmu，自动解绑集合为Lau
                             *  自动绑定的部分为：(C - L) ∪ (C ∩ L - Lmb - Lmu - Lab) 即：CT查询结果与本地查询结果的差集 以及 两者交集中为自动解绑状态的卡
                             *  自动解绑的部分为：(L - C) - Lmu - Lau 即：本地查询结果与CT查询结果的差集 并且 状态为绑定（包含自动绑定以及手动绑定）的卡
                             */
                            // [接口查询的卡列表不存在，但数据库绑定列表存在] 并且 [状态为绑定的卡需要自动解绑]
                            List autoUnbind = localCt.parallelStream()
                                    // 数据库查询集合与CT接口查询列表集合的差集
                                    .filter(msisdnBindingVo -> !msisdnList.parallelStream().anyMatch(item -> msisdnBindingVo.getMsisdn().equals(item.get(CommonConstant.FIELD_MSISDN))))
                                    // 筛选出状态为绑定的卡
                                    .filter(msisdnBindingVo -> msisdnBindingVo.getBindStatus().startsWith(CommonConstant.WX_BIND_STATUS_BIND))
                                    .collect(Collectors.toList());
                            // [接口查询的卡列表存在，但数据库绑定列表不存在的卡] 以及 [接口查询的卡列表和数据库绑定列表都存在并且数据库状态为自动解绑的卡] 需要自动绑定
                            List autoBind = msisdnList.parallelStream()
                                    // [CT接口查询列表集合与数据库查询集合的差集] 加上 [两者交集中，数据库绑定状态为自动解绑的卡]
                                    .filter(item -> !localCt.parallelStream().anyMatch(msisdnBindingVo -> msisdnBindingVo.getMsisdn().equals(String.valueOf(item.get(CommonConstant.FIELD_MSISDN))))
                                            || localCt.parallelStream().anyMatch(msisdnBindingVo -> msisdnBindingVo.getMsisdn().equals(String.valueOf(item.get(CommonConstant.FIELD_MSISDN))) && CommonConstant.WX_BIND_STATUS_AUTO_UNBIND.equals(msisdnBindingVo.getBindStatus())))
                                    .collect(Collectors.toList());
                            // 做自动绑定操作
                            setParams.put(CommonConstant.FIELD_BIND_STATUS, CommonConstant.WX_BIND_STATUS_AUTO_BIND);
                            batchAutoHandle(autoBind, setParams);
                            // 做自动解绑操作
                            setParams.put(CommonConstant.FIELD_BIND_STATUS, CommonConstant.WX_BIND_STATUS_AUTO_UNBIND);
                            batchAutoHandle(autoUnbind, setParams);
                        }
                    }
                }
            } else {
                iLog.error(logger, transNo, params, "缺少必要参数");
                throw new Exception("缺少必要参数");
            }
        } catch (Exception e) {
            iLog.error(logger, transNo, params, "", e);
        }
    }


    /**
     * 批量自动绑定/自动解绑（异步）
     */
    public void batchAutoHandle(List list, Map params) throws Exception {
        String transNo = params.getOrDefault(CommonConstant.TRANSNO, "").toString();
        if (list == null || list.size() <= 0) {
            iLog.info(logger, transNo, params, "批量自动绑定/自动解绑，列表为空！", list);
            return;
        }
        MapParamChecker mapParamChecker = MapParamChecker.instance(params)
                .isNotBlank(CommonConstant.USERID)
                .isNotBlank(CommonConstant.FIELD_BIND_STATUS);
        if (!mapParamChecker.isValid()) {
            iLog.error(logger, transNo, params, "批量自动绑定/自动解绑，缺少必要参数！", list);
            throw new Exception("缺少必要参数");
        }
        MsisdnAutoHandle msisdnAutoHandle = new MsisdnAutoHandle(this, list, params);
        executorService.submit(msisdnAutoHandle);
    }

    /**
     * 记录绑定/解绑卡操作日志
     *
     * @param params
     */
    @Transactional(rollbackFor = Exception.class)
    public void saveOperLog(Map params) {
        MapParamChecker mapParamChecker = MapParamChecker.instance(params)
                .isNotBlank(CommonConstant.FIELD_MSISDN)
                .isNotBlank(CommonConstant.OPER_TYPE);
        if (!mapParamChecker.isValid()) {
            iLog.error(logger, String.valueOf(params.getOrDefault(CommonConstant.TRANSNO, "")), params, "记录操作日志缺少必要参数！");
        }
        params.put(CommonConstant.OPER_PLAT, params.getOrDefault(CommonConstant.OPER_PLAT, CommonConstant.PLAT_SING_WX));
        String comment = String.valueOf(params.getOrDefault(CommonConstant.OPER_COMMENTS, ""));
        comment = comment.length() > 512 ? comment.substring(0, 512) : comment;
        params.put(CommonConstant.OPER_COMMENTS, comment);
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        wxPersonUserInfoDao.saveOperLog(params);
    }

    /**
     * 卡绑定组装返回结果
     *
     * @param map
     * @return
     */
    public Map packageResult(Map map) {
        String transNo = String.valueOf(map.getOrDefault(CommonConstant.TRANSNO, ""));
        // 组装返回结果，查询已绑定列表
        Map responseMap = new HashMap(1);
        Map bindListParam = new HashMap(3);
        bindListParam.put(CommonConstant.USERID, map.get(CommonConstant.USERID));
        bindListParam.put(CommonConstant.FIELD_BIND_STATUS, CommonConstant.WX_BIND_STATUS_BIND);
        bindListParam.put(CommonConstant.TRANSNO, transNo);
        PageResultVo bindListQry = getMsisdnList(bindListParam);
        if (bindListQry != null && bindListQry.getCount() > 0 && bindListQry.getList() != null) {
            responseMap.put("list", bindListQry.getList());
        } else {
            responseMap.put("list", null);
        }
        return responseMap;
    }

    /**
     * 绑定 PB 物联卡
     *
     * @param map
     * @return
     */
    public ResponseVo bindPBMsisdn(Map map) {
        ResponseVo result = new ResponseData();
        String transNo = String.valueOf(map.getOrDefault(CommonConstant.TRANSNO, ""));
        try {
            MapParamChecker mapParamChecker = MapParamChecker.instance(map)
                    .isNotBlank(CommonConstant.FIELD_MSISDN)
                    .isNotBlank(CommonConstant.FIELD_ICCID)
                    .isNotBlank(CommonConstant.USERID);
            if (mapParamChecker.isValid()) {
                String subsId = map.getOrDefault(CommonConstant.FIELD_SUBSID, "").toString();
                Map qryList = new HashMap(2);
                qryList.put(CommonConstant.FIELD_MSISDN, map.get(CommonConstant.FIELD_MSISDN));
                qryList.put(CommonConstant.FIELD_CARDBELONG, CommonConstant.WX_CARD_BELONG_PB);
                PageResultVo pageResultVo = getMsisdnList(qryList);
                if (pageResultVo != null && pageResultVo.getCount() > 0
                        && pageResultVo.getList() != null
                        && pageResultVo.getList().size() > 0) {
                    MsisdnBindingVo msisdnBindingVo = (MsisdnBindingVo) pageResultVo.getList().get(0);
                    if (msisdnBindingVo.getBindStatus().startsWith(CommonConstant.WX_BIND_STATUS_UNBIND)
                            // subsId 不一致的情况，说明卡信息已经变更，允许绑定
                            || !subsId.equalsIgnoreCase(msisdnBindingVo.getSubsId())) {
                        // 该卡在绑定信息表中已存在记录，但是属于解绑状态
                        msisdnBindingVo.setBindStatus(CommonConstant.WX_BIND_STATUS_MANUAL_BIND);
                        msisdnBindingVo.setRemark(map.get(CommonConstant.FIELD_REMARK) == null || StringUtils.isEmpty(map.get(CommonConstant.FIELD_REMARK).toString()) ? " " : map.get(CommonConstant.FIELD_REMARK).toString());
                        msisdnBindingVo.setTopTime(format.format(new Date()));
                        msisdnBindingVo.setUserId(map.get(CommonConstant.USERID).toString());
                        msisdnBindingVo.setSubsId(subsId);
                        if (modifyBindMsisdn(msisdnBindingVo) > 0) {
                            result = ResponseVo.success("绑定成功");
                        } else {
                            throw new Exception("更改行数为0，修改失败！");
                        }
                    } else {
                        // 该卡在绑定信息表中已存在记录，并且属于绑定状态
                        Map checkMap = new HashMap(4);
                        checkMap.put(CommonConstant.USERID, map.get(CommonConstant.USERID));
                        checkMap.put(CommonConstant.FIELD_MSISDN, msisdnBindingVo.getMsisdn());
                        if (authorityCheck(checkMap, transNo)) {
                            result.setCode(ResponseEnum.ERR_BINDED.getState());
                            result.setErrParams(new String[]{"该卡已经被当前用户绑定，不可重复绑定！"});
                            iLog.error(logger, transNo, null, "该卡已经被当前用户绑定，不可重复绑定！", map);
                        } else {
                            iLog.error(logger, transNo, null, "该卡已经被其他用户绑定，不可重复绑定！", map);
                            result.setCode(ResponseEnum.ERR_BINDED.getState());
                            result.setErrParams(new String[]{"该卡已经被其他用户绑定，不可重复绑定！"});
                        }
                    }
                } else {
                    // 新绑卡
                    map.put(CommonConstant.FIELD_BIND_TIME, format.format(System.currentTimeMillis()));
                    map.put(CommonConstant.FIELD_REMARK, map.get(CommonConstant.FIELD_REMARK) == null || StringUtils.isEmpty(map.get(CommonConstant.FIELD_REMARK).toString()) ? " " : map.get(CommonConstant.FIELD_REMARK).toString());
                    map.put(CommonConstant.FIELD_BIND_STATUS, CommonConstant.WX_BIND_STATUS_MANUAL_BIND);
                    map.put(CommonConstant.FIELD_CARDBELONG, CommonConstant.WX_CARD_BELONG_PB);
                    map.put(CommonConstant.FIELD_SUBSID, subsId);
                    // 入库
                    if (bindMsisdn(map) > 0) {
                        result = ResponseVo.success("绑定成功");
                    } else {
                        throw new Exception("更改行数为0，入库失败！");
                    }
                }
            } else {
                iLog.error(logger, transNo, map, "绑定PB卡缺少必要参数");
                result = new ResponseData().setResponse(ResponseEnum.ERR_MISS_PARAMS);
            }
        } catch (Exception e) {
            iLog.error(logger, transNo, map, "绑定PB卡发生异常", e);
            result = new ResponseData().setResponse(ResponseEnum.ERR_SYSTEM);
        }
        return result;
    }


    /**
     * BBC授权校验
     * @param map
     * @return
     */
    public boolean validateBBC(Map map){
        return outerNetInterface.isAuthorize(map);
    }

    /**
     * 绑定 CT 物联卡
     *
     * @param map         绑定必须的参数
     * @param checkerData 校验结果
     * @return
     */
    public ResponseVo bindCTMsisdn(Map map, Map checkerData) {
        ResponseVo result = new ResponseData();
        String transNo = String.valueOf(map.getOrDefault(CommonConstant.TRANSNO, ""));
        try {
            MapParamChecker mapParamChecker = MapParamChecker.instance(map)
                    .isNotBlank(CommonConstant.FIELD_MSISDN)
                    .isNotBlank(CommonConstant.FIELD_ICCID)
                    .isNotBlank(CommonConstant.USERID);
            if (mapParamChecker.isValid()) {
                Map qryList = new HashMap(4);
                qryList.put(CommonConstant.FIELD_MSISDN, map.get(CommonConstant.FIELD_MSISDN));
                qryList.put(CommonConstant.FIELD_CARDBELONG, CommonConstant.WX_CARD_BELONG_CT);
                PageResultVo pageResultVo = getMsisdnList(qryList);
                if (pageResultVo != null && pageResultVo.getCount() > 0 && pageResultVo.getList() != null && pageResultVo.getList().size() > 0) {
                    MsisdnBindingVo msisdnBindingVo = (MsisdnBindingVo) pageResultVo.getList().get(0);
                    // 该卡属于解绑状态
                    if (msisdnBindingVo.getBindStatus().startsWith(CommonConstant.WX_BIND_STATUS_UNBIND)) {
                        // 如果该物联卡已存在，且绑定状态为解绑，则直接修改数据库记录的绑定状态为绑定
                        msisdnBindingVo.setBindStatus(CommonConstant.WX_BIND_STATUS_MANUAL_BIND);
                        msisdnBindingVo.setRemark(map.get(CommonConstant.FIELD_REMARK) == null || StringUtils.isEmpty(map.get(CommonConstant.FIELD_REMARK).toString()) ? " " : map.get(CommonConstant.FIELD_REMARK).toString());
                        msisdnBindingVo.setTopTime(format.format(new Date()));
                        msisdnBindingVo.setUserId(map.get(CommonConstant.USERID).toString());
                        if (modifyBindMsisdn(msisdnBindingVo) > 0) {
                            result = ResponseVo.success("绑定成功");
                        } else {
                            throw new Exception("更改行数为0，修改失败！");
                        }
                        // 判断是否需要激活
                        if (CommonConstant.CT_API_CONSTANNTS.CARD_STATUS_STORE.equals(checkerData.get(CommonConstant.FIELD_STATUS))) {
                            // 未激活
                            iLog.warn(logger, transNo, null, "未激活", map);
                            result = new ResponseData().setResponse(ResponseEnum.ERR_UNACTIVED, checkerData);
                        }
                    } else {
                        // 该物联卡已存在，且绑定状态为已绑定
                        Map checkMap = new HashMap(4);
                        checkMap.put(CommonConstant.USERID, map.get(CommonConstant.USERID));
                        checkMap.put(CommonConstant.FIELD_MSISDN, msisdnBindingVo.getMsisdn());
                        if (authorityCheck(checkMap, transNo)) {
                            iLog.error(logger, transNo, null, "该卡已经被当前用户绑定，不可重复绑定！", map);
                            result.setCode(ResponseEnum.ERR_BINDED.getState());
                            result.setErrParams(new String[]{"该卡已经被当前用户绑定，不可重复绑定！"});
                        } else {
                            iLog.error(logger, transNo, null, "该卡已经被其他用户绑定，不可重复绑定！", map);
                            result.setCode(ResponseEnum.ERR_BINDED.getState());
                            result.setErrParams(new String[]{"该卡已经被其他用户绑定，不可重复绑定！"});
                        }
                    }
                } else {
                    // 新绑卡
                    // 增加 CT 标识
                    map.put(CommonConstant.FIELD_BIND_TIME, format.format(System.currentTimeMillis()));
                    map.put(CommonConstant.FIELD_CARDBELONG, CommonConstant.WX_CARD_BELONG_CT);
                    map.put(CommonConstant.FIELD_BIND_STATUS, CommonConstant.WX_BIND_STATUS_MANUAL_BIND);
                    map.put(CommonConstant.FIELD_REMARK, map.get(CommonConstant.FIELD_REMARK) == null || StringUtils.isEmpty(map.get(CommonConstant.FIELD_REMARK).toString()) ? " " : map.get(CommonConstant.FIELD_REMARK).toString());
                    // 入库
                    if (bindMsisdn(map) > 0) {
                        result = ResponseVo.success("绑定成功");
                    } else {
                        throw new Exception("更改行数为0，入库失败！");
                    }
                    // 判断是否需要激活
                    if (CommonConstant.CT_API_CONSTANNTS.CARD_STATUS_STORE.equals(checkerData.get(CommonConstant.FIELD_STATUS))) {
                        // 未激活
                        iLog.warn(logger, transNo, null, "未激活", map);
                        result = new ResponseData().setResponse(ResponseEnum.ERR_UNACTIVED, checkerData);
                    }
                }
            } else {
                iLog.error(logger, transNo, map, "绑定PB卡缺少必要参数");
                result = new ResponseData().setResponse(ResponseEnum.ERR_MISS_PARAMS);
            }
        } catch (Exception e) {
            iLog.error(logger, transNo, map, "绑定PB卡发生异常", e);
            result = new ResponseData().setResponse(ResponseEnum.ERR_SYSTEM);
        }
        return result;
    }

    /**
     * 校验是否实名登记，如果已实名登记，则返回实名登记信息
     *
     * @param map
     * @return
     */
    public ResponseData isRealNameRegisted(Map map) {
        String transNo = map.get(CommonConstant.TRANSNO) == null ? "" : map.get(CommonConstant.TRANSNO).toString();
        ResponseData response = new ResponseData();
        try {
            MapParamChecker mapParamChecker = MapParamChecker.instance(map)
                    .isNotBlank(CommonConstant.FIELD_MSISDN);
            if (mapParamChecker.isValid()) {
                Map realNameParams = new HashMap(2);
                realNameParams.put(CommonConstant.FIELD_MSISDN, map.get(CommonConstant.FIELD_MSISDN));
                RealNameInfoRecord realName = checkRealName(realNameParams);
                if (realName == null) {
                    // 校验是否绑定，如果已经绑定，则直接默认已实名登记
                    Map qry = new HashMap(1);
                    qry.put(CommonConstant.FIELD_MSISDN, map.get(CommonConstant.FIELD_MSISDN));
                    qry.put(CommonConstant.FIELD_BIND_STATUS, CommonConstant.WX_BIND_STATUS_BIND);
                    PageResultVo pageResultVo = getMsisdnList(qry);
                    if (pageResultVo == null) {
                        iLog.error(logger, transNo, qry, "校验是否绑定发生异常!{}", pageResultVo);
                        throw new Exception("校验是否绑定发生异常！");
                    } else {
                        if (pageResultVo.getCount() > 0) {
                            // 卡已绑定但是未实名登记，返回一个空的实名登记对象
                            iLog.warn(logger, transNo, map, "卡已绑定，但是未实名登记,{}", pageResultVo);
                            response.setResponse(ResponseEnum.ERR_BINDED_UNREGISTED);
                        } else {
                            iLog.info(logger, transNo, map, "未实名登记");
                            response.setResponse(ResponseEnum.ERR_UNREGISTED);
                        }
                    }
                } else {
                    response.setData(realName);
                }
            } else {
                response.setResponse(ResponseEnum.ERR_MISS_PARAMS);
                iLog.info(logger, transNo, null, "缺少必要参数", map);
            }
        } catch (Exception e) {
            iLog.info(logger, transNo, null, "校验物联卡号和 ICCID 是否匹配异常", e, map);
            response.setResponse(ResponseEnum.ERR_SYSTEM);
        }
        return response;
    }

    /**
     * 校验 msisdn 和 iccid 是否匹配主逻辑
     *
     * @param map
     * @return
     */
    public ResponseData check(Map map) {
        String transNo = map.get(CommonConstant.TRANSNO) == null ? "" : map.get(CommonConstant.TRANSNO).toString();
        ResponseData response = new ResponseData();
        try {
            Map responseMap = new HashMap();
            MapParamChecker mapParamChecker = MapParamChecker.instance(map)
                    .isNotBlank(CommonConstant.FIELD_MSISDN)
                    .isNotBlank(CommonConstant.FIELD_ICCID);
            if (mapParamChecker.isValid()) {
                // 从缓存判断是否存在
                MsisdnCacheVo msisdnCacheVo = cache.getByMsisdn(map.get(CommonConstant.FIELD_MSISDN).toString());
                if (msisdnCacheVo != null) {

                    //上海pb卡割接到ct单独判断
                    if("210".equals(msisdnCacheVo.getProvinceId())){
                        // 调用 CT 接口判断是否存在
                        ResponseVo ctChecker = ctUserService.queryCardBasicInfo(map);
                        if (ctChecker != null && ctChecker.isSuccess() && ctChecker.getData() != null) {
                            // 归属 CT 的卡
                            logger.info("上海pb割接ct卡{}", JsonUtils.parseString(map));
                            Map ctCheckerData = (Map) ctChecker.getData();
                            if(map.get("msgId") != null && !"".equals(map.get("msgId"))){
                                String beId = iCache.get(CacheManager.PublicNameSpace.TEMP,"realnameH5_".concat(String.valueOf(map.get("msgId"))));
                                if(StringUtils.isEmpty(beId)){
                                    //缓存过期，返回错误信息
                                    logger.info("实名登记H5网页，缓存中不存在本次调用的省份限制，msisdn is:[{}],msgId is:[{}]",map.get(CommonConstant.FIELD_MSISDN),map.get("msgId"));
//                                return response.setResponse(ResponseEnum.ERR_OBJECT_MISSING);
                                }else {
                                    if(!beId.equals(ctCheckerData.get(CommonConstant.FIELD_BEID))){
                                        logger.info("实名登记H5网页，校验物联权限失败,msisdn is:[{}],card beId is:[{}],H5 beId is:[{}]",map.get(CommonConstant.FIELD_MSISDN),ctCheckerData.get(CommonConstant.FIELD_BEID),beId);
                                        return response.setResponse(ResponseEnum.ERR_OBJECT_AUTH);
                                    }
                                }
                            }
                            if (String.valueOf(map.get(CommonConstant.FIELD_ICCID)).trim().equalsIgnoreCase(String.valueOf(ctCheckerData.get(CommonConstant.FIELD_ICCID)).trim())) {
                                //ct卡埋点
                                try {
                                    realNameRegisterService.innerStatisService("twoct");
                                }catch (Exception e){
                                    logger.info("ct卡号埋点报错...{}",e);
                                }
                                responseMap.put(CommonConstant.FIELD_CARDBELONG, CommonConstant.WX_CARD_BELONG_CT);
                                responseMap.put(CommonConstant.FIELD_IMSI, ctCheckerData.get(CommonConstant.FIELD_IMSI));
                                responseMap.put(CommonConstant.FIELD_BEID, ctCheckerData.get(CommonConstant.FIELD_BEID));
                                responseMap.put(CommonConstant.FIELD_CUSTID, ctCheckerData.get(CommonConstant.FIELD_CUSTID));
                                responseMap.put(CommonConstant.FIELD_STATUS, ctCheckerData.get(CommonConstant.FIELD_STATUS));
                                responseMap.put("msisdn",map.get("msisdn"));
                                //查询卡是否管理停机
                                responseMap.put("managerClose",iCtBusinessSerClient.queryCardStatus(transNo,responseMap));
                                response.setData(responseMap);
                            } else {
                                iLog.info(logger, transNo, null, "物联卡号与ICCID不匹配，请检查后修改", map);
                                response.setResponse(ResponseEnum.ERR_DISACCORD,ctChecker.getData());
                            }
                            return response;
                        }
                    }
                    // 归属PB的卡

                    /**
                     * 4.300.8.9
                     * 新增物联卡归属省份判断
                     * */
                    if(map.get("msgId") != null && !"".equals(map.get("msgId"))){
                        String beId = iCache.get(CacheManager.PublicNameSpace.TEMP,"realnameH5_".concat(String.valueOf(map.get("msgId"))));
                        if(StringUtils.isEmpty(beId)){
                            //缓存过期，返回错误信息
                            logger.info("实名登记H5网页，缓存中不存在本次调用的省份限制，msisdn is:[{}],msgId is:[{}]",map.get(CommonConstant.FIELD_MSISDN),map.get("msgId"));
//                            return response.setResponse(ResponseEnum.ERR_OBJECT_MISSING);
                        }else {
                            if(!beId.equals(msisdnCacheVo.getProvinceId())){
                                logger.info("实名登记H5网页，校验物联权限失败,msisdn is:[{}],card beId is:[{}],H5 beId is:[{}]",msisdnCacheVo.getMsisdn(),msisdnCacheVo.getProvinceId(),beId);
                                return response.setResponse(ResponseEnum.ERR_OBJECT_AUTH);
                            }
                        }
                    }
                    if (String.valueOf(map.get(CommonConstant.FIELD_ICCID)).trim().equalsIgnoreCase(msisdnCacheVo.getIccid().trim())) {
                        String status = StringUtils.isEmpty(msisdnCacheVo.getStatus()) ? "" : msisdnCacheVo.getStatus();
                        String provinceId = StringUtils.isEmpty(msisdnCacheVo.getProvinceId()) ? "" : msisdnCacheVo.getProvinceId();
                        if (StringUtils.isEmpty(status)) {
                            Map dbSimInfo = getDbSimInfo(String.valueOf(map.get(CommonConstant.FIELD_MSISDN)), provinceId, msisdnCacheVo.getCustId());
                            status = dbSimInfo == null || dbSimInfo.get(CommonConstant.FIELD_STATUS) == null ? status : dbSimInfo.get(CommonConstant.FIELD_STATUS).toString();
                        }
                        if (CommonConstant.PB_CARDSTATUS_CANCEL.equalsIgnoreCase(status) || StringUtils.isEmpty(status)) {
                            // 销户状态不允许绑定
                            response.setResponse(ResponseEnum.ERR_ACCOUNT_CANCEL);
                        }else {

                            //实名埋点
                            try {
                                realNameRegisterService.innerStatisService("twopb");
                            }catch (Exception e){
                                logger.info("pb卡号埋点报错...{}",e);
                            }

                            responseMap.put(CommonConstant.FIELD_CARDBELONG, CommonConstant.WX_CARD_BELONG_PB);
                            responseMap.put(CommonConstant.FIELD_IMSI, msisdnCacheVo.getImsi());
                            responseMap.put(CommonConstant.FIELD_BEID, StringUtils.isEmpty(msisdnCacheVo.getProvinceId()) ? "" : msisdnCacheVo.getProvinceId());
                            responseMap.put(CommonConstant.FIELD_STATUS, status);
                            responseMap.put(CommonConstant.FIELD_SUBSID, getSubsId(String.valueOf(map.get(CommonConstant.FIELD_MSISDN)), transNo));
                            response.setData(responseMap);
                        }
                    } else {
                        iLog.info(logger, transNo, null, "物联卡号与ICCID不匹配，请检查后修改", map);
                        response.setResponse(ResponseEnum.ERR_DISACCORD);
                    }
                } else {
                    // 调用 CT 接口判断是否存在
                    ResponseVo ctChecker = ctUserService.queryCardBasicInfo(map);
//                    logger.info("register ct卡查询基本信息返回:{}", JsonUtils.parseString(ctChecker));
                    if (ctChecker != null && ctChecker.isSuccess() && ctChecker.getData() != null) {
                        // 归属 CT 的卡
                        Map ctCheckerData = (Map) ctChecker.getData();
                        /**
                         * 4.300.8.9
                         * 新增物联卡归属省份判断
                         * */
                        if(map.get("msgId") != null && !"".equals(map.get("msgId"))){
                            String beId = iCache.get(CacheManager.PublicNameSpace.TEMP,"realnameH5_".concat(String.valueOf(map.get("msgId"))));
                            if(StringUtils.isEmpty(beId)){
                                //缓存过期，返回错误信息
                                logger.info("实名登记H5网页，缓存中不存在本次调用的省份限制，msisdn is:[{}],msgId is:[{}]",map.get(CommonConstant.FIELD_MSISDN),map.get("msgId"));
//                                return response.setResponse(ResponseEnum.ERR_OBJECT_MISSING);
                            }else {
                                if(!beId.equals(ctCheckerData.get(CommonConstant.FIELD_BEID))){
                                    logger.info("实名登记H5网页，校验物联权限失败,msisdn is:[{}],card beId is:[{}],H5 beId is:[{}]",map.get(CommonConstant.FIELD_MSISDN),ctCheckerData.get(CommonConstant.FIELD_BEID),beId);
                                    return response.setResponse(ResponseEnum.ERR_OBJECT_AUTH);
                                }
                            }
                        }
                        if (String.valueOf(map.get(CommonConstant.FIELD_ICCID)).trim().equalsIgnoreCase(String.valueOf(ctCheckerData.get(CommonConstant.FIELD_ICCID)).trim())) {
                            //ct卡埋点
                            try {
                                realNameRegisterService.innerStatisService("twoct");
                            }catch (Exception e){
                                logger.info("ct卡号埋点报错...{}",e);
                            }
                            responseMap.put(CommonConstant.FIELD_CARDBELONG, CommonConstant.WX_CARD_BELONG_CT);
                            responseMap.put(CommonConstant.FIELD_IMSI, ctCheckerData.get(CommonConstant.FIELD_IMSI));
                            responseMap.put(CommonConstant.FIELD_BEID, ctCheckerData.get(CommonConstant.FIELD_BEID));
                            responseMap.put(CommonConstant.FIELD_CUSTID, ctCheckerData.get(CommonConstant.FIELD_CUSTID));
                            responseMap.put(CommonConstant.FIELD_STATUS, ctCheckerData.get(CommonConstant.FIELD_STATUS));
                            responseMap.put("msisdn",map.get("msisdn"));
                            //查询卡是否管理停机
                            responseMap.put("managerClose",iCtBusinessSerClient.queryCardStatus(transNo,responseMap));
                            response.setData(responseMap);
                        } else {
                            iLog.info(logger, transNo, null, "物联卡号与ICCID不匹配，请检查后修改", map);
                            response.setResponse(ResponseEnum.ERR_DISACCORD,ctChecker.getData());
                        }
                    } else {
                        iLog.info(logger, transNo, null, "物联卡号不存在", map);
                        response.setResponse(ResponseEnum.ERR_NOT_EXIST,ctChecker.getData());
                    }
                }
            } else {
                iLog.info(logger, transNo, null, "缺少必要参数", map);
                response.setResponse(ResponseEnum.ERR_MISS_PARAMS);
            }
        } catch (Exception e) {
            iLog.info(logger, transNo, null, "校验物联卡号与ICCID是否匹配异常", e, map);
            response.setResponse(ResponseEnum.ERR_SYSTEM);
        }
        return response;
    }

    /**
     * 根据Msisdn查询subsId
     *
     * @param msisdn
     * @return
     */
    public String getSubsId(String msisdn, String transNo) {
        // 从缓存中查询subsId
        MsisdnCacheVo cacheByMsisdn = cache.getByMsisdn(msisdn);
        if (cacheByMsisdn == null) {
            return "";
        }
        String subsId = StringUtils.isEmpty(cacheByMsisdn.getSubsId()) ? "" : cacheByMsisdn.getSubsId();
        String provinceId = StringUtils.isEmpty(cacheByMsisdn.getProvinceId()) ? "" : cacheByMsisdn.getProvinceId();
        if (StringUtils.isEmpty(subsId)) {
            // 缓存查询为空，从数据库查询
            long start = System.currentTimeMillis();
            if (StringUtils.isEmpty(provinceId)) {
                setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
            } else {
                setDatasourceByProvince(provinceId);
            }
            Map params=new HashMap();
            params.put("msisdn",msisdn);
            params.put("provinceId",provinceId);
            subsId = userService.getSubsId(params);
            iLog.info(logger, transNo, null, String.format("从缓存中未查询到subsId，从数据库查询结果：%s [耗时：%s ms]", subsId, System.currentTimeMillis() - start));
        }
        return subsId;
    }


    /**
     * 业务点击量入库
     *
     * @param params
     * @return
     */
    public Integer saveBusinessHitLog(Map params) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        List<Map> list = new ArrayList();
        try {
            List<Map> hitList = (List<Map>) params.get("list");
            String plat = (String) params.get(CommonConstant.BUSINESS_HIT_PLAT);
            String userId = (String) params.get(CommonConstant.USERID);
            for (Map map : hitList) {
                // 校验参数
                MapParamChecker mapParamChecker = MapParamChecker.instance(map)
                        .isNotBlank(CommonConstant.BUSINESS_HIT_TYPE)
                        .isNotBlank(CommonConstant.HIT_TIME);
                if (mapParamChecker.isValid()) {
                    // BUSINESS_HIT_TYPE 在参数列表中
                    if (CommonConstant.BUSINESS_HIT_MAP.containsKey(map.get(CommonConstant.BUSINESS_HIT_TYPE))) {
                        map.put(CommonConstant.HIT_ID, UUID.randomUUID().toString().replaceAll("-", ""));
                        map.put(CommonConstant.BUSINESS_HIT_PLAT, plat);
                        map.put(CommonConstant.USERID, userId);
                        map.put(CommonConstant.HIT_TIME, format.format(Long.parseLong(map.get(CommonConstant.HIT_TIME).toString())));
                        list.add(map);
                    }
                }
            }
            if (list.size() > 0) {
                setAsDefaultDatasource();
                Integer reList = wxPersonUserInfoDao.saveBusinessHitLog(list);
                setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
                return reList;

            } else {
                iLog.info(logger, params.get(CommonConstant.TRANSNO).toString(), params, "业务点击量信息入库操作无效,有效点击量信息为空");
                return 0;
            }
        } catch (Exception e) {
            iLog.error(logger, params.get(CommonConstant.TRANSNO).toString(), params, "业务点击量信息入库操作异常", e);
            return 0;
        }
    }

    public MsisdnBindingVo getMsisdnIccid(String msisdn, String provinceId) {
        Map<String, String> map = new HashMap<>(1);
        map.put("msisdn", msisdn);
        setDatasourceByProvince(provinceId);
        map.put("provinceId", provinceId);
        return wxPersonUserInfoDao.getMsisdnIccid(map);
    }

    public List getDicts(String type) {
        setAsDefaultDatasource();
        Map params = new HashMap();
        params.put("dict_type", type);
        return wxPersonUserInfoDao.getDicts(params);
    }

    @Transactional(rollbackFor = Exception.class)
    public int saveFeedback(Map params) {
        setAsDefaultDatasource();
        params.put(CommonConstant.FIELD_FEEDBACK_ID, java.util.UUID.randomUUID().toString().replace("-", "").toUpperCase());
        return wxPersonUserInfoDao.saveFeedback(params);
    }

    public String getSegmentBelong(String phone) {
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.getSegmentBelong(phone);
    }

    public MsisdnBindingVo selectCtByMsisdn(String msisdn){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.selectCtByMsisdn(msisdn);
    }

    public String authAndNormalUserId(String custCertNo){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        return wxPersonUserInfoDao.authAndNormalUserId(custCertNo);
    }

    public void deleteOpenId(Map map){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        String dbOpenId = wxPersonUserInfoDao.queryOpenIdByPhone(map);
        logger.info("{}退出登录，数据库openId:{},传入openId:{}",CommonUtils.mobileEncrypt(map.get("phone")!=null?map.get("phone").toString():""),dbOpenId,map.get("openId"));
        wxPersonUserInfoDao.deleteOpenIdByPhone(map);
    }

    public int queryRegisterCt(String msisdn){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
       return wxPersonUserInfoDao.queryRegisterStatusCt(msisdn);
    }
}