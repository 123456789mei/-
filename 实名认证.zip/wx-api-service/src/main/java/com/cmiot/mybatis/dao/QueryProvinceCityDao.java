package com.cmiot.mybatis.dao;

import org.apache.ibatis.annotations.Mapper;

import java.util.Map;

/**
 * company ustcinfo.com
 * description 查询省份、地市信息
 * date 2018/4/2
 *
 * @author yang.dehao@ustcinfo.com
 */
@Mapper
public interface QueryProvinceCityDao {
    /**
     * 根据省份名称查询省份编码
     * @param map
     * @return
     */
    String getCodeByProvinceName(Map<String, Object> map);

    /**
     * 根据城市名称查询城市编码
     * @param map
     * @return
     */
    String getCodeByCityName(Map<String, Object> map);
}
