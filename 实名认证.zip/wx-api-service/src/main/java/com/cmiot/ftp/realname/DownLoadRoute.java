package com.cmiot.ftp.realname;


import com.cmiot.commons.cache.ICache;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DownLoadRoute extends RouteBuilder {

    private static final Logger logger = LoggerFactory.getLogger( DownLoadRoute.class );

    @Autowired
    ICache cache;

    @Override
    public void configure() throws Exception {

        from(   cache.getSysParams("REAL_NAME_FTP_URL", "") + cache.getSysParams("REAL_NAME_FTP_PARAMS", "")+"&filter=#downLoadFileFilter")
                .streamCaching().log("Get file from FTP to NAS")
                .to("file:"+  cache.getSysParams("REAL_NAME_FTP_LOCAL", "") )
                .log(LoggingLevel.INFO, logger, "Downloaded file $simple{file:name} complete.");

    }
}