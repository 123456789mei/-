package com.cmiot.ftp.realname;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.Session;

/**
 * @Author mofan
 * @Date 2020/10/23 10:07
 */
public class SftpEntity {

    private Session session;
    private Channel channel;

    public SftpEntity(SFTPUtil ft, String host, Integer port, String user, String password, String timeOut) {
        Session session = ft.getSession(host, port, user, password, timeOut);
        Channel channel = ft.getChannel(session);
        this.session = session;
        this.channel = channel;
    }

    public Session getSession() {
        return session;
    }

    public void setSession(Session session) {
        this.session = session;
    }

    public Channel getChannel() {
        return channel;
    }

    public void setChannel(Channel channel) {
        this.channel = channel;
    }
}
