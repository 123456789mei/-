package com.cmiot.ftp.realname;


import com.cmiot.commons.cache.ICache;
import com.cmiot.wx.apiservice.utiles.RealNameAuthConstant;
import org.apache.camel.component.file.GenericFile;
import org.apache.camel.component.file.GenericFileFilter;
import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class DownLoadFileFilter implements GenericFileFilter {

    private static final Logger logger = LoggerFactory.getLogger(DownLoadFileFilter.class);

    @Autowired
    ICache cache;

    /**
     * 过滤下载文件
     *
     * @author zhangpengfei
     */
    @Override
    public boolean accept(GenericFile file) {
        try {
            String fileName = file.getFileName();
            return isQualified(fileName) && !isInLocalDir(fileName);
        } catch (Exception e) {
            logger.error("ftp download file filter error !", e);
            return false;
        }
    }

    /**
     * 压缩包名称是否符合规定
     *
     * @author zhangpengfei
     */
    private boolean isQualified(String fileName) {
        if (fileName != null) {
            if (fileName.startsWith("BOSS" + RealNameAuthConstant.CMIOT_CODE + "_PIC_") && fileName.endsWith(".tar.gz")) {
                String date= "";
                try {
                    date =  fileName.substring(15,29);
                    DateUtils.parseDate(date,new String[]{RealNameAuthConstant.BUSISEQ_DATE_FORMAT});
                    return true;
                } catch (ParseException e) {
                    logger.error("Fail to pull gz from ftp because the date of gz is not correct",e,date);
                }
            }
        }
        return false;
    }

    /**
     * 文件是否已在本地目录中
     *
     * @author zhangpengfei
     */
    private boolean isInLocalDir(String fileName) {
        try {
            //获取本地文件夹中已下载的文件名
            //String date  = fileName.substring(15,23);       +"/"+date
            List<String> localFileNames = Files.walk(Paths.get(cache.getSysParams("REAL_NAME_FTP_LOCAL", "")))
                    .filter(Files::isRegularFile)
                    .map(Path::getFileName)
                    .map(Path::toString)
                    .collect(Collectors.toList());
            for (String str:
                    localFileNames) {
                if(str.contains(fileName)){
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            logger.error("get local downloaded files fail !", e);
            return true;
        }
    }
}
