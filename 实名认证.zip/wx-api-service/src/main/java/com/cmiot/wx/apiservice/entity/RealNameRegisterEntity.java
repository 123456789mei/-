package com.cmiot.wx.apiservice.entity;

/**
 * 个人业务，物联卡实名认证登记信息实体
 */
public class RealNameRegisterEntity {

    private String custCertNo;//登记身份证号
    private String msisdn;//物联卡号

    public String getCustCertNo() {
        return custCertNo;
    }

    public void setCustCertNo(String custCertNo) {
        this.custCertNo = custCertNo;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }
}
