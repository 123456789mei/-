package com.cmiot.wx.apiservice.utiles;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author 王军
 * @Date 2018/2/8
 * @description 签名，算法见省平台
 */
public class SignUtil {
    private static final String SIGN_METHOD_HMACSHA256 = "HmacSHA256";
    private static final String CONTENT = "content";
    private static final String SIGN = "sign";

    private SignUtil() {}
    private static String signWithSHA256(Map<String, String> sysParam, String busiParam, String key)
            throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException {
        HashMap map = new HashMap(sysParam);
        map.put(CONTENT, busiParam);
        String[] keys = (String[])map.keySet().toArray(new String[map.size()]);
        Arrays.sort(keys);
        StringBuilder buf = new StringBuilder();
        buf.append(key);
        String[] var9 = keys;
        int var8 = keys.length;

        for(int var7 = 0; var7 < var8; ++var7) {
            String k = var9[var7];
            if(!SIGN.equalsIgnoreCase(k)) {
                buf.append(k).append((String)map.get(k));
            }
        }
        buf.append(key);
        return SecurityUtils.encodeHmacSHA256HexUpper(buf.toString(), SecurityUtils.decodeHexUpper(key));
    }

    public static String sign(Map<String, String> sysParam, String busiParam, String method, String key)
            throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException {
        if((sysParam == null || sysParam.isEmpty()) && (busiParam == null || busiParam.trim().length() == 0)) {
            return null;
        } else if(SIGN_METHOD_HMACSHA256.equals(method)) {
            return signWithSHA256(sysParam, busiParam, key);
        } else {
            throw new NoSuchAlgorithmException("对不起，暂不支持[" + method + "]签名方法！");
        }
    }

}
