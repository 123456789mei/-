package com.cmiot.wx.apiservice.service.impl;

import com.cmiot.comm.dao.connector.DatasourceBase;
import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.mybatis.dao.PbRegisterDao;
import com.cmiot.util.HttpUtil;
import com.cmiot.wx.apiservice.entity.PbResultVo;
import com.cmiot.wx.apiservice.utiles.SecurityUtils;
import com.cmiot.wx.apiservice.utiles.SignUtil;
import com.cmiot.wx.apiservice.utiles.XmlUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class BjPbRegisterService extends DatasourceBase {

    static  Logger logger = LoggerFactory.getLogger(BjPbRegisterService.class);

    @Autowired
    ICache cache;


    @Autowired
    PbRegisterDao pbRegisterDao;


    /**
     * PB卡实名认证流程查询
     */
    public ResponseVo checkMsisdnFlowService(Map map) {
        try {
            //业务数据封装
            Map p=new HashMap();
            p.put("MSISDN",map.get("msisdn"));
            Map request=new HashMap();
            request.put("BUSICODE","OPF_SO_GROU_WLW_CRMGROUPQRY_002");
            request.put("BUSIPARAMS",p);
            Map PUBINFO=new HashMap();
            PUBINFO.put("OPCODE","27010385");
            PUBINFO.put("OPORGID","14");
            PUBINFO.put("TRANSACTIONTIME",getTime());
            PUBINFO.put("INTERFACEID","100000000001");
            PUBINFO.put("CHNLTYPE","1");
            Map AICRMSERVICE=new HashMap();
            AICRMSERVICE.put("PUBINFO",PUBINFO);
            AICRMSERVICE.put("REQUEST",request);
            Map Req=new HashMap();
            Req.put("AICRMSERVICE",AICRMSERVICE);
            String params = XmlUtil.map2XmlString(Req).toString();
            logger.info("pb100 卡号查询接口业务参数检查msisdn:{}",map.get("msisdn"));
            //从缓存获取参数
            String url=cache.getSysParams("100.url","");
            String openId=cache.getSysParams("100.openId","");
            String appId=cache.getSysParams("100.appId","");
            String privateKey=cache.getSysParams("100.privateKey","");
            String publicKey=cache.getSysParams("100.publicKey","");

            //业务参数加密
            String busiparam = encryptBusiXml(params,publicKey,privateKey);
            Map systemParam = createSysParam("OPF_SO_GROU_WLW_CRMGROUPQRY_002", busiparam,appId,openId,url,privateKey);
            url = createUrl(systemParam,url);
            logger.info("pb100 卡号查询接口请求前检查url:{},params:{}",url,busiparam);
            String result = HttpUtil.sendPost(url,busiparam);
            logger.info("100checkMsisdnFlowService能开返回结果...{}",result);
            //返回结果xml转map
            Map<String, Object> objectMap = XmlUtil.multilayerXmlToMap(result);
           Map descMap=(Map) objectMap.get("root");
           if("00000".equals(descMap.get("respCode"))){
               result = SecurityUtils.decodeAES256HexUpper(descMap.get("result").toString(), SecurityUtils.decodeHexUpper(privateKey));
               logger.info("checkMsisdnFlowService100解密后的结果...{}",result);
               Map<String, Object> resultMap = XmlUtil.multilayerXmlToMap(result);
               //获取结果
               Map response = (Map) resultMap.get("RESPONSE");
               Map retinfo = (Map) response.get("RETINFO");
               return ResponseVo.success(JsonUtils.parseObject(retinfo, PbResultVo.class));
           }else {
               return ResponseVo.fail("10001");
           }
        } catch (Exception e) {
            logger.info("100 pb msisdn query fail checkMsisdnFlowService...{}...{}",
                    JsonUtils.parseString(map),e.getMessage());
            return ResponseVo.fail("99");
        }
    }


    /**
     * 一证五号校验
     */
    public ResponseVo idCardCheck(Map map) {
        try {
            //业务数据封装
            Map p=new HashMap();
            p.put("MSISDN",map.get("msisdn").toString().trim());
            p.put("IDTYPE",map.get("idType").toString().trim());
            p.put("IDCARD",map.get("idCard").toString().trim());
            p.put("CUSTOMERNAME",map.get("customerName").toString().trim());
            Map request=new HashMap();
            request.put("BUSICODE","OPF_SO_GROU_WLW_ONECERTNOCHECK_001");
            request.put("BUSIPARAMS",p);
            Map PUBINFO=new HashMap();
            PUBINFO.put("OPCODE","27010385");
            PUBINFO.put("OPORGID","14");
            PUBINFO.put("TRANSACTIONTIME",getTime());
            PUBINFO.put("INTERFACEID","100000000001");
            PUBINFO.put("CHNLTYPE","1");
            Map AICRMSERVICE=new HashMap();
            AICRMSERVICE.put("PUBINFO",PUBINFO);
            AICRMSERVICE.put("REQUEST",request);
            Map Req=new HashMap();
            Req.put("AICRMSERVICE",AICRMSERVICE);
            String params = XmlUtil.map2XmlString(Req).toString();
            logger.info("100idCardCheck入参检查msisdn:{}",map.get("msisdn").toString().trim());
            //从缓存获取参数
            String url=cache.getSysParams("100.url","");
            String openId=cache.getSysParams("100.openId","");
            String appId=cache.getSysParams("100.appId","");
            String privateKey=cache.getSysParams("100.privateKey","");
            String publicKey=cache.getSysParams("100.publicKey","");

            //业务参数加密
            String busiparam = encryptBusiXml(params,publicKey,privateKey);
            Map systemParam = createSysParam("OPF_SO_GROU_WLW_ONECERTNOCHECK_001", busiparam,appId,openId,url,privateKey);
            url = createUrl(systemParam,url);
            logger.info("pb100idCardCheck接口请求前检查url:{},params:{}",url,busiparam);
            String result = HttpUtil.sendPost(url,busiparam);
            logger.info("100idCardCheck能开返回结果...{}",result);
            //返回结果xml转map
            Map<String, Object> objectMap = XmlUtil.multilayerXmlToMap(result);
            Map descMap=(Map) objectMap.get("root");
            if("00000".equals(descMap.get("respCode"))){
                result = SecurityUtils.decodeAES256HexUpper(descMap.get("result").toString(), SecurityUtils.decodeHexUpper(privateKey));
                logger.info("idCardCheck100解密后的结果...{}",result);
                Map<String, Object> resultMap = XmlUtil.multilayerXmlToMap(result);
                //获取结果
                Map response = (Map) resultMap.get("RESPONSE");
                Map retinfo = (Map) response.get("RETINFO");
                return ResponseVo.success(JsonUtils.parseObject(retinfo, PbResultVo.class));
            }else {
                return ResponseVo.fail("10001");
            }
        } catch (Exception e) {
            logger.info("100 pb idCardCheck fail idCardCheck...{}...{}",
                    JsonUtils.parseString(map),e.getMessage());
            return ResponseVo.fail("99");
        }
    }



    /**
     * 获取token令牌
     */
    public static String getToken(String url,String appId,String privateKey){
        String tokenUrl = String.format("%saopoauth/oauth/authorize?app_id=%s&app_key=%s&redirect_uri=http://www.example.com&response_type=token",
                url, appId, privateKey);
        String result = HttpUtil.doGet(tokenUrl, "");
        if(result!=null&&!"".equals(result)&&result.contains("access_token")){
            String accessToken = getUrl(result, "access_token");
            return accessToken;
        }else {
            return "";
        }
    }

    public static String getUrl(String url, String name){
        url +="&";
        String pattern = "(\\?|&){1}#{0,1}"  + name + "=[a-zA-Z0-9]*(&{1})";
        Pattern r = Pattern.compile(pattern);
        Matcher matcher = r.matcher(url);
        if(matcher.find()){
            //            System.out.println(matcher.group(0));
            return matcher.group(0).split("=")[1].replace("&","");
        }else{
            return null;
        }
    }



    /**
     * 生成时间戳
     */
    public static String getTime(){
        Date date=new Date(System.currentTimeMillis());
        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
        return sdf.format(date);
    }




    public static String encryptBusiXml(String busiParam,String publicKey,String privateKey)
    {
        busiParam = busiParam.replaceAll("<\\?xml\\s*version=\"1.0\"\\s*encoding=\"(.*?)\"\\?>", "");
        busiParam = busiParam.replaceAll("[\\n\\r]", "");

        String encryptionContent = "";
        try{
            encryptionContent = SecurityUtils.encodeAES256HexUpper(busiParam,SecurityUtils.decodeHexUpper(privateKey));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return encryptionContent;
    }

    //生成公共参数
    public static Map createSysParam(String method , String busiParam,String appId,String openId,String url,String privateKey)
    {
        //构建公共参数
        Map<String, String> sysParam = new HashMap<String, String>();
        sysParam.put("method", method);//跟你要使用的接口有关
        sysParam.put("format", "xml");
        sysParam.put("appId", appId);
        sysParam.put("operId", "10000");
        sysParam.put("openId", openId);//由能力开发平台提供
        sysParam.put("version", "1.1.3");
        sysParam.put("accessToken", "2cb147ec-1652-4d56-8dc5-5e3d4509aae3");
        sysParam.put("timestamp", getTime());//也可以传时间字符串
        sysParam.put("busiSerial", getTime()+new Random().nextInt(1000000));//流水号
        String sign = createSign(sysParam,busiParam,privateKey);//其中busiParam为加密后的业务参数
        sysParam.put("sign", sign);
        return sysParam;
    }

    //生成数字签名
    public static String createSign(Map sysParam , String busiParam,String privateKey)
    {
        //数字签名算法
        String signType = "SHA";
        //数字签名
        String sign = "";
        try {
            sign = SignUtil.sign(sysParam, busiParam, "HmacSHA256", privateKey);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return sign;
    }
    //拼装url
    public static String createUrl(Map systemParam,String url){
        url = url+"oppf";
        StringBuffer param = new StringBuffer();
        param.append(url+"?");
        param.append("timestamp="+systemParam.get("timestamp")+"&");
        param.append("busiSerial="+systemParam.get("busiSerial")+"&");
        param.append("appId="+systemParam.get("appId")+"&");
        param.append("accessToken="+systemParam.get("accessToken")+"&");
        param.append("method="+systemParam.get("method")+"&");
        param.append("format="+systemParam.get("format")+"&");
        param.append("version="+systemParam.get("version")+"&");
        param.append("openId="+systemParam.get("openId")+"&");
        param.append("operId="+systemParam.get("operId")+"&");
        param.append("sign="+systemParam.get("sign"));
        url=param.toString();

        return url;
    }





}
