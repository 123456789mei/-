package com.cmiot.wx.apiservice.entity;

import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;

public class RealNameParams {

    @NotNull(message = "用户Id不能为空")
    @Length(min = 1,max = 32,message = "用户ID长度不符合规定")
    private String userId;

    @NotNull(message = "用户手机号不能为空")
    @Length(min = 1,max = 11,message = "手机号长度不符合规定")
    private String phone;

    @NotNull(message = "认证结果推送地址不能为空")
    @Length(min = 1,max = 200,message = "回调地址长度不符合规范")
    private String callBackUrl;

    @NotNull(message = "接入渠道不能为空")
    @Length(min = 1,message = "接入渠道不能为空")
    private String channelId;


    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCallBackUrl() {
        return callBackUrl;
    }

    public void setCallBackUrl(String callBackUrl) {
        this.callBackUrl = callBackUrl;
    }

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }
}
