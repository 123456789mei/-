package com.cmiot.wx.apiservice.service;

import com.asiainfo.openplatform.utils.SignUtil;
import com.cmiot.comm.dao.connector.DatasourceBase;
import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.mybatis.dao.PbRegisterDao;
import com.cmiot.util.HttpUtil;
import com.cmiot.util.signtj.SignUtilTj;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class TjPbRegisterService extends DatasourceBase {

    static  Logger logger = LoggerFactory.getLogger(TjPbRegisterService.class);

    @Autowired
    ICache cache;


    @Autowired
    PbRegisterDao pbRegisterDao;

    static final String APPID="TJ_APPID";

    static final String APPKEY="TJ_APPKEY";

    static final String PUBLICKEY="TJ_PUBLICKEY";



    /**
     * PB卡实名认证流程查询
     */
    public ResponseVo checkMsisdnFlowService(Map map,String transNo) {
        try {
            String appId = cache.getSysParams(APPID, "");
            String appKey = cache.getSysParams(APPKEY, "");
            String publicKey = cache.getSysParams(PUBLICKEY, "");
            Map param=new HashMap();
            param.put("msisdn",map.get("msisdn"));
            param.put("Req_seq",transNo);
            param.put("Req_time",getTime());
            param.put("X_TRANS_CODE","TJ_UNHT_ValidateRealName");
            param.put("PROVINCE_CODE","TJIN");
            param.put("ROUTE_EPARCHY_CODE","0022");
            param.put("TRADE_EPARCHY_CODE","0022");
            param.put("EPARCHY_CODE","0022");
            param.put("TRADE_CITY_CODE","INTF");
            String publicParams = cache.getSysParams("TJ_PUBLICPARAMS", "");
            if(StringUtils.isNotBlank(publicParams)){
                Map publicMap = JsonUtils.parseObject(publicParams, Map.class);
                param.putAll(publicMap);
            }
            String json = JsonUtils.parseString(param);
            //获取环境配置
            String urlParam = cache.getSysParams("PBREGISTER_TJ_URL", "");
            String baseUrl=urlParam.split(",")[0];
            String status=urlParam.split(",")[1];
            logger.info("天津参数检查...appId:{},appKey:{},publicKey:{},urlParam:{}",appId,appKey,publicKey,urlParam);
            Map<String, String> sysParam = new HashMap();
            sysParam.put("method", "TJ_UNHT_ValidateRealName");
            sysParam.put("appId", appId);
            sysParam.put("timestamp", getTime());
            sysParam.put("format", "json");
            // 请根据实际业务创建流水号
            sysParam.put("flowId", getTime());
            sysParam.put("status", status);
            sysParam.put("appKey", appKey);
            // 生成sign签名
            String sign = SignUtilTj.generateSign(sysParam, new String(json.getBytes("utf-8")));
            logger.info("天津签名检查...sign:{}",sign);
            String url = baseUrl+"?method=" + sysParam.get("method") + "&appId="
                    + sysParam.get("appId") + "&flowId=" + sysParam.get("flowId") + "&status=" + sysParam.get("status")
                    + "&format=" + sysParam.get("format") + "&appKey=" + sysParam.get("appKey") + "&timestamp="
                    + sysParam.get("timestamp") + "&sign=" + URLEncoder.encode(sign, "utf-8");
            logger.info("天津pb卡信息校验接口请求前检查...url:{},params:{}",url,json);
            String x = HttpUtil.sendPostTj(url,json);
            logger.info("天津pb卡信息校验接口返回参数检查...{}",x);
            if(StringUtils.isNotBlank(x)){
                Map reMap = JsonUtils.parseObject(x, Map.class);
                Map result = JsonUtils.parseObject(reMap.get("result"), Map.class);
                List content = JsonUtils.parseObject(result.get("SVC_CONTENT"), List.class);
                Map resultParams = JsonUtils.parseObject(content.get(0), Map.class);
                if(resultParams.containsKey("isAuth")&&resultParams.containsKey("needAuth")){
                    return ResponseVo.success(resultParams);
                }else{
                    return ResponseVo.fail("10001");
                }
            }else {
                return ResponseVo.fail("10001");
            }
        } catch (Exception e) {
            logger.info("天津pb卡信息校验接口报错...{}...{}",
                    JsonUtils.parseString(map),e.getMessage());
            return ResponseVo.fail("99");
        }
    }


    /**
     * 一证五号校验
     */
    public ResponseVo idCardCheck(Map map,String transNo) {
        try {
            String appId = cache.getSysParams(APPID, "");
            String appKey = cache.getSysParams(APPKEY, "");
            String publicKey = cache.getSysParams(PUBLICKEY, "");
            Map param=new HashMap();
            param.put("msisdn",map.get("msisdn"));
            param.put("Req_seq",transNo);
            param.put("idType","0");
            param.put("idCard",map.get("idCard"));
            param.put("Cust_name",map.get("customerName"));
            param.put("Channelid","022");
            param.put("Req_time",getTime());
            param.put("X_TRANS_CODE","TJ_UNHT_RegisteRealName");
            param.put("PROVINCE_CODE","TJIN");
            param.put("ROUTE_EPARCHY_CODE","0022");
            param.put("TRADE_EPARCHY_CODE","0022");
            param.put("EPARCHY_CODE","0022");
            param.put("TRADE_CITY_CODE","INTF");
            String publicParams = cache.getSysParams("TJ_PUBLICPARAMS", "");
            if(StringUtils.isNotBlank(publicParams)){
                Map publicMap = JsonUtils.parseObject(publicParams, Map.class);
                param.putAll(publicMap);
            }
            String json = JsonUtils.parseString(param);
            //获取环境配置
            String urlParam = cache.getSysParams("PBREGISTER_TJ_URL", "");
            String baseUrl=urlParam.split(",")[0];
            String status=urlParam.split(",")[1];
            logger.info("天津参数检查...appId:{},appKey:{},publicKey:{},urlParam:{}",appId,appKey,publicKey,urlParam);
            Map<String, String> sysParam = new HashMap();
            sysParam.put("method", "TJ_UNHT_RegisteRealName");
            sysParam.put("appId", appId);
            sysParam.put("timestamp", getTime());
            sysParam.put("format", "json");
            // 请根据实际业务创建流水号
            sysParam.put("flowId", getTime());
            sysParam.put("status", status);
            sysParam.put("appKey", appKey);
            // 生成sign签名
            String sign = SignUtil.generateSign(sysParam, new String(json.getBytes("utf-8")));
            logger.info("天津签名检查...sign:{}",sign);
            String url = baseUrl+"?method=" + sysParam.get("method") + "&appId="
                    + sysParam.get("appId") + "&flowId=" + sysParam.get("flowId") + "&status=" + sysParam.get("status")
                    + "&format=" + sysParam.get("format") + "&appKey=" + sysParam.get("appKey") + "&timestamp="
                    + sysParam.get("timestamp") + "&sign=" + URLEncoder.encode(sign, "utf-8");
            logger.info("天津pb一证五号接口请求前检查...url:{},params:{}",url,json);
            String x = HttpUtil.sendPostTj(url,json);
            logger.info("天津pb一证五号接口返回参数检查...{}",x);
            if(StringUtils.isNotBlank(x)){
                Map reMap = JsonUtils.parseObject(x, Map.class);
                Map result = JsonUtils.parseObject(reMap.get("result"), Map.class);
                List content = JsonUtils.parseObject(result.get("SVC_CONTENT"), List.class);
                Map resultParams = JsonUtils.parseObject(content.get(0), Map.class);
                if(resultParams.containsKey("checkCode")&&resultParams.containsKey("checkMsg")){
                    return ResponseVo.success(resultParams);
                }else{
                    return ResponseVo.fail("10001");
                }
            }else {
                return ResponseVo.fail("10001");
            }
        } catch (Exception e) {
            logger.info("天津pb一证五号接口报错...{}...{}",
                    JsonUtils.parseString(map),e.getMessage());
            return ResponseVo.fail("99");
        }
    }



    /**
     * 获取token令牌
     */
    public  String getToken(){
        String tokenUrl=cache.getSysParams("371.token","http://192.168.195.31/hnToken");
        logger.info("河南tokenUrl检查:{}",tokenUrl);
        String result = HttpUtil.doGet(tokenUrl+"?app_id=1083846&app_key=a9c8113b2271b9e8edccfb7b7eecfa63&grant_type=client_credentials", "");
        if(result==null||"".equals(result)){
            result = HttpUtil.doGet(tokenUrl+"?app_id=1083846&app_key=a9c8113b2271b9e8edccfb7b7eecfa63&grant_type=client_credentials", "");
        }
        logger.info("检查token结果:{}",result);
        if(result!=null&&!"".equals(result)){
            Map resultMap = JsonUtils.parseObject(result, Map.class);
            if(resultMap!=null&&resultMap.get("access_token")!=null&&!"".equals(resultMap.get("access_token"))){
                return resultMap.get("access_token").toString();
            }else {
                return "";
            }
        }else {
            return "";
        }
    }

    /**
     * 生成时间戳
     */
    public  String getTime(){
        Date date=new Date(System.currentTimeMillis());
        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
        return sdf.format(date);
    }






}
