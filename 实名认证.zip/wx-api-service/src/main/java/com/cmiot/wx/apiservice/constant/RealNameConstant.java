package com.cmiot.wx.apiservice.constant;

public class RealNameConstant {
    public static final String REAL_NAME_RESULT_AUDIT_STATUS = "auditStatus";
    public static final String REAL_NAME_RESULT_TRANSACTION_ID = "transactionID";
    public static final String REAL_NAME_RESULT_BUSISEQ = "busiSeq";
    public static final String REAL_NAME_RESULT_PHONE = "phone";
    public static final String REAL_NAME_RESULT_INFORMATION = "information";

    public static final String SYS_PARAM_WX_BASE_URL = "WX_BASE_URL";
    public static final String SYS_PARAM_REAL_NAME_OPEN_CHANNEL = "REAL_NAME_OPEN_CHANNEL";

    public static final String REAL_NAME_CHANNEL_WX_OA = "WX_OA"; //微信公众号
    public static final String REAL_NAME_CHANNEL_WX_MP = "WX_MP"; //个人业务小程序
    public static final String REAL_NAME_CHANNEL_ONE_LINK_APP = "OneLink_APP"; //个人业务APP


    public static final String BACK_REAL_SYS_CALLBACK_URL = "callBackUrl";
    public static final String BACK_REAL_SYS_RETURN_CODE = "returnCode";
    public static final String BACK_REAL_SYS_RETURN_MESSAGE = "returnMessage";

    public static final String AUDIT_STATUS_SUCCESS = "0";
}
