package com.cmiot.wx.apiservice.entity;

import java.io.Serializable;

/**
 * 描述：流量信息
 */
public class DataAmountBean implements Serializable {
    private static final long serialVersionUID = 1;
    //APN名称
    private String apnName;
    //01-短信业务； 02-GPRS业务 03-语音业务
    private String dataAmountType;
    //用户订购原子产品的实例ID
    private String prodInstID;
    //用户订购原子产品的名称
    private String prodName;
    //套餐总量 短信业务：条数，单位：条； 语音业务：时长，单位：分钟； GPRS业务：流量，单位：MB
    private String dataTotal;
    //套餐使用量 解释同上
    private String dataAmount;
    //套餐剩余量  解释同上
    private String setAmount;
    //若是实时查询：时间是当月一号的00:00:00至当前查询时间；若是月：时间是查询月的一号至 查询月的月最后一天
    private String startTime;
    //若是实时查询：时间是当月一号的00:00:00至当前查询时间；若是月：时间是查询月的一号至 查询月的月最后一天
    private String endTime;
    //是否订购阶梯流量,0-未订购，1,-已订购
    private String flowFlag;
    private String prodId;

    public DataAmountBean(){
        super();
    }
    public String getApnName() {
        return apnName;
    }

    public void setApnName(String apnName) {
        this.apnName = apnName;
    }

    public String getDataAmountType() {
        return dataAmountType;
    }

    public void setDataAmountType(String dataAmountType) {
        this.dataAmountType = dataAmountType;
    }

    public String getProdInstID() {
        return prodInstID;
    }

    public void setProdInstID(String prodInstID) {
        this.prodInstID = prodInstID;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public String getDataTotal() {
        return dataTotal;
    }

    public void setDataTotal(String dataTotal) {
        this.dataTotal = dataTotal;
    }

    public String getDataAmount() {
        return dataAmount;
    }

    public void setDataAmount(String dataAmount) {
        this.dataAmount = dataAmount;
    }

    public String getSetAmount() {
        return setAmount;
    }

    public void setSetAmount(String setAmount) {
        this.setAmount = setAmount;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getFlowFlag() {
        return flowFlag;
    }

    public void setFlowFlag(String flowFlag) {
        this.flowFlag = flowFlag;
    }

    public String getProdId() {
        return prodId;
    }

    public void setProdId(String prodId) {
        this.prodId = prodId;
    }

    @Override
    public String toString() {
        return "DataAmountBean{" +
                "apnName='" + apnName + '\'' +
                ", dataAmountType='" + dataAmountType + '\'' +
                ", prodInstID='" + prodInstID + '\'' +
                ", prodName='" + prodName + '\'' +
                ", dataTotal='" + dataTotal + '\'' +
                ", dataAmount='" + dataAmount + '\'' +
                ", setAmount='" + setAmount + '\'' +
                ", startTime='" + startTime + '\'' +
                ", endTime='" + endTime + '\'' +
                ", flowFlag='" + flowFlag + '\'' +
                ", prodId='" + prodId + '\'' +
                '}';
    }
}
