package com.cmiot.wx.apiservice.entity;

/**
 * @author xiapeicheng
 * @date 2018/9/7 9:56
 * @email xiapeicheng@cmiot.chinamobile.com
 */
public class CTResponseVo {

    private String respCode;

    private String respDesc;

    private String lang;

    private String data;

    public String getRespCode() {
        return respCode;
    }

    public void setRespCode(String respCode) {
        this.respCode = respCode;
    }

    public String getRespDesc() {
        return respDesc;
    }

    public void setRespDesc(String respDesc) {
        this.respDesc = respDesc;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
