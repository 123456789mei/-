package com.cmiot.wx.apiservice.entity;

import java.text.SimpleDateFormat;

/**
 * @author xiapeicheng
 * @date 2018/10/9 11:29
 * @email xiapeicheng@cmiot.chinamobile.com
 */
public class CTRequestVo {

    private String code;

    private String lang;

    private String channelId;

    private String timeStamp;

    private CTParams params;

    public CTRequestVo() {
        code = "";
        lang = "zh-CN";
        channelId = "101";
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
        String date = format.format(System.currentTimeMillis());
        timeStamp = date;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public CTParams getParams() {
        return params;
    }

    public void setParams(CTParams params) {
        this.params = params;
    }
}
