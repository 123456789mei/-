package com.cmiot.wx.apiservice.utiles;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.SecureRandom;

public class PublicFunc {

    static Logger logger = LoggerFactory.getLogger(PublicFunc.class);

    static SecureRandom random = new SecureRandom();

    /**
     * 生成6位随机验证码
     *
     * @return 验证码
     */
    public static String generateSmsValidateCode() {
        StringBuilder smsBuilder = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            smsBuilder.append(random.nextInt(10));
        }
        return smsBuilder.toString();
    }

    public static boolean checkChannels(String openChannel,String busiSeq){
        if(StringUtils.isEmpty(openChannel)){
            return false;
        }
        String[] openChannels = openChannel.split(",");
        if(openChannels.length == 0){
            return false;
        }
        boolean flag = false;
        for(int i=0;i< openChannels.length;i++){
            if(busiSeq.startsWith(openChannels[i])){
                flag = true;
                break;
            }
        }
        return flag;
    }
}
