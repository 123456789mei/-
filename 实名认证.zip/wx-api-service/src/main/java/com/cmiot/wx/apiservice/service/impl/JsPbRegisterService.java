package com.cmiot.wx.apiservice.service.impl;

import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.mybatis.dao.PbRegisterDao;
import com.cmiot.util.HttpUtil;
import com.cmiot.wx.apiservice.utiles.Base64Util;
import com.cmiot.wx.apiservice.utiles.SecurityUtils;
import com.cmiot.wx.apiservice.utiles.SignUtil;
import com.cmiot.wx.apiservice.utiles.XmlUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class JsPbRegisterService{

    static  Logger logger = LoggerFactory.getLogger(JsPbRegisterService.class);

    @Autowired
    ICache cache;


    @Autowired
    PbRegisterDao pbRegisterDao;



    static final String APP_ID="109000000461";
    static final String ACCESS_TOKEN="gvx2az1Y3HsXHKvP6p7c";
    static final String XML_HEADER="<?xml version=\"1.0\" encoding=\"GBK\" ?>";


    /**
     * PB卡实名认证流程查询
     */

    public ResponseVo checkMsisdnFlowService(Map map,String transNo) {
        try {
            //业务数据封装
            Map p=new HashMap();
            p.put("msisdn",map.get("msisdn"));
            String paramsXml = XmlUtil.map2XmlString(p).toString();
            String url = cache.getSysParams("PBREGISTER_JS_URL", "");
            Map PUBINFO=new HashMap();
            PUBINFO.put("app_id",APP_ID);
            PUBINFO.put("access_token",ACCESS_TOKEN);
            PUBINFO.put("sign","");
            PUBINFO.put("verify_code","");
            PUBINFO.put("terminal_id","");
            PUBINFO.put("accept_seq","");
            PUBINFO.put("req_time",getTime());
            PUBINFO.put("req_seq",transNo);
            PUBINFO.put("req_type","01");
            PUBINFO.put("process_code","cc_wlw_queryUser");
            PUBINFO.put("org_id","");
            PUBINFO.put("req_source","1");
            PUBINFO.put("oper_id","");
            PUBINFO.put("content",paramsXml);
            Map AICRMSERVICE=new HashMap();
            AICRMSERVICE.put("operation_in",PUBINFO);
            String params = XmlUtil.map2XmlString(AICRMSERVICE).toString();
//            params=new String(params.getBytes("utf-8"),"GBK");
            logger.info("250checkMsisdnFlowService请求参数检查url:{},params:{}",url,XML_HEADER+params);
            String result = HttpUtil.sendPostJS(url,XML_HEADER+params);
            logger.info("250checkMsisdnFlowService能开返回结果...{}",result);
            //返回结果xml转map
            Map<String, Object> objectMap = XmlUtil.multilayerXmlToMap(result);
            if(objectMap!=null&&objectMap.get("operation_out")!=null){
                Map operationOut = JsonUtils.parseObject(objectMap.get("operation_out"), Map.class);
                if(operationOut!=null&&operationOut.get("content")!=null){
                    Map reMap = JsonUtils.parseObject(operationOut.get("content"), Map.class);
                    if(StringUtils.isNotBlank(reMap.getOrDefault("isAuth","").toString())&&
                            StringUtils.isNotBlank(reMap.getOrDefault("needAuth","").toString())){
                        return ResponseVo.success(reMap);
                    }
                }
            }
            return ResponseVo.fail("10001");
        } catch (Exception e) {
            logger.info("100 pb msisdn query fail checkMsisdnFlowService...{}...{}",
                    JsonUtils.parseString(map),e);
            return ResponseVo.fail("99");
        }
    }




    /**
     * 一证五号校验
     */
    public ResponseVo idCardCheck(Map map,String transNo) {

        try {
            //业务数据封装
            Map p=new HashMap();
            p.put("msisdn",map.get("msisdn"));
            p.put("idCard",map.get("idCard"));
            p.put("idType",map.get("idType"));
            p.put("customerName",map.get("customerName")!=null? Base64Util.getBase64EncodeString(map.get("customerName").toString()):"");
            String paramsXml = XmlUtil.map2XmlString(p).toString();
            String url = cache.getSysParams("PBREGISTER_JS_URL", "");
            Map PUBINFO=new HashMap();
            PUBINFO.put("app_id",APP_ID);
            PUBINFO.put("access_token",ACCESS_TOKEN);
            PUBINFO.put("sign","");
            PUBINFO.put("verify_code","");
            PUBINFO.put("terminal_id","");
            PUBINFO.put("accept_seq","");
            PUBINFO.put("req_time",getTime());
            PUBINFO.put("req_seq",transNo);
            PUBINFO.put("req_type","01");
            PUBINFO.put("process_code","cc_wlw_checkUserTen");
            PUBINFO.put("org_id","");
            PUBINFO.put("req_source","1");
            PUBINFO.put("oper_id","");
            PUBINFO.put("content",paramsXml);
            Map AICRMSERVICE=new HashMap();
            AICRMSERVICE.put("operation_in",PUBINFO);
            String params = XmlUtil.map2XmlString(AICRMSERVICE).toString();
            params=XML_HEADER+params;
//            params=new String(params.getBytes("utf-8"),"GBK");
            logger.info("250idCardCheck请求参数检查url:{},params:{}",url,params);
            String result = HttpUtil.sendPostJS(url,params);
            logger.info("250idCardCheck能开返回结果...{}",result);
            //返回结果xml转map
            Map<String, Object> objectMap = XmlUtil.multilayerXmlToMap(result);
            if(objectMap!=null&&objectMap.get("operation_out")!=null){
                Map operationOut = JsonUtils.parseObject(objectMap.get("operation_out"), Map.class);
                if(operationOut!=null&&operationOut.get("content")!=null){
                    Map reMap = JsonUtils.parseObject(operationOut.get("content"), Map.class);
                    if(StringUtils.isNotBlank(reMap.getOrDefault("checkCode","").toString())&&
                            StringUtils.isNotBlank(reMap.getOrDefault("checkMsg","").toString())){
                        return ResponseVo.success(reMap);
                    }
                }
            }
            return ResponseVo.fail("10001");
        } catch (Exception e) {
            logger.info("100 pb msisdn query fail idCardCheck...{}...{}",
                    JsonUtils.parseString(map),e.getMessage());
            return ResponseVo.fail("99");
        }
    }

//    public static void main(String arg[]){
//        String str="<?xml version=\"1.0\" encoding=\"GBK\" ?><operation_in><req_source>1</req_source><sign></sign><accept_seq></accept_seq><verify_code></verify_code><req_time>20210429002539</req_time><content><idType>1</idType><idCard>500107199205262012</idCard><msisdn>1440125553638</msisdn><customerName>夏骏辰</customerName></content><access_token>gvx2az1Y3HsXHKvP6p7c</access_token><process_code>cc_wlw_checkUserTen</process_code><org_id></org_id><req_seq>837122424494780416</req_seq><req_type>01</req_type><oper_id></oper_id><app_id>109000000461</app_id><terminal_id></terminal_id></operation_in>";
//        try {
//
//            //获取系统默认编码
//            System.out.println("系统默认编码：" + System.getProperty("file.encoding")); //查询结果GBK
//            System.out.println("系统默认字符编码：" + Charset.defaultCharset()); //查询结果GBK
//            str=new String(str.getBytes(),"GBK");
//            Map<String, Object> objectMap = XmlUtil.multilayerXmlToMap(str);
//            if(objectMap!=null&&objectMap.get("operation_out")!=null){
//                Map operationOut = JsonUtils.parseObject(objectMap.get("operation_out"), Map.class);
//                if(operationOut!=null&&operationOut.get("content")!=null){
//                    Map reMap = JsonUtils.parseObject(operationOut.get("content"), Map.class);
//                    if(StringUtils.isNotBlank(reMap.getOrDefault("isAuth","").toString())&&
//                            StringUtils.isNotBlank(reMap.getOrDefault("needAuth","").toString())){
//                        System.out.println(JsonUtils.parseString(reMap));
//                    }
//                }
//            }
//        }catch (Exception e){
//
//        }
//    }






    /**
     * 获取token令牌
     */
    public static String getToken(String url,String appId,String privateKey){
        String tokenUrl = String.format("%saopoauth/oauth/authorize?app_id=%s&app_key=%s&redirect_uri=http://www.example.com&response_type=token",
                url, appId, privateKey);
        String result = HttpUtil.doGet(tokenUrl, "");
        if(result!=null&&!"".equals(result)&&result.contains("access_token")){
            String accessToken = getUrl(result, "access_token");
            return accessToken;
        }else {
            return "";
        }
    }

    public static String getUrl(String url, String name){
        url +="&";
        String pattern = "(\\?|&){1}#{0,1}"  + name + "=[a-zA-Z0-9]*(&{1})";
        Pattern r = Pattern.compile(pattern);
        Matcher matcher = r.matcher(url);
        if(matcher.find()){
            //            System.out.println(matcher.group(0));
            return matcher.group(0).split("=")[1].replace("&","");
        }else{
            return null;
        }
    }



    /**
     * 生成时间戳
     */
    public static String getTime(){
        Date date=new Date(System.currentTimeMillis());
        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
        return sdf.format(date);
    }




    public static String encryptBusiXml(String busiParam,String publicKey,String privateKey)
    {
        busiParam = busiParam.replaceAll("<\\?xml\\s*version=\"1.0\"\\s*encoding=\"(.*?)\"\\?>", "");
        busiParam = busiParam.replaceAll("[\\n\\r]", "");

        String encryptionContent = "";
        try{
            encryptionContent = SecurityUtils.encodeAES256HexUpper(busiParam,SecurityUtils.decodeHexUpper(privateKey));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return encryptionContent;
    }

    //生成公共参数
    public static Map createSysParam(String method , String busiParam,String appId,String openId,String url,String privateKey)
    {
        //构建公共参数
        Map<String, String> sysParam = new HashMap<String, String>();
        sysParam.put("method", method);//跟你要使用的接口有关
        sysParam.put("format", "xml");
        sysParam.put("appId", appId);
        sysParam.put("operId", "10000");
        sysParam.put("openId", openId);//由能力开发平台提供
        sysParam.put("version", "1.1.3");
        sysParam.put("accessToken", "2cb147ec-1652-4d56-8dc5-5e3d4509aae3");
        sysParam.put("timestamp", getTime());//也可以传时间字符串
        sysParam.put("busiSerial", getTime()+new Random().nextInt(1000000));//流水号
        String sign = createSign(sysParam,busiParam,privateKey);//其中busiParam为加密后的业务参数
        sysParam.put("sign", sign);
        return sysParam;
    }

    //生成数字签名
    public static String createSign(Map sysParam , String busiParam,String privateKey)
    {
        //数字签名算法
        String signType = "SHA";
        //数字签名
        String sign = "";
        try {
            sign = SignUtil.sign(sysParam, busiParam, "HmacSHA256", privateKey);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return sign;
    }
    //拼装url
    public static String createUrl(Map systemParam,String url){
        url = url+"oppf";
        StringBuffer param = new StringBuffer();
        param.append(url+"?");
        param.append("timestamp="+systemParam.get("timestamp")+"&");
        param.append("busiSerial="+systemParam.get("busiSerial")+"&");
        param.append("appId="+systemParam.get("appId")+"&");
        param.append("accessToken="+systemParam.get("accessToken")+"&");
        param.append("method="+systemParam.get("method")+"&");
        param.append("format="+systemParam.get("format")+"&");
        param.append("version="+systemParam.get("version")+"&");
        param.append("openId="+systemParam.get("openId")+"&");
        param.append("operId="+systemParam.get("operId")+"&");
        param.append("sign="+systemParam.get("sign"));
        url=param.toString();

        return url;
    }





}
