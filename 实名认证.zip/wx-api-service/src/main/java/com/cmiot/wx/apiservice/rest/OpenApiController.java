package com.cmiot.wx.apiservice.rest;

import com.cmiot.commons.common.constants.ParamConstants;
import com.cmiot.commons.common.utils.MapParamChecker;
import com.cmiot.commons.response.ResponseCode;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.commons.rest.RestBase;
import com.cmiot.wx.apiservice.entity.RealNameParams;
import com.cmiot.wx.apiservice.service.OpenApiService;
import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.Map;

@RestController
@RequestMapping("openApi")
public class OpenApiController extends RestBase {

    Logger logger = LoggerFactory.getLogger(OpenApiController.class);

    @Autowired
    HttpServletRequest request;

    private static String PLAT_KEY = "platKey";

    @Autowired
    OpenApiService apiService;

    @RequestMapping("getRealNameAuthURL")
    public ResponseVo getRealNameAuthURL(@Valid @RequestBody RealNameParams params) {
        logger.info("openApi access,wx api getRealNameAuthURL");
        String platKey = request.getHeader(PLAT_KEY);
        if (StringUtils.isEmpty(platKey)) {
            return ResponseVo.fail(ResponseCode.ERROR_NOTALLOW_REQUEST, new String[]{"未携带平台标识，无访问权限"});
        }
        logger.info("openApi access, getRealNameAuthURL plat is:[{}]", platKey);
        ResponseVo responseVo = apiService.getRealNameAuthURL(platKey,params,getTransNo(request));
        return responseVo;
    }

    @RequestMapping("getRealNameResult")
    public ResponseVo getRealNameResult(@RequestBody Map params){
        logger.info("openApi access,wx api getRealNameResult");
        if (params.get("busiSeq") == null || StringUtils.isEmpty(params.get("busiSeq"))) {
            return ResponseVo.fail(ResponseCode.ERROR_NOTALLOW_REQUEST, new String[]{"业务流水号不能为空"});
        }
        String busiSeq = String.valueOf(params.get("busiSeq"));
        return apiService.getRealNameResult(getTransNo(request),busiSeq);
    }

    /**
     * 物联卡实名登记状态查询
     * */
    @RequestMapping("realNameStatus")
    public ResponseVo realNameStatus(@RequestBody Map params){
        MapParamChecker mapParamChecker = MapParamChecker.instance(params)
                .isNotBlank(ParamConstants.MSISDN);
        if(!mapParamChecker.isValid()){
            logger.info("查询物联卡实名登记状态缺少必要参数");
            return ResponseVo.fail(ResponseCode.ERROR_MISS_PARAM);
        }
        return apiService.getRealNameStatus(params);
    }
}
