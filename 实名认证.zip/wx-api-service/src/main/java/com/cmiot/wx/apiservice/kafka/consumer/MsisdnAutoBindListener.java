package com.cmiot.wx.apiservice.kafka.consumer;

import com.alibaba.fastjson.JSONObject;
import com.cmiot.api.client.ICtBusinessSerClient;
import com.cmiot.api.service.AuthenticationServiceClient;
import com.cmiot.common.ct.access.entity.CTRequestFactory;
import com.cmiot.common.ct.access.entity.CTResponse;
import com.cmiot.commons.cache.impl.CacheManager;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.ftp.realname.SFTPUtil;
import com.cmiot.ftp.realname.SftpEntity;
import com.cmiot.ftp.realname.UpLoadFile;
import com.cmiot.ms.dal.common.orcl.NormalBaseService;
import com.cmiot.mybatis.dao.RealNameRegisterDao;
import com.cmiot.mybatis.service.RealNameRegisterService;
import com.cmiot.mybatis.vo.*;
import com.cmiot.util.RegisterCode;
import com.cmiot.wx.apiservice.constant.KafkaConstant;
import com.cmiot.wx.apiservice.service.CTUserService;
import com.cmiot.wx.apiservice.service.CommonSmsService;
import com.cmiot.wx.apiservice.service.IMsisdnAutoBindService;
import com.cmiot.wx.apiservice.utiles.CommonConstant;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import sun.misc.BASE64Decoder;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;


/**
 * @author S.j@onlying.cn
 * @date 2020/3/9 16:25:46
 */
@Slf4j
@Component
public class MsisdnAutoBindListener extends NormalBaseService {

    @Autowired
    private IMsisdnAutoBindService msisdnAutoBindService;

    static Logger logger = LoggerFactory.getLogger(MsisdnAutoBindListener.class);

    @Autowired
    RealNameRegisterDao realNameRegisterDao;

    @Autowired
    CommonSmsService commonSmsService;

    @Autowired
    RealNameRegisterService registerService;

    @Autowired
    CTRequestFactory ctRequestFactory;

    @Autowired
    ICtBusinessSerClient ctBusinessSerClient;

    @Autowired
    CTUserService ctUserService;

    @Autowired
    ThreadPoolTaskExecutor pushExecutor;

    @Autowired
    AuthenticationServiceClient authenticationServiceClient;

    /**
     * kafka消费
     * @param cr
     * @throws Exception
     */
//    @KafkaListener(topics = {KafkaConstant.BD_CT_CUSTINFO_CM_CERT_INFO_TOPIC})
    public void bdCtCustinfoCmCertInfoTopicListener(ConsumerRecord<String, String> cr) throws Exception {
        log.info(cr.value());
        JSONObject data = JSONObject.parseObject(cr.value());
        CtCmCertInfoVo cmCertInfo = JSONObject.toJavaObject(data.getJSONObject("data"), CtCmCertInfoVo.class);
        msisdnAutoBindService.setBdCtCustinfoCmCertInfo(cmCertInfo);
        faucet(cmCertInfo.getIdNumber());
    }


    /**
     * kafka消费
     * @param cr
     * @throws Exception
     */
//    @KafkaListener(topics = {KafkaConstant.BD_CT_COMMON_PERSONAL_IDENTITY_DETAIL_TOPIC})
    public void bdCtCommonPersonalIdentityDetailTopiclistener(ConsumerRecord<String, String> cr) throws Exception {
        log.info(cr.value());
        JSONObject data = JSONObject.parseObject(cr.value());
        /*******因CT发送的数据中图像数据是一个数字，超过了int存储的大小，造成了现网错误，且数据无意义，故直接处理不做存储*****3.300.8.1***lxc***/
        JSONObject dataInfo = data.getJSONObject("data");
        dataInfo.put("CUST_PHOTO_IDENTITY",null);
        dataInfo.put("CUST_PHOTO_SCENE",null);
        dataInfo.put("CUST_PHOTO_FRONT",null);
        dataInfo.put("CUST_PHOTO_BACK",null);
        data.put("data",dataInfo);
        /*******因CT发送的数据中图像数据是一个数字，超过了int存储的大小，造成了现网错误，且数据无意义，故直接处理不做存储*****3.300.8.1***lxc***/
        CtPersonalIdentityDetailVo ctPersonalIdentityDetail = JSONObject.toJavaObject(data.getJSONObject("data"), CtPersonalIdentityDetailVo.class);
        msisdnAutoBindService.setCtPersonalIdentityDetail(ctPersonalIdentityDetail);
        faucet(ctPersonalIdentityDetail.getCustCertNo());
    }

    /**
     * kafka消费
     * @param cr
     * @throws Exception
     */
//    @KafkaListener(topics = {KafkaConstant.BD_CT_COMMON_SYS_OPER_PERSONAL_IDENTITY_TOPIC})
    public void bdCtCommonSysOperPersonalIdentityTopicListener(ConsumerRecord<String, String> cr) throws Exception {
        log.info(cr.value());
        JSONObject data = JSONObject.parseObject(cr.value());
        CtSysOperPersonalIdentityVo ctSysOperPersonalIdentity = JSONObject.toJavaObject(data.getJSONObject("data"),CtSysOperPersonalIdentityVo.class);
        msisdnAutoBindService.setCtSysOperPersonalIdentity(ctSysOperPersonalIdentity);
        faucet(ctSysOperPersonalIdentity.getCustCertNo());
    }

    private void faucet(String certNo) {
        if(StringUtils.isEmpty(certNo)){
            log.warn("消息缺少唯一字段，该消息无效");
            return;
        }
        CtCmCertInfoVo vo1 = msisdnAutoBindService.getBdCtCustinfoCmCertInfo(certNo);
        CtPersonalIdentityDetailVo vo2 = msisdnAutoBindService.getCtPersonalIdentityDetail(certNo);
        CtSysOperPersonalIdentityVo vo3 = msisdnAutoBindService.getCtSysOperPersonalIdentity(certNo);
        log.info("消费者1:{}", vo1);
        log.info("消费者2:{}", vo2);
        log.info("消费者3:{}", vo3);
        if (vo1 != null && vo2 != null && vo3 != null) {
            log.info("已经集齐三条数据，准备执行绑定任务");
            long beginTime = System.currentTimeMillis();
            long lastTime = 0;
            try {
                lastTime = msisdnAutoBindService.exct(vo1, vo2, vo3);
            } catch (Exception e) {
                log.error("msisdn auto bind: [{}] card error.{}",vo2.getMsisdn(),e);
            }finally {
                log.warn("总共耗时：{} ms",lastTime - beginTime);
                msisdnAutoBindService.clearAll(vo1.getId(),vo2.getId(),vo3.getId());
            }
        }
    }

    /**
     * ct活体认证-获取实名结果
     * @param cr
     * @throws Exception
     */
    @KafkaListener(topics = {"BD_CT_CUSTINFO_PM_VIDEO_URL_RESULT_NOTIFY"})
    public void getCtRegisterInfo(ConsumerRecord<String, String> cr) throws Exception {
        try {
            logger.info("kafka消费...");
//            logger.info("kafka活体认证结果...json:{},key:{},value:{}", cr.toString(),cr.key(),cr.value());
            JSONObject data = JSONObject.parseObject(cr.value());
            Map result = JSONObject.toJavaObject(data.getJSONObject("data"), Map.class);
            //优先判断数据是否有效
            if("0".equals(result.getOrDefault("RECORD_STATUS","0"))){
                logger.info("kafka活体认证结果，数据失效...");
                return;
            }
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
            CtRealNameVo v = realNameRegisterDao.queryCtRealNameByKafka(result.get("BUSI_SEQ").toString());
            if(v==null)return;
            v.setAuditStatus(result.getOrDefault("AUDIT_STATUS","").toString());
            //确认AuditStatus非空
            if(!StringUtils.isNotBlank(v.getAuditStatus()))return;
            if(result.get("AUDIT_MESSAGE")!=null){
                v.setAuditMessage(result.getOrDefault("AUDIT_MESSAGE","").toString());
            }
            //ct完成采集埋点
            try {
                registerService.innerStatisService("threect");
            }catch (Exception e){
                logger.info("ct卡完成采集埋点报错...{}",e);
            }
            if("2".equals(v.getAuditStatus())){
                //审核不通过，结束流程，发短信
                v.setRegisterCode(RegisterCode.REALNAME_FIRST_FAIL);
                commonSmsService.sendRegisterResult(v.getPhone(),v.getMsisdn(),v.getRegisterCode(),v.getAuditMessage(),v.getTransNo());
                //h5推送实名结果
                pushCTRegisterResult(v,"88888");
                if("oneLinkApiPb".equals(v.getUserId())){
                    //api推送实名结果
                    CtRealNameVo vo=new CtRealNameVo();
                    vo.setRegisterMsg(v.getAuditMessage());
                    vo.setMsisdn(v.getMsisdn());
                    vo.setPhone(v.getPhone());
                    //获取实名时间
                    SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date now=new Date(System.currentTimeMillis());
                    String time=sdf1.format(now);
                    vo.setRegisterTime(time);
                    vo.setBusiSeq(v.getBusiSeq());
                    vo.setTransNo(v.getTransNo());
                    pushApiRegisterResult(vo,RegisterCode.REALNAME_FIRST_FAIL);
                }
            }
            if ("4".equals(v.getAuditStatus())){
                //二次稽核不通过，结束流程，发短信
                v.setRegisterCode(RegisterCode.REALNAME_SECOND_FAIL);
                commonSmsService.sendRegisterResult(v.getPhone(),v.getMsisdn(),v.getRegisterCode(),v.getAuditMessage(),v.getTransNo());
                //h5推送实名结果
                pushCTRegisterResult(v,"88888");
                if("oneLinkApiPb".equals(v.getUserId())){
                    //api推送实名结果
                    CtRealNameVo vo=new CtRealNameVo();
                    vo.setRegisterMsg(v.getAuditMessage());
                    vo.setMsisdn(v.getMsisdn());
                    vo.setPhone(v.getPhone());
                    //获取实名时间
                    SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date now=new Date(System.currentTimeMillis());
                    String time=sdf1.format(now);
                    vo.setRegisterTime(time);
                    vo.setBusiSeq(v.getBusiSeq());
                    vo.setTransNo(v.getTransNo());
                    pushApiRegisterResult(vo,RegisterCode.REALNAME_SECOND_FAIL);
                }
            }
            //信息第二次入库
            realNameRegisterDao.updateCtRealNameResult(v);
        } catch (Exception e) {
            logger.info("ct活体认证从kafka接收消息报错{}...{}",JsonUtils.parseString(cr.value()),e);
        }
    }

    /**
     * ct活体认证-H5推送实名信息
     * @param cr
     * @throws Exception
     */
    @KafkaListener(topics = {KafkaConstant.BD_CT_CUSTINFO_CM_CERT_INFO_TOPIC})
    public void registerSendH5(ConsumerRecord<String, String> cr) throws Exception {
        try {
            logger.info("kafka registerSendH5接收实名结果...");
            logger.info("kafka registerSendH5活体认证结果value:{}",cr.value());
            JSONObject data = JSONObject.parseObject(cr.value());
            Map opMap = JSONObject.toJavaObject(data.getJSONObject("meta"), Map.class);
            Map result=new HashMap();
            if("ins".equals(opMap.get("op"))){
                result=JSONObject.toJavaObject(data.getJSONObject("data"), Map.class);
                if(!"01".equals(result.get("OP_CODE"))){
                    logger.info("ins数据结构不符合要求...");
                    return;
                }
            }else if("upd".equals(opMap.get("op"))){
                result=JSONObject.toJavaObject(data.getJSONObject("data"), Map.class);
                if(!"03".equals(result.get("OP_CODE"))){
                    logger.info("upd数据结构不符合要求...");
                    return;
                }
            }else {
                logger.info("op和OP_CODE不符合要求...");
                return;
            }
            //优先判断数据是否有效
            if(!"2".equals(result.getOrDefault("SOURCE_TYPE",""))){
                logger.info("kafka活体认证结果，非补录资料...");
                return;
            }
//            Thread.currentThread().sleep(1000);
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
            String subsId="";
            String idNumber="";
            String name="";
            if("ins".equals(opMap.get("op"))){
                subsId= result.get("SUBS_ID").toString();
                idNumber= result.get("ID_NUMBER").toString();
                name=result.get("NAME").toString();
            }else{
                idNumber= result.get("ID_NUMBER").toString();
                name=result.get("NAME").toString();
                Map keyMap = JSONObject.toJavaObject(data.getJSONObject("key"), Map.class);
                subsId=keyMap.get("SUBS_ID").toString();
            }
//            Thread.currentThread().sleep(1000);
            logger.info("H5回传...参数检查subsId:{}",subsId);
            CtRealNameVo v = realNameRegisterDao.getInfoBySubsId(subsId);
            if(v==null){
//                logger.info("根据subsid未获取到信息,入库");
                RegisterH5Info h5Info=new RegisterH5Info();
                h5Info.setIdNumber(idNumber);
                h5Info.setSubsId(subsId);
                h5Info.setName(name);
                realNameRegisterDao.saveRegisterH5Info(h5Info);
                return;
            }

            //订单已完成，修改状态:1完成 0未完成
            realNameRegisterDao.modifyChangeStatus(v.getBusiSeq());
            dealH5Traffic(v.getMsgId(),2,v.getTransNo());
            commonSmsService.sendRegisterResult(v.getPhone(),v.getMsisdn(),"00000","",v.getTransNo());
            logger.info("ct订单状态已变更成功msisdn:{},busiSeq:{}",v.getMsisdn(),v.getBusiSeq());
//            Map orderReqMap=new HashMap();
//            orderReqMap.put("beId",v.getBeId());
//            orderReqMap.put("custId",v.getCustId());
//            orderReqMap.put("orderId",v.getJobId());
//            String statusResult = ctBusinessSerClient.queryOrderStatus(v.getTransNo(), orderReqMap);
//            logger.info("查询订单状态msisdn:{},status:{}",v.getMsisdn(),statusResult);
//            if("1".equals(statusResult)){
//                //实名状态变更成功,更新状态
//                realNameRegisterDao.updateChangeStatusByBusiSeq(v.getBusiSeq());
//                //发送短信
//                commonSmsService.sendRegisterResult(v.getPhone(),v.getMsisdn(),"00000","",v.getTransNo());
//            }else {
//                //存入表，定时任务执行
//                orderReqMap.put("msisdn",v.getMsisdn());
//                orderReqMap.put("phone",v.getPhone());
//                orderReqMap.put("status","0");
//                orderReqMap.put("transNo",v.getTransNo());
//                realNameRegisterDao.insertRegisterStatusOrder(orderReqMap);
//            }
            v.setIdCard(idNumber);
            v.setName(name);
            if("oneLinkApiPb".equals(v.getUserId())){
                pushApiRegisterResult(v,"00000");
            }else {
                pushCTRegisterResult(v,v.getRegisterCode());
            }
            if("0".equals(v.getIsActive())){
                //卡激活操作
                Map<String,String> activeMap=new HashMap<>();
                activeMap.put("msisdn",v.getMsisdn());
                activeMap.put("beId",v.getBeId());
                activeMap.put("custId",v.getCustId());
                //获取卡状态
                ResponseVo basicInfo = ctUserService.queryCardBasicInfo(activeMap);
                if(basicInfo.isSuccess()&&basicInfo.getData()!=null){
                    Map obj = JsonUtils.parseObject(basicInfo.getData(), Map.class);
                    logger.info("获取卡状态 success...msisdn:{},status:{}",v.getMsisdn(),JsonUtils.parseString(basicInfo));
                    activeMap.put("status",obj.getOrDefault("status","").toString());
                    activeMap.put("realname","1");
                }
                ResponseVo activateResp = ctUserService.activateCardFromCT(activeMap, v.getTransNo());
                logger.info("卡激活结果msisdn:{}...{}",v.getMsisdn(),JsonUtils.parseString(activateResp));
            }
        } catch (Exception e) {
            logger.info("registerSendH5从kafka接收消息报错{}...{}",JsonUtils.parseString(cr.value()),e);
        }
    }


    private void pushCTRegisterResult(CtRealNameVo ctRegisterVo,String status){
        if(!StringUtils.isEmpty(ctRegisterVo.getChannelId())){
            try {
                //具备渠道编码，确定是从H5渠道发起的认证
                Map<String,String> pushData = new HashMap<>();
                pushData.put("channelId",ctRegisterVo.getChannelId());
                pushData.put(CommonConstant.FIELD_MSISDN,ctRegisterVo.getMsisdn());
                pushData.put(CommonConstant.REAL_NAME_PUSH_NAME,StringUtils.isNotBlank(ctRegisterVo.getName())?ctRegisterVo.getName():"");
                pushData.put(CommonConstant.REAL_NAME_PUSH_CUSTCERTNO,StringUtils.isNotBlank(ctRegisterVo.getIdCard())?ctRegisterVo.getIdCard():"");
                pushData.put(CommonConstant.REAL_NAME_PUSH_REGISTERCODE,status); //登记结果 0 或 00000 成功，其他 登记失败
                pushData.put(CommonConstant.PHONE,ctRegisterVo.getPhone());
                logger.info("ct实名登记h5推送结果msisdn:{}",ctRegisterVo.getMsisdn());
                registerService.sendRegisterResult(pushData);
                //实名成功推送后，往计费系统ftp传话单
                if(("0".equals(status)||"00000".equals(status))&&"0".equals(cache.getSysParams("register_ftp_control",""))){
                    //写入appid和calling_nbr对应关系
//                    String custList = cache.getSysParams("register_appid_custcode", "");
//                    Map<String,String> map=JsonUtils.parseObject(custList,Map.class);
                    pushExecutor.execute(new Runnable() {
                        @Override
                        public void run() {
                            long s1=System.currentTimeMillis();
//                            String custCode=map.get(ctRegisterVo.getChannelId());
//                            if(org.apache.commons.lang3.StringUtils.isBlank(custCode)){
//                                logger.info("{}不存在，跳过",ctRegisterVo.getChannelId());
//                                return;
//                            }
                            //序列号自增
                            String seq = cache.get(CacheManager.PublicNameSpace.TEMP, "REALNAME_H5_SEQ");
                            if(seq==null||"".equals(seq)){
                                seq="0";
                            }
                            int count=Integer.parseInt(seq)+1;
                            cache.put(CacheManager.PublicNameSpace.TEMP,"REALNAME_H5_SEQ",count+"");
                            String fileName="IOT_0_0_"+getTime()+"_"+count;
                            //获取商品编码
                            String goods_code = cache.getSysParams("register_goods_code_ct", "");
                            logger.info("名称：{},商品编码:{}",fileName,goods_code);
                            Map paramMap=new HashMap();
                            paramMap.put("calling_nbr",ctRegisterVo.getChannelId());
                            paramMap.put("goods_code",goods_code);
                            paramMap.put("frequency","1");
                            paramMap.put("called_nbr","");
                            paramMap.put("event_begin_time",System.currentTimeMillis()+"");
                            paramMap.put("event_end_time",System.currentTimeMillis()+"");
                            paramMap.put("location","");
                            paramMap.put("apn","");
                            paramMap.put("roaming_flag","");
                            String paramJson="["+JsonUtils.parseString(paramMap)+"]";
                            //写文件
                            String fName=fileName+".cdr";
                            //获取ftp连接信息(ip,端口号,目录,用户名,密码)
                            String ftpConnect = cache.getSysParams("register_ftp_connect", "");
                            SFTPUtil ft=new SFTPUtil();
                            SftpEntity sftpEntity = new SftpEntity(ft, ftpConnect.split(",")[0], Integer.parseInt(ftpConnect.split(",")[1]), ftpConnect.split(",")[3], ftpConnect.split(",")[4], "3000");
                            ChannelSftp sftp =  sftpConnect(sftpEntity.getChannel(), ftpConnect.split(",")[2]);
                            try {
//                        writer = new FileWriter(fName);
//                        writer.write(paramJson);
//                        writer.flush();
//                        writer.close();
                                if(null == sftpEntity.getChannel()){
                                    logger.info("连接计费系统sftp失败");
                                    return;
                                }
                                if(sftp.isConnected()) {
                                    logger.info("Connected {} : {} ",ftpConnect.split(",")[0], Integer.parseInt(ftpConnect.split(",")[1]));
                                    sftp.put(UpLoadFile.getStrToStream(paramJson), fName);
                                    Map params=new HashMap();
                                    params.put("msisdn",ctRegisterVo.getMsisdn());
                                    params.put("fileName",fName);
                                    params.put("channelId",ctRegisterVo.getChannelId());
                                    //成功上传话单后 入库记录
                                    setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
                                    realNameRegisterDao.insertTrafficRecord(params);
                                    logger.info("卡号{}上传成功,耗时:{}",ctRegisterVo.getMsisdn(),System.currentTimeMillis()-s1);
                                }
                            } catch (Exception e) {
                                logger.info("卡号{}本地写文件{}报错{}",ctRegisterVo.getMsisdn(),fileName,e);
                            }finally {
                                // 关闭sftp连接
                                ft.closeAll(sftp, sftpEntity.getChannel(), sftpEntity.getSession());
                            }
                        }
                    });
                }
            }catch (Exception e){
                logger.info("推送CT物联卡登记结果报错msisdn:{}...{}",ctRegisterVo.getMsisdn(),e);
            }
        }
    }

//    public static void main(String[] args){
//        SFTPUtil ft=new SFTPUtil();
//        SftpEntity sftpEntity = new SftpEntity(ft, "10.19.103.71", 22, "smrztest", "!QAZ2wsx", "3000");
//        ChannelSftp sftp =  sftpConnect(sftpEntity.getChannel(), "/iot/cdrdispatch/apicall/");
//        try {
////                        writer = new FileWriter(fName);
////                        writer.write(paramJson);
////                        writer.flush();
////                        writer.close();
//            if(null == sftpEntity.getChannel()){
//                logger.info("连接计费系统sftp失败");
//                return;
//            }
//            if(sftp.isConnected()) {
//                sftp.put(UpLoadFile.getStrToStream("[test]"), "xjctest.txt");
//                logger.info("上传成功");
//            }
//        } catch (Exception e) {
//            logger.info("报错{}",e);
//        }finally {
//            // 关闭sftp连接
//            ft.closeAll(sftp, sftpEntity.getChannel(), sftpEntity.getSession());
//        }
//    }

    private void pushApiRegisterResult(CtRealNameVo ctRegisterVo,String status){
        Map map=new HashMap();
        map.put("registerCode",status);
        map.put("registerMsg",ctRegisterVo.getRegisterMsg());
        map.put("msisdn",ctRegisterVo.getMsisdn());
        map.put("name",ctRegisterVo.getName());
        map.put("custCertNo",ctRegisterVo.getIdCard());
        map.put("phone",ctRegisterVo.getPhone());
        map.put("registerTime",ctRegisterVo.getRegisterTime());
        map.put("busiSeq",ctRegisterVo.getBusiSeq());
        String transNo=ctRegisterVo.getTransNo();
        if(transNo==null||"".equals(transNo)||transNo.contains("know")){
            transNo= UUID.randomUUID().toString().replace("-","");
        }
        logger.info("{},pushApiRegisterResult回传前检查",ctRegisterVo.getMsisdn());
        CTResponse response = ctRequestFactory.pushRegisterApi(map, transNo);
        logger.info("{},pushApiRegisterResult结果:{}",ctRegisterVo.getMsisdn(),JsonUtils.parseString(response));
    }

    /**
     * Base64解密
     */
    public static String getFromBase64(String s) {
        String result = null;
        byte[] b = null;
        result = null;
        if (s != null) {
            BASE64Decoder decoder = new BASE64Decoder();
            try {
                b = decoder.decodeBuffer(s);
                result = new String(b, "utf-8");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    /**
     * 生成时间戳
     */
    public  String getTime(){
        Date date=new Date(System.currentTimeMillis());
        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
        return sdf.format(date);
    }

    /**
     * 获取sftp连接
     *
     * @param channel
     * @param filePath
     * @return
     */
    private static  ChannelSftp sftpConnect(Channel channel, String filePath) {
        ChannelSftp sftp = (ChannelSftp) channel;
        //判断是否存在该目录
        try {
            sftp.cd(filePath);
        } catch (SftpException e) {
            logger.error("sftp上传目录不存在：", e);
        }
        return sftp;
    }

    /**
     * 实名登记H5，流控回收处理
     * */
    public void dealH5Traffic(int msgId, int status, String transNo) {
        if (msgId != 0) {
            //存在消息流水号，消费调用次数
            Map<String, Integer> param = new HashMap<>(2);
            param.put("msgId", msgId);
            param.put("status", status); //2:有效调用 3:无效调用
            ResponseVo verifyStatusVo = authenticationServiceClient.changeVerifyStatus(param);
            if (verifyStatusVo.isSuccess()) {
                logger.info("transNo is:[{}],实名登记H5，限流状态更新成功,msgId is:[{}],status is:[{}]", transNo, msgId, (status == 2) ? "有效调用" : "无效调用");
            } else {
                logger.info("transNo is:[{}],实名登记H5，限流状态更新失败,msgId is:[{}],status is:[{}]", transNo, msgId, (status == 2) ? "有效调用" : "无效调用");
            }
        }
    }

    }

