package com.cmiot.wx.apiservice.entity;

public class MsisdnAccountEntity {
    /**
     * 账户状态
     * */
    private String status;
    /**
     * 账户余额
     * */
    private String balance;
    /**
     * 开关机状态
     * */
    private String netStatus;
    /**
     * 充值地址
     * */
    private String rechargeUrl;

    /**
     * 用户名称
     * */
    private String custName;

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getNetStatus() {
        return netStatus;
    }

    public void setNetStatus(String netStatus) {
        this.netStatus = netStatus;
    }

    public String getRechargeUrl() {
        return rechargeUrl;
    }

    public void setRechargeUrl(String rechargeUrl) {
        this.rechargeUrl = rechargeUrl;
    }

    @Override
    public String toString(){
        return "MsisdnAccountEntity{" +
                "status='" + status + '\'' +
                ", balance='" + balance + '\'' +
                ", netStatus='" + netStatus + '\'' +
                ", rechargeUrl='" + rechargeUrl + '\'' +
                ", custName='" + custName + '\'' +
                '}';
    }
}
