package com.cmiot.wx.apiservice.service;

import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.ms.dal.common.orcl.NormalBaseService;
import com.cmiot.mybatis.dao.PbRegisterDao;
import com.cmiot.mybatis.vo.PbRegisterVo;
import com.cmiot.util.HttpUtil;
import com.cmiot.wx.apiservice.entity.PbResultVo;
import com.cmiot.wx.apiservice.utiles.CommonConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PbRegisterService extends NormalBaseService {

    static  Logger logger = LoggerFactory.getLogger(PbRegisterService.class);

    @Autowired
    ICache cache;


    @Autowired
    PbRegisterDao pbRegisterDao;



    /**
     * 安徽PB卡实名认证流程查询
     * @deprecated
     */
    public ResponseVo checkMsisdnFlowService(Map map) {
        try {
            //get请求
            Map param=new HashMap();
            Map p=new HashMap();
            p.put("msisdn",map.get("msisdn"));
            param.put("ROOT",p);
            String json = JsonUtils.parseString(param);
            String url =cache.getSysParams("551.checkMsisdnFlow","");
            String ss ="pin="+json;
            ss = URLEncoder.encode(ss, "UTF-8");
            Date now=new Date(System.currentTimeMillis());
            SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
            String time=sdf.format(now);
            String requestParameters=ss+cache.getSysParams("551.checkMsisdnFlow.param","")+"&timeStamp="+time;
            String sign = HttpUtil.toSign(requestParameters,"/data_realname/auth/key/pb_private_key.pem");
            logger.info("551 pb msisdn query...msisdn:{}...url:{}...sign:{}",JsonUtils.parseString(p),url,sign);
            requestParameters = requestParameters + "&sign=" + sign;
            String x = HttpUtil.sendPost(url,requestParameters);
            x=new String(x.getBytes(),"UTF-8");
            logger.info("551 pb msisdn query...msisdn{}...get result:{}",JsonUtils.parseString(p),x);
            Map result = JsonUtils.parseObject(x, Map.class);
            if(result.get("ROOT")!=null&&JsonUtils.parseObject(result.get("ROOT"), PbResultVo.class)!=null){
                PbResultVo vo = JsonUtils.parseObject(result.get("ROOT"), PbResultVo.class);
                logger.info("551 pb msisdn query success...{}",JsonUtils.parseString(vo));
                //安徽pb修改为可重复实名 2021-03-22
                vo.setIsAuth("1");
                return ResponseVo.success(vo);
            }else {
                logger.info("551 pb msisdn query fail...");
                return ResponseVo.fail("99");
            }
//            Map<String,String> result=new HashMap<>();
//            map.put("isAuth","1");
//            map.put("needAuth","0");
//            return ResponseVo.success(result);
        } catch (Exception e) {
            logger.info("551 pb msisdn query fail checkMsisdnFlowService...{}...{}",
                    JsonUtils.parseString(map),e.getMessage());
            return ResponseVo.fail("99");
        }
    }


    /**
     * 一证五号校验
     */
    public ResponseVo idCardCheck(Map map) {
        try {
            Map p=new HashMap();
            p.put("idCard",map.get("idCard"));
            p.put("idType",map.get("idType"));
            p.put("phoneNo",map.get("msisdn"));
            Map param=new HashMap();
            param.put("ROOT",p);
            String json = JsonUtils.parseString(param);
            String url = cache.getSysParams("551.idCardCheck","");
            String ss ="pin="+json;
            ss = URLEncoder.encode(ss, "UTF-8");
            Date now=new Date(System.currentTimeMillis());
            SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
            String time=sdf.format(now);
            String requestParameters=ss+cache.getSysParams("551.idCardCheck.param","")+"&timeStamp="+time;
            String sign = HttpUtil.toSign(requestParameters,"/data_realname/auth/key/pb_private_key.pem");
            logger.info("551 pb idcard query...url:{}...sign:{}",url,sign);
            requestParameters = requestParameters + "&sign=" + sign;
            String x = HttpUtil.sendPost(url, requestParameters);
            x=new String(x.getBytes(),"UTF-8");
            logger.info("551 pb idcard query...get result:{}",x);
            Map result = JsonUtils.parseObject(x, Map.class);
            if(result.get("ROOT")!=null&&JsonUtils.parseObject(result.get("ROOT"), PbResultVo.class)!=null){
                PbResultVo vo = JsonUtils.parseObject(result.get("ROOT"), PbResultVo.class);
                logger.info("551 pb idcard query success...");
                return ResponseVo.success(vo);
            }else {
                logger.info("551 pb idcard query fail...");
                return ResponseVo.fail("99");
            }
//            Map<String,String> result=new HashMap<>();
//            result.put("checkCode","0");
//            return ResponseVo.success(result);
        }catch (Exception e){
            logger.info("551 pb idcard query fail...{}",e.getMessage());
            return ResponseVo.fail("99");
        }
    }

    /**
     * 在线公司回调校验流水号
     */
    public ResponseVo orderNumCheck(Map param){
        try {
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
            List<PbRegisterVo> list = pbRegisterDao.queryOrderNum(param);
            if(list.size()>0){
                if(list.get(0).getUserId()!=null&&"realNameH5".equals(list.get(0).getUserId())){
                    //h5返回
                    return ResponseVo.success("0");
                }else {
                    //公众号返回
                    return ResponseVo.success("1");
                }
            }
        }catch (Exception e){
            logger.info("551 pb orderNumCheck fail...{}",e);
        }
        return ResponseVo.fail("99");
    }

    /**
     * 查询15分钟内是否存在重复订单
     */
    public ResponseVo querySameOrderPb(String msisdn){
        setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
        int waitCount = pbRegisterDao.queryWaitInfoPb(msisdn);
        if(waitCount>0){
            logger.info("querySameOrderPb存在重复记录，跳过...{}",msisdn);
            return ResponseVo.fail("4014");
        }else {
            return ResponseVo.success("ok");
        }
    }



}
