package com.cmiot.wx.apiservice.utiles;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description: xml工具类
 * @Author: cyg
 * @Date: 2019/8/15
 * @Version:
 **/
public class XmlUtil {

    /**
     * 功能描述: 工具方法，将map转为xml的字符串
     *  <br>
     * @date 2019/10/9
     * @param map 入参map
     * @return java.lang.StringBuilder
     */
    public static StringBuilder map2XmlString(Map<String, Object> map) {
        StringBuilder xml = new StringBuilder();

        // 如果map不为空，并且map集合包含数据
        if (null != map && map.entrySet().size() > 0) {
            for (Map.Entry<String, Object> it : map.entrySet()) {
                Object obj = it.getValue();
                if (obj instanceof List) {
                    StringBuffer sb = new StringBuffer();
                    List list = (List) obj;
                    for (int i = 0; i < list.size(); i++) {
                        xml.append("<").append(it.getKey()).append(">")
                                .append(map2XmlString((Map<String, Object>) list.get(i))).append("</")
                                .append(it.getKey()).append(">");
                    }
                    xml.append(sb);
                } else {
                    xml.append("<").append(it.getKey()).append(">");
                    if (obj instanceof Map) {
                        xml.append(map2XmlString((Map) obj));
                    } else {
                        xml.append(it.getValue());
                    }
                    xml.append("</").append(it.getKey()).append(">");
                }
            }
        }
        return xml;
    }

    /**
     * xml转map
     * @param xml
     * @return
     */
    public static Map<String, Object> multilayerXmlToMap(String xml) throws Exception {
        Document doc = null;
        try {
            doc = DocumentHelper.parseText(xml);
        } catch (Exception e) {

        }
        Map<String, Object> map = new HashMap<>();
        if (null == doc) {
            return map;
        }
        // 获取根元素
        Element rootElement = doc.getRootElement();
        recursionXmlToMap(rootElement,map);
        return map;
    }

    /**
     * multilayerXmlToMap核心方法，递归调用
     *
     * @param element 节点元素
     * @param outmap 用于存储xml数据的map
     */
    private static void recursionXmlToMap(Element element, Map<String, Object> outmap) {
        // 得到根元素下的子元素列表
        List<Element> list = element.elements();
        int size = list.size();
        if (size == 0) {
            // 如果没有子元素,则将其存储进map中
            outmap.put(element.getName(), element.getTextTrim());
        } else {
            // innermap用于存储子元素的属性名和属性值
            Map<String, Object> innermap = new HashMap<>();
            // 遍历子元素
            list.forEach(childElement -> recursionXmlToMap(childElement, innermap));
            outmap.put(element.getName(), innermap);
        }
    }
}
