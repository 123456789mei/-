package com.cmiot.wx.apiservice.utiles;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;


public class AESEncrypt {
    private static Logger debugLog = LoggerFactory.getLogger(AESEncrypt.class);

    private static final String ENCRYPT_FAILED = "Encrypt! failed ";

    private AESEncrypt() {
    }

    /**
     * 加密
     *
     * @param content  需要加密的内容
     * @param password 加密密码
     * @return 加密后字符串
     */
    private static byte[] encryption(String content, String password) {
        try {
            SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
            random.setSeed(password.getBytes());
            KeyGenerator kgen = KeyGenerator.getInstance("AES");
            kgen.init(128, random);
            SecretKey secretKey = kgen.generateKey();
            byte[] enCodeFormat = secretKey.getEncoded();
            SecretKeySpec key = new SecretKeySpec(enCodeFormat, "AES");
            // 创建密码器
            Cipher cipher = Cipher.getInstance("AES");
            byte[] byteContent = content.getBytes("utf-8");
            // 初始化
            cipher.init(Cipher.ENCRYPT_MODE, key);
            // 加密
            return cipher.doFinal(byteContent);
        } catch (NoSuchAlgorithmException | BadPaddingException | IllegalBlockSizeException | UnsupportedEncodingException | InvalidKeyException | NoSuchPaddingException e) {
            debugLog.error(ENCRYPT_FAILED, e);
        }
        return new byte[0];
    }

    /**
     * 解密
     *
     * @param content  待解密内容
     * @param password 解密密钥
     * @return 解密后字符串
     */
    private static byte[] decrypt(byte[] content, String password) {
        try {
            SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
            random.setSeed(password.getBytes());
            KeyGenerator kgen = KeyGenerator.getInstance("AES");
            kgen.init(128, random);
            SecretKey secretKey = kgen.generateKey();
            byte[] enCodeFormat = secretKey.getEncoded();
            SecretKeySpec key = new SecretKeySpec(enCodeFormat, "AES");
            // 创建密码器
            Cipher cipher = Cipher.getInstance("AES");
            // 初始化
            cipher.init(Cipher.DECRYPT_MODE, key);
            // 加密
            return cipher.doFinal(content);
        } catch (NoSuchAlgorithmException | BadPaddingException | IllegalBlockSizeException | InvalidKeyException | NoSuchPaddingException e) {
            debugLog.error(ENCRYPT_FAILED, e);
        }
        return new byte[0];
    }

    /**
     * 加密
     *
     * @param content 内容
     * @param key     密钥
     * @return 加密后的内容
     */
    public static String encrypt(String content, String key) {
        byte[] encryptResult = encryption(content, key);
        return Base64Util.encode(encryptResult);
    }

    /**
     * 解密
     *
     * @param content 内容
     * @param key     密钥
     * @return 解密后的内容
     */
    public static String decrypt(String content, String key) {
        byte[] decryptResult = decrypt(Base64Util.decode(content), key);
        return new String(decryptResult);
    }
}
