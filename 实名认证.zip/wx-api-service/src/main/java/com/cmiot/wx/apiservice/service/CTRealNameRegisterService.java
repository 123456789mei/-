package com.cmiot.wx.apiservice.service;

import com.alibaba.fastjson.JSON;
import com.cmiot.common.ct.access.CTFeignClient;
import com.cmiot.common.ct.access.entity.CTResponse;
import com.cmiot.common.ct.access.entity.DataAccess;
import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.common.utils.HttpRequestClient;
import com.cmiot.commons.common.utils.MapParamChecker;
import com.cmiot.commons.log.ILog;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.mybatis.service.WxPersonUserInfoService;
import com.cmiot.wx.apiservice.utiles.CommonConstant;
import com.cmiot.wx.apiservice.utiles.ResponseEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.Map;

@Service
public class CTRealNameRegisterService {

    private static Logger logger = LoggerFactory.getLogger(CTRealNameRegisterService.class);

    @Autowired
    ILog iLog;

    @Autowired
    HttpRequestClient httpClient;

    @Autowired
    ICache cache;

    @Autowired
    CTFeignClient ctFeignClient;

    @Autowired
    CTUserService ctUserService;

    @Autowired
    WxPersonUserInfoService wxPersonUserInfoService;

    public CTResponse realNameReg(Map<String, String> params) {
        String transNo = params.getOrDefault(CommonConstant.TRANSNO , "");
        MapParamChecker mapParamChecker = MapParamChecker.instance(params)
                .isNotBlank(CommonConstant.FIELD_MSISDN)
                .isNotBlank(CommonConstant.FIELD_CUSTCERTNO)
                .isNotBlank(CommonConstant.FIELD_CUSTNAME)
                .isNotBlank(CommonConstant.FIELD_CUSTPHONENO)
                .isNotBlank(CommonConstant.FIELD_ISHANDLECARD)
                .isNotBlank(CommonConstant.FIELD_PICNAME_R)
                //3.7改造升级
                .isNotBlank(CommonConstant.CUST_CERT_ADDR)
                .isNotBlank(CommonConstant.CERT_VALIDDATE)
                .isNotBlank(CommonConstant.CERT_EXPDATE)
                .isNotBlank(CommonConstant.GENDER)
                .isNotBlank(CommonConstant.NATION)
                .isNotBlank(CommonConstant.BIRTHDAY)
                .isNotBlank(CommonConstant.ISSUING_AUTHORITY)
                .isNotBlank(CommonConstant.PIC_NAME_F)
                .isNotBlank(CommonConstant.PIC_NAME_Z);
        if (mapParamChecker.isValid()) {
            String custId = params.getOrDefault(CommonConstant.FIELD_CUSTID , "");
            String beId = params.getOrDefault(CommonConstant.FIELD_BEID , "");
            if (StringUtils.isEmpty(custId) || StringUtils.isEmpty(beId)) {
                Map qry = new HashMap(1);
                qry.put(CommonConstant.FIELD_MSISDN , params.get(CommonConstant.FIELD_MSISDN));
                ResponseVo cardBasic = ctUserService.queryCardBasicInfo(qry);
                if (cardBasic != null && ResponseEnum.SUCCESS.getState().equals(cardBasic.getCode()) && cardBasic.getData() != null) {
                    Map cardBasicInfo = (Map) cardBasic.getData();
                    custId = cardBasicInfo.get(CommonConstant.FIELD_CUSTID) == null ? "" : cardBasicInfo.get(CommonConstant.FIELD_CUSTID).toString();
                    beId = cardBasicInfo.get(CommonConstant.FIELD_BEID) == null ? "" : cardBasicInfo.get(CommonConstant.FIELD_BEID).toString();
                } else {
                    iLog.error(logger , transNo , null , "查询SIM卡基本信息失败，返回结果:{}" , JSON.toJSONString(cardBasic));
                    return new CTResponse().setRespCode(ResponseEnum.ERR_SYSTEM.getState());
                }
            }
            Map requestParam = new HashMap();
            requestParam.put(CommonConstant.FIELD_MSISDN , params.get(CommonConstant.FIELD_MSISDN));
            requestParam.put(CommonConstant.FIELD_ICCID , params.get(CommonConstant.FIELD_ICCID));
            requestParam.put(CommonConstant.FIELD_CUSTNAME , params.get(CommonConstant.FIELD_CUSTNAME));
            requestParam.put(CommonConstant.FIELD_CUSTCERTNO , params.get(CommonConstant.FIELD_CUSTCERTNO));
            requestParam.put(CommonConstant.FIELD_CUSTPHONENO , params.get(CommonConstant.FIELD_CUSTPHONENO));
            //3.7改造升级
            requestParam.put(CommonConstant.CUST_CERT_ADDR , params.get(CommonConstant.CUST_CERT_ADDR));
            requestParam.put(CommonConstant.CERT_VALIDDATE , params.get(CommonConstant.CERT_VALIDDATE));
            requestParam.put(CommonConstant.CERT_EXPDATE , params.get(CommonConstant.CERT_EXPDATE));
            requestParam.put(CommonConstant.GENDER , params.get(CommonConstant.GENDER));
            requestParam.put(CommonConstant.NATION , params.get(CommonConstant.NATION));
            requestParam.put(CommonConstant.BIRTHDAY , params.get(CommonConstant.BIRTHDAY));
            requestParam.put(CommonConstant.ISSUING_AUTHORITY , params.get(CommonConstant.ISSUING_AUTHORITY));

            requestParam.put(CommonConstant.FIELD_ISHANDLECARD , params.get(CommonConstant.FIELD_ISHANDLECARD));
            requestParam.put(CommonConstant.FIELD_PICNAME_R , params.get(CommonConstant.FIELD_PICNAME_R));
            requestParam.put(CommonConstant.FIELD_PICNAME_T , params.get(CommonConstant.PIC_NAME_Z));
            //3.7改造升级
            requestParam.put(CommonConstant.PIC_NAME_F , params.get(CommonConstant.PIC_NAME_F));
            requestParam.put(CommonConstant.PIC_NAME_Z , params.get(CommonConstant.PIC_NAME_Z));

            CTResponse ctResult = ctFeignClient.exec(CommonConstant.CT_API_CONSTANNTS.CT_REAL_NAME_AUTH , requestParam , DataAccess.build(beId , custId));
//            logger.info("实名登记结果：transNo is:[{}],msisdn is:[{}],custNo is:[{}],phone:[{}],result is:[{}]",transNo,params.get(CommonConstant.FIELD_MSISDN),params.get(CommonConstant.FIELD_CUSTCERTNO), params.get(CommonConstant.FIELD_CUSTPHONENO),JsonUtils.parseString(ctResult));
            if (StringUtils.isEmpty(ctResult)) {
                //实名认证失败，暂定
                ctResult.setRespCode("050");
                return ctResult;
            }
            return ctResult;
        } else {
            return new CTResponse().setRespCode(ResponseEnum.ERR_MISS_PARAMS.getState());
        }
    }
}
