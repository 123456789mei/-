package com.cmiot.wx.apiservice.rest;


import com.cmiot.commons.rest.RestBase;
import com.cmiot.mybatis.service.QueryRegisterService;
import com.cmiot.mybatis.vo.CmPsRegisterVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/queryRegister")
public class QueryRegisterController extends RestBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(QueryRegisterController.class);



    @Autowired
    QueryRegisterService queryRegisterService;



    @RequestMapping("/queryPbCount")
    public long queryPbCount(@RequestBody Map map) {
        return queryRegisterService.queryPbCount(map);
    }

    @RequestMapping("/queryCtCount")
    public long queryCtCount(@RequestBody Map map) {
        return queryRegisterService.queryCtCount(map);
    }

    @RequestMapping("/queryByPb")
    public List<CmPsRegisterVO> queryByPb(@RequestBody Map map) {
        return queryRegisterService.queryByPb(map);
    }

    @RequestMapping("/queryByCt")
    public List<CmPsRegisterVO> queryByCt(@RequestBody Map map) {
        return queryRegisterService.queryByCt(map);
    }





}
