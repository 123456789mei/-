package com.cmiot.wx.apiservice.utiles;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import java.util.Map;


/**
 * @author lixiangcheng
 * @date 2020/06/16
 * 实名认证结果推送专用
 */

@Component
public class HttpUtils {

    private static final Logger logger = LoggerFactory.getLogger(HttpUtils.class);

    /***
     * 请求参数传递方式
     **/
    // Form
    public static final String CONTENT_TYPE_FORM = "application/x-www-form-urlencoded";
    // JSON
    public static final String CONTENT_TYPE_JSON = "application/json;charset=utf-8";

    // 数据传输的最长时间
    private static final int TIME_OUT = 30000;
    // 创建连接的最长时间
    private static final int CONNECTION_TIME_OUT = 3000;
    // 从连接池中获取到连接的最长时间
    private static final int CONNECTION_REQUEST_TIME_OUT = 2000;

    private static RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(TIME_OUT)
            .setConnectTimeout(CONNECTION_TIME_OUT).setConnectionRequestTimeout(CONNECTION_REQUEST_TIME_OUT).build();
    private PoolingHttpClientConnectionManager cm;

    public String post(String transNo, String httpUrl, String params, String contentType, Map<String, String> header) {
        logger.info("{} > Http request url : {}", transNo, httpUrl);
        logger.info("{} >  params :{}", transNo, params);
        HttpPost httpPost = new HttpPost(httpUrl);// 创建httpPost
        try {
            httpPost.setEntity(getEntity(params, contentType));
        } catch (UnsupportedEncodingException e) {
            logger.warn("", e);
        }
        return doHttpRequest(httpPost, -1, header, null);
    }

    protected String doHttpRequest(HttpRequestBase httpMethod, int timeout, Map<String, String> headers, String encoding) {
        CloseableHttpResponse response;
        HttpEntity entity;
        String responseContent = null;
        try {
            CloseableHttpClient httpClient = getHttpClient();
            if (timeout > 0) {
                RequestConfig reqConfig =
                        RequestConfig.custom().setSocketTimeout(timeout * 1000).setConnectTimeout(CONNECTION_TIME_OUT)
                                .setConnectionRequestTimeout(CONNECTION_REQUEST_TIME_OUT).build();
                httpMethod.setConfig(reqConfig);
            } else {
                httpMethod.setConfig(requestConfig);
            }
            if (headers != null && !headers.isEmpty()) {
                String key;
                for (Iterator<String> it = headers.keySet().iterator(); it.hasNext(); ) {
                    key = it.next();
                    httpMethod.setHeader(key, headers.get(key));
                }
            }
            // 执行请求
            response = httpClient.execute(httpMethod);
            entity = response.getEntity();

            if (!StringUtils.isEmpty(encoding)) {
                responseContent = new String(EntityUtils.toByteArray(entity), encoding);
            } else {
                responseContent = new String(EntityUtils.toByteArray(entity), "utf-8");
            }
            logger.info("result: {}", responseContent);
        } catch (IOException e) {
            logger.error("Send http request exception:", e);
        }
        return responseContent;
    }

    private StringEntity getEntity(String params, String contentType) throws UnsupportedEncodingException {
        String specificContentType = this.getContentType(contentType);
        StringEntity entity = new StringEntity(params, "utf-8");// 解决中文乱码问题
        entity.setContentType(specificContentType);
        return entity;
    }

    private CloseableHttpClient getHttpClient() {
        return HttpClients.custom().setConnectionManager(cm).build();
    }

    public String getContentType(String contentType) {
        if (contentType == null) {
            return CONTENT_TYPE_JSON;
        }
        return contentType;
    }
}
