package com.cmiot.wx.apiservice.utiles;

import com.alibaba.fastjson.JSON;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.util.*;

/**
 * @author : 周世雄 <br>
 * @date : 2019/4/16 16:43 <br>
 * @E-mail : zhoushixiong@chinasoftinc.com
 * @description : Map 相关工具类
 */
public final class MapUtils {
    private MapUtils() {
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(MapUtils.class);

    /**
     * 将Bean转换成Map对象
     *
     * @param object
     * @return
     */
    public static Map convertBeanToMap(Object object) {
        Map map;
        if (object instanceof Map) {
            map = (Map) object;
        } else {
            Class clazz = object.getClass();
            List<Field> fields = new ArrayList<>();
            while (clazz != null) {
                fields.addAll(Arrays.asList(clazz.getDeclaredFields()));
                clazz = clazz.getSuperclass();
            }
            map = new HashMap(fields.size());
            for (Field field : fields) {
                field.setAccessible(true);
                try {
                    map.put(field.getName() , field.get(object));
                } catch (IllegalAccessException e) {
                    LOGGER.error("解析对象失败，{}" , e.getLocalizedMessage());
            }
            }
        }
        return map;
    }

    /**
     * Map 转对象
     *
     * @param param
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> T mapConvertBean(Map param , Class<T> clazz) {
        String json = JSON.toJSONString(param);
        return JSON.parseObject(json , clazz);
    }
}
