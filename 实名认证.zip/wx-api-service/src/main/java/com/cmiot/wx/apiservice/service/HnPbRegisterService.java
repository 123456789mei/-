package com.cmiot.wx.apiservice.service;

import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.ms.dal.common.orcl.NormalBaseService;
import com.cmiot.mybatis.dao.PbRegisterDao;
import com.cmiot.mybatis.vo.PbRegisterVo;
import com.cmiot.util.HttpUtil;
import com.cmiot.wx.apiservice.utiles.CommonConstant;
import com.cmiot.wx.apiservice.utiles.SecurityUtils;
import com.cmiot.wx.apiservice.utiles.SignUtil;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class HnPbRegisterService extends NormalBaseService {

    static  Logger logger = LoggerFactory.getLogger(HnPbRegisterService.class);

    @Autowired
    ICache cache;


    @Autowired
    PbRegisterDao pbRegisterDao;

    static final String APPID="1083846";

    static final String APPKEY="a9c8113b2271b9e8edccfb7b7eecfa63";



    /**
     * PB卡实名认证流程查询
     */
    public ResponseVo checkMsisdnFlowService(Map map) {
        try {
            Map param=new HashMap();
            param.put("msisdn",map.get("msisdn"));
            String json = JsonUtils.parseString(param);
            //业务参数加密
            String encyptBusiParam = SecurityUtils.encodeAES256HexUpper(json, SecurityUtils.decodeHexUpper(APPKEY));
            //生成时间戳
            String now = getTime();
            //能力编码
            String method="OSP_CHECK_ISFOR_RECORD";
            //请求token
            String token=getToken();
            //生成数字签名
            Map<String, String> sysParam = new HashMap<String, String>();
            sysParam.put("method", "OSP_CHECK_ISFOR_RECORD");
            sysParam.put("format", "json");
            sysParam.put("timestamp", now);
            sysParam.put("appId", APPID);
            sysParam.put("version", "1.0");
            sysParam.put("accessToken",token);
            sysParam.put("busiSerial","1");
            String sign = SignUtil.sign(sysParam, encyptBusiParam, "HmacSHA256", APPKEY);
            String url=cache.getSysParams("371.registerUrl","http://192.168.195.31/pbRegisterHN");
            String sys=String.format("%s?method=%s&format=json&appId=%s&busiSerial=1&version=1.0&accessToken=%s&timestamp=%s" +
                    "&sign=%s",url,method,APPID,token,now,sign);
            logger.info("河南卡号接口请求前url校验：{}",sys);
            String x = HttpUtil.sendPost(sys,encyptBusiParam);
            logger.info("河南checkMsisdnFlowService...msisdn:{}返回:{}",map.get("msisdn"),x);
            Map resultMap = JsonUtils.parseObject(x, Map.class);
            if(!"00000".equals(resultMap.get("respCode"))){
                return ResponseVo.fail("1001");
            }
            //参数解密
            Map result = JsonUtils.parseObject(SecurityUtils.decodeAES256HexUpper(resultMap.get("result").toString(), SecurityUtils.decodeHexUpper(APPKEY)), Map.class);
            List<Map> list = JsonUtils.parseList(result.get("SO_MEMBER_DEAL").toString(), Map.class);
            Map transMap = new HashMap();
            transMap.put("isAuth",list.get(0).get("ISAUTH"));
            transMap.put("needAuth",list.get(0).get("NEEDAUTH"));
            return ResponseVo.success(transMap);
        } catch (Exception e) {
            logger.info("hn pb msisdn query fail checkMsisdnFlowService...{}...{}",
                    JsonUtils.parseString(map),e.getMessage());
            return ResponseVo.fail("99");
        }
    }


    /**
     * 一证五号校验
     */
    public ResponseVo idCardCheck(Map map) {
        try {
            Map param=new HashMap();
            param.put("idCard",map.get("idCard"));
            param.put("idType",map.get("idType"));
            param.put("msisdn",map.get("msisdn"));
            String json = JsonUtils.parseString(param);
            //业务参数加密
            String encyptBusiParam = SecurityUtils.encodeAES256HexUpper(json, SecurityUtils.decodeHexUpper(APPKEY));
            //生成时间戳
            String now = getTime();
            //能力编码
            String method="OSP_CHECK_USER_FOR_MAX";
            //请求token
            String token=getToken();
            //生成数字签名
            Map<String, String> sysParam = new HashMap<String, String>();
            sysParam.put("method", "OSP_CHECK_USER_FOR_MAX");
            sysParam.put("format", "json");
            sysParam.put("timestamp", now);
            sysParam.put("appId", APPID);
            sysParam.put("version", "1.0");
            sysParam.put("accessToken",token);
            sysParam.put("busiSerial","1");
            String sign = SignUtil.sign(sysParam, encyptBusiParam, "HmacSHA256", APPKEY);
            String url=cache.getSysParams("371.registerUrl","http://192.168.195.31/pbRegisterHN");
            String sys=String.format("%s?method=%s&format=json&appId=%s&busiSerial=1&version=1.0&accessToken=%s&timestamp=%s" +
                    "&sign=%s",url,method,APPID,token,now,sign);
            String x = HttpUtil.sendPost(sys,encyptBusiParam);
            logger.info("河南idCardCheck...msisdn:{}返回:{}",map.get("msisdn"),x);
            Map resultMap = JsonUtils.parseObject(x, Map.class);
            if(!"00000".equals(resultMap.get("respCode"))){
                return ResponseVo.fail("1001");
            }
            //参数解密
            Map result = JsonUtils.parseObject(SecurityUtils.decodeAES256HexUpper(resultMap.get("result").toString(), SecurityUtils.decodeHexUpper(APPKEY)), Map.class);
            List<Map> list = JsonUtils.parseList(result.get("SO_MEMBER_DEAL").toString(), Map.class);
            Map transMap = new HashMap();
            transMap.put("checkCode",list.get(0).get("CHECKCODE"));
            transMap.put("checkMsg",list.get(0).get("CHECKMSG"));
            return ResponseVo.success(transMap);
        } catch (Exception e) {
            logger.info("hn pb msisdn query fail idCardCheck...{}...{}",
                    JsonUtils.parseString(map),e.getMessage());
            return ResponseVo.fail("99");
        }
    }

    /**
     * 在线公司回调校验流水号
     */
    public ResponseVo orderNumCheck(Map param){
        try {
            setDatasourceByProvince(CommonConstant.ONELINK_PERSON_SOURCE);
            List<PbRegisterVo> list = pbRegisterDao.queryOrderNum(param);
            if(list.size()>0){
                return ResponseVo.success("ok");
            }
        }catch (Exception e){
            logger.info("551 pb orderNumCheck fail...{}",e);
        }
        return ResponseVo.fail("99");
    }

    /**
     * 获取token令牌
     */
    public  String getToken(){
        String tokenUrl=cache.getSysParams("371.token","http://192.168.195.31/hnToken");
        logger.info("河南tokenUrl检查:{}",tokenUrl);
        String result = HttpUtil.doGet(tokenUrl+"?app_id=1083846&app_key=a9c8113b2271b9e8edccfb7b7eecfa63&grant_type=client_credentials", "");
        if(result==null||"".equals(result)){
            result = HttpUtil.doGet(tokenUrl+"?app_id=1083846&app_key=a9c8113b2271b9e8edccfb7b7eecfa63&grant_type=client_credentials", "");
        }
        logger.info("检查token结果:{}",result);
        if(result!=null&&!"".equals(result)){
            Map resultMap = JsonUtils.parseObject(result, Map.class);
            if(resultMap!=null&&resultMap.get("access_token")!=null&&!"".equals(resultMap.get("access_token"))){
                return resultMap.get("access_token").toString();
            }else {
                return "";
            }
        }else {
            return "";
        }
    }

    /**
     * 生成时间戳
     */
    public  String getTime(){
        Date date=new Date(System.currentTimeMillis());
        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
        return sdf.format(date);
    }


    public static String sendhttpServiceByGet(String url,String sysparam,String busiparam) throws Exception{
        url = url+"?"+sysparam;
        HttpClient httpClient = new HttpClient();
        httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(3000);
        PostMethod postMethod = new PostMethod(url);
        if (StringUtils.isNotBlank(busiparam)) {
            RequestEntity entity = new StringRequestEntity(busiparam, "application/json", "utf-8");
            postMethod.setRequestEntity(entity);
        }
        int statusCode = httpClient.executeMethod(postMethod);
        if (statusCode != HttpStatus.SC_OK) {
            throw new Exception("Method failed:"  + postMethod.getStatusLine());
        }
        byte[] responseBody = postMethod.getResponseBody();
        String response = new String(responseBody, "utf-8");
        return response;
    }

    public  static String sendhttpServiceByPost(String url,String sysparam_busiparam) throws Exception{
        HttpClient httpClient = new HttpClient();
        httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(3000);
        PostMethod postMethod = new PostMethod(url);
        if (StringUtils.isNotBlank(sysparam_busiparam)) {
            RequestEntity entity = new StringRequestEntity(sysparam_busiparam, "application/json", "utf-8");
            postMethod.setRequestEntity(entity);
        }
        int statusCode = httpClient.executeMethod(postMethod);
        if (statusCode != HttpStatus.SC_OK) {
            throw new Exception("Method failed:"  + postMethod.getStatusLine());
        }
        byte[] responseBody = postMethod.getResponseBody();
        String response = new String(responseBody, "utf-8");
        return response;
    }




}
