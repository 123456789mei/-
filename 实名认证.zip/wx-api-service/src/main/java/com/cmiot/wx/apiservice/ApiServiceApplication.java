package com.cmiot.wx.apiservice;

import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.cache.impl.CacheImpl;
import com.cmiot.commons.common.utils.UUID4Long;
import com.cmiot.commons.config.BaseRedisConfig;
import com.cmiot.commons.config.CardRedisConfig;
import com.cmiot.commons.config.KafkaConfig;
import com.cmiot.commons.config.SystemRedisConfig;
import com.cmiot.commons.config.TempRedisConfig;
import com.cmiot.commons.log.ILog;
import com.cmiot.commons.log.LogImpl;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@SpringBootApplication
@EnableHystrixDashboard
@EnableCircuitBreaker
@EnableDiscoveryClient
@EnableCaching
@EnableFeignClients(basePackages = "com.cmiot.api")
@ComponentScan(basePackages = "com.cmiot")
@MapperScan(basePackages = "com.cmiot.mybatis")
@ImportResource(locations = {"classpath:spring-beans.xml"})
public class ApiServiceApplication {

    @Autowired
    private CardRedisConfig cardRedisConfig;

    @Autowired
    private SystemRedisConfig systemRedisConfig;

    @Autowired
    private TempRedisConfig tempRedisConfig;

    @Autowired
    private KafkaConfig kafkaConfig;

    public static void main(String[] args) {
        SpringApplication.run(ApiServiceApplication.class, args);
    }

    @Bean
    public ILog getLogger(){
        return new LogImpl();
    }
    @Bean
    public ICache getCache(){
        List<BaseRedisConfig> configs = Stream.of(cardRedisConfig, systemRedisConfig,
                tempRedisConfig).collect(Collectors.toList());
        return new CacheImpl(configs, kafkaConfig);
    }

    @Bean
    public UUID4Long getUUID4Long() {
        return new UUID4Long();
    }

    @Bean
    @LoadBalanced
    public RestTemplate getRestTemplate() {
        return new RestTemplate();
    }

    @Bean
    public ThreadPoolTaskExecutor getThreadPool() {
        ThreadPoolTaskExecutor poolTaskExecutor = new ThreadPoolTaskExecutor();
        poolTaskExecutor.setCorePoolSize(10);
        poolTaskExecutor.setMaxPoolSize(100);
        poolTaskExecutor.setQueueCapacity(300);
        poolTaskExecutor.setKeepAliveSeconds(60);
        poolTaskExecutor.setThreadNamePrefix("api-realName-push-");
        poolTaskExecutor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        return poolTaskExecutor;
    }
}
