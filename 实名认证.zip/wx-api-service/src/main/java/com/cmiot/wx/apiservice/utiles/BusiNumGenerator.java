package com.cmiot.wx.apiservice.utiles;

import java.util.concurrent.atomic.AtomicInteger;

public class BusiNumGenerator {
    private static AtomicInteger count = new AtomicInteger(0);

    public static String  generateBusiNum(){
        count.incrementAndGet();
        int i = count.get();
        return  String.format("%06d", i);
    }
}
