package com.cmiot.wx.apiservice.entity;

/**
 * @author xiapeicheng
 * @date 2018/9/7 10:14
 * @email xiapeicheng@cmiot.chinamobile.com
 */
public class PBMsisdnDetail {

    private String msisdn;

    private String imsi;

    private String iccid;

    private String custId;

    private String beId;

    private String status;

    public PBMsisdnDetail() {
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getIccid() {
        return iccid;
    }

    public void setIccid(String iccid) {
        this.iccid = iccid;
    }

    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }

    public String getBeId() {
        return beId;
    }

    public void setBeId(String beId) {
        this.beId = beId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
