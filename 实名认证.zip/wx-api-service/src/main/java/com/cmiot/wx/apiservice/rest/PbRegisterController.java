package com.cmiot.wx.apiservice.rest;


import com.cmiot.commons.log.ILog;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.commons.rest.RestBase;
import com.cmiot.wx.apiservice.entity.PbResultVo;
import com.cmiot.wx.apiservice.service.HnPbRegisterService;
import com.cmiot.wx.apiservice.service.PbRegisterService;
import com.cmiot.wx.apiservice.service.TjPbRegisterService;
import com.cmiot.wx.apiservice.service.impl.BjPbRegisterService;
import com.cmiot.wx.apiservice.service.impl.HainanPbRegisterService;
import com.cmiot.wx.apiservice.service.impl.JsPbRegisterService;
import com.cmiot.wx.apiservice.service.impl.ShPbRegisterService;
import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * xiajunchen
 * 2020-8-19
 */
@RestController
@RequestMapping(value = "/pbRegister")
public class PbRegisterController extends RestBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(PbRegisterController.class);

    @Autowired
    ILog iLog;

    @Autowired
    HttpServletRequest request;

    @Autowired
    PbRegisterService pbRegisterService;

    @Autowired
    HnPbRegisterService hnPbRegisterService;

    @Autowired
    BjPbRegisterService bjPbRegisterService;

    @Autowired
    JsPbRegisterService jsPbRegisterService;

    @Autowired
    TjPbRegisterService tjPbRegisterService;

    @Autowired
    ShPbRegisterService shPbRegisterService;

    @Autowired
    HainanPbRegisterService hainanPbRegisterService;

    /**
     * 安徽PB卡实名认证流程查询
     *
     * @return
     */
    @RequestMapping("/checkMsisdnFlow")
    public ResponseVo checkMsisdnFlow(@RequestBody Map map) {
        try {
            PbResultVo vo=new PbResultVo();
            vo.setIsAuth("1");
            vo.setNeedAuth("0");
            return ResponseVo.success(vo);
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "查询账户实名信息失败：{}", e);
            return ResponseVo.fail("002");
        }

    }



    /**
     * 一证五号校验
     *
     * @param map
     * @return
     */
    @RequestMapping("/idCardCheck")
    public ResponseVo idCardCheck(@RequestBody Map map) {
        try {
            return pbRegisterService.idCardCheck(map);
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "查询账户实名信息失败：{}", e);
            return ResponseVo.fail("002");
        }
    }

    /**
     * 订单回调校验
     *
     * @param map
     * @return
     */
    @RequestMapping("/orderNumCheck")
    public ResponseVo orderNumCheck(@RequestBody Map map) {
        try {
            return pbRegisterService.orderNumCheck(map);
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "订单回调校验：{}", e);
            return ResponseVo.fail("002");
        }
    }

    /**
     * 增加入库限制
     *
     * @param map
     * @return
     */
    @RequestMapping("/querySameOrderPb")
    public ResponseVo querySameOrderPb(@RequestBody Map map) {
        try {
            if("210".equals(map.get("beId"))){
                return ResponseVo.success("ok");
            }
            return pbRegisterService.querySameOrderPb(map.get("msisdn").toString());
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "querySameOrderPb：{}", e);
            return ResponseVo.fail("002");
        }
    }



    /*---------------河南实名登记--------------------------*/

    /**
     * 卡实名认证流程查询
     *
     * @return
     */
    @RequestMapping("/checkMsisdnFlowHN")
    public ResponseVo checkMsisdnFlowHN(@RequestBody Map map) {
        try {
            return hnPbRegisterService.checkMsisdnFlowService(map);
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "查询账户实名信息失败：{}", e);
            return ResponseVo.fail("002");
        }

    }



    /**
     * 一证五号校验
     *
     * @param map
     * @return
     */
    @RequestMapping("/idCardCheckHN")
    public ResponseVo idCardCheckHN(@RequestBody Map map) {
        try {
            return hnPbRegisterService.idCardCheck(map);
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "查询账户实名信息失败：{}", e);
            return ResponseVo.fail("002");
        }
    }


    /*---------------北京实名登记--------------------------*/

    /**
     * 卡实名认证流程查询
     *
     * @return
     */
    @RequestMapping("/checkMsisdnFlowBJ")
    public ResponseVo checkMsisdnFlowBJ(@RequestBody Map map) {
        try {
            return bjPbRegisterService.checkMsisdnFlowService(map);
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "查询账户实名信息失败：{}", e);
            return ResponseVo.fail("002");
        }

    }



    /**
     * 一证五号校验
     *
     * @param map
     * @return
     */
    @RequestMapping("/idCardCheckBJ")
    public ResponseVo idCardCheckBJ(@RequestBody Map map) {
        try {
            return bjPbRegisterService.idCardCheck(map);
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "查询账户实名信息失败：{}", e);
            return ResponseVo.fail("002");
        }
    }

    /*---------------江苏实名登记--------------------------*/

    /**
     * 卡实名认证流程查询
     *
     * @return
     */
    @RequestMapping("/checkMsisdnFlowJS")
    public ResponseVo checkMsisdnFlowJS(@RequestBody Map map) {
        try {
            return jsPbRegisterService.checkMsisdnFlowService(map,getTransNo(request));
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "checkMsisdnFlowJS查询失败：{}", e);
            return ResponseVo.fail("002");
        }

    }



    /**
     * 一证五号校验
     *
     * @param map
     * @return
     */
    @RequestMapping("/idCardCheckJS")
    public ResponseVo idCardCheckJS(@RequestBody Map map) {
        try {
            return jsPbRegisterService.idCardCheck(map,getTransNo(request));
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "查询账户实名信息失败：{}", e);
            return ResponseVo.fail("002");
        }
    }

    /*---------------天津实名登记--------------------------*/

    /**
     * 卡实名认证流程查询
     *
     * @return
     */
    @RequestMapping("/checkMsisdnFlowTJ")
    public ResponseVo checkMsisdnFlowTJ(@RequestBody Map map) {
        try {
            return tjPbRegisterService.checkMsisdnFlowService(map,getTransNo(request));
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "checkMsisdnFlowTJ查询失败：{}", e);
            return ResponseVo.fail("002");
        }

    }



    /**
     * 一证五号校验
     *
     * @param map
     * @return
     */
    @RequestMapping("/idCardCheckTJ")
    public ResponseVo idCardCheckTJ(@RequestBody Map map) {
        try {
            return tjPbRegisterService.idCardCheck(map,getTransNo(request));
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "idCardCheckTJ查询失败：{}", e);
            return ResponseVo.fail("002");
        }
    }

    /*---------------上海实名登记--------------------------*/

    /**
     * 卡实名认证流程查询
     *
     * @return
     */
    @RequestMapping("/checkMsisdnFlowSH")
    public ResponseVo checkMsisdnFlowSH(@RequestBody Map map) {
        try {
            return shPbRegisterService.checkMsisdnFlowService(map);
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "checkMsisdnFlowSH查询失败：{}", e);
            return ResponseVo.fail("002");
        }

    }


    /*---------------海南实名登记--------------------------*/

    /**
     * 卡实名认证流程查询
     *
     * @return
     */
    @RequestMapping("/checkMsisdnFlowHainan")
    public ResponseVo checkMsisdnFlowHainan(@RequestBody Map map) {
        try {
            return hainanPbRegisterService.checkMsisdnFlowService(map,getTransNo(request));
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "checkMsisdnFlowHainan查询失败：{}", e);
            return ResponseVo.fail("002");
        }

    }



    /**
     * 一证五号校验
     *
     * @param map
     * @return
     */
    @RequestMapping("/idCardCheckHainan")
    public ResponseVo idCardCheckHainan(@RequestBody Map map) {
        try {
            return hainanPbRegisterService.idCardCheck(map,getTransNo(request));
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "idCardCheckHainan查询失败：{}", e);
            return ResponseVo.fail("002");
        }
    }

}
