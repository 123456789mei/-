package com.cmiot.wx.apiservice.utiles;

public class RealNameAuthConstant {

    //加密机地址
    public static final String ENCRYPT_MACHINE = "ENCRYPT_MACHINE";
    //前端H5跳转
    public static final String RESERVATION_CERTIFICATION_H5 = "RESERVATION_CERTIFICATION_H5";

    public static final String ALLOW_MODIFY_DESKEY = "ALLOW_MODIFY_DESKEY";

    public static final String ALLOW_MODIFY_SIGNATUREKEY = "ALLOW_MODIFY_SIGNATUREKEY";

    public static final String CMIOT_CODE = "230030";

    public static final String ONLINE_CODE = "1085"; //在线公司的

    public static final String MP_REQUEST_TYPE = "mp"; //手机接入版

    public static final String REQUEST_BUSI_CATEGORY  = "7"; //中移物联网卡激活

    public static final String CHECK_TYPE = "0";//0自动审核 1人工审核 不传默认人工

    public static final String DESKEY_BUSI_CODE ="PUSH_KEY";

    public static final String SIGNATUREKEY_BUSI_CODE ="RSA_KEY_FRESH";

    public static final String SUCCESS_RETURN_CODE ="0000";

    public static final String FAILURE_RETURN_CODE ="1001";

    public static final String EXCEPTION_RETURN_CODE ="2999";

//    public static final String WX_REAL_NAME_AUTH_RETURN_URL = "WX_REAL_NAME_AUTH_RETURN_URL";//微信公众号实名认证第三方回调接口地址

//    public static final String APP_REAL_NAME_AUTH_RETURN_URL = "APP_REAL_NAME_AUTH_RETURN_URL";//小程序实名认证第三方回调接口地址

    //实名认证的加密密钥参数
    public static final String CACHED_DESKEY_INFO = "CACHEDDESKEYINFO";

    public static final String DESKEY = "DESKEY";

    public static final String DESKEY_ID = "DESKEYID";

    //实名认证的签名加密密钥参数
    public static final String CACHED_SIGNATUREKEY = "CACHEDSIGNATUREKEY";

    public static final int TID_DESKEYID_BIND_EXPIRE = 900; //transactionID和DESkeyid关系缓存过期时间

    public static final String SIGNATURE_TIMESTAMP_FORMAT =  "yyyy-MM-dd HH:mm:ss";

    public static final String DESKEY_CERTEXPDATE_FORMAT =  "yyyy-MM-dd";

    public static final String BUSISEQ_DATE_FORMAT =  "yyyyMMddHHmmss";

    public static final String WX_OFFICIAL_ACCOUNT =  "WX_OA"; //official account 微信公众号

    public static final String REAL_NAME_DAILY_LIMIT =  "REAL_NAME_DAILY_LIMIT";

    public static final String REAL_NAME_PROVCODE =  "230";

    public static final String MSG_VERSION="1.0";

}
