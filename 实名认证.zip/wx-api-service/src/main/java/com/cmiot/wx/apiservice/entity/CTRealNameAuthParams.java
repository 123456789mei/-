package com.cmiot.wx.apiservice.entity;

/**
 * CT实名认证请求参数实体
 */
public class CTRealNameAuthParams extends CTParams {

    private String msisdn;

    private String iccid;

    private String custName;

    private String custCertNo;

    private String custPhoneNo;

    private String isHandleCard;

    private String picNameT;

    private String picNameR;

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getIccid() {
        return iccid;
    }

    public void setIccid(String iccid) {
        this.iccid = iccid;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getCustCertNo() {
        return custCertNo;
    }

    public void setCustCertNo(String custCertNo) {
        this.custCertNo = custCertNo;
    }

    public String getCustPhoneNo() {
        return custPhoneNo;
    }

    public void setCustPhoneNo(String custPhoneNo) {
        this.custPhoneNo = custPhoneNo;
    }

    public String getIsHandleCard() {
        return isHandleCard;
    }

    public void setIsHandleCard(String isHandleCard) {
        this.isHandleCard = isHandleCard;
    }

    public String getPicNameT() {
        return picNameT;
    }

    public void setPicNameT(String picNameT) {
        this.picNameT = picNameT;
    }

    public String getPicNameR() {
        return picNameR;
    }

    public void setPicNameR(String picNameR) {
        this.picNameR = picNameR;
    }
}
