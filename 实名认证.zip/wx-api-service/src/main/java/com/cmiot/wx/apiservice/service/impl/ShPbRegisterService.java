package com.cmiot.wx.apiservice.service.impl;

import com.cmiot.commons.cache.ICache;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.mybatis.dao.PbRegisterDao;
import com.cmiot.util.ShAESUtils;
import com.cmiot.wx.apiservice.utiles.SignUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Random;

@Service
public class ShPbRegisterService {

    static  Logger logger = LoggerFactory.getLogger(ShPbRegisterService.class);

    @Autowired
    ICache cache;


    @Autowired
    PbRegisterDao pbRegisterDao;




    /**
     * PB卡实名认证流程查询
     */

    public ResponseVo checkMsisdnFlowService(Map map) {
        try {
            //业务数据封装
            String url = cache.getSysParams("SH_PB_REGISTER_URL", "https://www.sh.10086.cn/h5/171207.jsp");
            String msisdn=map.get("msisdn").toString();
            //安吉星号段判断
            if(msisdn.startsWith("147660")||msisdn.startsWith("178940")||msisdn.startsWith("178941")||msisdn.startsWith("178942")
                    ||msisdn.startsWith("178943")||msisdn.startsWith("178944")||msisdn.startsWith("178945")||msisdn.startsWith("17239")
                    ||msisdn.startsWith("148020")||(Integer.valueOf(msisdn.substring(0,6))>=178946&&Integer.valueOf(msisdn.substring(0,6))<=178949)
                    ||(Integer.valueOf(msisdn.substring(0,6))>=172460&&Integer.valueOf(msisdn.substring(0,6))<=172463)
                    ||(Integer.valueOf(msisdn.substring(0,6))>=1724640&&Integer.valueOf(msisdn.substring(0,6))<=1724699)
                    ||(Integer.valueOf(msisdn.substring(0,6))>=172500&&Integer.valueOf(msisdn.substring(0,6))<=172504)
                    ||(Integer.valueOf(msisdn.substring(0,6))>=1480210&&Integer.valueOf(msisdn.substring(0,6))<=1480299)
                    ||(Integer.valueOf(msisdn.substring(0,6))>=1480600&&Integer.valueOf(msisdn.substring(0,6))<=1480639)){
                String cardNumber= URLEncoder.encode("91310000717884392Q","UTF-8");
                cardNumber = ShAESUtils.aesEncrypt(cardNumber, "WLWRHZX2021CHECK0524");
                msisdn= URLEncoder.encode(msisdn,"UTF-8");
                msisdn = ShAESUtils.aesEncrypt(msisdn, "WLWRHZX2021CHECK0524");
                url=url+"?certificateType=0&cardNumber="+cardNumber+"&number="+msisdn+"&cardType=1";
                map.put("idCard","91310000717884392Q");
            }else {
                msisdn= URLEncoder.encode(msisdn,"UTF-8");
                msisdn = ShAESUtils.aesEncrypt(msisdn, "WLWRHZX2021CHECK0524");
                String iccid=map.get("iccid").toString();
                iccid= URLEncoder.encode(iccid,"UTF-8");
                iccid = ShAESUtils.aesEncrypt(iccid, "WLWRHZX2021CHECK0524");
                url=url+"?certificateType=1&cardNumber="+iccid+"&number="+msisdn+"&cardType=";
            }
            map.put("orderNum",getRandomNickname(10));
            logger.info("上海url检查：{},入库参数检查:{}",url,JsonUtils.parseString(map));
            pbRegisterDao.insertShPbRegister(map);
            return ResponseVo.success(url);
        } catch (Exception e) {
            logger.info("210 pb msisdn query fail checkMsisdnFlowService...{}...{}",
                    JsonUtils.parseString(map),e);
            return ResponseVo.fail("99");
        }
    }

    public static void main(String[] args){
        try {
            String msisdn="dAvNT6vIFSfjTwNbqkqPAg==";
            String iccid="sffeuhWndoAnYYiYvqcl5h9wHiXLoncNuhPJlImT3zo=";
            System.out.println(ShAESUtils.aesDecrypt(msisdn,"WLWRHZX2021CHECK0524"));
            System.out.println(ShAESUtils.aesDecrypt(iccid,"WLWRHZX2021CHECK0524"));
        }catch (Exception e){

        }
    }




    /**
          * 生成随机数字10位数
          * @return
          */
    public static String getRandomNickname(int length) {
        String val = "";
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            val += String.valueOf(random.nextInt(10));
        }
        return val;
    }


    /**
     * 生成时间戳
     */
    public static String getTime(){
        Date date=new Date(System.currentTimeMillis());
        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
        return sdf.format(date);
    }





    //生成数字签名
    public static String createSign(Map sysParam , String busiParam,String privateKey)
    {
        //数字签名算法
        String signType = "SHA";
        //数字签名
        String sign = "";
        try {
            sign = SignUtil.sign(sysParam, busiParam, "HmacSHA256", privateKey);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return sign;
    }

}
