package com.cmiot.wx.apiservice.entity;

/**
 * pb物联卡校验结果封装
 * xiajunchen
 */
public class PbResultVo {
    //卡是否已经实名认证（0：已认证，1：未认证）
    private String isAuth;
    //卡是否需要实名认证（0：需要，1：不需要）
    private String needAuth;
    //校验结果（0：通过，1：未通过）
    private String checkCode;
    //校验结果信息描述（checkCode为1时为非空）
    private String checkMsg;
    //图片同步结果
    private String result;

    public String getIsAuth() {
        return isAuth;
    }

    public void setIsAuth(String isAuth) {
        this.isAuth = isAuth;
    }

    public String getNeedAuth() {
        return needAuth;
    }

    public void setNeedAuth(String needAuth) {
        this.needAuth = needAuth;
    }

    public String getCheckCode() {
        return checkCode;
    }

    public void setCheckCode(String checkCode) {
        this.checkCode = checkCode;
    }

    public String getCheckMsg() {
        return checkMsg;
    }

    public void setCheckMsg(String checkMsg) {
        this.checkMsg = checkMsg;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
