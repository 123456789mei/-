package com.cmiot.wx.apiservice.rest;


import com.cmiot.common.ct.access.entity.CTResponse;
import com.cmiot.commons.common.utils.JsonUtils;
import com.cmiot.commons.common.utils.MapParamChecker;
import com.cmiot.commons.log.ILog;
import com.cmiot.commons.response.ResponseVo;
import com.cmiot.commons.rest.RestBase;
import com.cmiot.mybatis.service.RealNameRegisterService;
import com.cmiot.tasks.PersonTaskService;
import com.cmiot.wx.apiservice.service.CTRealNameRegisterService;
import com.cmiot.wx.apiservice.utiles.CommonConstant;
import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping(value = "/register")
public class RealNameRegisterController extends RestBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(RealNameRegisterController.class);

    @Autowired
    ILog iLog;

    @Autowired
    HttpServletRequest request;

    @Autowired
    CTRealNameRegisterService ctRegistService;

    @Autowired
    RealNameRegisterService realNameRegisterService;

    @Autowired
    PersonTaskService personTaskService;

    /**
     * 校验用户输入信息是否和账号实名信息一致
     *
     * @param map
     * @return
     */
    @RequestMapping("/isUserIdentityInfo")
    public ResponseVo isUserIdentityInfo(@RequestBody Map map) {
        try {
            Map data = new HashMap(1);
            if (realNameRegisterService.authed(map) || realNameRegisterService.isUserIdentityInfo(map)) {//一致
                data.put("code", "010");
                return ResponseVo.success(data);
            } else {//不一致
                data.put("code", "011");
                return ResponseVo.success(data);
            }
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "查询账户实名信息失败：{}", e);
            return ResponseVo.fail("002");
        }
    }

    /**
     * 存储实名认证登记信息
     *
     * @param map
     * @return
     */
    @RequestMapping("/saveRealNameRegInfo")
    public ResponseVo saveRealNameRegisterInfo(@RequestBody Map map) {
        try {
            realNameRegisterService.saveRealNameRegisterInfo(map);
            return ResponseVo.success("0");
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "实名登记信息存储失败：{}", e);
            return ResponseVo.fail("002");
        }
    }

    /**
     * 向CT发起实名认证
     *
     * @return
     */
    @RequestMapping(value = "/realNameRegist")
    public ResponseVo realNameRegist(@RequestBody Map map) {
        String msisdn = map.getOrDefault(CommonConstant.FIELD_MSISDN, "").toString();
        String iccid = map.getOrDefault(CommonConstant.FIELD_ICCID, "").toString();
        String custId = map.getOrDefault(CommonConstant.FIELD_CUSTID, "").toString();
        String custName = map.getOrDefault(CommonConstant.FIELD_CUSTNAME, "").toString();
        String custCertNo = map.getOrDefault(CommonConstant.FIELD_CUSTCERTNO, "").toString();
        //用户手机号码
        String custPhoneNo = map.getOrDefault(CommonConstant.FIELD_CUSTPHONENO, "").toString();
        //是否检测手持身份证(取值为0或1 0：代表人像图片1：代表上传手持身份证图片)
        String isHandleCard = map.getOrDefault(CommonConstant.FIELD_ISHANDLECARD, "").toString();
        //当isHandleCard=0时，该字段必传；Base64字符串
        String picNameT = map.getOrDefault(CommonConstant.FIELD_PICNAME_T, "").toString();
        //用户现场头像图片或用户现场手持身份证图片 Base64字符串
        String picNameR = map.getOrDefault(CommonConstant.FIELD_PICNAME_R, "").toString();
        //省份id
        String beId = map.getOrDefault(CommonConstant.FIELD_BEID, "").toString();
        // 3.7改造升级
        String custCertAddr = map.getOrDefault(CommonConstant.CUST_CERT_ADDR, "").toString();//身份证地址
        String certValiddate = map.getOrDefault(CommonConstant.CERT_VALIDDATE, "").toString();//身份证生效时间
        String certExpdate = map.getOrDefault(CommonConstant.CERT_EXPDATE, "").toString();//身份证失效时间
        String gender = map.getOrDefault(CommonConstant.GENDER, "").toString();//性别
        String nation = map.getOrDefault(CommonConstant.NATION, "").toString();//民族
        String birthday = map.getOrDefault(CommonConstant.BIRTHDAY, "").toString();//生日
        String issuingAuthority = map.getOrDefault(CommonConstant.ISSUING_AUTHORITY, "").toString();//签证机关
        String picNameF = map.getOrDefault(CommonConstant.PIC_NAME_F, "").toString();//用户证件反面图片
        String picNameZ = map.getOrDefault(CommonConstant.PIC_NAME_Z, "").toString();//用户证件正面图片

        Map<String, String> params = new HashMap(10);
        params.put(CommonConstant.TRANSNO, getTransNo(request));
        params.put(CommonConstant.FIELD_MSISDN, msisdn);
        params.put(CommonConstant.FIELD_ICCID, iccid.toUpperCase());//lxc 因为CT接口要求，ICCID字母统一为大写
        params.put(CommonConstant.FIELD_CUSTID, custId);
        params.put(CommonConstant.FIELD_CUSTNAME, custName);
        params.put(CommonConstant.FIELD_CUSTCERTNO, custCertNo);
        params.put(CommonConstant.FIELD_CUSTPHONENO, custPhoneNo);
        params.put(CommonConstant.FIELD_ISHANDLECARD, isHandleCard);
        params.put(CommonConstant.FIELD_PICNAME_T, picNameT);
        params.put(CommonConstant.FIELD_PICNAME_R, picNameR);
        params.put(CommonConstant.FIELD_BEID, beId);
        // 3.7改造升级
        params.put(CommonConstant.CUST_CERT_ADDR, custCertAddr);
        params.put(CommonConstant.CERT_VALIDDATE, certValiddate);
        params.put(CommonConstant.CERT_EXPDATE, certExpdate);
        params.put(CommonConstant.GENDER, gender);
        params.put(CommonConstant.NATION, nation);
        params.put(CommonConstant.BIRTHDAY, birthday);
        params.put(CommonConstant.ISSUING_AUTHORITY, issuingAuthority);
        params.put(CommonConstant.PIC_NAME_F, picNameF);
        params.put(CommonConstant.PIC_NAME_Z, picNameZ);
        CTResponse resp = ctRegistService.realNameReg(params);

        return CommonConstant.WX_CT_CODE_SUCCESS.equals(resp.getRespCode()) ? ResponseVo.success(resp) : ResponseVo.fail(resp.getRespCode());
    }

    /**
     * 查询物联卡是否已完成实名登记
     * 2019-03-07 该方法废弃，已被其他人实现
     * @deprecated
     * @param paramMap
     * @return
     */
    @Deprecated
    @RequestMapping("/getSuccessRegisterInfo")
    public ResponseVo getSuccessRegisterInfo(@RequestBody Map paramMap) {
        try {
            String msisdn = paramMap.get(CommonConstant.FIELD_MSISDN).toString();
            Map<String, String> map = realNameRegisterService.getSuccessRegisterInfo(msisdn);
            return map.isEmpty() ? ResponseVo.success("0") : ResponseVo.fail("022", map);
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "物联卡是否已成功实名登记查询失败：{}", e);
            return ResponseVo.fail("002");
        }
    }


    /**
     *公众号ct实名认证-卡激活弹窗判断
     *
     * @param paramMap
     * @return
     */
    @RequestMapping("/queryBbcStatus")
    public ResponseVo queryBbcStatus(@RequestBody Map paramMap) {
        try {
            return realNameRegisterService.queryBbccStatus(paramMap);
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "queryBbcStatus fail：{}", e);
            return ResponseVo.fail("99");
        }
    }

    /**
     *公众号ct实名认证-获取url
     *
     * @param paramMap
     * @return
     */
    @RequestMapping("/registerUrl")
    public ResponseVo registerUrl(@RequestBody Map paramMap) {
        try {
            paramMap.put("transNo",getTransNo(request));
            return realNameRegisterService.startCtRegister(paramMap);
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "registerUrl fail：{}", e);
            return ResponseVo.fail("99");
        }
    }

    /**
     *公众号ct实名认证-供外部调用获取活体url
     *
     * @param paramMap
     * @return
     */
    @RequestMapping("/registerUrlApi")
    public ResponseVo registerUrlApi(@RequestBody Map paramMap) {
        try {
            // 参数校验
            MapParamChecker mapParamChecker = MapParamChecker.instance(paramMap)
                    .isNotBlank("msisdn")
                    .isNotBlank("iccid")
                    .isNotBlank("beId")
                    .isNotBlank("custId");
            if (!mapParamChecker.isValid()) {
                LOGGER.info("registerUrlApi请求缺少必要参数:{}", JsonUtils.parseString(paramMap));
                return ResponseVo.fail("010");
            }
            paramMap.put("flag","1");
            paramMap.put("isActive","1");
            paramMap.put("userId","oneLinkApiPb");
            return realNameRegisterService.startCtRegisterApi(paramMap);
        } catch (Exception e) {
            LOGGER.info("registerUrlApi fail:{},{}", JsonUtils.parseString(paramMap),e);
            return ResponseVo.fail("001");
        }
    }

    /**
     *运营埋点
     *
     * @param paramMap
     * @return
     */
    @RequestMapping("/innerStatis")
    public ResponseVo innerStatis(@RequestBody Map paramMap) {
        try {
            realNameRegisterService.innerStatisService(paramMap.get("step").toString());
            return ResponseVo.success("ok");
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "innerStatis fail：{}", e);
            return ResponseVo.fail("99");
        }
    }

    /**
     *运营埋点-执行定时任务
     *
     */
    @RequestMapping("/innerStatisTask")
    public ResponseVo innerStatisTask() {
        try {
//            LOGGER.info("innerStatisTask start...");
            realNameRegisterService.saveCacheStatis();
            return ResponseVo.success("ok");
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "innerStatisTask fail：{}", e);
            return ResponseVo.fail("99");
        }
    }

    /**
     *定时任务-查询ct卡实名订单状态
     *
     */
    @RequestMapping("/queryOrderStatus")
    public ResponseVo queryOrderStatus() {
        try {
            LOGGER.info("queryOrderStatus start...");
            realNameRegisterService.queryOrderStatusService();
            return ResponseVo.success("ok");
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "queryOrderStatus fail：{}", e);
            return ResponseVo.fail("99");
        }
    }

    /**
     *个人业务-卡实名查询
     *
     */
    @RequestMapping("/queryCardRegisterList")
    public ResponseVo queryCardRegisterList(@RequestBody Map paramMap) {
        try {
            LOGGER.info("queryCardRegisterList start...");
            // 参数校验
            MapParamChecker mapParamChecker = MapParamChecker.instance(paramMap)
                    .isNotBlank("userId");
            if (!mapParamChecker.isValid()) {
                LOGGER.info("queryCardRegisterList请求缺少必要参数:{}", JsonUtils.parseString(paramMap));
                return ResponseVo.fail("010");
            }
            return realNameRegisterService.queryCardRegisterList(paramMap);
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "queryCardRegisterList fail：{}", e);
            return ResponseVo.fail("99");
        }
    }

    /**
     *定时更新流控次数
     *
     */
    @RequestMapping("/updateTrafficControl")
    public ResponseVo updateTrafficControl() {
        try {
//            LOGGER.info("innerStatisTask start...");
            realNameRegisterService.updateTrafficControl();
            return ResponseVo.success("ok");
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "updateTrafficControl fail：{}", e);
            return ResponseVo.fail("99");
        }
    }

    /**
     *查询h5企业名称
     *
     */
    @RequestMapping("/queryCustNameByAppId")
    public ResponseVo queryCustNameByAppId(@RequestBody Map paramMap) {
        try {
           return realNameRegisterService.queryCustNameByAppId(paramMap);
        } catch (Exception e) {
            iLog.error(LOGGER, getTransNo(request), null, "updateTrafficControl fail：{}", e);
            return ResponseVo.fail("99");
        }
    }

    /**
     *pb实名登记定时任务
     *
     */
//    @RequestMapping("/pbRegisterSync")
//    public ResponseVo pbRegisterSync() {
//        try {
//            LOGGER.info("pbRegisterSync start...");
//            personTaskService.syncInfo();
//            return ResponseVo.success("ok");
//        } catch (Exception e) {
//            iLog.error(LOGGER, getTransNo(request), null, "pbRegisterSync fail：{}", e);
//            return ResponseVo.fail("99");
//        }
//    }

    /**
     *实名记录查询开放接口
     *
     */
    @RequestMapping("/queryRegisterInfo")
    public ResponseVo queryRegisterInfo(@RequestBody Map paramMap) {
        try {
            // 参数校验
            MapParamChecker mapParamChecker = MapParamChecker.instance(paramMap)
                    .isNotBlank("msisdn")
                    .isNotBlank("orderNo");
            if (!mapParamChecker.isValid()) {
                LOGGER.info("queryRegisterInfo请求缺少必要参数:{}", JsonUtils.parseString(paramMap));
                return ResponseVo.fail("010");
            }
            return realNameRegisterService.queryRegisterInfoService(paramMap);
        } catch (Exception e) {
            LOGGER.info("queryRegisterInfo fail:{},{}", JsonUtils.parseString(paramMap),e);
            return ResponseVo.fail("001");
        }
    }

    /**
     *手动清理ct_customer表
     *
     */
    @RequestMapping("/modifyCtCustomer")
    public ResponseVo modifyCtCustomer() {
        try {
            LOGGER.info("清理ct集团start");
            return realNameRegisterService.modifyCtService();
        } catch (Exception e) {
            LOGGER.info("清理ct集团 fail:{}",e);
            return ResponseVo.fail("001");
        }
    }

    /**
     *手动传历史话单
     *
     */
    @RequestMapping("/sendHisOrder")
    public ResponseVo sendHisOrder() {
        try {
            LOGGER.info("传历史话单start");
            return realNameRegisterService.sendHisOrderService();
        } catch (Exception e) {
            LOGGER.info("传历史话单start fail:{}",e);
            return ResponseVo.fail("001");
        }
    }
}
