package com.cmiot.wx.apiservice.entity;

import java.io.Serializable;
import java.util.List;

/**
 * 描述：机器卡信息
 */
public class CardAccountBean implements Serializable {
    private static final long serialVersionUID = 1;
    private String oprNum;
    private String msisdn;
    private String imsi;

    private AccountBean accountInfo;

    private List<DataAmountBean> servDataAmountArrayList;

    public String getOprNum() {
        return oprNum;
    }

    public void setOprNum(String oprNum) {
        this.oprNum = oprNum;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public AccountBean getAccountBeanInfo() {
        return accountInfo;
    }

    public void setAccountBeanInfo(AccountBean accountInfo) {
        this.accountInfo = accountInfo;
    }

    public List<DataAmountBean> getServDataAmountArrayList() {
        return servDataAmountArrayList;
    }

    public void setServDataAmountArrayList(List<DataAmountBean> servDataAmountArrayList) {
        this.servDataAmountArrayList = servDataAmountArrayList;
    }

    @Override
    public String toString() {
        return "CardAccountBean{" +
                "oprNum='" + oprNum + '\'' +
                ", msisdn='" + msisdn + '\'' +
                ", imsi='" + imsi + '\'' +
                ", accountInfo=" + accountInfo +
                ", servDataAmountArrayList=" + servDataAmountArrayList +
                '}';
    }

}
