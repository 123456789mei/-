/**
 * httpService 的模拟返回服务
 * 通过配置每一个path对应的json文件，达到mock效果
 * 
 **/
personui.factory('mockConfig', [function() {
    var mock_Config = {}
    mock_Config["/test"] = "json/test.json";
    mock_Config["/service/wx/person/api/getBaseInfo"] = "json/baseInfo.json"; //票据
    mock_Config["/service/wx/person/api/checkMsisdnIccid"] = "json/checkMsisdnIccid.json";
    mock_Config["/service/wx/person/api/getMsisdnList"] = "json/getMsisdnList.json"; //物联卡列表
    mock_Config["/service/wx/person/api/getVerifiedStatus"] = "json/getVerifiedStatus.json"; //是否认证
    mock_Config["/service/wx/person/api/realNameReg"] = "json/realNameReg.json";
    mock_Config["/service/wx/person/api/checkIdNumber"] = "json/checkIdNumber.json";
    mock_Config["/service/wx/person/api/activateCardFromCT"] = "json/activateCardFromCT.json";
    mock_Config["/service/wx/person/api/getMsisdnInfo"] = "json/getMsisdnInfo.json"; //物联卡信息
    mock_Config["/service/wx/person/api/getSimFlowInfo"] = "json/getSimFlowInfo.json"; //用量信息
    mock_Config["/service/wx/person/api/getProductInfo"] = "json/getProductInfo.json"; //套餐信息
    mock_Config["/service/wx/person/api/modifyRemark"] = "json/modifyRemark.json"; //修改别名
    mock_Config["/service/wx/person/api/activateCardFromCT"] = "json/activateCardFromCT.json"; //激活
    mock_Config["/service/wx/person/api/unbindMsisdn"] = "json/unbindMsisdn.json"; //解绑
    mock_Config["/service/wx/person/api/userIdentityValidate"] = "json/userIdentityValidate.json";
    mock_Config["/service/wx/person/api/bindingMsisdn"] = "json/bindingMsisdn.json";
    mock_Config["/service/wx/person/api/queryMsisdnList"] = "json/queryMsisdnList.json"; //查询列表
    mock_Config["/service/wx/person/api/syncMsisdnList"] = "json/syncMsisdnList.json"; //查询列表(包含状态信息)
    mock_Config["/service/wx/person/api/queryBalance"] = "json/queryBalance.json"; //查余额（用于列表）
    mock_Config["/service/wx/person/api/queryNetStatus"] = "json/queryNetStatus.json"; //查开关机状态（用于列表）
    mock_Config["/service/wx/person/api/queryUseTotal"] = "json/queryUseTotal.json"; //查询用量信息（用于列表）
    mock_Config["/service/wx/person/api/queryStatus"] = "json/queryStatus.json"; //查询卡状态（用于列表）
    mock_Config["/service/wx/person/api/chargeOfCT"] = "json/chargeOfCT.json"; //CT充值接口路径
    mock_Config["/service/wx/person/api/checkIndividualAccount"] = "json/checkIndividualAccount.json"; //CT充值接口返回账户信息
    mock_Config["/service/wx/person/api/saveChargeLogOfPB"] = "json/saveChargeLogOfPB.json"; //PB充值接口返回记录
    mock_Config["/service/wx/person/api/getIndustries"] = "json/getIndustries.json"; //行业信息
    mock_Config["/service/wx/person/api/getDicts"] = "json/getDicts.json"; //意见类型
    mock_Config["/service/wx/person/api/saveFeedback"] = "json/saveFeedback.json"; //意见反馈
    mock_Config["/service/wx/person/api/ocr"] = "json/ocr.json"; //识别身份证

    return {
        getMockDataPath: function(httpPath) {
            return mock_Config[httpPath];
        }
    }
}]);