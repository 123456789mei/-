/**
 * Created by hp-01 on 2017/9/20.
 * author: liz;
 * dis: sessionStorage 公共;
 */
personui.factory('personStorage', function () {
    return {
        removeSessionItem:function(){
          sessionStorage.clear();
        },
        getOpenId: function () {
            return sessionStorage.getItem("openId");
        },
        setOpenId: function (openId) {
            return sessionStorage.setItem("openId", openId)
        },
        getPhone: function () {
            return sessionStorage.getItem("phone");
        },
        setPhone: function (phone) {
            return sessionStorage.setItem("phone", phone)
        },
        getUserId: function () {
            return sessionStorage.getItem("userId");
        },
        setUserId: function (userId) {
            return sessionStorage.setItem("userId", userId)
        },
        setName: function (name) {
            return sessionStorage.setItem("name", name)
        },
        getName: function () {
            return sessionStorage.getItem("name");
        },
        setTitle:function(title){
            return sessionStorage.setItem("title",title);
        },
        getTitle:function () {
            return sessionStorage.getItem("title");
        },
        setMsisdn:function(msisdn){
            return sessionStorage.setItem("msisdn",msisdn);
        },
        getMsisdn:function () {
            return sessionStorage.getItem("msisdn");
        },
        setBeId:function(beId){
            return sessionStorage.setItem("beId",beId);
        },
        getBeId:function () {
            return sessionStorage.getItem("beId");
        },
        //是否认证的状态码 01:已经通过认证 00:未认证 10:身份证过期，需重新认证 99:显示错误
        setVerifiedStatus:function(status){
            return sessionStorage.setItem("verifiedStatus",status);
        },
        getVerifiedStatus:function () {
            return sessionStorage.getItem("verifiedStatus");
        },
        //用户操作
        getOperate:function(){
            return localStorage.getItem('operate')||null
        },
        setOperate:function(operate){
            if(!operate){
                localStorage.setItem('operate',null)
            }else{
                var operates=JSON.parse(this.getOperate())||[];
                operates.push(operate);
                localStorage.setItem('operate',JSON.stringify(operates))
            }
        }
    }

});
