personui
    .factory('publicFun',['$location','homePath','personStorage',
        function ($location,homePath,personStorage) {
        var openId = personStorage.getOpenId();
        return {
            getParam: function (option) {

                if(decodeURIComponent(option).split('?').length>1) {
                    var arr = decodeURIComponent(option).split('?')[1].split("&");

                    var jsonObj = {};
                    for (var i = 0; i < arr.length; i++) {
                        var arrStr = arr[i].toString().split('=');
                        if (arrStr) {
                            var k = arrStr[0];
                            var val = arrStr[1];
                            jsonObj[k] = val;
                        }
                    }
                    return jsonObj;
                }else {
                    return decodeURIComponent(option).split('?')[0]
                }
            },

            layerMsg:function (content) { //提示框显示
                layer.open({
                    type:0,
                    content: content+'<div><img onClick="layer.closeAll()" style="width:60%;margin-top:30px;margin-bottom:-30px" src="images/primaryActiveSuccessBtn.png"/></div>'
                    ,style: 'background-color: #fff;color: #333;Border-radius: 15px;border: none;width: 80%;background-image: url(images/primaryActiveSuccess.png);background-size: 100%;background-repeat: no-repeat;padding-top: 30px;font-size:18px;    overflow-wrap: break-word;' //自定风格
                });
            },
            layerMsgYj:function (content) { //提示框显示
                layer.open({
                    type:0,
                    content: content+'<div><img onClick="layer.closeAll()" style="width:60%;margin-top:30px;margin-bottom:-30px" src="images/primaryActiveSuccessBtn.png"/></div>'
                    ,style: 'background-color: #fff;color: #333;Border-radius: 15px;border: none;width: 80%;background-image: url(images/primaryActiveSuccess.png);background-size: 100%;background-repeat: no-repeat;padding-top: 30px;font-size:18px;    overflow-wrap: break-word;' //自定风格
                ,yes: function(index, layero){
                        window.location.reload();
                        layer.close(index); //如果设定了yes回调，需进行手工关闭
                    }
                });
            },
            //验证11位手机号码
            verifyPhone : function(phoneNum){
                var reg = /^1[0-9]{10}$/;
                var flag = reg.test(phoneNum);
                return flag;
            },
            //数字校验
            verifyNum : function (num) {
                var patrn = /(^[0-9]{13}$)|(^[0-9]{11}$)/;
                var flag =patrn.test(num);
                return flag;
            },
            verifyIccid : function (num) {
                if (num == null || num ===''){
                    return true
                }
                var partn = /^[0-9A-Za-z]{20}$/;
                var flag = partn.test(num);
                return flag;
            },
            //输入别名校验 num 设置
            checkLength : function(str,num) {
                if(!str){
                    str='';
                }
                var reg = /^[\u4e00-\u9fa5a-z\d_]{0,}$/gi;
                if (reg.test(str)) {
                    var len = str.replace(/[^\x00-\xff]/g,"aa").length;
                    if ( len <= num) {
                        return true;
                    }
                    return false;
                }
                return false;
            },
            //是否需要执行单点登录
            checkSignOn : function () {
                personStorage.removeSessionItem();
                window.location.href = homePath + '/service/wx/person/login?' + 'openId=' + openId + '&msgId=3';
            },
            //手机号脱敏
            desensitizePhone : function (str) {
                if(!str){
                    return '';
                }
                var str =str+'';
                var pat=/(\d{3})\d*(\d{4})/;
                var phoneNum =str.replace(pat,'$1****$2');
                return phoneNum
            },
            //姓名脱敏
            desensitizeName : function (items) {
                if(!items){
                    return '';
                }
                if (items.length == 3) {
                    return  items.substr(0,1)+'**';
                }
                if (items.length > 3) {
                    var surname = "";
                    for (var i = 0; i < items.length - 2; i++) {
                        surname = surname + "*";
                    }
                    return items.substr(0, 2)+ surname;
                }
                return items.substr(0,1)+'*';
            },
            //单位换算
            bytesToSize: function (bytes) {
                if (Number(bytes) === 0) {return '0 MB'}
                var k = 1024,
                    sizes = [ 'MB', 'G'],
                    i = Math.floor(Math.log(bytes) / Math.log(k));
                i=i<=0?0:i;
                if(Number(i)===0){
                    return bytes +sizes[0];
                }
                return Math.floor((bytes / Math.pow(k, i))*100)/100 + ' ' + sizes[1];
            },
            //安卓设备
            androidDevice:function () {
                var u = navigator.userAgent;
                var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Linux') > -1; //android终端或者uc浏览器

                return isAndroid;
            },
            //IOS设备
            iosDevice:function () {
                var u = navigator.userAgent;
                var isIOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
                return isIOS;
            },

            /**
             * 根据code 返回对应的信息
             * @param code 错误值
             */
            errCodeMsg:function (code) {
                var hasCode = false;
                var arrCodeObj = [{"code":'0',"msg":"成功"},
                    {"code":'001',"msg":"系统繁忙，请稍后再试！"},
                    {"code":'002',"msg":"数据库操作出错！"},
                    {"code":'004',"msg":"用户名或密码错误！"},
                    {"code":'005',"msg":"请求被网关拦截"},
                    {"code":'007',"msg":"获取卡归属异常"},
                    {"code":'009',"msg":"服务不可用"},
                    {"code":'011',"msg":"缺少请求参数"},
                    {"code":'013',"msg":"访问次数受限，请稍候再试"},
                    {"code":'014',"msg":"未找到该物联卡信息"},
                    {"code":'021',"msg":"已实名登记信息与本账号不一致"},
                    {"code":'034',"msg":"当日实名认证次数超过限制，请明日再试"},
                    {"code":'036',"msg":"该物联卡已销户，无法绑定"},
                    {"code":'037',"msg":"物联卡号不存在"},
                    {"code":"041","msg":"卡激活失败,当前卡状态不支持激活"},
                    {"code":"042","msg":"卡激活失败,系统错误！"},
                    {"code":'401',"msg":"缺少必要的参数！"},
                    {"code":'402',"msg":"物联卡号与ICCID不匹配，请检查后修改"},
                    {"code":'403',"msg":"系统错误！"},
                    {"code":'404',"msg":"物联卡未进行实名登记"},
                    {"code":'405',"msg":"当前卡无个人账户！"},
                    {"code":'406',"msg":"物联卡未激活"},
                    {"code":'407',"msg":"用户没有操作该物联卡的权限！"},
                    {"code":'408',"msg":"未做任何修改！"},
                    {"code":'409',"msg":"该卡已经被绑定，不可重复绑定！"},
                    {"code":'410',"msg":"充值金额不合法！"},
                    {"code":'411',"msg":"充值缴费验证失败！"},
					{"code":'413',"msg":"请联系上级物联卡经销商！"},
                    {"code":'420',"msg":"该卡已实名登记，无需重复实名登记"},
                    {"code":'421',"msg":"该卡已被他人实名登记"},
                    {"code":'422',"msg":"人证对比不一致"},
                    {"code":'441',"msg":"手机号码位数错误！"},
                    {"code":'442',"msg":"身份证号码位数错误！"},
                    {"code":'443',"msg":"实名认证用户信息变更失败！"},
                    {"code":'434',"msg":"登记信息入库失败！"},
                    {"code":'431',"msg":"输入身份证信息和身份证图片不一致"},
                    {"code":'432',"msg":"图片有误，请重新拍摄"},
                    {"code":'433',"msg":"后台获取图片失败！"},
                    {"code":'3001',"msg":"当前业务系统繁忙，请稍后再试！"},
                    {"code":'3002',"msg":"当前业务系统繁忙，请稍后再试！"},
                    {"code":'5005',"msg":"物联卡卡号/ICCID错误或不存在，请确认后重试！"},
                    {"code":'5007',"msg":"当前业务系统繁忙，请稍后再试！"},
                    {"code":'2009',"msg":"当前业务系统繁忙，请稍后再试！"},
                    {"code":'2008',"msg":"当前业务系统繁忙，请稍后再试！"},
                    {"code":'-99',"msg":"当前业务系统繁忙，请稍后再试！"},
                    {"code":'99',"msg":"当前业务系统繁忙，请稍后再试！"},
                    {"code":'4013',"msg":"当前业务系统繁忙，请稍后再试！"},
                    {"code":'4014',"msg":"同一物联卡15分钟内不可重复发起活体认证，请稍后再试！"},
                    {"code":'1999',"msg":"CMIOT开户卡暂未开放绑定！"},
                    {"code":'12021',"msg":"凭证过期，请通过'意见反馈'反馈问题发生时间及卡号，我们将尽快处理，给您带来的不便请谅解！"},
                    {"code":'19999',"msg":"系统错误，请通过'意见反馈'反馈问题发生时间及卡号，我们将尽快处理，给您带来的不便请谅解！"},
                    {"code":'11011',"msg":"物联卡号或ICCID错误，请检查后重试"},
                    {"code":'999',"msg":"该省系统正在升级，暂不支持充值服务"}
                ];
              for(var i =0;i<arrCodeObj.length;i++){
                  if(code===arrCodeObj[i].code){
                      this.layerMsg(arrCodeObj[i].msg);
                      hasCode = true;
                      break;
                  }
              }
              if(!hasCode){
                  this.layerMsg(code);
              }
            },
           HandleStatus : function(status){
                var billImgName='';
                switch (status) {
                    case "00":
                        billImgName = "lifePb_normal";
                        break;
                    case "01":
                        billImgName = "lifePb_singleStop";
                        break;
                    case "02":
                        billImgName = "lifePb_downTime";
                        break;
                    case "03":
                        billImgName = "lifePb_scheduleRemoveAccount";
                        break;
                    case "04":
                        billImgName = "lifePb_removeAccount";
                        break;
                    case "05":
                        billImgName = "lifePb_transferAccount";
                        break;
                    case "06":
                        billImgName = "lifePb_dormancy";
                        break;
                    case "07":
                        billImgName = "lifePb_waitActive";
                        break;
                    case "99":
                        billImgName = "lifePb_nullAccount";
                        break;
                    case "1":
                        billImgName = "lifePb_waitActive";
                        break;
                    case "2":
                        billImgName = "lifeCt_activing";
                        break;
                    case "4":
                        billImgName = "lifePb_downTime";
                        break;
                    case "6":
                        billImgName = "lifeCt_test";
                        break;
                    case "7":
                        billImgName = "lifeCt_Stock";
                        break;
                    case "8":
                        billImgName = "lifePb_scheduleRemoveAccount";
                        break;
                }
                return billImgName;
            },
            //解决微信安卓内核跳转页面时清除sessionStorage问题
            copySessionToLocalStorage:function(){
                var sessionCache={};
                for(var key in sessionStorage){
                    sessionCache[key]=sessionStorage[key];
                }
                localStorage['sessionCache']=JSON.stringify(sessionCache)
            },
            parseSessionStorge:function(){
                var sessionCache=JSON.parse(localStorage['sessionCache']||null)||{};
                for(var key in sessionCache){
                    sessionStorage[key]=sessionCache[key];
                }
                localStorage['sessionCache']=null
            }
        }
    }]);
