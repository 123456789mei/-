/**
 * Created by hp-01 on 2017/9/20.
 * author: Gao sir;
 * dis: HTTP请求公有方法;
 *
 * @rewrite: lixiangcheng
 * @date: 2019-01-09
 * @dis: 根据移动端需求进行修改
 */

personui.factory('httpService', ['$http', '$q', '$filter', 'homePath', 'personStorage', 'mockConfig', 'publicFun',
    function($http, $q, $filter, homePath, personStorage, mockConfig, publicFun) {
        var _countall = 0;
        var _count = 0;
        var _showloading = false;
        var _iscount = true;
        var _defer = [];
        var _doError = true;
        var arrCodeObj = ['0', '001', '002', '003', '004', '005', '006', '007', '008', '009', '011', '013',
            '021', '014', '401', '402', '403', '404', '405', '406', '407', '408', '409', '410', '411', '413',
            '420', '421', '422', '441', '442', '443', '201', '041', '042', '034', '036', '037', '431', '432',
            '433', '434','020','030','031','032','033','035', '038','039','430','012','3001','5005','5007','2008','2009',
            '-99','99','4013','4014','1999','3002','19999','12021','11011','10001','999'
        ];

        var MergeArray = function(arr1, arr2) {
            var _arr = new Array();
            for (var i = 0; i < arr1.length; i++) {
                _arr.push(arr1[i]);
            }
            for (var i = 0; i < arr2.length; i++) {
                var flag = true;
                for (var j = 0; j < arr1.length; j++) {
                    if (arr2[i] == arr1[j]) {
                        flag = false;
                        break;
                    }
                }
                if (flag) {
                    _arr.push(arr2[i]);
                }
            }
            return _arr;
        };

        return {

            /**
             * POST方式取数据  doPost
             *
             * @param {string} ajax请求url路径, 必传;
             * @param {object} ajax请求向服务器发送的数据, 必传;
             * @param {object}
             *     object.type => <string>：设置请求方式，默认post, 可选；
             *     object.contentType => <string>：header头信息，默认json, 可选；
             *     object.isLoad => <string>：是否显示加载层效果('true'/'false')，默认true，可选;
             *     object.arrCode => <array>：需要将部分错误码返回，默认[]，可选;
             *     object.doError => ('true/false') 默认 'true',是否需要使用默认的错误提示
             */
            getData: function(url, datas, options) {
                if (url === '' || url == null) {
                    console.error('必须有请求地址');
                    return false;
                }
                // url='/'+url.split('/').slice(3).join('/')
                /*****************************httpMock配置*************************************/
                var mockData = mockConfig.getMockDataPath(url);
                /*****************************httpMock配置*************************************/
                url = homePath + url;
                if (options && typeof options !== 'object') {
                    console.error('配置参数必须是对象');
                    return false;
                }

                //清除ie缓存机制
                datas = this.interceptor(datas);

                //是否使用默认的提示
                var _doError = (options && options.doError) || true;
                if (_doError === 'false') {
                    _doError = false;
                } else if (_doError === 'true') {
                    _doError = true;
                }

                //是否显示加载层
                var _isLoad = (options && options.isLoad) || true;
                if (_isLoad === 'false') {
                    _isLoad = false;
                } else if (_isLoad === 'true') {
                    _isLoad = true;
                }
                //需要要返回的错误码
                var _arrCode = (options && options.arrCode) || [];

                //将预置的数组与传入数组合并生成新的错误码数组
                _arrCode = MergeArray(_arrCode, arrCodeObj);
                //请求类型
                var _type = ((options && options.type) || 'POST').toUpperCase();
                //主求头文件类型
                var contentType_ = (options && options.contentType) || "application/json;charset=utf-8";

                var headers_ = {
                    "Content-Type": contentType_,
                    "platKey": "weChat",
                    "phone": personStorage.getPhone(),
                    "userId": personStorage.getUserId(),
                    //测试
                    // "userId": "530706964512907264",
                    "openId": personStorage.getOpenId()
                };

                var d = $q.defer();
                _defer.push(d); //加入到数组中；
                var that_ = this;

                //请求数据
                if (_isLoad) this.showLoading((options && options.elementId) || null);
                if (_isLoad) _countall++; // 计算量
                _iscount = true;
                if (window.debugFlag == true && mockData) {
                    _type = "GET";
                    url = mockData;
                }

                this.httpType(url, datas, headers_, _type, d).then(
                    function(resp) {
                        if (_isLoad) _count++;
                        if (_isLoad) that_.hideLoading();
                        if (resp && resp.data) {
                            if (resp.data.code === '0' || resp.data.length) {
                                d.resolve(resp.data);
                            } else {

                                // 如果是特殊的code直接返回登录页
                                if (resp.data.code === '087') {
                                    publicFun.checkSignOn();
                                    d.resolve(null);
                                    return;
                                }
                                //如果存在并需要将部分错误码返回作其它操作
                                if (_arrCode && _arrCode.length > 0) {
                                    if (_arrCode.indexOf(resp.data.code) !== -1) {
                                        d.resolve(resp.data);
                                    } else {
                                        //没有要返回的错误码，直接进行弹出显示
                                        if (_doError) that_.showCoder(resp.data);
                                        d.resolve(null);
                                    }
                                } else {
                                    //没有要返回的错误码，直接进行弹出显示
                                    if (_doError) that_.showCoder(resp.data);
                                    d.resolve(null);
                                }
                            }
                        } else {
                            if(resp){
                                d.resolve(resp)
                            }else{
                                d.resolve(null);
                            }
                        }
                    },
                    function(err) {
                        if (_isLoad && _iscount) _count++;
                        layer.closeAll();
                        if (_doError) that_.errorMsg(err);
                        d.resolve(null);
                    }
                );
                return d.promise;
            },
            httpType: function(url, datas, headers_, _type, d) {
                if (_type === 'POST') {
                    return $http({
                        url: url,
                        method: "POST",
                        timeout: d.promise,
                        data: headers_["Content-Type"].indexOf("json") ? JSON.stringify(datas) : datas,
                        headers: headers_
                    });
                } else {
                    return $http({
                        url: url,
                        method: "GET",
                        timeout: d.promise,
                        params: datas || '',
                        headers: headers_
                    });
                }
            },
            showLoading: function(eleId) {
                if (!_showloading) {
                    //layer
                    layer.open({ type: 2, shadeClose: false });
                    _showloading = true;
                }
            },
            showCoder: function(code) {
                layer.open({
                    content: code,
                    skin: 'msg',
                    time: 3
                });
                return false;
            },
            errorMsg: function(err) {
                this.hideLoading();
                if (err && err !== '') {
                    layer.open({
                        content: '本次操作业务受理失败，失败原因：' + err,
                        btn: '我知道了'
                    });
                }
                return false;
            },
            hideLoading: function(arg) {
                //计算统计
                if (!arg) {
                    if (_countall === _count) {
                        _countall = _count = 0;
                        _showloading = false;
                        layer.closeAll();
                    }
                }
            },
            interceptor: function(datas) {
                datas = datas || {};
                datas._timestamp = new Date().getTime();
                return datas;
            }

        };
    }
]);
