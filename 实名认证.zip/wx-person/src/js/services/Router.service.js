/**
* @author：lixiangcheng
* @date 2019-02-01
* 框架路由服务用于页面跳转和回退
* 支持页面间传值
**/
personui.service("Router",['$rootScope',function($rootScope){
	//页面传值的缓存对象，不建议一次传值使用多次易发生变量污染
	this.bundle = null;
	this.path_prefix = "#!";
	this.base_z_index = 10;

	this.copyData =function(result,base){
		for(var i=0;i<base.length;i++){
			result[i] = base[i];
		}
    }
    
    //处理手机回退键遮罩层
    $rootScope.$on('$locationChangeStart', function(e){
        if(document.querySelector('.layui-m-layermain')&&!document.querySelector('.layui-m-layerload')){
            layer.closeAll();
            e.preventDefault();
        }
    });

	/**
	*页面跳转方法，例：go('/home',{name:'123'})
	*参数说明：
	*
	*path 定义在路由上的页面路径
	*data 向下级页面传值的对象JSON 其他页面可通过getBundle方法获取
	**/
	this.go = function (path,data) {
		if(data) this.bundle = data;
		path = this.path_prefix + path;
		$rootScope.enterPath = path;
		$rootScope.leavePath = this.getTopPath();
		$rootScope.topPage_Z_index = this.base_z_index + $rootScope.pathHistory.length;
		location.hash = path;
	}

	/**
	* 外部可使用方法，返回几个页面
	**/
	this.back = function(num) {
		if(!num) num = 1;
		$rootScope.leavePath = this.getTopPath();
		$rootScope.topPage_Z_index = this.base_z_index + $rootScope.pathHistory.length;
		$rootScope.enterPath = this.getBackPath(num);
		location.hash = this.getBackPath(num);
	}

	this.pushPath =function(currentPath) {
		$rootScope.pathHistoryPre = [];
		this.copyData($rootScope.pathHistoryPre,$rootScope.pathHistory);
		if(currentPath){
			$rootScope.pathHistory.push(currentPath);
		}
	}

	this.popPath = function(num){
		num = num >= $rootScope.pathHistory.length? $rootScope.pathHistory.length :num;
		$rootScope.pathHistoryPre = [];
		this.copyData($rootScope.pathHistoryPre,$rootScope.pathHistory);
		for(var i=0;i<num;i++){
			$rootScope.pathHistory.pop();
		}
	}


	/**
	* 外部可使用方法，跳转回固定的页面
	**/
	this.popToPage = function(Path){
		if($rootScope.pathHistory.indexOf("#!"+Path) != -1){
			//路由历史中存在
			var index = $rootScope.pathHistory.indexOf("#!"+Path);
			var num = $rootScope.pathHistory.length - (index + 1);
			this.back(num);
		}
	}

	this.getBundle = function(){
		return this.bundle;
	}

	this.resetPath = function(){
		$rootScope.pathHistory.splice(0,ary.length);
	}

	this.getTopPath = function(){
		return $rootScope.pathHistory[$rootScope.pathHistory.length -1];
	}
	this.getBackPath = function(num){
		return $rootScope.pathHistory[$rootScope.pathHistory.length - 1 -num];
	}
}]);