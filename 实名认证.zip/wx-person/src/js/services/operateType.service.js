personui.factory('personOperateType',function(){
   return {
    	msisdn_info:'MSISDN_INFO_HIT_NUMBER', //物联卡信息
    	product_info:'PRODUCT_INFO_HIT_NUMBER',//套餐信息点击量
    	user_quantity:'USE_QUANTITY_HIT_NUMBER',//用量点击量
    	recharge:'RECHARGE_HIT_NUMBER',//充值点击量
    	real_name:'REAL_NAME_VERIFICATION_HIT_NUMBER',//实名认证点击量
    	bind_msisdn:'BIND_MSISDN_HIT_NUMBER',//绑定物理卡点击量
    	unbind_msisdn:'UNBIND_MSISDN_HIT_NUMBER',//解绑物联卡点击量
    	update_alias:'UPDATE_ALIAS_HIT_NUMB',//修改别名点击量
    	log_out:'LOG_OUT_HIT_NUMBER',//退出登陆点击量
    	log_off:'LOG_OFF_HIT_NUMBER',//注销账号点击量
   } 
})