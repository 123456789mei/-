personui.controller('authResultController', ['$scope','Router','personStorage','personOperateType','httpService','publicFun',
    function ($scope,Router,personStorage,personOperateType,httpService,publicFun) {
        var params=window.location.href.split('?')[1]||'';
        params.split('&').forEach(function(param){
            var entriy=param.split('=');
            $scope[entriy[0]]=decodeURIComponent(entriy[1])
        });
        $scope.goBack = function () {
            Router.back();
        };

        !sessionStorage.length&&publicFun.parseSessionStorge();
        //重新刷新认证信息
        sessionStorage.removeItem('verifiedStatus');

        $scope.reauth=function(){
            personStorage.setOperate({
                hitTime:Date.now(),
                businessHitType:personOperateType.real_name,
                msisdn:null 
            });
            httpService
                .getData('/service/wx/person/api/getRealNameAuthURL',{userId:personStorage.getUserId()}, {type: 'POST'})
                .then(function (resp) {
                    if (resp && resp.code==0) {
                        $scope.realName = resp.data;
                        publicFun.copySessionToLocalStorage()
                        window.location.href = $scope.realName;
                    }else{
                        publicFun.errCodeMsg(resp.code);
                    }
                });
        }
    }]);