personui.controller('cardRegisterController', ['$scope', 'httpService','personStorage','$location','Router','publicFun','homePath',
    function ($scope, httpService,personStorage,$location,Router,publicFun,homePath) {
        $scope.msisdn = '';
        $scope.iccid = '';

        $scope.goBack = function () {
            Router.back();
        };
        // 检查是否授权
        $scope.checkVerify = function () {
            var data = {
                msisdn: $scope.msisdn,
                userId: personStorage.getUserId()
            };
            httpService.getData("/service/wx/person/api/queryBbcStatus", data, {type: 'POST',doError:'false'})
                .then(function (resp) {
                    if (resp) {
                        if (resp.code === '0') {
                            var params = {
                                custId:resp.data.custId,
                                beId:resp.data.beId,
                                flag:resp.data.flag,
                                isActive:'',
                                status:resp.data.status
                            }
                            if (resp.data.flag === "0") {
                                // 已授权 && 卡状态为库存
                                if(resp.data.status === '1' || resp.data.status === '6' || resp.data.status === '7'){
                                    var statusDict = {
                                        1:'待激活',
                                        6:'可测试',
                                        7:'库存'
                                    }
                                    var content = '物联卡为' + statusDict[resp.data.status] +'状态,是否激活?'
                                    //弹窗是否激活
                                    layer.open({
                                        content: content,
                                        btn: ['激活','取消'],
                                        yes: function(index){
                                            //后续激活
                                            params.isActive = '0'
                                            $scope.toVerify(params)
                                            layer.close(index);
                                        },
                                        no: function(index){
                                            //后续不激活
                                            params.isActive = '1'
                                            $scope.toVerify(params)
                                            layer.close(index);
                                        }
                                    });
                                }else{
                                    $scope.toVerify(params)
                                }
                            } else {
                                $scope.toVerify(params)
                            }
                        } else {
                            if(resp.code === '88'){
                                publicFun.layerMsg(resp.data);
                            }else {
                                publicFun.errCodeMsg(resp.code)
                            }
                        }
                    }
                })
        };
        // 活体认证
        $scope.toVerify = function (params) {
            var data = {
                msisdn: $scope.msisdn,
                iccid: $scope.iccid,
                userId: personStorage.getUserId(),
                phone:  personStorage.getPhone(),
                isActive:params.isActive,
                custId:params.custId,
                beId:params.beId,
                flag:params.flag,
                status:params.status
            };
            httpService.getData("/service/wx/person/api/startCtRegister", data, {type: 'POST',doError:'false'})
                .then(function (resp) {
                    console.log('判断返回值'+resp);
                    if (resp) {
                        if (resp.code === '0') {
                            location.href = resp.data;
                        } else if (resp.code === '88' &&resp.data) {
                            publicFun.layerMsg("当前业务系统繁忙，请稍后再试！");
                        }else {
                            publicFun.errCodeMsg(resp.code);
                        }
                    }
                    console.log('返回值为null'+resp);
                });
        };

        $scope.nextStep = function () {
            if ($scope.msisdn ==='' && $scope.iccid === ''){
                publicFun.layerMsg("请输入物联卡号和ICCID");
                return;
            }
            if ($scope.msisdn ===''){
                publicFun.layerMsg("请输入物联卡号");
                return;
            }
            if ($scope.iccid ===''){
                publicFun.layerMsg("请输入ICCID");
                return;
            }
            var msisdnIsNum = publicFun.verifyNum($scope.msisdn);
            var iccidIsNum = publicFun.verifyIccid($scope.iccid);
            if(!msisdnIsNum || !iccidIsNum){
                return  publicFun.layerMsg("请检查物联卡号或ICCID是否输入正确")
            }

            var data = {
                msisdn: $scope.msisdn,
                iccid: $scope.iccid
            };

            httpService.getData("/service/wx/person/api/checkMsisdnIccid", data, {type: 'POST',doError:'false'})
                .then(function (resp) {
                    if (resp) {
                        if (resp.code === '0'){
                            // if(resp.data.cardBelong == "01" && resp.data.status == "4"){
                            //     publicFun.layerMsg("卡处于停机状态，请前往附近营业厅处理后再进行实名！");
                            // }else if(resp.data.cardBelong == "01" && resp.data.status == "8"){
                            //     publicFun.layerMsg("卡处于预销户状态，请前往附近营业厅处理后再进行实名！");
                            // }else
                            // if (resp.data.cardBelong == "01" && resp.data.managerClose == "1") {
                            //     publicFun.layerMsg("卡处于管理停机状态，请前往附近营业厅处理后再进行实名！");
                            // }else
                                if ((resp.data.beId == '551' || resp.data.beId == '100' || resp.data.beId == '371' || resp.data.beId == '220'|| resp.data.beId == '210'|| resp.data.beId == '250'|| resp.data.beId == '898') && resp.data.cardBelong == "00") {
                                $scope.checkAUth(resp.data);
                            } else if (resp.data.cardBelong == "00") {
                                publicFun.layerMsg("PBOSS开户物联卡，暂未开放线上登记渠道");
                            } else if (resp.data.isRealNameRegisted === "00") {
                                //已实名登记
                                publicFun.layerMsg("该卡已实名登记");
                            } else if (resp.data.isRealNameRegisted === "02") {
                                publicFun.layerMsg("卡已绑定，无法进行实名登记！");
                            } else {
                                if(resp.data.control == "1"){
                                    publicFun.layerMsg("实名认证系统维护中，给您带来的不便敬请谅解");
                                }else {
                                    $scope.checkVerify();
                                }
                            }
                        }else {
                            publicFun.errCodeMsg(resp.code)
                        }
                    }
                });
        }
        $scope.checkAUth = function (dataObj) {
            dataObj.msisdn = $scope.msisdn;
            dataObj.iccid = $scope.iccid;
            var data = {
                msisdn:$scope.msisdn,
                beId:dataObj.beId,
                iccid:$scope.iccid
            }
            httpService.getData('/service/wx/person/api/checkMsisdnFlow', data, {
                type: 'POST',
                doError: 'false'
            }).then(function(resp) {
                if (resp) {
                    if(resp.code === '0' && resp.data && dataObj.beId == '210'){
                        location.href = resp.data;
                    }else if (resp.code === '0' && resp.data) {
                        if(resp.data.isAuth == '0'){
                            publicFun.layerMsg("卡号已实名");
                            return;
                        }else if(resp.data.isAuth == '1'){//未实名且需要实名
                            if(resp.data.needAuth == '0'){
                                Router.go('/checkIdCard',dataObj);
                            }else{
                                publicFun.layerMsg("卡号无需实名");
                                return;
                            }
                        }else if(resp.data.isAuth == null){
                            publicFun.layerMsg("卡号实名认证未开放");
                        }
                    }else if(resp.code === '4014'){
                        publicFun.layerMsg("同一物联卡15分钟内不可重复发起活体认证，请稍后再试！");
                    }else if(resp.code === '10001'){
                        publicFun.layerMsg("省侧接口异常！");
                    }else if(resp.code === '99'){
                        publicFun.layerMsg("后台调用异常！");
                    }else {
                        publicFun.layerMsg("卡号实名认证未开放");
                        return;
                    }
                }else {
                    Router.go('/error');
                }
            });
        }

    }]);
