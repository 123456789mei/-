personui
    .controller('itemTypeChooeseController', ['$scope', 'httpService', 'personStorage', '$location', 'Router', 'publicFun', 'homePath',
        function ($scope, httpService, personStorage, $location, Router, publicFun, homePath) {
            $scope.saveBusinessHitLog = function () {
                var operates = JSON.parse(personStorage.getOperate());
                var params = {
                    userId: personStorage.getUserId(),
                    plat: '00',
                    list: operates || []
                }
                operates && httpService.getData('/service/wx/person/api/saveBusinessHitLog', params, {
                    type: "POST",
                    isLoad: false,
                    doError: false
                }).then(function (resp) {
                        if (resp && resp.code == 0) {
                            sessionStorage.setItem('fristLogin',false);
                            personStorage.setOperate(null);
                        }
                    });
            }
            $scope.homepath = homePath;
            $scope.openId = personStorage.getOpenId();
            $scope.verifiedData = {};
            //获取跳转url中参数值
            $scope.indexParm = publicFun.getParam($location.url()); //参数中有票据码
            //获取初始参数
            $scope.getInitParm = function () {
                //如果页面刷新则不去访问票据号接口
                if (personStorage.getOpenId() && personStorage.getUserId() && personStorage.getPhone()) {
                    $scope.validateHttp();
                    $scope.privacyisshow();
                    //第一次进入系统，检查用户操作是否同步到后台
                    if (sessionStorage.getItem('fristLogin') !== 'false') {
                        $scope.saveBusinessHitLog()
                    }
                } else {
                    $scope.initData = {};
                    $scope.initData.ticket = $scope.indexParm.ticket;
                    httpService
                        .getData('/service/wx/person/api/getBaseInfo', $scope.initData)
                        .then(function (resp) {
                            if (resp) {
                                if (resp.code === '99') {
                                    publicFun.layerMsg("登录凭证过期，请关闭页面重新进入");
                                }
                                if (resp.data) {
                                    personStorage.setPhone(resp.data.phone);
                                    personStorage.setUserId(resp.data.userId);
                                    personStorage.setOpenId(resp.data.openId);
                                    $scope.validateHttp();
                                    $scope.privacyisshow();
                                    if (sessionStorage.getItem('fristLogin') !== 'false') {
                                        $scope.saveBusinessHitLog()
                                    }
                                }
                            } else {
                                Router.go('/error');
                            }
                        });
                }

            };
            $scope.cancel = function () {
                //用户手动取消，本次使用不再提示
                $scope.modal_invalid = false;
                sessionStorage.setItem("accountAuthTip","true");
            };
            //判断是否认证
            $scope.validateHttp = function () {
                var verifiedStatus = personStorage.getVerifiedStatus();
                if (verifiedStatus) {
                    $scope.isShowName = verifiedStatus === '01'||verifiedStatus === '10' ? true : false;
                    if (verifiedStatus === '10' && !sessionStorage.getItem("accountAuthTip")) {
                        $scope.modal_invalid = true;
                    }
                } else {
                    httpService
                        .getData('/service/wx/person/api/getVerifiedStatus', {})
                        .then(function (resp) {
                            if (resp) {
                                if (resp.data && resp.data.status) {
                                    if (resp.data.status === '01') {
                                        personStorage.setName(resp.data.name);
                                        //已经通过认证
                                    } else if (resp.data.status === '10' && !sessionStorage.getItem("accountAuthTip")) {
                                        //身份证过期，需重新认证
                                        $scope.modal_invalid = true;
                                        personStorage.setName(resp.data.name); //重新认证提示
                                    } else if (resp.data.status === '00') {
                                        personStorage.setName('');//显示未认证
                                    }
                                    personStorage.setVerifiedStatus(resp.data.status);//存入状态码
                                    if (resp.data.status === '01' || resp.data.status === '10') {
                                        $scope.isShowName = true;
                                        $scope.name = publicFun.desensitizeName(resp.data.name);
                                    } else {
                                        $scope.isShowName = false;
                                    }

                                }
                            } else {
                                Router.go('/error');
                            }
                        });
                }
                /*手机号、姓名脱敏*/
                $scope.phoneNum = publicFun.desensitizePhone(personStorage.getPhone());
                $scope.name = publicFun.desensitizeName(personStorage.getName());
            };
            //隐私协议是否展示
            $scope.privacyisshow = function(){
                httpService
                    .getData('/service/wx/person/api/queryProtocolInfo', {'phone':personStorage.getPhone()})
                    .then(function (resp) {
                        if (resp) {
                            if (resp.data && resp.data.flag) {
                                if (resp.data.flag === '0') {
                                    $scope.privacyTip = true;
                                } else if(resp.data.flag === '1') {
                                    $scope.privacyTip = false;
                                }else{
                                    layer.open({
                                        skin: "msg",
                                        content: '系统错误,请关闭页面重新进入',
                                        time:2
                                    });
                                }
                            }else{
                                layer.open({
                                    skin: "msg",
                                    content: resp.errParams[0] || '系统错误,请关闭页面重新进入',
                                    time:2
                                });
                            }
                        } else {
                            Router.go('/error');
                        }
                    });
            };

            $scope.agree = function(){
                httpService
                    .getData('/service/wx/person/api/insertProtocolInfo', {'phone':personStorage.getPhone()})
                    .then(function (resp) {
                        if(resp){
                            if(resp.code == '0'){
                                $scope.privacyTip = false;
                            }else{
                                layer.open({
                                    skin: "msg",
                                    content: resp.errParams[0] || '系统错误,请关闭页面重新进入',
                                    time:2
                                });
                            }
                        }
                        else{
                            Router.go('/error');
                        }
                    });
            };
            $scope.unagree = function(){
                personStorage.removeSessionItem()
                window.location.href = $scope.homepath + '/service/wx/person/login?' + 'openId=' + $scope.openId + '&msgId=5';
            }
            $scope.goOutWx = function () {
                $scope.saveBusinessHitLog();
                wx.closeWindow();
            }
            $scope.toPersonCenterPage = function () {
                $scope.modal_invalid = false;
                Router.go("/personCenter");
            };
            $scope.toCardRegister = function () {
                //埋点统计
                console.log("埋点统计start...");
                var data={step:'one'};
                httpService.getData("/service/wx/person/api/innerStatis", data, {type: 'POST',doError:'false'})
                    .then(function (resp) {
                        if (resp) {
                            console.log("one success");
                        }
                    });
                // if(personStorage.getPhone().toString() === '15178855944'){
                    Router.go("/cardRegister");
                // }else{
                //     layer.open({
                //         skin: "msg",
                //         content: "因物联卡实名登记系统升级，暂停办理物联卡实名登记业务！",
                //         time: 5
                //     });
                // }
                // var timestamp = new Date().getTime();
                // if(timestamp <= 1609171200000){
                //     layer.open({
                //         skin: "msg",
                //         content: "因物联卡实名登记系统升级，12月25-12月28日暂停通过办理实名登记业务，29日可恢复正常办理！",
                //         time:2
                //     });
                //     return;
                // }
            };
            $scope.toCertificationIndex = function () {
                Router.go("/certificationIndex");
            };
            $scope.toCardRegisterIndex = function () {
                Router.go("/cardRegisterIndex");
            };
            $scope.toHelpCenterPage = function () {
                Router.go("/helpCenter");
            };
            $scope.toInDevelopment=function(title){
                Router.go('/development',{title:title})
            };
            $scope.toQuestionnaire=function(){
                window.location.href='https://www.wjx.cn/jq/41250202.aspx'
            }
            $scope.toOpinion=function(){
                Router.go("/opinion");
            }
        }]);
