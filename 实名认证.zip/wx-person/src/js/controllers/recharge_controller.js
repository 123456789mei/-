personui.controller('rechargeController',
    ['$scope','publicFun','$location','httpService','personStorage','Router',
        function($scope,publicFun,$location,httpService,personStorage,Router){

    var locatieParm = Router.getBundle();
    $scope.goBack =function () {
        Router.back();
    };

    $scope.cancel = function () {

    };
    //判断是否title是否与msisdn相同
    $scope.checkTitle=function(){
       $scope.showTitle =  locatieParm.title==locatieParm.msisdn?true:false;
    }
    $scope.isBtn=true;
    $scope.isInput=false;
    $scope.payMoney='';
    $scope.change= function (num) {
        $scope.payMoney = num;
        $scope.isBtn=true;
        $scope.isInput=false;
        $scope.payMoneyInput='';
        angular.element(document.getElementsByClassName('button-money')).removeClass("active")
        var ment = event.target;
        ment.classList.add("active");
    };
    $scope.myPayInput=function () {
        $scope.isBtn=false;
        angular.element(document.getElementsByClassName('button-money')).removeClass("active")
        // $scope.payMoneyInput= $scope.payMoneyInput.replace(/^[6-9]\d{3}|4[\d]{2}[1-9]|\D|^0/g,'')
        $scope.payMoneyInput= $scope.payMoneyInput.replace(/^0|[^0-9]+/g,'')
        if($scope.payMoneyInput>500){
            $scope.payMoneyInput='500';
        }
        $scope.payMoney=0;
        $scope.isInput=true;
    }

    $scope.cardBelong = locatieParm.cardBelong;
    $scope.msisdn = locatieParm.msisdn;
    $scope.iccid = locatieParm.iccid;
    $scope.remarkName = locatieParm.title;
    $scope.beId = locatieParm.beId;
    $scope.phone = personStorage.getPhone();
    $scope.userId = personStorage.getUserId();
    $scope.openId = personStorage.getOpenId();
    $scope.CTChargeUrl = "/service/wx/person/api/chargeOfCT";
    $scope.PBChargeUrl = "/service/wx/person/api/chargeOfPB";
    $scope.submFormPay = function () {
        if(!Number($scope.payMoneyInput)&&!$scope.payMoney){
            publicFun.layerMsg("请输入金额");
        }else {
            var url = $scope.cardBelong === "00" ? $scope.PBChargeUrl : $scope.CTChargeUrl;
            var bill =Number($scope.payMoneyInput)>0?Number($scope.payMoneyInput):$scope.payMoney;
            $scope.chargeData= {
                msisdn: $scope.msisdn,
                chargeMoney: String(bill),
                beId:$scope.beId,
                paymentType:"WEIXIN-JSAPI",
                channelId:"WX_OA",
                accountId : locatieParm.accountId,
                accountName : locatieParm.accountName
            };
            httpService
                .getData(url, $scope.chargeData, {type: 'POST'})
                .then(function (resp) {
                    if (resp) {
                        if (resp.code === '0' && resp.data) {
                           location.href = resp.data.url;
                        } else {
                            publicFun.errCodeMsg(resp.code);
                        }
                    } else{
                        Router.go('/error');
                    }
                });
        }

    }

}]);