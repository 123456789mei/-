personui
    .controller('cardInfoController', ['$scope', 'httpService', '$location', 'publicFun', 'personStorage', 'Router', 'personOperateType', '$timeout',
        function($scope, httpService, $location, publicFun, personStorage, Router, personOperateType, $timeout) {
            /*截取参数*/

            var indexParm = Router.getBundle();
            //解決刷新問題，將msidn 和 alias 存入session
            if (indexParm) {
                $scope.title = indexParm.title;
                $scope.msisdn = indexParm.msisdn;
                $scope.beId = indexParm.beId;
                $scope.cardBelong = indexParm.cardBelong;
                $scope.iccid = indexParm.iccid;
                $scope.balance = indexParm.balance;
                $scope.bindStatus = indexParm.bindStatus;
                personStorage.setTitle(indexParm.title);
                personStorage.setMsisdn(indexParm.msisdn);
                if (indexParm.beId) {
                    personStorage.setBeId(indexParm.beId); //特殊处理有坑 router.js 中bundle待修改
                }
            } else {
                $scope.title = personStorage.getTitle();
                $scope.msisdn = personStorage.getMsisdn();
                $scope.beId = personStorage.getBeId();
            }

            $scope.registerStatus='未实名';

            $scope.goBack = function() {
                Router.back();
            };
            //页面操作变量
            $scope.page = {
                focusIndex: '' //切换
            };

            /*物联卡信息*/
            $scope.cardInfo = {
                provinceId: "",
                msisdn: "",
                custId: '', //CT使用的客户ID    CT接口必传参数 custId beId
                openTime: "",
                provinceName: '',
                balance: "",
                iccid: "",
                imsi: "",
                imei: "",
                netStatus: "", //开停机状态
                billingStatus: "",
                chargeURL: "",
                beId: '',
                billImgStatusCh: "",
                billImgUrl: '',
                cardBelong: ""
            };
            /*查询物联卡信息*/
            $scope.searchCardInfo = function() {
                var cardData = {};
                $scope.recordOprate(0);
                cardData.msisdn = $scope.msisdn;
                cardData.beId = $scope.beId;
                cardData.custId = $scope.custId;
                cardData.cardBelong = $scope.cardBelong;
                cardData.iccid = $scope.iccid;
                cardData.balance = $scope.balance;
                cardData.bindStatus = $scope.bindStatus;
                $timeout(httpService.getData('/service/wx/person/api/getMsisdnInfo', cardData, { type: 'POST', doError: 'false' })
                    .then(function(resp) {

                        if (resp) {
                            if (resp.code === '0' && resp.data) {
                                $scope.isExistProvince = false; //判断是否存在
                                if (resp.data.provinceName) {
                                    $scope.isExistProvince = true;
                                }
                                if (resp.data.cardBelong === '00') {
                                    if (resp.data.status === '03' || resp.data.status === '04') {
                                        $scope.showIcon = 'unTopUp';
                                    } else {
                                        $scope.showIcon = 'topUp';
                                    }
                                }
                                if (resp.data.cardBelong === '01') {
                                    $scope.checkAccount();
                                }
                                if(resp.data.registerStatus == '1'){
                                    $scope.registerStatus='已实名';
                                }
                                //显示--列表页面
                                angular.extend($scope.cardInfo, $scope.handleLifeStatus(resp.data)); //extend 会顶替掉原有数据
                                $scope.searchUsageAmountInfo(); //查询用量信息
                            } else if (resp.code == '036') {
                                layer.open({
                                    type: 0,
                                    success: function(layero, index) {
                                        $(layero).find('.closeBtn').on('click', function() {
                                            layer.closeAll();
                                            Router.back();
                                        })
                                    },
                                    content: '<div>该卡已销户，无法查看卡详情，返回卡列表后会自动解绑</div><div><img class="closeBtn" style="width:60%;margin-top:30px;margin-bottom:-30px" src="images/primaryActiveSuccessBtn.png"/></div>',
                                    style: 'background-color: #fff;color: #333;Border-radius: 15px;border: none;width: 80%;background-image: url(images/primaryActiveSuccess.png);background-size: 100%;background-repeat: no-repeat;padding-top: 30px;font-size:18px;    overflow-wrap: break-word;' //自定风格
                                });
                            } else {
                                publicFun.errCodeMsg(resp.code);
                            }
                        } else {
                            Router.go('/error');
                        }
                    }), 0);
            };
            //检测CT卡是否是个人账户
            $scope.checkAccount = function() {
                httpService.getData('/service/wx/person/api/checkIndividualAccount', { 'msisdn': $scope.msisdn }, {
                    type: 'POST',
                    doError: 'false'
                }).then(function(resp) {
                    if (resp) {
                        if (resp.code === '0' && resp.data) {
                            $scope.cardInfo.isUserAccount = true; //判断是否是个人账户
                            $scope.cardInfo.accountId = resp.data.accountId;
                            $scope.cardInfo.accountName = resp.data.accountName;
                        } else {
                            $scope.cardInfo.isUserAccount = false;
                        }
                        //判断CT的卡显示充值的逻辑
                        if ($scope.cardInfo.status === '8' || $scope.cardInfo.isUserAccount === false) {
                            $scope.showIcon = 'unTopUp';
                        } else {
                            $scope.showIcon = 'topUp';
                        }
                    } else {
                        Router.go('/error');
                    }
                });
            };

            //获取生命周期的图
            $scope.handleLifeStatus = function(data) {
                data.statusCode = publicFun.HandleStatus(data.status);
                return data;
            };

            //用量信息
            $scope.usageAmountInfo = [];

            //换算
            $scope.handleFluxConversion = function(data) {
                if (!data) { //判断数据是否为空，null,undefined
                    return '0.0 MB';
                } else {
                    return data.replace(data, publicFun.bytesToSize(data));
                }
            };
            //处理用量数据格式化
            $scope.handleUsageAmountData = function(data) {
                for (var i = 0; i < data.length; i++) {
                    if ("02" === data[i].dataAmountType) { //流量
                        if (!data[i].dataAmount) {
                            data[i].dataAmount = "0.0 MB"
                        } else {
                            data[i].dataAmount = $scope.handleFluxConversion(data[i].dataAmount);
                        }
                        if (!data[i].setAmount) {
                            data[i].setAmount = "0.0 MB"
                        } else {
                            data[i].setAmount = $scope.handleFluxConversion(data[i].setAmount);
                        }
                        if (!data[i].dataTotal) {
                            data[i].dataTotal = "0.0 MB"
                        } else {
                            data[i].dataTotal = $scope.handleFluxConversion(data[i].dataTotal);
                        }
                    } else { //短信 与 (01短信\02流量\03语音),
                        if (!data[i].dataAmount) {
                            "01" === data[i].dataAmountType ? data[i].dataAmount = '0 条' : data[i].dataAmount = '0 分钟';
                        } else {
                            data[i].dataAmount = $scope.handleMsgAndVoiceConversion(data[i].dataAmount) + " " + data[i].valueUnit;
                        }
                        if (!data[i].setAmount) {
                            "01" === data[i].dataAmountType ? data[i].setAmount = '0 条' : data[i].setAmount = '0 分钟';
                        } else {
                            data[i].setAmount = $scope.handleMsgAndVoiceConversion(data[i].setAmount) + " " + data[i].valueUnit;
                        }
                        if (!data[i].dataTotal) {
                            "01" === data[i].dataAmountType ? data[i].dataTotal = '0 条' : data[i].dataTotal = '0 分钟';
                        } else {
                            data[i].dataTotal = $scope.handleMsgAndVoiceConversion(data[i].dataTotal) + " " + data[i].valueUnit;
                        }
                    }
                    //时间处理格式
                    if (data[i].startTime) {
                        data[i].startTime = data[i].startTime.slice(0, 4) + '-' + data[i].startTime.slice(4, 6) + '-' + data[i].startTime.slice(6)
                    }
                    if (data[i].endTime) {
                        data[i].endTime = data[i].endTime.slice(0, 4) + '-' + data[i].endTime.slice(4, 6) + '-' + data[i].endTime.slice(6)
                    }

                }
                return data;
            };
            //语音与短信的处理
            $scope.handleMsgAndVoiceConversion = function(data) {
                if (data) {
                    data = data + "";
                    if (data.indexOf(".") !== -1)
                        data = data.substring(0, data.indexOf("."));
                }
                return data;
            };
            // 是否过期
            $scope.invalidFun = function(endTime) {
                    if (endTime) {
                        var endTimeVal = new Date(endTime.replace(/-/g, "\/") + " 23:59:59");
                        var nowTimeVal = new Date();
                        if (endTimeVal > nowTimeVal) {
                            return false; //未过期
                        } else {
                            return true; //过期
                        }
                    } else {
                        return false;
                    }
                }
                // 默认为空图
            $scope.isShowEmptyPage = true;
            $scope.showEmptyPackagePage = true;
            /*查询用量信息*/
            $scope.searchUsageAmountInfo = function() {
                var packageData = {};
                //userId 与 phone 从session 里拿
                packageData.msisdn = $scope.cardInfo.msisdn;
                packageData.custId = $scope.cardInfo.custId; //CT
                packageData.cardBelong = $scope.cardInfo.cardBelong
                    //测试
                    // packageData = {
                    //     "custId": "99992017071319861214133",
                    //     "msisdn": "1440041471510"
                    // }
                httpService.getData('/service/wx/person/api/getSimFlowInfo', packageData, { type: 'POST', doError: 'false' })
                    .then(function(resp) {
                        if (resp) {
                            if (resp.code === '0') {
                                if (resp.data && resp.data.length && resp.data.length > 0) {
                                    $scope.isShowEmptySimFlowPage = false;
                                    //显示--列表页面cardRegister
                                    $scope.usageAmountInfo = $scope.handleUsageAmountData(resp.data);
                                    //增加逻辑如果查用量为空数组则不进行下部分调用
                                    if ($scope.usageAmountInfo.length > 0) {
                                        $scope.searchPackageInfo(); //套餐信息
                                        $scope.showEmptyPackagePage = false;
                                    } else {
                                        $scope.showEmptyPackagePage = true; //显示空图
                                    }
                                } else {
                                    $scope.isShowEmptySimFlowPage = true; //显示空图
                                }
                            } else {
                                publicFun.errCodeMsg(resp.code)
                            }
                        } else {
                            Router.go('/error');
                        }
                    });
            };
            /*物联卡套餐信息*/
            $scope.packageInfo = [];

            /*查询套餐信息*/
            $scope.searchPackageInfo = function() {

                var packageData = {};
                packageData.beid = $scope.cardInfo.provinceId; //从套餐信息内取
                packageData.prodInstIds = "";
                packageData.apnNames = [];
                packageData.cardBelong = $scope.cardInfo.cardBelong;
                for (var i = 0; i < $scope.usageAmountInfo.length; i++) {
                    packageData.prodInstIds += $scope.usageAmountInfo[i].prodInstID + ",";
                    if ($scope.cardInfo.cardBelong === '01') {
                        packageData.apnNames.push($scope.usageAmountInfo[i].apnName);
                    }

                }
                packageData.msisdn = $scope.msisdn;
                httpService.getData('/service/wx/person/api/getProductInfo', packageData, {
                    type: 'POST',
                    doError: 'false'
                }).then(function(resp) {
                    if (resp) {
                        if (resp.code === '0') {
                            if (resp.data && resp.data.length > 0) {
                                $scope.packageInfo = resp.data;
                            } else {
                                $scope.showEmptyPackagePage = true;
                            }
                        } else {
                            publicFun.errCodeMsg(resp.code);
                        }
                    } else {
                        Router.go('/error');
                    }
                });
            };
            //刚进入物联卡信息页面需要做的查询
            $scope.initEvents = function() {
                event.stopPropagation();
                $scope.registerStatus='未实名';
                $scope.searchCardInfo(); //查询物联卡信息
            };

            $scope.goTopUp = function() {
                $scope.rechargeObj = {};
                $scope.rechargeObj.msisdn = $scope.cardInfo.msisdn;
                $scope.rechargeObj.iccid = $scope.cardInfo.iccid;
                $scope.rechargeObj.accountId = $scope.cardInfo.accountId;
                $scope.rechargeObj.accountName = $scope.cardInfo.accountName;
                $scope.rechargeObj.beId = $scope.beId;
                $scope.rechargeObj.cardBelong = $scope.cardInfo.cardBelong;
                $scope.rechargeObj.title = personStorage.getTitle();
                Router.go('/recharge', $scope.rechargeObj);
            };
            //tab切换
            $scope.tabChange = function(index) {
                $scope.recordOprate(index);
                event.stopPropagation();
                $scope.page.focusIndex = index;
                $scope.swiperList.slideTo(index, 1000, false);
            };

            //充值调用
            $scope.toCheckIndividualAccount = function() {
                 personStorage.setOperate({
                     hitTime: Date.now(),
                     businessHitType: personOperateType.recharge,
                     msisdn: $scope.msisdn
                 });
                 $scope.goTopUp();
                 // if ("00" === $scope.cardInfo.cardBelong) {
                 //     httpService.getData('/service/wx/person/api/saveChargeLogOfPB', { 'msisdn': $scope.msisdn }, {
                 //         type: 'POST',
                 //         doError: 'false'
                 //     }).then(function(resp) {});
                 //     window.location.href = $scope.cardInfo.chargeURL
                 // } else if ("01" === $scope.cardInfo.cardBelong) {
                 //     $scope.goTopUp();
                 // }
            };
            //    --------------------------swiper--------------------
            $scope.swiperList = new Swiper('#cardInfo_swiper', {
                spaceBetween: 0,
                slidesPerView: 'auto',
                speed: 500, //滑动速度，单位ms
                calculateHeight: true,
                on: {
                    slideChangeTransitionEnd: function() {
                        $scope.page.focusIndex = this.activeIndex;
                        $scope.recordOprate(this.activeIndex);
                        $scope.$digest();
                        //当使用第三方插件以及JS的时候angular 检测不到值的改变就必须用apply 或者$digest!
                    }
                }
            });
            $scope.recordOprate = function(index) {
                var businessHitType;
                index = parseInt(index)
                switch (index) {
                    case 0:
                        businessHitType = personOperateType.msisdn_info;
                        break;
                    case 1:
                        businessHitType = personOperateType.user_quantity;
                        break;
                    case 2:
                        businessHitType = personOperateType.product_info;
                        break;
                }
                personStorage.setOperate({
                    hitTime: Date.now(),
                    businessHitType: businessHitType,
                    msisdn: $scope.msisdn
                })
            }
        }
    ]);