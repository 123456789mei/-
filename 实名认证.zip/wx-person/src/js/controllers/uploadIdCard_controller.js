personui.controller('uploadIdCardController', ['$scope', 'httpService', 'personStorage', '$location', 'Router', 'publicFun',
    function ($scope, httpService, personStorage, $location, Router, publicFun) {
        $scope.idName = "";
        $scope.idNumber = "";
        $scope.headImgServerId = "";
        $scope.cardImgServerId = "";
        $scope.backImgServerId = "";
        $scope.selected = false;
        $scope.numberReg = /^[1-9]\d{5}(18|19|20)\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/;
        //YYYY-MM-DD
        $scope.dateRegex = /^(([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29)$/;
        //YYYYMMDD
        $scope.dateNumRegex = /^([\d]{4}((((0[13578]|1[02])((0[1-9])|([12][0-9])|(3[01])))|(((0[469])|11)((0[1-9])|([12][0-9])|30))|(02((0[1-9])|(1[0-9])|(2[0-8])))))|((((([02468][048])|([13579][26]))00)|([0-9]{2}(([02468][048])|([13579][26]))))(((0[13578]|1[02])((0[1-9])|([12][0-9])|(3[01])))|(((0[469])|11)((0[1-9])|([12][0-9])|30))|(02((0[1-9])|(1[0-9])|(2[0-9]))))){4})$/;
        $scope.nameReg = /^[\u4E00-\u9FA5]+(·[\u4E00-\u9FA5]+)*$/;
        $scope.imgSrc = "images/idCardImg.png";
        $scope.phone = personStorage.getPhone();
        $scope.locatieParm = Router.getBundle();
        $scope.idInfoCheckStatus = "00"; //01 账户实名信息和输入身份证不一致；00 账户实名信息和输入身份证一致(默认)
        $scope.pageMark = $scope.locatieParm.pageMark; //00:卡登记页面跳转  01:卡绑定页面跳转
        $scope.fileZPath = '';
        $scope.fileFPath = '';
        $scope.issuingAuthority = '';
        $scope.nation = '';
        $scope.pictureRTip = false;
        $scope.inputFReadOnly = true;
        $scope.inputZReadOnly = true;
        $scope.birthday_readonly = true;//生日只读
        $scope.certV_readonly = true;//身份证生效只读
        $scope.certE_readonly = true;//身份证失效只读
        $scope.birthday_cansel = false;//生日选择器
        $scope.certV_cansel = false;//身份证生效选择器
        $scope.certE_cansel = false;//身份证生效选择器

        $scope.goBack = function () {
            Router.back();
        };
        $scope.showTips = function () {
            $scope.pictureRTip = true;
        };
        $scope.closeTips = function () {
            $scope.pictureRTip = false;
        };
        $scope.comfirmTips = function () {
            $scope.pictureRTip = false;
            $scope.takePictureHead();
        };
        $scope.getWidthHeight = function () {
            if (!$scope._height && !$scope._width) {
                $scope._height = document.querySelector("#card").clientHeight;
                $scope._width = document.querySelector("#card").clientWidth;
            }
        };

        //人像图片拍摄
        $scope.takePictureHead = function () {
            $scope.getWidthHeight();
            wx.chooseImage({
                count: 1, // 默认9
                sizeType: ['original'], // 可以指定是原图还是压缩图，默认二者都有
                sourceType: ['camera'], // 可以指定来源是相册还是相机，默认二者都有
                success: function (res) {
                    var localId = res.localIds[0].toString(); // 返回选定照片的本地ID列表，localId可以作为img标签的src属性显示图片
                    wx.getLocalImgData({
                        localId: localId, // 图片的localID
                        success: function (res) {
                            if (publicFun.iosDevice()) {
                                //这里需要注意的是，尽管ios返回的是base64编码的字符串，但前缀还是有点不一样，是：'data:image/jgp/png;base64'；
                                //网上很多文章都说要按一下方式替换掉‘jgp’为‘jpeg’，但实际操作发现，不替换也可以正常显示，所以本人就不替换了，直接取值使用
                                //$scope.imgSrc = res.localData.replace('jgp', 'jpeg');//替换‘jgp’为‘jpeg’
                                $scope.headloaclData = res.localData; //赋值显示
                            } else if (publicFun.androidDevice()) {
                                $scope.headloaclData = 'data:image/jpeg/png;base64,' + res.localData; // localData是图片的base64数据，可以用img标签显示
                            }
                            wx.uploadImage({
                                localId: localId, // 需要上传的图片的本地ID，由chooseImage接口获得
                                isShowProgressTips: 1, // 默认为1，显示进度提示
                                success: function (res) {
                                    $scope.headImgServerId = res.serverId; // 返回图片的服务器端ID
                                    angular.element(document.querySelector("#head"))
                                        .replaceWith("<img id=\"head\" style=\"" + "height:" + $scope._height + ";width:" + $scope._width + "\" src=\"" + $scope.headloaclData + "\">");
                                }
                            });
                        }
                    });
                }
            });
        };
        //背面图片选择
        $scope.takePictureBack = function () {
            $scope.getWidthHeight();
            wx.chooseImage({
                count: 1, // 默认9
                sizeType: ['original'], // 可以指定是原图还是压缩图，默认二者都有
                sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
                success: function (res) {
                    var localId = res.localIds[0].toString(); // 返回选定照片的本地ID列表，localId可以作为img标签的src属性显示图片
                    wx.getLocalImgData({
                        localId: localId, // 图片的localID
                        success: function (res) {
                            if (publicFun.iosDevice()) {
                                //这里需要注意的是，尽管ios返回的是base64编码的字符串，但前缀还是有点不一样，是：'data:image/jgp/png;base64'；
                                //网上很多文章都说要按一下方式替换掉‘jgp’为‘jpeg’，但实际操作发现，不替换也可以正常显示，所以本人就不替换了，直接取值使用
                                //$scope.imgSrc = res.localData.replace('jgp', 'jpeg');//替换‘jgp’为‘jpeg’
                                $scope.backloaclData = res.localData; //赋值显示
                            } else if (publicFun.androidDevice()) {
                                $scope.backloaclData = 'data:image/jpeg/png;base64,' + res.localData; // localData是图片的base64数据，可以用img标签显示
                            }
                            wx.uploadImage({
                                localId: localId, // 需要上传的图片的本地ID，由chooseImage接口获得
                                isShowProgressTips: 1, // 默认为1，显示进度提示
                                success: function (res) {
                                    $scope.backImgServerId = res.serverId; // 返回图片的服务器端ID
                                    angular.element(document.querySelector("#back"))
                                        .replaceWith("<img id=\"back\" style=\"" + "height:" + $scope._height + ";width:" + $scope._width + "\" src=\"" + $scope.backloaclData + "\">");
                                    //识别图片，反面
                                    $scope.recognizePicBack();
                                }
                            });
                        }
                    });
                }
            });
        };
        //正面图片选择
        $scope.takePictureCard = function () {
            $scope.getWidthHeight();
            wx.chooseImage({
                count: 1, // 默认9
                sizeType: ['original'], // 可以指定是原图还是压缩图，默认二者都有
                sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
                success: function (res) {
                    var localId = res.localIds[0].toString(); // 返回选定照片的本地ID列表，localId可以作为img标签的src属性显示图片
                    wx.getLocalImgData({
                        localId: localId, // 图片的localID
                        success: function (res) {
                            if (publicFun.iosDevice()) {
                                //这里需要注意的是，尽管ios返回的是base64编码的字符串，但前缀还是有点不一样，是：'data:image/jgp/png;base64'；
                                //网上很多文章都说要按一下方式替换掉‘jgp’为‘jpeg’，但实际操作发现，不替换也可以正常显示，所以本人就不替换了，直接取值使用
                                //$scope.imgSrc = res.localData.replace('jgp', 'jpeg');//替换‘jgp’为‘jpeg’
                                $scope.cardloaclData = res.localData; //赋值显示
                            } else if (publicFun.androidDevice()) {
                                $scope.cardloaclData = 'data:image/jpeg/png;base64,' + res.localData; // localData是图片的base64数据，可以用img标签显示
                            }
                            wx.uploadImage({
                                localId: localId, // 需要上传的图片的本地ID，由chooseImage接口获得
                                isShowProgressTips: 1, // 默认为1，显示进度提示
                                success: function (res) {
                                    $scope.cardImgServerId = res.serverId; // 返回图片的服务器端ID
                                    angular.element(document.querySelector("#card"))
                                        .replaceWith("<img id=\"card\" style=\"" + "height:" + $scope._height + ";width:" + $scope._width + "\" src=\"" + $scope.cardloaclData + "\">");
                                    //识别图片，正面
                                    $scope.recognizePicFront();
                                }
                            });
                        }
                    });
                }
            });
        };

        $scope.valid_date_handle = function (validDate) {
            var validDateArr = validDate.split('-');
            if (validDateArr.length < 2) {
                //长期有效
                var endDate = "长期有效";
                validDateArr.push(endDate)
            }
            var validDateArrNew = '';
            if (validDateArr[1] == '长期' || validDateArr[1] == '长期有效') {
                return validDateArrNew = [validDateArr[0].slice(0, 4) + '-' + validDateArr[0].slice(4, 6) + '-' + validDateArr[0].slice(6, 8), validDateArr[1]]
            } else {
                validDateArrNew = [validDateArr[0].slice(0, 4) + '-' + validDateArr[0].slice(4, 6) + '-' + validDateArr[0].slice(6, 8), validDateArr[1].slice(0, 4) + '-' + validDateArr[1].slice(4, 6) + '-' + validDateArr[1].slice(6, 8)]
                var validYears = parseInt(validDateArr[1].slice(0, 4)) - parseInt(validDateArr[0].slice(0, 4));
                if (validYears >= 10) {
                    return validDateArrNew;
                } else {
                    $scope.backImgServerId === '';
                    return ['', '']
                }
            }
        };

        //身份证数据处理识别
        $scope.reconIdCard = function (idCard) {
            if (idCard) {
                var sexMap = {0: "女", 1: "男"};
                //获取性别
                if (idCard.length == 15) {
                    $scope.gender = sexMap[idCard.substring(14, 15) % 2];
                } else if (idCard.length == 18) {
                    $scope.gender = sexMap[idCard.substring(14, 17) % 2];
                }
                var birth;
                if (15 == idCard.length) {
                    birthdayStr = idCard.charAt(6) + idCard.charAt(7);
                    if (parseInt(birthdayStr) < 10) {
                        birthdayStr = '20' + birthdayStr;
                    } else {
                        birthdayStr = '19' + birthdayStr;
                    }
                    birth = birthdayStr + '-' + idCard.charAt(8) + idCard.charAt(9) + '-' + idCard.charAt(10) + idCard.charAt(11);
                } else if (18 == idCard.length) {
                    birth = idCard.charAt(6) + idCard.charAt(7) + idCard.charAt(8) + idCard.charAt(9) + '-' + idCard.charAt(10) + idCard.charAt(11) + '-' + idCard.charAt(12) + idCard.charAt(13);
                }
                $scope.birthday = birth;
            }
        };
        $scope.ocrAlert = function (err_code) {
            switch (err_code) {
                case '430':
                    publicFun.errCodeMsg('获取access_token失败，请重试');
                    break;
                case '403':
                    publicFun.errCodeMsg('查询异常，请重试');
                    break;
                case '433':
                    publicFun.errCodeMsg('素材文件下载失败');
                    break;
                case '432':
                    publicFun.errCodeMsg('证件识别失败');
                    break;
                case '012':
                    publicFun.errCodeMsg('身份证件照大小必须大于50KB，小于300KB');
                    break;
                default:
                    publicFun.errCodeMsg('证件识别失败，错误码：' + err_code);
                    break;
            }
        };
        //识别图片方法,正面
        $scope.recognizePicFront = function () {
            httpService.getData("/service/wx/person/api/ocr", {
                msisdn: $scope.locatieParm.msisdn,
                mediaId: $scope.cardImgServerId,
                type: 'Front'
            }, {type: 'GET', doError: 'false'})
                .then(function (resp) {
                    if (resp != null && resp.data && resp.code === '0') {
                        $scope.idNumber = resp.data.id;
                        $scope.idName = resp.data.name;
                        $scope.addr = resp.data.addr;
                        $scope.fileZPath = resp.data.mediaFilePath;
                        //性别和生日识别
                        $scope.reconIdCard(resp.data.id);
                    } else {
                        if (resp != null && resp.code === "432" && resp.data) {
                            //OCR 认证失败 或 次数超限
                            $scope.fileZPath = resp.data;
                            $scope.inputZReadOnly = false;
                            $scope.birthday_readonly = false;//生日只读隐藏
                            $scope.birthday_cansel = true;//生日选择器显示
                            layer.open({
                                content: "身份证正面已上传成功,请输入身份证信息",
                                skin: "msg",
                                time: 2
                            });
                        } else {
                            // alert(JSON.stringify(resp));
                            var msg = resp.errParams ? resp.errParams[0] : "身份证正面上传失败，请重新上传";
                            $scope.ocrAlert(msg);
                        }
                    }
                })
        };
        // 识别图片方法,反面
        $scope.recognizePicBack = function () {
            httpService.getData("/service/wx/person/api/ocr", {
                msisdn: $scope.locatieParm.msisdn,
                mediaId: $scope.backImgServerId,
                type: 'Back'
            }, {type: 'GET', doError: 'false'})
                .then(function (resp) {
                    if (resp != null && resp.data && resp.code === '0') {
                        // 有效期处理
                        var validDate = $scope.valid_date_handle(resp.data.valid_date);
                        $scope.certValiddate = validDate[0];
                        $scope.certExpdate = validDate[1];
                        $scope.fileFPath = resp.data.mediaFilePath;
                    } else {
                        if (resp != null && resp.code === "432" && resp.data) {
                            //OCR次数超限
                            $scope.fileFPath = resp.data;
                            $scope.inputFReadOnly = false;
                            $scope.certV_readonly = false;//身份证生效只读隐藏
                            $scope.certE_readonly = false;//身份证失效只读隐藏
                            $scope.certV_cansel = true;//身份证生效选择器显示
                            $scope.certE_cansel = true;//身份证生效选择器显示
                            layer.open({
                                content: "身份证反面上传成功,请输入身份证信息",
                                skin: "msg",
                                time: 2
                            });

                        } else {
                            // alert(JSON.stringify(resp));
                            var msg = resp.errParams ? resp.errParams[0] : "身份证正面上传失败，请重新上传";
                            $scope.ocrAlert(msg);
                        }
                    }
                })
        };

        $scope.showActivation = function () {
            return $scope.locatieParm.cardBelong === "01" && $scope.locatieParm.cardStatus === "7";
        };

        $scope.submit = function () {
            if ($scope.headImgServerId === '') {
                publicFun.layerMsg("人像照片异常，请重新拍摄");
                return;
            }
            if ($scope.cardImgServerId === '' || !$scope.fileZPath) {
                publicFun.layerMsg("身份证正面照片异常，请重新拍摄");
                return;
            }
            if ($scope.backImgServerId === '' || !$scope.fileFPath) {
                publicFun.layerMsg("身份证背面照片异常，请重新拍摄");
                return;
            }
            if (!$scope.nameReg.test($scope.idName)) {
                publicFun.layerMsg("请输入正确的姓名");
                return;
            }
            if (!$scope.numberReg.test($scope.idNumber)) {
                publicFun.layerMsg("请输入正确的身份证号");
                return;
            }
            $scope.birthday = $scope.birthday ? $scope.birthday : $("input[name = 'birthday']").val();
            if (!$scope.dateRegex.test($scope.birthday)) {
                publicFun.layerMsg("请输入正确的出生日期");
                return;
            }
            if ($scope.gender !== "男" && $scope.gender !== "女") {
                publicFun.layerMsg("请输入正确的性别(男/女)");
                return;
            }
            if ($scope.nation === '') {
                publicFun.layerMsg("请输入对应的民族");
                return;
            }
            if ($scope.addr === '') {
                publicFun.layerMsg("请输入住址");
                return;
            }
            $scope.certValiddate = $scope.certValiddate ? $scope.certValiddate : $("input[name = 'certValiddate']").val();
            if (!$scope.dateRegex.test($scope.certValiddate)) {
                publicFun.layerMsg("请输入正确的生效日期");
                return;
            }
            $scope.certExpdate = $scope.certExpdate ? $scope.certExpdate : $("input[name = 'certExpdate']").val();
            if ($scope.certExpdate != "长期有效" && $scope.certExpdate != "长期") {
                if (!$scope.dateRegex.test($scope.certExpdate)) {
                    publicFun.layerMsg("请输入正确的失效日期");
                    return;
                }
            }
            if ($scope.issuingAuthority === '') {
                publicFun.layerMsg("请输入对应的签发机关");
                return;
            }
            var data = {
                name: $scope.idName,
                custCertId: $scope.idNumber
            };
            httpService.getData("/service/wx/person/api/userIdentityValidate", data, {type: 'POST', doError: 'false'})
                .then(function (resp) {
                    if (resp) {
                        if (resp.code === '0') {
                            if (resp.data.code === '011') {
                                $scope.idInfoCheckStatus = '01';
                            } else {
                                $scope.uploadIdInfo();
                            }
                        } else {
                            publicFun.errCodeMsg(resp.code);
                        }
                    }
                })
        };

        $scope.showModalDialog = function () {
            return $scope.idInfoCheckStatus !== "00";
        };
        $scope.closeDialog = function () {
            $scope.idInfoCheckStatus = "00";
        };

        $scope.uploadIdInfo = function () {
            $scope.idInfoCheckStatus = "00";
            var data = {
                formCustCerNo: $scope.idNumber,
                formCustName: $scope.idName,
                mediaIdR: $scope.headImgServerId,
                mediaIdZ: $scope.cardImgServerId,
                mediaIdF: $scope.backImgServerId,
                custPhoneNo: $scope.phone,
                iccid: $scope.locatieParm.iccid,
                msisdn: $scope.locatieParm.msisdn,
                beId: $scope.locatieParm.beId,
                custId: $scope.locatieParm.custId,
                pbOrct: $scope.locatieParm.cardBelong,
                isActive: $scope.selected === true ? "0" : "1",
                alias: $scope.locatieParm.remark,
                plat: "00",
                custCertAddr: $scope.addr,
                certValiddate: $scope.certValiddate,
                certExpdate: $scope.certExpdate,
                gender: $scope.gender,
                nation: $scope.nation,
                birthday: $scope.birthday ? $scope.birthday : $("input[name = 'birthday']").val(),
                issuingAuthority: $scope.issuingAuthority,
                fileZPath: $scope.fileZPath,
                fileFPath: $scope.fileFPath,
            };
            httpService.getData("/service/wx/person/api/realNameReg", data, {type: 'POST', doError: 'false'})
                .then(function (resp) {
                    if (resp) {
                        if (resp.code === '0') {
                            Router.go("/uploadResult", {
                                success: true,
                                msisdn: $scope.locatieParm.msisdn,
                                phone: $scope.phone,
                                pageMark: $scope.pageMark,
                                cardBelong: $scope.locatieParm.cardBelong
                            });
                        } else {
                            $scope.realNameErrorMsg(resp);
                        }
                    }
                });
        };

        $scope.realNameErrorMsg = function (resp) {
            switch (resp.code) {
                case '020':
                    publicFun.errCodeMsg('该卡你已实名登记，无需重复实名登记');
                    break;
                case '030':
                    publicFun.errCodeMsg('获取微信access_token失败');
                    break;
                case '031':
                    publicFun.errCodeMsg('人证比对不一致（ 输入信息和身份证信息不一致）');
                    break;
                case '032':
                    publicFun.errCodeMsg('微信OCR识别失败');
                    break;
                case '033':
                    publicFun.errCodeMsg('拉取微信临时素材文件失败');
                    break;
                case '034':
                    publicFun.errCodeMsg('登记信息保存失败');
                    break;
                case '035':
                    publicFun.errCodeMsg('ICCID和MSISDN对应关系错误');
                    break;
                case '036':
                    publicFun.errCodeMsg('卡已销户， 无法登记');
                    break;
                case '037':
                    publicFun.errCodeMsg('该卡在CMIOT系统中不存在');
                    break;
                case '038':
                    publicFun.errCodeMsg('该卡实名登记请求次数已超过系统每日最大限制（ 10 次）');
                    break;
                case '039':
                    publicFun.errCodeMsg('该卡正在进行实名登记， 请勿重复提交请求');
                    break;
                case '401':
                    var msg = resp.errParams ? resp.errParams[0] : "请求参数缺失，请重新输入认证信息";
                    publicFun.errCodeMsg(msg);
                    break;
                case '430':
                    publicFun.errCodeMsg('与微信服务器交互失败，请重新提交');
                    break;
                case '403':
                    publicFun.errCodeMsg('未获取到上传图片文件临时目录');
                    break;
                case '433':
                    var msg = resp.errParams ? resp.errParams[0] : "未获取到现场人像照片，请选择图片文件";
                    publicFun.errCodeMsg(msg);
                    break;
                default:
                    publicFun.layerMsg((resp.errParams && resp.errParams.length > 0) ? resp.errParams[0] : "未知异常，请稍后再试！");
                    break;
            }
        };

        $scope.time = function (n) {
            var date = new Date();
            var year = date.getFullYear();
            year += n;
            var month = date.getMonth() + 1;
            var day = date.getDate();
            if (month < 10) {
                month = "0" + month;
            }
            if (day < 10) {
                day = "0" + day;
            }
            var nowDate = year + "-" + month + "-" + day;
            return nowDate
        };
        //初始化函数
        this.$onInit = function () {
            var selectDate0 = new MobileSelectDate();
            var selectDate1 = new MobileSelectDate();
            var selectDate2 = new MobileSelectDate();
            var today = $scope.time(0);
            var todayn = today.split('-');
            var todayy = todayn[1];
            var todayr = todayn[2];
            today = todayn[0] + '/' + todayy + '/' + todayr;
            var tenYear = $scope.time(30);
            var tenn = tenYear.split('-');
            var teny = tenn[1];
            var tenr = tenn[2];
            tenYear = tenn[0] + '/' + teny + '/' + tenr;
            selectDate0.init({trigger: '#birthday', value: today, min: '1900/01/01', max: today});
            selectDate1.init({trigger: '#certValiddate', value: today, min: '1900/01/01', max: today});
            selectDate2.init({trigger: '#certExpdate', value: today, min: '1900/01/01', max: tenYear});
        };
    }

]);