personui
    .controller('CardRegisterIndexController', ['$scope', 'httpService', '$location', 'publicFun', 'personStorage', 'Router', 'homePath', 'personOperateType',
        function($scope, httpService, $location, publicFun, personStorage, Router, homePath, personOperateType) {
            $scope.goBack = function() { //返回按钮
                Router.back();
            };
            $scope.homepath = homePath;
            $scope.cardInfoVo = {};
            $scope.cardInfoVo.isSetting = true;
            $scope.swperWhere = "indexPage"; //判断卡片是否可以点击
            /*
               {1:过渡页面加载中;
                2:认证页面;
                3:添加物联卡页面;
                4:已经实名并且添加完成物联卡,显示物联卡列表页面;
                5:错误提示页面}
            */
            $scope.cardInfoVo.isShow = 1;

            var data = {
                phone: personStorage.getPhone(),
                userId: personStorage.getUserId(),
                openId: personStorage.getOpenId()
            };

            $scope.openId = personStorage.getOpenId();

            //判断是否认证
            $scope.isValidate = function() {
                if (personStorage.getVerifiedStatus() === '087') {
                    publicFun.checkSignOn();
                } else {
                    $scope.getSearchList();
                }
            };

            //物联卡列表
            $scope.cardList = [];
            //初始化查询物联卡list数据
            $scope.getSearchList = function(){
                var cardList = [];
                //物联卡列表
                var cardListPromise = new Promise(function (resolve) {
                    httpService.getData('/service/wx/person/api/queryCardRegisterList', { userId: personStorage.getUserId() }, { doError: 'false', isLoad: 'false' })
                        .then(function(resp){
                            resp ? resolve(resp) : resolve(null);
                        });
                });
                Promise.all([cardListPromise]).then(function(lists){
                    console.log("响应结果:",lists);
                    var reqStatus = lists.some(function(resp){return resp && (resp.success === true);});
                    if(!reqStatus){
                        console.log("all failed");
                        Router.go("/error");
                        return;
                    }
                    lists.forEach(function(resp){
                        if (resp && resp.data && resp.data && resp.data.length) {
                            cardList.push.apply(cardList,resp.data);
                        }
                    });
                    console.log("处理后结果:",cardList);
                    if(cardList.length === 0){
                        $scope.cardInfoVo.isShow = 3;
                    }else{
                        $scope.cardInfoVo.isShow = 4;
                        $scope.listSize = cardList.length;
                        $scope.cardList = cardList;
                        $scope.initPullRefresh();
                    }
                    $scope.$apply();
                });
            };



            $scope.knowBtn = function() {
                $scope.modal_activateSuccess = false;
            }


            $scope.cancel = function() { //取消按钮
                $scope.modal.isShowModal = false;
            };
            $scope.closeCurr = function() {
                //关闭当前错误页
                window.location.href = $scope.homepath + '/service/wx/person/login?' + 'openId=' + $scope.openId + '&msgId=4';
            };

            //上拉刷新
            $scope.initPullRefresh = function() {
                if ($scope.pullRefresh) {
                    return
                }
                $scope.pullRefresh = new PullRefresh({
                    pullContainer: document.querySelector('.scrollContainer'),

                    loadingContent: document.querySelector('.loadingContainer'),

                    wholePullMode: true,

                    loadingBoxPullMode: false,

                    MaxLoadingHeight: 60,

                    transition: '.3s ease',

                    loadingBefore: function(hasScroll) {
                        if (hasScroll < 60) {

                        }
                    },
                    prepareLoading: function(hasScroll) {
                        if (hasScroll > 60) {

                        }
                    },
                    loading: function() {

                    },
                    ajax: function() {
                        $scope.getSearchList();
                    },
                    loaded: function(hasScroll) {

                    }
                })
            }
        }
    ]);