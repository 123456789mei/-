personui.controller('checkIdCardController', ['$scope','Router','publicFun','httpService','personStorage',
    function ($scope,Router,publicFun,httpService,personStorage) {
        $scope.goBack = function () {
            Router.back(2);
        };
        var chackData = Router.getBundle();
        var idcard = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
        $scope.custName = '';

        $scope.province = chackData.beId;
        // $scope.province = '100';
        //检验物联卡号
        $scope.checkIdcardNextStep = function () {
            if ($scope.idcard ===''){
                console.log('idcard:'+$scope.idcard);
                publicFun.layerMsg("请输入身份证号");
                return;
            }

            if($scope.province == '100' && !$scope.custName){
                console.log('province:'+$scope.province+",custName:"+$scope.custName);
                publicFun.layerMsg("请输入证件姓名");
                return ;
            }

            if(!idcard.test($scope.idcard)){
                return  publicFun.layerMsg("请输入正确的身份证号");
            }
            var data = {
                idCard: $scope.idcard,
                idType:'1',
                userId: personStorage.getUserId(),
                beId:chackData.beId,
                msisdn:chackData.msisdn,
                phone:personStorage.getPhone(),
                customerName:$scope.custName
            };

            httpService.getData('/service/wx/person/api/idCardCheck', data, {
                type: 'POST',
                doError: 'false'
            }).then(function(resp) {
                if (resp) {
                    if (resp.code == '0' && resp.data) {
                        if(resp.data.checkCode == '0'){
                            $scope.getRealNameAuth();
                        }else{
                            publicFun.layerMsg(resp.data.checkMsg);
                        }
                    } else {
                        publicFun.layerMsg("身份证校验失败");
                        return;
                    }
                } else {
                    Router.go('/error');
                }
            });
        };

    $scope.getRealNameAuth = function (){
        var data={
            phone:personStorage.getPhone(),
            idCard:$scope.idcard,
            msisdn:chackData.msisdn,
            iccid:chackData.iccid,
            beid:chackData.beId,
            userId:personStorage.getUserId()
        }
        var headers = {
            openId:personStorage.getOpenId(),
            accessToken:sessionStorage.obj ? JSON.parse(sessionStorage.obj).accessToken : '',
            platKey: 'weChat'
        }
        $.ajax({
            type: "POST",
            url: "/service/wx/person/api/getRealNameAuthURL",
            data: JSON.stringify(data),
            dataType: "json",
            contentType: "application/json;charset=utf-8",
            headers: Object.assign(data,headers),
            success: function (resp) {
                if (resp.code === '0' && resp.data) {
                    $scope.realName = resp.data;
                    publicFun.copySessionToLocalStorage()
                    window.location.href = $scope.realName;
                } else if(resp.code == '001'){
                    publicFun.layerMsg("当日实名认证次数超过限制，请明日再试");
                }else {
                    publicFun.layerMsg('实名认证失败');
                }
            },
            error: function (){
                Router.go('/error');
            }

        });

        // httpService.getData('/service/wx/person/api/getRealNameAuthURL', data,{
        //     type: 'POST',
        //     doError: 'false'
        // }).then(function(resp) {
        //     if (resp) {
        //         if (resp.code === '0' && resp.data) {
        //             $scope.realName = resp.data;
        //             publicFun.copySessionToLocalStorage()
        //             window.location.href = $scope.realName;
        //         } else {
        //             publicFun.layerMsg(resp.code);
        //         }
        //
        //     } else {
        //         Router.go('/error');
        //     }
        // });
    }

    }]);