personui
    .controller('ValidateController', ['$scope', 'httpService', '$location', 'publicFun', 'personStorage', 'Router', 'homePath', 'personOperateType',
        function($scope, httpService, $location, publicFun, personStorage, Router, homePath, personOperateType) {
            $scope.goBack = function() { //返回按钮
                Router.back();
            };
            $scope.homepath = homePath;
            $scope.cardInfoVo = {};
            $scope.cardInfoVo.isSetting = true;
            $scope.swperWhere = "indexPage"; //判断卡片是否可以点击
            /*
               {1:过渡页面加载中;
                2:认证页面;
                3:添加物联卡页面;
                4:已经实名并且添加完成物联卡,显示物联卡列表页面;
                5:错误提示页面}
            */
            $scope.cardInfoVo.isShow = 1;

            var data = {
                phone: personStorage.getPhone(),
                userId: personStorage.getUserId(),
                openId: personStorage.getOpenId()
            };

            $scope.openId = personStorage.getOpenId();

            //判断是否认证
            $scope.isValidate = function() {
                if (personStorage.getVerifiedStatus() === '087') {
                    publicFun.checkSignOn();
                } else {
                    if (personStorage.getVerifiedStatus() === '01') {
                        //已经通过认证
                        $scope.getSearchList();
                    } else if (personStorage.getVerifiedStatus() === '10') {
                        //身份证过期，需重新认证
                        // personStorage.setName('');
                        $scope.cardInfoVo.isShow = 2;
                        $scope.cardInfoVo.isexpiredIDCard = true //重新认证提示
                    } else if (personStorage.getVerifiedStatus() == '00') {
                        personStorage.setName('');
                        $scope.cardInfoVo.isShow = 2; //显示未认证
                    } else {
                        //显示错误页面
                        // $scope.cardInfoVo.isShow = 5;
                        // $scope.cardInfoVo.isSetting = false;
                        Router.go('/error')
                    }
                }
                /*手机号、姓名脱敏*/
                $scope.phoneNum = publicFun.desensitizePhone(personStorage.getPhone());
                $scope.name = publicFun.desensitizeName(personStorage.getName());
            };

            //物联卡列表
            $scope.cardList = [];
            /*去认证接口*/
            $scope.go2Validate = function() {
                var timestamp = new Date().getTime();
                if(timestamp >= 1594396800000 && timestamp <= 1594526400000){
                    layer.open({
                        skin: "msg",
                        content: "因系统升级，实名认证暂停服务，请于7月12日中午12点后重试",
                        time:2
                    });
                    return;
                }
                personStorage.setOperate({
                    hitTime: Date.now(),
                    businessHitType: personOperateType.real_name,
                    msisdn: null
                })
                httpService
                    .getData('/service/wx/person/api/getRealNameAuthURL', { userId: personStorage.getUserId() }, { type: 'POST', doError: 'false' })
                    .then(function(resp) {
                        if (resp) {
                            if (resp.code === '0') {
                                $scope.realName = resp.data;
                                publicFun.copySessionToLocalStorage()
                                window.location.href = $scope.realName;
                            } else {
                                publicFun.layerMsg("当日实名认证次数超过限制，请明日再试");
                                personStorage.setName('');
                                $scope.cardInfoVo.isShow = 2; //显示未认证
                            }
                        } else {
                            Router.go('/error');
                        }
                    });
            };
            $scope.cardList = [];
            /*初始化查询物联卡list数据*/
            //初始化查询物联卡list数据
            $scope.getSearchList = function(){
                var cardList = [];
                //物联卡列表
                var cardListPromise = new Promise(function (resolve) {
                    httpService.getData('/service/wx/person/api/syncMsisdnList', { phone: personStorage.getPhone() }, { doError: 'false', isLoad: 'false' })
                        .then(function(resp){
                            resp ? resolve(resp) : resolve(null);
                        });
                });
                //重庆boss物联卡列表
                var cqBossCardListPromise = new Promise(function (resolve) {
                    httpService.getData('/service/wx/person/api/getCQMsisdns', { phone: personStorage.getPhone() }, { doError: 'false', isLoad: 'false' }).
                    then(function(resp){
                        resp ? resolve(resp) : resolve(null);
                    });
                });
                Promise.all([cardListPromise,cqBossCardListPromise]).then(function(lists){
                    console.log("响应结果:",lists);
                    var reqStatus = lists.some(function(resp){return resp && (resp.success === true);});
                    if(!reqStatus){
                        console.log("all failed");
                        Router.go("/error");
                        return;
                    }
                    lists.forEach(function(resp){
                        if (resp && resp.data && resp.data.list && resp.data.list.length) {
                            cardList.push.apply(cardList,resp.data.list);
                        }
                    });
                    console.log("未处理结果:",cardList);
                    if(cardList.length > 0){
                        //同样的卡号只保留一个
                        cardList = cardList.filter(function(ele,index,arr){
                            return arr.findIndex(function(element){
                                return element.msisdn === ele.msisdn;
                            }) === index;
                        });
                    }
                    console.log("处理后结果:",cardList);
                    if(cardList.length === 0){
                        $scope.cardInfoVo.isShow = 3;
                    }else{
                        $scope.cardInfoVo.isShow = 4;
                        $scope.listSize = cardList.length;
                        $scope.cardList = cardList;
                        for (var i = 0; i < cardList.length; i++) {
                            if (cardList[i].cardBelong === "01") {
                                $scope.checkAccount(cardList[i].msisdn); //增加查询个人账户接口
                            }
                            var status = cardList[i].status;
                            $scope.cardList[i].statusCode = publicFun.HandleStatus(status);
                            $scope.cardList[i].isShowTopUp = !(status === "03" || status === "04" || status === "8");
                            $scope.queryBalanceAndTotal($scope.cardList[i]);
                        }
                        $scope.initPullRefresh();
                    }
                    $scope.$apply();
                });
            };
            //检测CT卡是否是个人账户
            $scope.checkAccount = function(msisdn) {
                httpService.getData('/service/wx/person/api/checkIndividualAccount', { 'msisdn': msisdn }, {
                    type: 'POST',
                    doError: 'false',
                    isLoad: "false"
                }).then(function(resp) {
                    if (resp) {
                        var cardIndex = $scope.cardList.findIndex(function(x){return x.msisdn === msisdn;});
                        if(cardIndex > -1) {
                            if (resp.code === "0" && resp.data) {
                                $scope.cardList[cardIndex].isShowTopUp = true; //判断是否是个人账户
                                $scope.cardList[cardIndex].accountId = resp.data.accountId;
                                $scope.cardList[cardIndex].accountName = resp.data.accountName;
                            } else {
                                $scope.cardList[cardIndex].isShowTopUp = false;
                            }
                        }
                    } else {
                        Router.go('/error');
                    }
                });
            };
            $scope.queryBalanceAndTotal = function(cardInfo) {
                $scope.queryParm = {};
                /*组装传参*/
                $scope.queryParm.beId = cardInfo.beId;
                $scope.queryParm.msisdn = cardInfo.msisdn;
                $scope.queryParm.custId = cardInfo.custId;
                $scope.queryParm.cardBelong = cardInfo.cardBelong;
                $scope.queryParm.bindStatus = cardInfo.bindStatus;
                $scope.queryBalance($scope.queryParm);
                $scope.queryUseTotal($scope.queryParm);
            };
            //查余额
            $scope.queryBalance = function(queryData) {
                /*"msisdn":"17296656080",
			      "beId":"100",
			      "custId":"4611000000476254"
               */
                httpService.getData('/service/wx/person/api/queryBalance', queryData, { doError: 'false', isLoad: 'false' })
                    .then(function(resp) {
                        if (resp) {
                            for (var i = 0; i < $scope.cardList.length; i++) {
                                if ($scope.cardList[i].msisdn === queryData.msisdn) {
                                    if (resp.data && resp.data.balance && $scope.cardList[i].isShowTopUp === true) {
                                        $scope.cardList[i].balance = resp.data.balance;
                                    } else {
                                        $scope.cardList[i].balance = "-- ";
                                    }
                                }
                            }
                        }
                    })
            };
            //查用量
            /* "msisdn":"17296656080",
             "beId":"100",
             "custId":"4611000000476254",
             "cardBelong":"01"*/
            $scope.queryUseTotal = function(queryData) {
                httpService.getData('/service/wx/person/api/queryUseTotal', queryData, { doError: 'false', isLoad: 'false' })
                    .then(function(resp) {
                        if (resp) {
                            if (resp.data && resp.data.useTotal) {
                                for (var i = 0; i < $scope.cardList.length; i++) {
                                    if ($scope.cardList[i].msisdn === queryData.msisdn) {
                                        if (!resp.data.useTotal) {
                                            $scope.cardList[i].useTotal = "0.0 MB";
                                        } else {
                                            $scope.cardList[i].useTotal = publicFun.bytesToSize(resp.data.useTotal);
                                        }
                                    }
                                }
                            }
                        }
                    })
            };



            //模态框属性
            $scope.modal = {
                isShowModal: false, //是否显示模态框
                type: "", //类型 remark别名 active激活 unBind解绑
                msisdn: "", //物联卡号
                bgImg: '', //背景图
                remarkName: "",
                //激活接口使用参数--开始--
                custId: '',
                beId: ''
                //激活接口使用参数--结束--
            };
            // 激活
            $scope.$on("ValidateControlle_showModelActive", function(event, data) {
                $scope.modal.bgImg = 'background-image: url("images/primaryEdit.png");';
                $scope.modal.isShowModal = true;
                $scope.modal.msisdn = data.msisdn;
                $scope.modal.custId = data.custId;
                $scope.modal.beId = data.beId;
                $scope.modal.type = "active";
            });
            $scope.primaryQuit = function() { //点击确认激活
                $scope.activePostData = {};
                $scope.activePostData.msisdn = $scope.modal.msisdn;
                $scope.activePostData.custId = $scope.modal.custId;
                $scope.activePostData.beId = $scope.modal.beId;
                $scope.modal.isShowModal = false;
                httpService
                    .getData('/service/wx/person/api/activateCardFromCT', $scope.activePostData, { type: 'POST', doError: 'false' })
                    .then(function(resp) {
                        if (resp) {
                            if (resp.code === '0') {
                                $scope.modal_activateSuccess = true;
                                $scope.getSearchList();
                            } else {
                                publicFun.errCodeMsg(resp.code);
                            }
                        }
                    });
            };
            $scope.knowBtn = function() {
                $scope.modal_activateSuccess = false;
            }
            //解绑接口
            $scope.$on("ValidateControlle_showModelUnbind", function(event, data) {
                $scope.modal.bgImg = 'background-image: url("images/primaryUnbind.png");';
                $scope.modal.isShowModal = true;
                $scope.modal.msisdn = data.msisdn;
                $scope.modal.type = "unbind";
            });
            //单卡查询
            $scope.$on("ValidateControlle_showModelSearch", function(event, data) {
                if(data.status == '8' || data.status == '04'){
                    return;
                }
                var ind = data.ind;
                var _data={
                    userId: personStorage.getUserId(),
                    msisdn:data.msisdn
                };
                httpService
                    .getData('/service/wx/person/api/getMsisdnInfo', _data, { type: 'POST', doError: true })
                    .then(function(resp) {
                        if (resp) {
                            if (resp.code === '0') {
                                var _data = resp.data;
                                $scope.cardList[ind].status = _data.status;
                                $scope.cardList[ind].statusCode = publicFun.HandleStatus(_data.status);
                            } else {
                                publicFun.errCodeMsg(resp.code);
                            }
                        }
                    });

            });
            //解绑
            $scope.primaryUnbinding = function() {
                $scope.modal.isShowModal = false;
                httpService
                    .getData('/service/wx/person/api/unbindMsisdn', { msisdn: $scope.modal.msisdn }, { type: 'POST', doError: 'false' })
                    .then(function(resp) {
                        if (resp) {
                            if (resp.code === '0') {
                                $scope.getSearchList();
                            } else {
                                publicFun.errCodeMsg(resp.code)
                            }
                        }
                    });
            };

            //修改别名
            $scope.$on("ValidateControlle_showModelRemark", function(event, data) {
                $scope.modal.bgImg = 'background-image: url("images/primaryEdit.png");';
                $scope.modal.isShowModal = true;
                $scope.modal.msisdn = data.msisdn;
                $scope.modal.type = "remark";
                $scope.modal.remarkName = "";
            });
            //清空别名
            $scope.deleteText = function() {
                $scope.modal.remarkName = "";
            };
            /*   $scope.regexName =function(){
                $scope.modal.remarkName=publicFun.checkLength($scope.modal.remarkName,16)
               };*/
            //修改按钮
            $scope.updateRemark = function() {
                if (!publicFun.checkLength($scope.modal.remarkName, 16)) {
                    return publicFun.layerMsg("请输入8个汉字或16个英文字母以内的别名");
                }
                var data = {
                    msisdn: $scope.modal.msisdn,
                    remark: $scope.modal.remarkName.trim(),
                };
                $scope.modal.isShowModal = false;
                httpService
                    .getData('/service/wx/person/api/modifyRemark', data, { type: 'POST', doError: 'false' })
                    .then(function(resp) {
                        if (resp) {
                            if (resp.code === '0') {

                                $scope.getSearchList();
                            } else {
                                publicFun.errCodeMsg(resp.code);
                            }
                        }
                    });
            };


            $scope.cancel = function() { //取消按钮
                $scope.modal.isShowModal = false;
            };
            $scope.closeCurr = function() {
                //关闭当前错误页
                window.location.href = $scope.homepath + '/service/wx/person/login?' + 'openId=' + $scope.openId + '&msgId=4';
            };

            $scope.toBindCard = function() {
                Router.go("/bindingIotCard");
            };
            $scope.toPersonCenterPage = function() {
                Router.go("/personCenter");
            };

            //上拉刷新
            $scope.initPullRefresh = function() {
                if ($scope.pullRefresh) {
                    return
                }
                $scope.pullRefresh = new PullRefresh({
                    pullContainer: document.querySelector('.scrollContainer'),

                    loadingContent: document.querySelector('.loadingContainer'),

                    wholePullMode: true,

                    loadingBoxPullMode: false,

                    MaxLoadingHeight: 60,

                    transition: '.3s ease',

                    loadingBefore: function(hasScroll) {
                        if (hasScroll < 60) {

                        }
                    },
                    prepareLoading: function(hasScroll) {
                        if (hasScroll > 60) {

                        }
                    },
                    loading: function() {

                    },
                    ajax: function() {
                        $scope.getSearchList();
                    },
                    loaded: function(hasScroll) {

                    }
                })
            }
        }
    ]);