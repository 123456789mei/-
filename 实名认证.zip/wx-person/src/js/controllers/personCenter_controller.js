personui
    .controller('PersonCenterController',
        ['$scope', 'httpService', 'publicFun', '$location','personStorage', 'homePath','Router','personOperateType',
            function ($scope, httpService, publicFun, $location,personStorage,homePath,Router,personOperateType) {
            $scope.goBackPersonBus = function () {
                Router.back();
          };
            $scope.isLoadName = false;
            $scope.isValidate = false;
            $scope.modal_quit = false;//退出模态框
            $scope.showUpdateInfo=false;
            $scope.modal_cancelAccount = false;//注销模态框
            $scope.modal_real_name=false;//更新实名认证模态框
            $scope.homepath = homePath;

            $scope.bindingPage = 0;

            //从sessionstory中获取存储的name
            if(personStorage.getName()!=''){
                $scope.isLoadName = true;
                $scope.name = personStorage.getName();
            }else {
                $scope.isValidate = true;
            }
            $scope.showUpdateInfo=personStorage.getVerifiedStatus()=='01'||personStorage.getVerifiedStatus()=='10'?true:false
            $scope.phone = personStorage.getPhone();
            $scope.userId = personStorage.getUserId();
            $scope.openId = personStorage.getOpenId();
        var data = {
            phone:  $scope.phone,
            userId: $scope.userId,
            openId: $scope.openId
        };

        $scope.go2Validate = function (addNote) {//点击认证 >
            var timestamp = new Date().getTime();
            if(timestamp >= 1594396800000 && timestamp <= 1594526400000){
                layer.open({
                    skin: "msg",
                    content: "因系统升级，实名认证暂停服务，请于7月12日中午12点后重试",
                    time:2
                });
                return;
            }
            $scope.cancel('modal_real_name');
            addNote&&personStorage.setOperate({
                hitTime:Date.now(),
                businessHitType:personOperateType.real_name,
                msisdn:null 
            })
            publicFun.copySessionToLocalStorage()
            httpService
                .getData('/service/wx/person/api/getRealNameAuthURL',{userId:personStorage.getUserId()}, {type: 'POST'})
                .then(function (resp) {
                    if (resp && resp.code==0) {
                        $scope.realName = resp.data;
                        window.location.href = $scope.realName;
                    }else{
                        publicFun.errCodeMsg(resp.code);
                    }
                });
        }

        //显示模态框
        $scope.showModel = function (type) {
            if(['modal_quit','modal_cancelAccount','modal_real_name'].indexOf(type)==-1){
                return
            }
            var businessHitType=type=='modal_quit'?personOperateType.log_out:type=='modal_real_name'?personOperateType.real_name:personOperateType.log_off
            personStorage.setOperate({
                hitTime:Date.now(),
                businessHitType:businessHitType,
                msisdn:null 
            })
            $scope[type] = true;
        }
        $scope.cancel = function (type) { //取消按钮
            if(['modal_quit','modal_cancelAccount','modal_real_name'].indexOf(type)==-1){
                return
            }
            $scope[type] = false;
        }

        $scope.primaryQuit = function () {//点击确认退出
            $scope.cancel('modal_quit');
            httpService
                .getData('/service/wx/person/api/logout', {type: 'POST'})
                .then(function (resp) {
                    if (resp && resp.code=='0') {
                        personStorage.removeSessionItem()
                        window.location.href = $scope.homepath + '/service/wx/person/login?' + 'openId=' + $scope.openId + '&msgId=2';
                    } else {
                        publicFun.layerMsg("退出登录失败,请重试")
                    }
                });

        }
        /*手机号、姓名脱敏*/
        $scope.phone = publicFun.desensitizePhone($scope.phone);
        $scope.name = publicFun.desensitizeName($scope.name);

  

    
        //点击确认注销账号
        $scope.primaryOff = function () {
            $scope.cancel('modal_cancelAccount')
            httpService
                .getData('/service/wx/person/api/deleteAccount', {type: 'POST'})
                .then(function (resp) {
                    if (resp && resp.code=='0') {
                        personStorage.removeSessionItem()
                        window.location.href = $scope.homepath + '/service/wx/person/login?' + 'openId=' + $scope.openId + '&msgId=5';
                    } else {
                        publicFun.layerMsg("注销失败,请重试")
                    }
                });
        }
    }])