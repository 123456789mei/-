/*echarts 自定义指令*/
personui.directive("echartsLocate", function () {
        return {
            scope: {
                echartsObj: "=echartsObj",
            },
            restrict: 'EA',
            replace: true,
            transclude: true,
            controller: ['$scope', '$location', '$timeout', function ($scope, $location, $timeout) {
                //处理用量百分比
                var objPercent = {}, usedArr = [];
                objPercent.value = $scope.echartsObj.usedPercentNum;
                usedArr.push(objPercent);
                //判断红蓝色调
                $scope.chooesColor = function () {
                    if ($scope.echartsObj) {
                        var amountType = $scope.echartsObj.dataAmountType;
                        var color = {};

                        switch (amountType) {//(01短信\02流量\03语音)
                            case "01":
                                color.bgcolor = "#ffc53d";
                                color.borderColor = "#ffedc4";
                                break;
                            case "02":
                                color.bgcolor = "#00b1ff";
                                color.borderColor = "#bae0ff";
                                break;
                            case "03":
                                color.bgcolor = "#48d28c";
                                color.borderColor = "#c8f1dc";
                                break;
                        }
                        return color;
                    }
                };
				$scope.toFixed=function(num,s){

                    var times = Math.pow(10, s);
                    var des = num * times + 0.5;
                    des = parseInt(des, 10) / times;
                    return des + '';
                };

                $scope.createEcharts = function (ele) {
                    //判断颜色
                    var color = $scope.chooesColor();
                    $scope.containers = ele;
                    $scope.options = [{
                        series: [{
                            itemStyle: {
                                shadowBlur: 1,
                                shadowColor: '#ffffff'
                            },
                            type: 'liquidFill',
                            radius: '95%',
                            amplitude: '5%',
                            backgroundStyle: {
                                shadowBlur: 5,
                                shadowColor: 'white',
                                color: '#ffffff'
                            },
                            color: [color.bgcolor],
                            outline: {
                                show: true,
                                borderDistance: 8,
                                itemStyle: {
                                    shadowBlur: 0,
                                    color: 'white',
                                    borderWidth: 2,
                                    borderColor: color.borderColor
                                }
                            },
                            data: usedArr,
                            label: {
                                color: color.bgcolor,
                                formatter: function (params) {
                                    return $scope.toFixed((params.value) * 100,0) + '%' + '\n' + '已使用'
                                },
                                fontSize: 15
                            }
                        }]
                    }];
                    $scope.charts = [];
                    for (var i = 0; i < $scope.options.length; ++i) {
                        $scope.chart = echarts.init($scope.containers[i]);
                        if (i > 0) {
                            $scope.options[i].series[0].silent = true;
                        }
                        $scope.chart.setOption($scope.options[i]);
                        $scope.charts.push($scope.chart);
                    }
                    /*    window.onresize = function () {
                              for (var i = 0; i < $scope.charts.length; ++i) {
                                  $scope.charts[i].resize();
                              }
                          };*/
                };
            }],
            link: function ($scope, ele, attrs) {
                $scope.createEcharts(ele);
            },
            template: '<div style="width:100%;height: 130px;padding-left: 5%;"  id="card_cardInfoPie"></div>'
        }
    });