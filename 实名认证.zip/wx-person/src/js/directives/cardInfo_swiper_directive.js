/*swiper 自定义指令*/
personui.directive("swiperLocate", ['personOperateType', 'personStorage', function(personOperateType, personStorage) {
    return {
        scope: {
            swperData: "=swperData",
            swperWhere: '@',
            swperCount: '@',
            swperIndex: '@'
        },
        restrict: 'EA',
        replace: true,
        controller: ['$scope', '$location', '$timeout', 'Router', 'httpService', 'publicFun',
            function($scope, $location, $timeout, router, httpService, publicFun) {
                // 对于“预销户”和“销户”的卡不提供充值链接，PB卡也做同样处理，保持逻辑一致。
                // 00-正常；01-单向停机；02-停机；03-预销号；04-销号；05-过户；06-休眠；07-待激活；99-号码不存在
                // CT状态：1：待激活；2：已激活；4：停机；6：可测试；7：库存；8：预销户
                //处理别名
                $scope.remarkHandle = '';
                if ($scope.swperData.remark) {
                    $scope.remarkHandle = $scope.swperData.remark;
                } else {
                    $scope.remarkHandle = $scope.swperData.msisdn;
                }
                $scope.testStatus = function(str) {
                        if (str == '10') {
                            return true;
                        } else {
                            return false;
                        }
                    }
                    //充值调用
                $scope.toCheckIndividualAccount = function(chargeURL, cardBelong, msisdn, iccid, title, accountId, accountName,beId) {
                     event.stopPropagation();
                     personStorage.setOperate({
                         hitTime: Date.now(),
                         businessHitType: personOperateType.recharge,
                         msisdn: msisdn
                     });
                     //if ('00' === cardBelong) {
                     //    httpService.getData('/service/wx/person/api/saveChargeLogOfPB', { 'msisdn': msisdn }, {
                     //        type: 'POST',
                     //        doError: 'false'
                     //    }).then(function(resp) {});
                     //    window.location.href = chargeURL;
                     //} else if ('01' === cardBelong) {
                         //  跳转充值页面
                         $scope.rechargeObj = {};
                         $scope.rechargeObj.msisdn = msisdn;
                         $scope.rechargeObj.cardBelong = cardBelong;
                         $scope.rechargeObj.iccid = iccid;
                         $scope.rechargeObj.title = title;
                         $scope.rechargeObj.accountId = accountId;
                         $scope.rechargeObj.accountName = accountName;
                         $scope.rechargeObj.beId = beId;
                     router.go('/recharge', $scope.rechargeObj);
                    // }
                };




                /*修改别名*/
                $scope.toUpdateName = function(msisdn) {
                    event.stopPropagation();
                    $scope.updateObj = {};
                    $scope.updateObj.msisdn = msisdn;
                    $scope.updateObj.remark = $scope.remarkHandle;
                    personStorage.setOperate({
                            hitTime: Date.now(),
                            businessHitType: personOperateType.update_alias,
                            msisdn: msisdn
                        })
                        //事件传播
                    $scope.$emit("ValidateControlle_showModelRemark", $scope.updateObj);
                };
                /*物联卡详情*/
                $scope.toCardInfo = function(msisdn, custId, beId, cardBelong, iccid, balance, bindStatus) {
                    event.stopPropagation();
                    if ("bindPage" === $scope.swperWhere) {
                        return false;
                    }
                    var alias = "";
                    if ($scope.swperData.reamrk) {
                        alias = $scope.swperData.reamrk;
                    } else {
                        alias = msisdn;
                    }
                    var cardObj = {};
                    cardObj.msisdn = msisdn;
                    cardObj.custId = custId;
                    cardObj.beId = beId;
                    cardObj.cardBelong = cardBelong;
                    cardObj.iccid = iccid;
                    cardObj.balance = balance;
                    cardObj.title = $scope.remarkHandle;
                    cardObj.bindStatus = bindStatus;
                    router.go("/cardInfo", cardObj);
                };
                /*解绑*/
                $scope.toUnBindCard = function(msisdn, remark, iccid, count) {
                    event.stopPropagation();
                    var bindCardObj = {};
                    bindCardObj.msisdn = msisdn;
                    bindCardObj.remark = remark;
                    bindCardObj.iccid = iccid;
                    bindCardObj.count = count;
                    $scope.unBindMsisdn = {};
                    $scope.unBindMsisdn.msisdn = msisdn;
                    personStorage.setOperate({
                            hitTime: Date.now(),
                            businessHitType: personOperateType.unbind_msisdn,
                            msisdn: msisdn
                        })
                        //事件传播
                    $scope.$emit("ValidateControlle_showModelUnbind", $scope.unBindMsisdn);
                };
                /*激活*/
                $scope.activateCard = function(msisdn, custId, beId) {
                    event.stopPropagation();
                    $scope.msisdnObj = {};
                    $scope.msisdnObj.msisdn = msisdn;
                    $scope.msisdnObj.custId = custId;
                    $scope.msisdnObj.beId = beId;
                    //事件传播
                    $scope.$emit("ValidateControlle_showModelActive", $scope.msisdnObj);
                };
                $scope.stopevent = function (){
                    event.stopPropagation();
                };
                //单卡查询
                $scope.searchCard = function(msisdn, status,ind) {
                    event.stopPropagation();
                    $scope.searchCardObj = {};
                    $scope.searchCardObj.msisdn = msisdn;
                    $scope.searchCardObj.status = status;
                    $scope.searchCardObj.ind = ind;
                    //事件传播
                    $scope.$emit("ValidateControlle_showModelSearch", $scope.searchCardObj);
                };
                $scope.$on("$destroy", function() {
                    if ($scope.swiperList) {
                        $scope.swiperList.destroy(true, true);
                    }
                });
                //swiper 集合
                $scope.createSwiper = function(el) {
                    $scope.swiperList = new Swiper(el, {
                        spaceBetween: 0,
                        slidesPerView: 'auto'
                    });
                };
            }
        ],
        link: function($scope, ele, attrs) {
            setTimeout(function() {
                $scope.createSwiper(ele[0]);
            }, 100);
        },
        //配置项
        templateUrl:'/service/person/cardItem.html'
    };
}]);