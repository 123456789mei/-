personui
    .filter('cardStatusCn', function () {
        return function (status) {
            var billImgStatusCh = '';
            switch (status) {
                case "00":
                    billImgStatusCh = "正常";
                    break;
                case "01":
                    billImgStatusCh = "单向停机";
                    break;
                case "02":
                    billImgStatusCh = "停机";
                    break;
                case "03":
                    billImgStatusCh = "预销号";
                    break;
                case "04":
                    billImgStatusCh = "销号";
                    break;
                case "05":
                    billImgStatusCh = "过户";
                    break;
                case "06":
                    billImgStatusCh = "休眠";
                    break;
                case "07":
                    billImgStatusCh = "待激活";
                    break;
                case "99":
                    billImgStatusCh = "号不存在";
                    break;
                case "1":
                    billImgStatusCh = "待激活";
                    break;
                case "2":
                    billImgStatusCh = "已激活";
                    break;
                case "4":
                    billImgStatusCh = "停机";
                    break;
                case "6":
                    billImgStatusCh = "可测试";
                    break;
                case "7":
                    billImgStatusCh = "库存";
                    break;
                case "8":
                    billImgStatusCh = "预销号";
                    break;
            }
            return billImgStatusCh;
        }
    });


   