var personui = angular.module('Personui', [
    'ngRoute',
    'mobile-angular-ui',
    'ngAnimate'
]).config(function($routeProvider) {
    $routeProvider
        .when('/', {templateUrl:'itemTypeChooese.html',  reloadOnSearch: false})/*应用首页*/
        .when('/certificationIndex',{templateUrl:'certificationIndex.html', reloadOnSearch:false})/*认证*/
        .when('/bindingIotCard',{templateUrl:'bindingIotCard.html',reloadOnSearch:false})/*绑定物联卡*/
        .when("/personInfo",{templateUrl:'personInfo.html'})/*个人中心-已废弃*/
        .when("/personCenter",{templateUrl:'personCenter.html'})/*个人中心的*/
        .when("/updatePhoneNum",{templateUrl:'updatePhoneNum.html'})/*已废弃使用*/
        .when("/cardInfo",{templateUrl:'cardInfo.html'})/*物联卡详情*/
        .when("/recharge",{templateUrl:'recharge.html'})/*物联卡充值*/
        .when("/cardRegister",{templateUrl:'cardRegister.html'})/*卡实名登记*/
        .when("/uploadIdCard",{templateUrl:'uploadIdCard.html'})/*上传身份证*/
        .when("/uploadResult",{templateUrl:'uploadResult.html'})/*上传结果通知*/
        .when("/itemTypeChooese",{templateUrl:'itemTypeChooese.html'})/*实名登记与卡管理页面*/
        .when("/helpCenter",{templateUrl:'helpCenter.html'})/*帮助中心*/
        .when('/error',{templateUrl:'error.html'})/*错误页面*/
        .when('/authResult',{templateUrl:'authResult.html'})/*认证结果页面*/
        .when('/development',{templateUrl:'development.html'})/*首页物联卡充值入口*/
        .when('/opinion',{templateUrl:'opinion.html'})//意见反馈
        .when('/checkIdCard',{templateUrl:'checkIdCard.html'})
        .when('/cardRegisterIndex',{templateUrl:'cardRegisterIndex.html', reloadOnSearch:false})/*卡实名查询*/
});

personui.run(['$rootScope', '$location', "weChatSdk",'Router', function($rootScope, $location, weChatSdk,Router) {
    //定义路由数组
    $rootScope.pathHistory = [];
    $rootScope.pathHistoryPre = [];  //上一次数据
    $rootScope.enterPath = null;
    $rootScope.leavePath = null;
    $rootScope.topPage_Z_index = null;
    weChatSdk.init();
    $location.$$path!='/authResult'&&$location.path("/");
    $rootScope.$on('$routeChangeStart',function(evt,next,current){
        var path = Router.path_prefix + next.$$route.originalPath;
        if($rootScope.pathHistory.indexOf(path) == -1){
            //新路由处理,压入path
            Router.pushPath(path);
        }else{
            //历史路由处理,移除path
            var index = $rootScope.pathHistory.indexOf(path);
            var num = $rootScope.pathHistory.length - (index + 1);
            Router.popPath(num);
        }
    });
}]);

personui.animation('.page',function(){
    return{
        enter :function(element,done){
            var $rootScope = angular.element(document.body).scope().$root;
            //判断是否是栈顶
            var topPath = $rootScope.pathHistoryPre.length?$rootScope.pathHistoryPre[$rootScope.pathHistoryPre.length -1]:"";
            //初始化页面最小高度
            var minHeight = (window.innerHeight - 54) + "px";
            element.children(0).css("min-height",minHeight);
            element.children(0).css("background-color","#f5f5f5");
            element.children(0).css("overflow-y","scroll");
            element.children(0).css("height","100%");
            if($rootScope.pathHistoryPre.indexOf($rootScope.enterPath) == -1){
                //栈顶右进
                jQuery(element).css("z-index", $rootScope.topPage_Z_index);
                jQuery(element).addClass("slideInRight");
                jQuery(element).on("animationend",function(){
                    jQuery(".slideInRight").removeClass("slideInRight");
                    done();
                });
            }else{
                setTimeout(function(){
                    done();
                },500);
            }
        },
        leave :function(element,done){
            var $rootScope = angular.element(document.body).scope().$root;
            //判断是否是栈顶
            if($rootScope.pathHistory.indexOf($rootScope.leavePath) == -1){
                //栈顶右出
                jQuery(element).addClass("slideOutRight");
                jQuery(element).on("animationend",function(){
                    var ment = jQuery(".slideOutRight");
                    ment.removeClass("slideOutRight");
                    done();
                });
            }else{
                setTimeout(function(){
                    done();
                },500);
            }
        }
    }
});

if(window.PROJECTENV == "prod"){
    personui.value("homePath","https://ec.iot.10086.cn");    // prod
}else {
    personui.value("homePath","http://iotpersonalbiz.top");    // test
}

